# v4 change log

Date: 2026-09-04. Design/specification changes only; no application implementation or remote writes.

## Scope

56 specs, 325 tickets, 975 required product checks, original 157 capabilities, 12 milestones and 24 admission gates. Added six specs (050–055), 35 tickets (0291–0325), 105 required checks, 28 explicitly traced v4 requirements and ADRs 062–065. Preserved all 290 previous IDs and every original task identity; no retired capability.

## Architectural changes

One SPEC-007 executor for every human/agent/app surface. Declarative apps arrive in S2, secure sharing in S3, consequential forms in S4 and executable host in S6. Rich Studio remains S8 but reuses early components. Link/session/current-rights, private asset bootstrap, host-owned consent, export/stream closure, per-subject runtime state and qualified Rivet staging/publication now have explicit contracts and task oracles.

Rivet Dynamic Apps Core is a candidate specialized adapter, not the data authority or a dependency for declarative apps. Actual vendor behavior/containment/browser profiles must be qualified. Private data in executable browser code needs an explicit approved disclosure profile; an iframe or CSP is not claimed to guarantee universal data-loss prevention.

## Execution migration

228 existing ticket records changed (including added normative read sets). See [machine-readable diff](verification/v3-to-v4.json). Import any external v3 execution state only after independent review of changed contracts and impacted dependencies; never automatically preserve accepted status. The supplied state has no accepted tickets. The full v3 input ZIP and v2 baseline remain byte-for-byte preserved.

## Validation limits

`tools/verify.py` validates this package and schema/control tests, not Zoen runtime behavior. All 975 target product checks remain unrun. No real PostgreSQL/Cedar/browser/Rivet/provider/cloud or production-capacity proof is supplied by this delivery.
