# Specification index

Normative execution contracts; no module is marked implemented. Numbers are stable identifiers, not a build order.

| Spec | Milestone | Contract | Tickets |
|---|---|---|---|
| [SPEC-000](spec-000.md) | S0 | Execution baseline, dependency admission and fail-closed CI | 6 |
| [SPEC-001](spec-001.md) | S0 | Kernel values, contract algebra and canonical encoding | 6 |
| [SPEC-002](spec-002.md) | S0 | Door, World genesis and fresh purpose-bound entry | 6 |
| [SPEC-003](spec-003.md) | S0 | Atomic authority, domain guards and durable handoff | 6 |
| [SPEC-004](spec-004.md) | S0 | Retained evidence and file-based source admission | 6 |
| [SPEC-005](spec-005.md) | S0 | Comparable claims, interpretations and scoped correction | 6 |
| [SPEC-006](spec-006.md) | S1 | Reversible domain identity and temporal explanations | 5 |
| [SPEC-007](spec-007.md) | S0 | WorldFrames and the first semantic surface | 5 |
| [SPEC-008](spec-008.md) | S0 | Baseline observability, local operations and safe migration preparation | 5 |
| [SPEC-009](spec-009.md) | S1 | Eve fenced turn machine and visible-message recovery | 6 |
| [SPEC-010](spec-010.md) | S1 | Context, grounded composition, model routing and voice | 6 |
| [SPEC-011](spec-011.md) | S1 | WhatsApp durable ingress, consent and secure continuation | 6 |
| [SPEC-012](spec-012.md) | S1 | Progressive onboarding and accessible conversation inspection | 5 |
| [SPEC-013](spec-013.md) | S2 | Bounded ontology grammar and deterministic release compiler | 7 |
| [SPEC-014](spec-014.md) | S2 | Runtime change governance, evaluation, preparation and activation | 7 |
| [SPEC-015](spec-015.md) | S2 | Source inventory, OAuth bindings and declarative integration plans | 7 |
| [SPEC-016](spec-016.md) | S2 | Foundation, household and confectionery domain packs | 5 |
| [SPEC-017](spec-017.md) | S2 | Clarification prioritization and scoped stewardship | 5 |
| [SPEC-018](spec-018.md) | S3 | Fine-grained rights, delegation and audience-safe disclosure | 6 |
| [SPEC-019](spec-019.md) | S3 | Retention, erasure, legal holds and restore suppression | 6 |
| [SPEC-020](spec-020.md) | S3 | Semantic Watches, Notices and quiet attention | 6 |
| [SPEC-021](spec-021.md) | S3 | Dental operations pack with clinical separation | 5 |
| [SPEC-022](spec-022.md) | S4 | Released Actions, approvals and accountable local decisions | 6 |
| [SPEC-023](spec-023.md) | S4 | Effect execution, provider evidence and honest settlement | 6 |
| [SPEC-024](spec-024.md) | S4 | Budget conservation, bounded Mandates and observed outcomes | 6 |
| [SPEC-025](spec-025.md) | S5 | Authorized retrieval and permitted specialized agents | 6 |
| [SPEC-026](spec-026.md) | S5 | REST, CLI, TypeScript SDK and MCP from one manifest | 6 |
| [SPEC-027](spec-027.md) | S5 | Living World charts, tables, timelines and safe Focus | 5 |
| [SPEC-028](spec-028.md) | S5 | Telegram, email and cross-channel continuity | 5 |
| [SPEC-029](spec-029.md) | S6 | Signed capability artifacts and controlled installation | 5 |
| [SPEC-030](spec-030.md) | S6 | Isolated runners, credential brokers and programmable analysis | 6 |
| [SPEC-031](spec-031.md) | S7 | Dense Parquet/Iceberg datasets and atomic publication | 6 |
| [SPEC-032](spec-032.md) | S7 | Governed batch, incremental, CDC and stream data flows | 6 |
| [SPEC-033](spec-033.md) | S7 | Entitled live feeds, gap-aware subscriptions and action capture | 5 |
| [SPEC-034](spec-034.md) | S7 | Virtual sources and distributed/GPU compute adapters | 5 |
| [SPEC-035](spec-035.md) | S8 | Progressive Workshop: early declarative apps, isolated views and full Studio | 5 |
| [SPEC-036](spec-036.md) | S8 | Read-only scenarios, notebooks and evaluated model artifacts | 6 |
| [SPEC-037](spec-037.md) | S8 | Pack registry, overlays, upgrades and marketplace governance | 6 |
| [SPEC-038](spec-038.md) | S9 | Enterprise SSO, SCIM and workload identity lifecycle | 6 |
| [SPEC-039](spec-039.md) | S9 | Dedicated regional cells, private networking and recovery | 6 |
| [SPEC-040](spec-040.md) | S9 | Fairness, economics, capacity admission and audited support | 6 |
| [SPEC-041](spec-041.md) | S9 | Enterprise source recipes and domain-wide reconciliation | 8 |
| [SPEC-042](spec-042.md) | S10 | Fenced cell migration and single-writer authority epochs | 5 |
| [SPEC-043](spec-043.md) | S10 | Federated Frames, independent approvals and partial global outcomes | 5 |
| [SPEC-044](spec-044.md) | S10 | Offline child scopes, self-hosted equivalence and fleet policy | 6 |
| [SPEC-045](spec-045.md) | S11 | Finance security master, corporate actions and licensed information | 6 |
| [SPEC-046](spec-046.md) | S11 | Market data, portfolio analytics and pre-trade risk | 6 |
| [SPEC-047](spec-047.md) | S11 | Orders, executions, allocations, custody and supervision | 8 |
| [SPEC-048](spec-048.md) | S11 | Full-ambition integration, adversarial assurance and final acceptance | 6 |
| [SPEC-049](spec-049.md) | S1 | Shared hosted pilot and progressive product activation | 4 |
| [SPEC-050](spec-050.md) | S0 | One semantic executor and transport-only client contract | 5 |
| [SPEC-051](spec-051.md) | S1 | Authority-free continuation links and scoped application sessions | 6 |
| [SPEC-052](spec-052.md) | S2 | Early declarative mini apps as released data | 6 |
| [SPEC-053](spec-053.md) | S6 | Isolated app host and transport-only bridge | 6 |
| [SPEC-054](spec-054.md) | S6 | Rivet Dynamic Apps Core qualification and immutable runtime adapter | 6 |
| [SPEC-055](spec-055.md) | S3 | Cross-surface equivalence, adversarial app journeys and capacity | 6 |
