# SPEC-042 — Fenced cell migration and single-writer authority epochs

**Milestone:** S10 · **Accountable function:** Platform Kernel · **Implementation root:** `packages/ontology/src/cells` · **Status:** specified, not implemented.

## Decision and intended behavior

A directory change alone is not fencing. Promotion requires durable proof that old authority can no longer accept writes/new effect attempts, or explicit independently verified infrastructure fencing. A partition sacrifices availability rather than creating two live writers.

## Owned state and storage contract

control.world_directory(world_id,realm PK,cell_id,epoch,region,state,version); control.promotions(promotion_id PK,world_id,source_epoch,target_epoch,source_fence_receipt,destination_proof,state); ontology.local_authority(world_id PK,installed_epoch,write_enabled,fence_receipt,boot_admission); jobs.migration_runs(run_id PK,world_id,source_cut,target_cut,validation_ref,state). Directory is a single-writer durable control store, not a grant database.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
PrepareMove(world,destination) -> StagedReplica; FenceSource(world,epoch) -> FenceReceipt; PromoteWorld(fence,destinationProof,expectedDirectory) -> NewEpoch; AdmitBoot(world,cell,epoch) -> WriteAdmission | ReadOnly.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Copy into non-authoritative destination, replay complete commits, verify data/rights/pins/open work. Source exclusive head fence stops new writes/permits and records final cut. Require source fence acknowledgement; when unavailable, block promotion unless approved infrastructure fencing proves the source cannot act. CAS coordinator epoch, install destination admission, then route. Every boot defaults fenced until current coordinator admission; an old restored backup cannot start as writer. Stable effect IDs reconcile escaped requests.

## Dependencies and sequencing

Referenced specs: [039](spec-039.md), [040](spec-040.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0245](../tickets/zn-0245.md) | Implement content-free directory and boot admission | S10 | component | ZN-0229, ZN-0235 |
| [ZN-0246](../tickets/zn-0246.md) | Stage destination copy and committed catch-up | S10 | component | ZN-0245 |
| [ZN-0247](../tickets/zn-0247.md) | Fence source and collect durable stop evidence | S10 | component | ZN-0246 |
| [ZN-0248](../tickets/zn-0248.md) | Promote epoch atomically and reject stale work | S10 | component | ZN-0247 |
| [ZN-0249](../tickets/zn-0249.md) | Prove partition, rollback and escaped-effect scenarios | S10 | chaos | ZN-0248 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[deployment-cells-and-federation.md](../baseline/v2/technical-blueprint/reference/deployment-cells-and-federation.md) · [authority-concurrency-and-cuts.md](../baseline/v2/technical-blueprint/reference/authority-concurrency-and-cuts.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
