# SPEC-002 — Door, World genesis and fresh purpose-bound entry

**Milestone:** S0 · **Accountable function:** Identity and Kernel · **Implementation root:** `packages/door/src` · **Status:** specified, not implemented.

## Decision and intended behavior

Door proves presence only. Ontology creates Worlds and membership through image-pinned governance operations. A phone number, group participation or email From header is never World authority.

## Owned state and storage contract

door.subject_map(subject_id PK, principal_id UNIQUE); ontology.worlds(world_id PK, realm, cell_id, epoch, release_digest, generation_id, security_revision, status); ontology.memberships(world_id,principal_id PK, role, status, revision); ontology.grants(grant_hash PK, world_id, principal_id, purpose, audience_hash, assurance, expires_at, security_revision, scope_json); ontology.invitations(invitation_hash PK, world_id, intended_subject, expires_at, consumed_by). Owner runtime role differs from migration owner.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
DoorPort.verify(assertion) -> PresenceProof; CreatePersonalWorld(operationId, seedDigest) -> GenesisReceipt; OpenWorld(worldId,purpose) -> GrantRef | Denied; AcceptInvitation(invitationToken,operationId) -> MembershipReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

No implicit membership on account creation. Validate planted foundation digest at genesis; atomically create head, owner membership and receipt. Entry reads current membership and security revision. Grants are bounded server records, not cached powers embedded in Focus. Identity adapters use official supported flows; the app never implements password cryptography.

## Dependencies and sequencing

Referenced specs: [001](spec-001.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Genesis implementation depends on SPEC-003, while SPEC-003 depends only on the presence adapter task of SPEC-002. This task-level split is normative and breaks the bootstrap cycle. World genesis, grants and invitations live in Ontology; Door supplies presence only.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0013](../tickets/zn-0013.md) | Integrate Better Auth behind a presence-only port | S0 | component | ZN-0012 |
| [ZN-0014](../tickets/zn-0014.md) | Implement idempotent private World genesis | S0 | component | ZN-0013, ZN-0024 |
| [ZN-0015](../tickets/zn-0015.md) | Issue fresh purpose-bound grants and request permits | S0 | component | ZN-0014 |
| [ZN-0016](../tickets/zn-0016.md) | Implement single-use invitation acceptance | S0 | component | ZN-0015 |
| [ZN-0017](../tickets/zn-0017.md) | Implement session termination and emergency deny | S0 | component | ZN-0016 |
| [ZN-0018](../tickets/zn-0018.md) | Prove genesis and entry isolation on real roles | S0 | component | ZN-0017 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md) · [repository-and-modules.md](../baseline/v2/technical-blueprint/reference/repository-and-modules.md) · [release-engine-and-compiler.md](../baseline/v2/technical-blueprint/reference/release-engine-and-compiler.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
