# SPEC-014 — Runtime change governance, evaluation, preparation and activation

**Milestone:** S2 · **Accountable function:** Kernel · **Implementation root:** `packages/ontology/src/releases` · **Status:** specified, not implemented.

## Decision and intended behavior

Four lanes: instance mutation, released declarative meaning, isolated executable artifact and privileged kernel change. The current policy governs a change; a candidate policy cannot approve itself. Activation is proof plus exact prepared data plus current approval.

## Owned state and storage contract

ontology.changes(change_id PK,world_id,base_release,candidate_release,risk,state,author,version); ontology.release_proofs(proof_id PK,release_digest,kernel_image,evaluation_world,cut_digest,report_ref,missing_attestations); ontology.preparations(preparation_id PK,world_id,expected_head,target_release,target_generation,through_cut,open_work_disposition,state); ontology.release_approvals(change_id,principal_id,case_digest PK,policy_basis); ontology.activations(receipt_id PK,world_id,old_head,new_head,proof_ref,preparation_ref). Evaluation namespaces and credentials are separate.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProposeDefinitionChange(base,patch,operationId) -> Change; EvaluateChange(change) -> ReleaseProof; PrepareActivation(change,world) -> PreparedActivation; ApproveChange(change,digest) -> Approval; ActivateRelease(proof,preparation,approval,operationId) -> ActivationReceipt | PreparationStale.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Each step binds immutable digests. Evaluation uses separate realm IDs, storage, source/effect leases and sink channels. Preparation builds a non-authoritative generation and catches up from committed envelopes only. Exclusive head lock rechecks current head, cuts, approvals and emergency denies. If convergence fails, use a bounded visible write fence. Rollback is a new prepared forward transition, never blind head reversal.

V4 refinement: MiniAppDefinition and AppPublicationBinding participate in this same release process. Runtime preparation and evaluation do not activate a public app. Publication, sharing and execution authority are distinct. Old-policy approval, prepared basis, manifest/artefact closure and emergency recall are rechecked at activation.

## Dependencies and sequencing

Referenced specs: [013](spec-013.md), [008](spec-008.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0082](../tickets/zn-0082.md) | Implement change lanes and current-policy classification | S2 | component | ZN-0051, ZN-0081 |
| [ZN-0083](../tickets/zn-0083.md) | Provision an isolated EvaluationWorld | S2 | component | ZN-0082 |
| [ZN-0084](../tickets/zn-0084.md) | Bind release proof to exact image, cut and exercised checks | S2 | component | ZN-0083 |
| [ZN-0085](../tickets/zn-0085.md) | Prepare data generations and open-work dispositions | S2 | component | ZN-0084 |
| [ZN-0086](../tickets/zn-0086.md) | Activate with an exclusive head transition | S2 | component | ZN-0085 |
| [ZN-0087](../tickets/zn-0087.md) | Implement concurrent edit rebase and forward repair | S2 | component | ZN-0086 |
| [ZN-0088](../tickets/zn-0088.md) | Prove runtime change without redeploy | S2 | journey | ZN-0087 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md) · [release-engine-and-compiler.md](../baseline/v2/technical-blueprint/reference/release-engine-and-compiler.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
