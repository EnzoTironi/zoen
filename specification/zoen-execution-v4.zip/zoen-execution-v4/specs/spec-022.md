# SPEC-022 — Released Actions, approvals and accountable local decisions

**Milestone:** S4 · **Accountable function:** Kernel · **Implementation root:** `packages/ontology/src/actions` · **Status:** specified, not implemented.

## Decision and intended behavior

Every consequential operation uses a released ActionDefinition and an immutable consequence-sensitive Case revision. Approval is not commitment; commitment is not external success. Existing image-pinned bootstrap/correction operations are not a generic bypass for arbitrary new actions.

## Owned state and storage contract

ontology.action_cases(case_id PK,world_id,revision,action_id,release_digest,basis_ref,intent_json,case_digest,consequences_digest,guards_json,expires_at,state); ontology.case_approvals(case_id,revision,principal_id PK,answer,case_digest,assurance,policy_basis,recorded_at); ontology.case_receipts(case_id,revision PK,receipt_id,commit_id). Normative states add cancelled and blocked to v2 representative type examples.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProposeAction(action,input,basis) -> ActionCase; AnswerCase(caseId,caseDigest,answer,operationId) -> CaseProgress | Receipt | Stale; CancelCase(caseId,operationId) -> State; CommitCase(caseId,digest) -> DecisionReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Plan reads, preconditions, local writes, reservations and effect templates using the bounded IR. Freeze intent, recipient, amount, consequences and dependencies into Case digest. Every answer and final commit rechecks current authority/assurance. Quorum members approve the same revision/digest; changed input invalidates affected approvals. Final commit uses the shared atomic authority primitive.

V4 refinement: Mini-app form submissions invoke the same ActionCase/approval/commit implementation as chat and SDK. Consequential confirmation is rendered by the trusted host from a server-authorized Case, never trusted from app HTML or postMessage approval=true.

## Dependencies and sequencing

Referenced specs: [014](spec-014.md), [018](spec-018.md), [020](spec-020.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0129](../tickets/zn-0129.md) | Compile Action plans and exact consequence digests | S4 | component | ZN-0088, ZN-0111, ZN-0123 |
| [ZN-0130](../tickets/zn-0130.md) | Persist Case revisions and lifecycle transitions | S4 | component | ZN-0129 |
| [ZN-0131](../tickets/zn-0131.md) | Implement scoped and quorum approvals | S4 | component | ZN-0130 |
| [ZN-0132](../tickets/zn-0132.md) | Commit guarded local decisions and effects atomically | S4 | component | ZN-0131 |
| [ZN-0133](../tickets/zn-0133.md) | Expose safe approvals through chat, UI and API | S4 | journey | ZN-0132 |
| [ZN-0134](../tickets/zn-0134.md) | Prove stale consent and concurrent approvals | S4 | chaos | ZN-0133 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[actions-effects-and-settlement.md](../baseline/v2/technical-blueprint/reference/actions-effects-and-settlement.md) · [authority-concurrency-and-cuts.md](../baseline/v2/technical-blueprint/reference/authority-concurrency-and-cuts.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
