# SPEC-009 — Eve fenced turn machine and visible-message recovery

**Milestone:** S1 · **Accountable function:** Experience · **Implementation root:** `packages/eve/src/turns` · **Status:** specified, not implemented.

## Decision and intended behavior

One EveStore owns interaction history and resumption. A durable model call is not exactly-once inference. Only one fenced attempt may settle a visible turn; tools always cross the semantic boundary.

## Owned state and storage contract

eve.conversations(conversation_id PK,relationship_id,world_ref_nullable,audience_ref,version); eve.turns(turn_id PK,conversation_id,ingress_id UNIQUE,state,version,lease_owner,fence,lease_until,release_digest); eve.attempts(attempt_id PK,turn_id,kind,intent_digest,output_ref,status,usage_json); eve.messages(message_id PK,turn_id,revision,state,visible_text,evidence_refs,UNIQUE(turn_id,revision)); eve.focus(focus_id PK,relationship_id,world_ref,subject_ref,frame_ref,lens,temporal_intent). No authority credentials in Eve tables.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AcceptTurn(ingressRef) -> TurnRef; AdvanceTurn(turnId,expectedVersion,fence,event) -> TurnState | LostLease; SettleVisibleMessage(turnId,attemptId,content) -> MessageRef; CancelTurn(turnId) -> CancellationState.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Persist model intent before call, output before tool proposal and final visible message before delivery. State transitions are CAS protected. Stream drafts are provisional. A failed stream is explicitly interrupted; do not splice unrelated retry tokens into a supposedly exact continuation. Same ingress is accepted once, and same tool semantic operation ID survives recovery.

V4 refinement: Eve is a semantic client, never a prerequisite for structured application calls. No LLM is involved in a structured table read unless a released operation explicitly requests a model.

## Dependencies and sequencing

Referenced specs: [006](spec-006.md), [007](spec-007.md), [008](spec-008.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0052](../tickets/zn-0052.md) | Create the single interaction journal and turn lifecycle | S1 | component | ZN-0041, ZN-0046, ZN-0051 |
| [ZN-0053](../tickets/zn-0053.md) | Fence model attempts and persist intent before inference | S1 | component | ZN-0052 |
| [ZN-0054](../tickets/zn-0054.md) | Dispatch tools through idempotent semantic clients | S1 | component | ZN-0053 |
| [ZN-0055](../tickets/zn-0055.md) | Implement provisional streaming and settled message replay | S1 | component | ZN-0054 |
| [ZN-0056](../tickets/zn-0056.md) | Implement cancellation, supersession and release-change stops | S1 | component | ZN-0055 |
| [ZN-0057](../tickets/zn-0057.md) | Prove all turn crash boundaries with real processes | S1 | chaos | ZN-0056 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[release-policy-eve.md](../baseline/v2/technical-blueprint/reference/release-policy-eve.md) · [messaging-channels.md](../baseline/v2/technical-blueprint/reference/messaging-channels.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
