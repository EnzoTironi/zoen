# SPEC-021 — Dental operations pack with clinical separation

**Milestone:** S3 · **Accountable function:** Domain Product · **Implementation root:** `packs/clinic` · **Status:** specified, not implemented.

## Decision and intended behavior

The clinic pack provides appointments, room/provider availability, administrative commitments and billing references. Clinical notes are a separately restricted domain; no diagnosis, treatment recommendation or prescribing is silently included in an operational assistant.

## Owned state and storage contract

Released definitions: Clinic, Appointment, ProviderAvailability, Room, PatientAdministrativeIdentity, BillingReference and ClinicalRecordReference. Clinical payload rights do not inherit from appointment visibility. All instances use the common ontology storage and audited domain operations.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
InspectAvailability(scope,timeRange) -> AuthorizedSlots; ProposeReschedule(appointment,slot,basis) -> ActionCase when S4 admitted; InspectAdministrativePatient(subject,purpose) -> RestrictedFrame.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Match patient identity through guarded resolution, not names alone. Represent appointments in explicit timezone/wall-time types. Prevent double booking with room/provider interval-domain fences. Clinical counts and existence stay hidden from reception unless policy explicitly permits a non-sensitive administrative reference.

## Dependencies and sequencing

Referenced specs: [016](spec-016.md), [018](spec-018.md), [019](spec-019.md), [020](spec-020.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0124](../tickets/zn-0124.md) | Author clinic administrative and restricted interfaces | S3 | component | ZN-0100, ZN-0111, ZN-0117, ZN-0123 |
| [ZN-0125](../tickets/zn-0125.md) | Implement available-slot planning without clinical disclosure | S3 | component | ZN-0124 |
| [ZN-0126](../tickets/zn-0126.md) | Define guarded rescheduling and reminders | S3 | component | ZN-0125 |
| [ZN-0127](../tickets/zn-0127.md) | Prove group, revocation and ambiguous identity cases | S3 | journey | ZN-0126 |
| [ZN-0128](../tickets/zn-0128.md) | Review clinical scope before real-data activation | S3 | admission | ZN-0127 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[domain-packs-and-marketplace.md](../baseline/v2/technical-blueprint/reference/domain-packs-and-marketplace.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
