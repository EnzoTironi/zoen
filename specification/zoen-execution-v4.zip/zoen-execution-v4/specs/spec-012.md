# SPEC-012 — Progressive onboarding and accessible conversation inspection

**Milestone:** S1 · **Accountable function:** Experience · **Implementation root:** `apps/web/src/experience` · **Status:** specified, not implemented.

## Decision and intended behavior

Onboarding starts from a useful intent and one optional source, not an integration project. A person can inspect evidence, correct an answer and stop the assistant without learning the ontology vocabulary. Accessibility is a shipped behavior, not a later theme.

## Owned state and storage contract

No domain database. UI stores only presentation preferences and opaque Focus in Eve-owned APIs. Browser caches are keyed by principal, World, purpose, release and security revision, and are cleared on identity/audience changes.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ConversationRoute(focus?) -> AccessibleConversation; SourceSetup(intent,availableSources) -> ProgressiveSetup; EvidencePanel(frameRef) -> AuthorizedView; StopControl(turnOrMandateRef) -> ExplicitState.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use React Aria primitives and semantic HTML. Start in pt-BR with internationalized messages and explicit locale for numbers/dates. Provide large text, keyboard operation, focus restoration and text alternatives. Do not reveal old content on a shared device before current authentication. Questions offer unknown/undo; consent is distinct from friendly conversational agreement.

V4 refinement: The accessible trusted host is reused by mini apps. Secure login/logout, inspection, evidence and confirmations are not reimplemented per app.

## Dependencies and sequencing

Referenced specs: [007](spec-007.md), [009](spec-009.md), [010](spec-010.md), [011](spec-011.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0070](../tickets/zn-0070.md) | Implement honest empty and partial onboarding states | S1 | journey | ZN-0046, ZN-0057, ZN-0062, ZN-0068 |
| [ZN-0071](../tickets/zn-0071.md) | Implement keyboard and large-text accessible interaction | S1 | journey | ZN-0070 |
| [ZN-0072](../tickets/zn-0072.md) | Implement evidence deepening and scoped clarification | S1 | journey | ZN-0071 |
| [ZN-0073](../tickets/zn-0073.md) | Implement shared-device logout and context separation | S1 | journey | ZN-0072 |
| [ZN-0074](../tickets/zn-0074.md) | Run moderated first-use acceptance across the three audiences | S1 | admission | ZN-0073 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [release-policy-eve.md](../baseline/v2/technical-blueprint/reference/release-policy-eve.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
