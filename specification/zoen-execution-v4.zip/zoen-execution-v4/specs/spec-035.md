# SPEC-035 — Progressive Workshop: early declarative apps, isolated views and full Studio

**Milestone:** S8 · **Accountable function:** Builder Platform · **Implementation root:** `apps/web/src/studio` · **Status:** specified, not implemented.

## Decision and intended behavior

Studio is an advanced authoring surface over the same runtime definitions and semantic executor. Declarative runtime is delivered in S2, isolated executable delivery in S6 and rich Studio in S8. There is one app renderer/host, not a replacement at each milestone.

## Owned state and storage contract

MiniAppDefinition is released meaning owned by Ontology. SPEC-052 owns definition/manifest contracts; SPEC-051 owns authority-free links and scoped execution sessions; SPEC-029 owns signed artifacts; SPEC-053 owns non-authoritative bridge/runner state. eve.builder_drafts remains non-authoritative authoring state. No app authority database.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
EditDraft -> Draft; PreviewApp -> IsolatedPreview; PublishApp -> existing DefinitionChange process. AppBridgeRequest is a transport envelope for SemanticCall, not a domain data API.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Reuse SPEC-050..054 without business logic in the bridge. Agent and human editors use the same runtime change operations. Full Studio composes the already-shipped declarative renderer, safe host, signed executable artifact and published operation manifest. It must not route reads through Eve/LLMs, access source credentials or create a second reconciliation engine.

## Dependencies and sequencing

Referenced specs: [014](spec-014.md), [027](spec-027.md), [029](spec-029.md), [030](spec-030.md), [031](spec-031.md), [052](spec-052.md), [053](spec-053.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Per-ticket stages override this full-Studio S8 label. ZN-0203 is S2; ZN-0204 and ZN-0205 are S6; ZN-0202 and ZN-0206 remain S8. Their exact DAG is normative; dense infrastructure is not required for the early renderer.

Read [mini-app contract](../architecture/mini-app-contract.md), [links](../architecture/protected-links.md) and [host security](../architecture/app-host-security.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0202](../tickets/zn-0202.md) | Build Studio definition, rule and integration editors | S8 | journey | ZN-0088, ZN-0163, ZN-0185, ZN-0305, ZN-0311 |
| [ZN-0203](../tickets/zn-0203.md) | Implement declarative operational app runtime | S2 | component | ZN-0071, ZN-0299, ZN-0303, ZN-0304 |
| [ZN-0204](../tickets/zn-0204.md) | Implement isolated executable app origin and bridge | S6 | component | ZN-0203, ZN-0311 |
| [ZN-0205](../tickets/zn-0205.md) | Implement negotiated MCP Apps delivery | S6 | component | ZN-0156, ZN-0204 |
| [ZN-0206](../tickets/zn-0206.md) | Prove agent-generated application without new authority paths | S8 | journey | ZN-0202, ZN-0205, ZN-0319, ZN-0321 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md) · [interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
