# SPEC-010 — Context, grounded composition, model routing and voice

**Milestone:** S1 · **Accountable function:** Experience · **Implementation root:** `packages/eve/src/context` · **Status:** specified, not implemented.

## Decision and intended behavior

Context is freshly compiled permitted material, not a universal memory. Summaries aid interaction but never become evidence. Models propose; deterministic semantic operations decide. Voice transcripts remain attributed, correctable interpretations of retained audio.

## Owned state and storage contract

eve.context_snapshots(context_id PK,turn_id,release_digest,visible_message_refs,frame_refs,skill_ref,model_route_ref,purpose,budget_ref); eve.summaries(summary_id PK,conversation_id,through_message_id,text,model_ref,expires_at); eve.model_observations(attempt_id PK,provider,model,usage,output_ref,retention_ref). Raw hidden reasoning fields are excluded by schema.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CompileContext(turn,grant,limits) -> ContextBundle | IncompleteBasis; SelectModel(requestPurpose,dataUse,region,budget) -> PermittedRoute | NoPermittedModel; ProposeTranscript(audioEvidence,languageHint) -> AttributedTranscript.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Freshly reopen every Frame used in context. Mark untrusted source text as data and isolate it from instructions. A tool set is the intersection of released skill, principal grant and current runtime policy. Route only to admitted model/data-use/residency profiles. Optional missing sources yield honest partial state. A voice transcription cannot authorize a consequential action without the normal confirmation path.

V4 refinement: Grounding and tool execution use the SPEC-007 SemanticExecutor through a narrow client. Model-generated principal, role, grants or provider credentials are never accepted as authority.

## Dependencies and sequencing

Referenced specs: [009](spec-009.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0058](../tickets/zn-0058.md) | Compile bounded provenance-carrying context | S1 | component | ZN-0057 |
| [ZN-0059](../tickets/zn-0059.md) | Compact conversational history without creating facts | S1 | component | ZN-0058 |
| [ZN-0060](../tickets/zn-0060.md) | Implement permitted model routing and usage accounting | S1 | component | ZN-0059 |
| [ZN-0061](../tickets/zn-0061.md) | Implement honest answer composition and evidence linking | S1 | component | ZN-0060 |
| [ZN-0062](../tickets/zn-0062.md) | Add audio transcription with provenance and correction | S1 | component | ZN-0061 |
| [ZN-0063](../tickets/zn-0063.md) | Qualify the actual model and voice provider profiles | S1 | admission | ZN-0062 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[models-retrieval-and-agents.md](../baseline/v2/technical-blueprint/reference/models-retrieval-and-agents.md) · [release-policy-eve.md](../baseline/v2/technical-blueprint/reference/release-policy-eve.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
