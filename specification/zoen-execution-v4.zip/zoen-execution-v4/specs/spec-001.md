# SPEC-001 — Kernel values, contract algebra and canonical encoding

**Milestone:** S0 · **Accountable function:** Kernel · **Implementation root:** `packages/kernel/src` · **Status:** specified, not implemented.

## Decision and intended behavior

Keep the kernel free of business-domain classes and I/O. Use validated opaque IDs, decimal strings, explicit time kinds and total tagged outcomes. Preserve v2 Interpretation status and verification as independent axes.

## Owned state and storage contract

No tables. Normative JSON schemas live under contracts/kernel. IDs are opaque UUID values tagged at runtime with world/realm; counters and monetary values cross JSON as decimal strings. Database identifiers must not be guessable credentials.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
parseEnvelope(bytes) -> ValidEnvelope | InvalidInput; normalizeDecimal(text, scalePolicy) -> Decimal | InvalidScalar; compareIntervals(a,b) -> ComparableInterval | NonComparable; canonicalDigest(value) -> sha256.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Validate before branding. Reject duplicate JSON keys and unsupported versions. Authority JSON permits finite I-JSON numbers only for bounded counters/flags; money uses strings. No locale guessing in canonical input. Date is not Instant. Currency/unit conversions require a released factor and evidence/effective interval. Normalize negative zero; preserve declared precision and never use Number for money.

## Dependencies and sequencing

Referenced specs: [000](spec-000.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0007](../tickets/zn-0007.md) | Define branded IDs and realm-safe boundary parsers | S0 | law | ZN-0006 |
| [ZN-0008](../tickets/zn-0008.md) | Implement decimal, money and unit algebra | S0 | law | ZN-0007 |
| [ZN-0009](../tickets/zn-0009.md) | Implement time kinds and half-open intervals | S0 | law | ZN-0008 |
| [ZN-0010](../tickets/zn-0010.md) | Implement bounded canonical parsing and hashing | S0 | law | ZN-0009 |
| [ZN-0011](../tickets/zn-0011.md) | Define stable errors, state axes and exhaustive serializers | S0 | law | ZN-0010 |
| [ZN-0012](../tickets/zn-0012.md) | Prove algebraic and resource-limit laws | S0 | law | ZN-0011 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[ontology-and-standards.md](../baseline/v2/technical-blueprint/reference/ontology-and-standards.md) · [types-and-protocols.md](../baseline/v2/technical-blueprint/reference/types-and-protocols.md) · [identity-and-time.md](../baseline/v2/technical-blueprint/reference/identity-and-time.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
