# SPEC-007 — WorldFrames and the first semantic surface

**Milestone:** S0 · **Accountable function:** Kernel and Experience · **Implementation root:** `packages/ontology/src/surfaces` · **Status:** specified, not implemented.

## Decision and intended behavior

One semantic operation registry feeds all surfaces. At S0 the registry is image-pinned; S2 makes its business definitions runtime-released. No temporary CRUD API may bypass it. Frames pin a consistent authorized basis.

## Owned state and storage contract

ontology.frames(frame_id PK,world_id,head_digest,cut_json,operation_id,plan_digest,perspective,rights_basis,payload_ref,created_at,expires_at); ontology.frame_pins(frame_id,evidence_or_snapshot_ref PK,retention_class). Opaque Focus records live in Eve, not here. Index frames by World and ID; no global public digest endpoint.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Inspect(operationId,input,purpose,expectedContract) -> WorldFrame; Explain(frameId,grant) -> Frame; OpenFrame(frameId,freshGrant) -> SameHistoricalFrame | NewerFrame | HistoricalContentUnavailable; Discover(grant) -> AllowedOperationManifest.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Open one REPEATABLE READ snapshot for head, rights, domain cuts and immutable input refs. Materialize only bounded sparse inputs then close long scans’ database transaction. Compute payload from pinned data, and reauthorize before disclosure. Frame output includes gaps, perspective, evidence and temporal basis; a partial result never masquerades as complete.

V4 refinement: SPEC-050 names and constrains this existing dispatcher as SemanticExecutor. It does not create another executor. Every human UI, agent, mini app and programmatic adapter resolves the same released operation and invokes this implementation. Read, discovery, mutation, subscription and export share authority and result semantics.

## Dependencies and sequencing

Referenced specs: [005](spec-005.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0042](../tickets/zn-0042.md) | Implement bounded Frame basis acquisition | S0 | component | ZN-0036 |
| [ZN-0043](../tickets/zn-0043.md) | Implement semantic dispatcher and stable error translation | S0 | component | ZN-0042 |
| [ZN-0044](../tickets/zn-0044.md) | Implement authorized discovery and explanation references | S0 | component | ZN-0043 |
| [ZN-0045](../tickets/zn-0045.md) | Ship the minimum web and CLI divergence flow | S0 | journey | ZN-0044, ZN-0291, ZN-0292 |
| [ZN-0046](../tickets/zn-0046.md) | Reauthorize result disclosure and historical reopen | S0 | component | ZN-0045 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md) · [authority-concurrency-and-cuts.md](../baseline/v2/technical-blueprint/reference/authority-concurrency-and-cuts.md) · [types-and-protocols.md](../baseline/v2/technical-blueprint/reference/types-and-protocols.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
