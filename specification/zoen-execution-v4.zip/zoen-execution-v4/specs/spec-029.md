# SPEC-029 — Signed capability artifacts and controlled installation

**Milestone:** S6 · **Accountable function:** Platform Security · **Implementation root:** `packages/ontology/src/artifacts` · **Status:** specified, not implemented.

## Decision and intended behavior

Executable variation is real code delivered as a signed isolated artifact, not disguised configuration. Signature proves origin, not safety. Installation records requested versus granted capabilities, exact bytes and evaluation evidence.

## Owned state and storage contract

ontology.artifacts(artifact_digest PK,kind,runtime_abi,entrypoint,sbom_ref,provenance_ref,signature_ref,capability_request,resource_profile); ontology.installations(installation_id PK,world_id,artifact_digest,granted_scope,release_ref,state); ontology.artifact_recalls(recall_id PK,digest,reason,effective_at,scope); ontology.artifact_evaluations(evaluation_id PK,digest,profile,report_ref,state). Blobs are retained under controlled object-store policy.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProposeArtifact(envelope,bytesRef) -> Candidate; EvaluateArtifact(candidate,EvaluationWorld) -> Proof; InstallArtifact(digest,requestedGrant,operationId) -> Change; RecallArtifact(digest) -> RecallReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Build in an isolated reproducible pipeline with dependency lock, SBOM and provenance. Validate image/entrypoint/output schemas and capability requests. Run hostile evaluation before installation. Source/effect credentials are brokered separately. A recalled artifact cannot obtain new execution leases; running work is stopped or reconciled according to its effect state.

V4 refinement: An executable app reuses this signed artifact/install/recall contract. Requested capabilities are not granted capabilities. Frontend-only signed bundles need not provision a backend. No credentials, private dataset or bootstrap snapshot may be compiled into an app bundle.

## Dependencies and sequencing

Referenced specs: [014](spec-014.md), [024](spec-024.md), [026](spec-026.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0169](../tickets/zn-0169.md) | Define and validate artifact envelopes | S6 | component | ZN-0088, ZN-0146, ZN-0158 |
| [ZN-0170](../tickets/zn-0170.md) | Build isolated provenance and dependency review pipeline | S6 | component | ZN-0169 |
| [ZN-0171](../tickets/zn-0171.md) | Evaluate capability requests against actual grants | S6 | component | ZN-0170 |
| [ZN-0172](../tickets/zn-0172.md) | Implement recall and deny new artifact leases | S6 | component | ZN-0171 |
| [ZN-0173](../tickets/zn-0173.md) | Prove agent-proposed custom connector installation | S6 | journey | ZN-0172 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md) · [domain-packs-and-marketplace.md](../baseline/v2/technical-blueprint/reference/domain-packs-and-marketplace.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
