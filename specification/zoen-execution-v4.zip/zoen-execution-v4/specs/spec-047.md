# SPEC-047 — Orders, executions, allocations, custody and supervision

**Milestone:** S11 · **Accountable function:** Finance Domain · **Implementation root:** `packs/finance/execution` · **Status:** specified, not implemented.

## Decision and intended behavior

Order submission, broker acknowledgement, execution, allocation, clearing and actual custody settlement are separate lifecycles. Cancellation does not prove no fill occurred. Busts and corrections append evidence and reconcile positions; historical executions are not deleted.

## Owned state and storage contract

Released objects: Order, OrderRevision, BrokerRequest, Execution, ExecutionCorrection, Allocation, ClearingObligation, CustodyMovement, SettlementObservation and SupervisedConversation. Stable provider/account/order/execution IDs are scoped; quantity and fee/currency conservation are checked in normal domain Actions.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProposeOrder(intent,basis) -> RiskBoundActionCase; ObserveBrokerEvent(rawEvidence) -> OrderLifecycleReceipt; AllocateExecution(execution,accounts) -> AllocationCase; ObserveCustody(movementEvidence) -> SettlementReceipt; ReviewCollaboration(space,policy) -> SupervisedView.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Orders preserve original quantity/terms and replacement/cancel chains. Deduplicate broker event identity. Track ordered, active filled, busted, allocated, cancelled remainder and open quantity with explicit conservation. A 100-unit order filled 40 then busted 10 has active fill 30 and 70 remaining before other events; settlement is a separate observation. Partial/unknown outcomes retain reservations. Professional communications follow participation, retention, entitlement and supervision policies without granting World membership.

## Dependencies and sequencing

Referenced specs: [046](spec-046.md), [023](spec-023.md), [043](spec-043.md), [019](spec-019.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0273](../tickets/zn-0273.md) | Implement order submission and acknowledged lifecycle | S11 | component | ZN-0117, ZN-0139, ZN-0254, ZN-0271 |
| [ZN-0274](../tickets/zn-0274.md) | Implement executions, corrections and quantity conservation | S11 | component | ZN-0273 |
| [ZN-0275](../tickets/zn-0275.md) | Handle cancel/replace, partial and fill races | S11 | component | ZN-0274 |
| [ZN-0276](../tickets/zn-0276.md) | Implement allocations and clearing obligations | S11 | component | ZN-0275 |
| [ZN-0277](../tickets/zn-0277.md) | Observe actual custody/cash settlement and fails | S11 | component | ZN-0276 |
| [ZN-0278](../tickets/zn-0278.md) | Implement supervised professional collaboration | S11 | component | ZN-0277 |
| [ZN-0279](../tickets/zn-0279.md) | Prove full finance lifecycle under adversarial ordering | S11 | chaos | ZN-0278 |
| [ZN-0280](../tickets/zn-0280.md) | Certify each broker, custodian and regulated operating scope | S11 | admission | ZN-0279 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[finance-domain.md](../baseline/v2/technical-blueprint/reference/finance-domain.md) · [actions-effects-and-settlement.md](../baseline/v2/technical-blueprint/reference/actions-effects-and-settlement.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
