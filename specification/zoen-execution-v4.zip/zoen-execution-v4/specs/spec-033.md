# SPEC-033 — Entitled live feeds, gap-aware subscriptions and action capture

**Milestone:** S7 · **Accountable function:** Data Platform · **Implementation root:** `packages/ontology/src/live` · **Status:** specified, not implemented.

## Decision and intended behavior

Live observations are entitled transient overlays, not automatically durable facts. Conflated and unconflated feeds are distinct contracts. Consequential use requires exact captured evidence with age/sequence/rights guards.

## Owned state and storage contract

live feed transport is non-authoritative and bounded; ontology.feed_bindings(binding_id PK,world_id,provider,feed_contract,entitlement_ref); ontology.live_captures(capture_id PK,world_id,binding_id,provider_sequence,event_time,acquired_at,digest,evidence_ref,rights_ref); ontology.feed_gaps(gap_id PK,binding_id,sequence_range,state). Sealed history publishes through normal datasets.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
SubscribeLive(binding,subjects,grant) -> EntitledSubscription; ObserveFeed(envelope) -> TransientState; CaptureObservation(binding,sequence,maxAge,operationId) -> CapturedObservationRef | SourceStale; SealFeedRange(range) -> DatasetProposal.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Validate provider sequence, subject alias, unit/currency, clocks, quality and entitlement. Make gap/out-of-order state explicit. Never recover discarded unconflated events from a conflated stream. Bound client fanout and reconnect catch-up. Captures verify current entitlement and exact bytes before Action proposal; final commit checks age/identity/feed guards.

V4 refinement: Apps subscribe through the common executor and entitlement checks. A WebSocket or SSE handshake does not authorize the lifetime of the stream; send/resume/queue-flush reauthorize. No raw feed endpoint for a chart.

## Dependencies and sequencing

Referenced specs: [031](spec-031.md), [032](spec-032.md), [022](spec-022.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0192](../tickets/zn-0192.md) | Implement versioned live envelopes and sequencing | S7 | component | ZN-0134, ZN-0185, ZN-0191 |
| [ZN-0193](../tickets/zn-0193.md) | Enforce live entitlement and bounded fanout | S7 | component | ZN-0192 |
| [ZN-0194](../tickets/zn-0194.md) | Capture exact live values before consequential use | S7 | component | ZN-0193 |
| [ZN-0195](../tickets/zn-0195.md) | Seal live history with sequence coverage metadata | S7 | component | ZN-0194 |
| [ZN-0196](../tickets/zn-0196.md) | Prove capture freshness, entitlement and reconnect races | S7 | journey | ZN-0195 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[data-events-parquet.md](../baseline/v2/technical-blueprint/reference/data-events-parquet.md) · [data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
