# SPEC-045 — Finance security master, corporate actions and licensed information

**Milestone:** S11 · **Accountable function:** Finance Domain · **Implementation root:** `packs/finance/reference-data` · **Status:** specified, not implemented.

## Decision and intended behavior

Finance is a governed domain pack, not an implicit license or regulated-service authorization. Instrument, listing, issuer, account and beneficial owner are distinct. Restated fundamentals, raw/adjusted series and revised corporate actions preserve point-in-time provenance.

## Owned state and storage contract

Released objects: Instrument, Listing, Issuer, IdentifierAssignment, Account, BeneficialOwner, CorporateAction, Filing, FundamentalObservation and NewsItem. Values use common claims/datasets with source/license/knowledge cuts. Identifier namespace and valid dates are explicit; licensed raw content may be reference-only.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ResolveInstrument(sourceAlias,cut) -> InstrumentFrame | Ambiguous; InspectCorporateAction(id,cut) -> RevisionedAction; QueryFundamentals(metric,asOf,knowledgeCut) -> LicensedFrame; QueryNews(subject,cut,use) -> PermittedEvidence.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Never key all finance entities by ticker. Corporate actions bind announcement/ex/record/pay dates, elections, affected quantities and revision chain. Point-in-time reads exclude later filings/restatements/mappings unless requested and labeled. Source entitlements constrain display, redistribution, analytics, storage and model use independently.

## Dependencies and sequencing

Referenced specs: [037](spec-037.md), [041](spec-041.md), [043](spec-043.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0261](../tickets/zn-0261.md) | Define instrument, listing, issuer and identifier master | S11 | component | ZN-0218, ZN-0244, ZN-0254 |
| [ZN-0262](../tickets/zn-0262.md) | Model corporate-action lifecycle and revisions | S11 | component | ZN-0261 |
| [ZN-0263](../tickets/zn-0263.md) | Ingest as-reported and restated fundamentals | S11 | component | ZN-0262 |
| [ZN-0264](../tickets/zn-0264.md) | Ingest licensed news and revisioned research evidence | S11 | component | ZN-0263 |
| [ZN-0265](../tickets/zn-0265.md) | Prove finance reference-data reconciliation | S11 | journey | ZN-0264 |
| [ZN-0266](../tickets/zn-0266.md) | Admit licensed reference-data and research scopes | S11 | admission | ZN-0265 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[finance-domain.md](../baseline/v2/technical-blueprint/reference/finance-domain.md) · [identity-and-time.md](../baseline/v2/technical-blueprint/reference/identity-and-time.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
