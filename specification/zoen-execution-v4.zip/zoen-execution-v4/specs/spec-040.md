# SPEC-040 — Fairness, economics, capacity admission and audited support

**Milestone:** S9 · **Accountable function:** Operations and Product · **Implementation root:** `packages/ontology/src/operations` · **Status:** specified, not implemented.

## Decision and intended behavior

Capacity is admitted against a reproducible workload envelope, not inferred from tenant count. Per-World fairness, resource budgets and audit-safe support are part of the product. Targets in this execution pack are proposed admission criteria, not measured promises.

## Owned state and storage contract

ontology.quota_policies(policy_id PK,world_id,resource,limit,window,priority); jobs.usage_reservations(reservation_id PK,world_id,kind,estimate,actual,state); audit.support_sessions(session_id PK,operator,world_scope,purpose,approver,expires_at,state); audit.slo_reports(report_id PK,profile,workload_digest,window,metrics,evidence_ref). Billing ledger references provider entitlements, never raw card data.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ReserveUsage(world,resource,estimate) -> Reservation | QuotaExceeded; AdmitWorkload(profile,benchmarkReport) -> CapacityCertificate; RequestSupportAccess(scope,purpose) -> TimeBoundCase; ExportAudit(scope,destination) -> AuthorizedArtifact.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Enforce concurrency, query rows/bytes, LLM tokens, source egress, storage and effect quotas before resource use. Reconcile actual usage after observation and bound unknown-cost exposure. Separate queues/fair scheduling by policy. Support starts metadata-only; content access requires explicit approval, expiry, reason and audit. No permanent global support superuser.

## Dependencies and sequencing

Referenced specs: [024](spec-024.md), [025](spec-025.md), [034](spec-034.md), [039](spec-039.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0231](../tickets/zn-0231.md) | Enforce per-World quotas and fair scheduling | S9 | component | ZN-0146, ZN-0152, ZN-0200, ZN-0229 |
| [ZN-0232](../tickets/zn-0232.md) | Attribute usage and cost without inventing actuals | S9 | component | ZN-0231 |
| [ZN-0233](../tickets/zn-0233.md) | Implement time-bound audited support access | S9 | component | ZN-0232 |
| [ZN-0234](../tickets/zn-0234.md) | Implement security audit exports and incident runbooks | S9 | component | ZN-0233 |
| [ZN-0235](../tickets/zn-0235.md) | Benchmark full mixed workloads and serializable hotspots | S9 | performance | ZN-0234 |
| [ZN-0236](../tickets/zn-0236.md) | Accept an institutional operating profile from measured evidence | S9 | admission | ZN-0235 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[capacity-economics-and-slos.md](../baseline/v2/technical-blueprint/reference/capacity-economics-and-slos.md) · [security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
