# SPEC-048 — Full-ambition integration, adversarial assurance and final acceptance

**Milestone:** S11 · **Accountable function:** Architecture and Operations · **Implementation root:** `journeys/acceptance` · **Status:** specified, not implemented.

## Decision and intended behavior

Final completion is the conjunction of traced capability tests, integrated audience outcomes, admitted operating profiles and explicitly accepted external gates. A green backlog validator proves plan integrity, not implemented product correctness. No reduced demo can close the full-ambition milestone.

## Owned state and storage contract

No new product authority store. evidence/release-candidates/<commit> contains immutable reports, dependency locks, requirement/test coverage, threat findings, workload certificates, user-study evidence, provider qualifications, unresolved deviations and sign-off records. The current capability support matrix is derived from accepted evidence, not manually edited success flags.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
EvaluateReleaseCandidate(commit,profile) -> AcceptanceReport; CheckCapabilityCoverage(requirements,evidence) -> Covered|Missing; PromoteOperatingProfile(report,approvals) -> Admitted|Blocked.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Run the same core invariants across consumer, professional and institutional Worlds. Add long-running chaos, upgrade/recovery, revocation, data erasure, cost and abuse workloads. Reuse approved primitives, never customer forks. Every unresolved unknown is scoped and disables affected routes. Reopen evidence when code, fixture, policy, provider API, dependency or operating profile changes materially.

V4 refinement: Final acceptance includes SPEC-055 cross-surface capstones and all v4 requirement checks. A browser/runtime qualification cannot be inferred from package-control tests or transport simulations.

## Dependencies and sequencing

Referenced specs: [037](spec-037.md), [040](spec-040.md), [041](spec-041.md), [044](spec-044.md), [047](spec-047.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0281](../tickets/zn-0281.md) | Run the consumer complete-life-administration acceptance | S11 | journey | ZN-0218, ZN-0235, ZN-0244, ZN-0259, ZN-0279 |
| [ZN-0282](../tickets/zn-0282.md) | Run professional operations and clinic-separation acceptance | S11 | journey | ZN-0281 |
| [ZN-0283](../tickets/zn-0283.md) | Run enterprise institutional and finance acceptance | S11 | journey | ZN-0282 |
| [ZN-0284](../tickets/zn-0284.md) | Run hostile-agent, supply-chain and privacy campaigns | S11 | chaos | ZN-0283 |
| [ZN-0285](../tickets/zn-0285.md) | Audit every capability and test evidence against the candidate | S11 | admission | ZN-0001, ZN-0002, ZN-0063, ZN-0069, ZN-0074, ZN-0095, ZN-0128, ZN-0140, ZN-0168, ZN-0179, ZN-0201, ZN-0217, ZN-0224, ZN-0230, ZN-0236, ZN-0243, ZN-0260, ZN-0266, ZN-0272, ZN-0280, ZN-0284, ZN-0290, ZN-0301, ZN-0312, ZN-0313, ZN-0319, ZN-0325 |
| [ZN-0286](../tickets/zn-0286.md) | Approve the fully qualified product support matrix | S11 | admission | ZN-0285 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[capability-horizon.md](../baseline/v2/technical-blueprint/reference/capability-horizon.md) · [ambition-audit.md](../baseline/v2/technical-blueprint/reference/ambition-audit.md) · [testing-and-ci.md](../baseline/v2/technical-blueprint/reference/testing-and-ci.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
