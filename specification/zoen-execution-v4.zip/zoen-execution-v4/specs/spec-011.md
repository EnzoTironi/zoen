# SPEC-011 — WhatsApp durable ingress, consent and secure continuation

**Milestone:** S1 · **Accountable function:** Channels · **Implementation root:** `packages/adapters/src/channels/whatsapp` · **Status:** specified, not implemented.

## Decision and intended behavior

Kapso is the selected WhatsApp route, subject to current provider/platform admission. Transport identity is not authority. Webhooks are acknowledged only after durable local ingress. Channel policy and delivery ambiguity are first-class states.

## Owned state and storage contract

channels.ingress(ingress_id PK,provider,account_ref,provider_event_id,received_at,signature_profile,payload_ref,UNIQUE(provider,account_ref,provider_event_id)); channels.bindings(binding_id PK,provider_subject,principal_ref_nullable,consent_ref,assurance,state); channels.delivery(delivery_id PK,message_ref,destination_ref,provider_message_id,state,attempt_ref); channels.consent(consent_id PK,subject_ref,purpose,granted_at,revoked_at,evidence_ref). Provider payload retention is explicit.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AdmitWebhook(rawBytes,verifiedHeaders) -> DurableAck | Reject; BindChannel(proof,challenge) -> BindingReceipt; PrepareDelivery(messageRef,policyBasis) -> DeliveryIntent | Deferred | Denied; ObserveDelivery(providerEvidence) -> DeliveryObservation.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use the actual documented signature/replay scheme of the admitted API version; do not invent a common HMAC header. Validate raw bytes before parsing. Persist ingress and owner outbox before ACK. Link channel identity through a fresh secure challenge. Evaluate consent/template/window and audience before each send. Tokens in continuation links are opaque, short-lived and single-use for linking, not transferable World access.

V4 refinement: ZN-0068 consumes the reusable authority-free continuation registry and browser exchange in SPEC-051. A URL, WhatsApp delivery receipt or sender number cannot confer World access. Preview GET/HEAD is generic and never redeems a challenge.

## Dependencies and sequencing

Referenced specs: [009](spec-009.md), [010](spec-010.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0064](../tickets/zn-0064.md) | Admit signed webhooks before acknowledgement | S1 | component | ZN-0057, ZN-0062 |
| [ZN-0065](../tickets/zn-0065.md) | Bind a channel without granting World access | S1 | component | ZN-0064 |
| [ZN-0066](../tickets/zn-0066.md) | Enforce message window, template and consent policy | S1 | component | ZN-0065 |
| [ZN-0067](../tickets/zn-0067.md) | Track message delivery ambiguity independently | S1 | component | ZN-0066 |
| [ZN-0068](../tickets/zn-0068.md) | Implement secure continuation and attachment handoff | S1 | component | ZN-0067, ZN-0297 |
| [ZN-0069](../tickets/zn-0069.md) | Qualify real WhatsApp transport and current operating terms | S1 | admission | ZN-0068 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[messaging-channels.md](../baseline/v2/technical-blueprint/reference/messaging-channels.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
