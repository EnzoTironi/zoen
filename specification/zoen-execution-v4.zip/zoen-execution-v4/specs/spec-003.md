# SPEC-003 — Atomic authority, domain guards and durable handoff

**Milestone:** S0 · **Accountable function:** Kernel · **Implementation root:** `packages/ontology/src/authority` · **Status:** specified, not implemented.

## Decision and intended behavior

One authoritative cell per World epoch, independent ordering domains inside a World. PostgreSQL is the local authority; no provider call runs in an authority transaction. Conservative domain/predicate fences are the initial correctness baseline.

## Owned state and storage contract

ontology.domains(world_id,domain_id PK,version bigint>=0); ontology.operations(world_id,principal_id,semantic_op,operation_id PK,intent_digest,result_ref,commit_id); ontology.commits(commit_id PK,world_id,head_digest,touched_domains jsonb,recorded_at); ontology.receipts(receipt_id PK,world_id,commit_id,kind,payload_digest,payload_json); jobs.outbox(outbox_id PK,owner,world_id,commit_id,event_ordinal,payload_ref,status,lease_owner,fence,lease_until,UNIQUE(owner,commit_id,event_ordinal)). All world references include realm and ownership checks.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AuthorityCommit(context, expectedHead, guards, operationKey, typedPlan) -> Receipt | Stale | Conflict; ProgressCommit(leaseToken,progress) -> Progress | LostLease; ClaimOutbox(owner,limit) -> FencedBatch.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Begin SERIALIZABLE; acquire WorldHead FOR SHARE, check epoch/release/generation/security; lock domains sorted by ID; verify current authority; validate operation digest; check domain/predicate/source/identity/clock guards; write semantic changes, counters, receipt and outbox atomically. Retry only serialization/deadlock failures up to 3 attempts with the same intent and no consent rebasing. A replay is reauthorized before disclosing stored output.

## Dependencies and sequencing

Referenced specs: [001](spec-001.md), [002](spec-002.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


The initial authority migration owns the Ontology tables listed by SPEC-002 as well as this spec. Genesis reuses AuthorityCommit; there is no separate privileged transaction engine. World creation uses an operation scope derived from the principal before the new World exists; its unique genesis operation row and all new World rows commit in one SERIALIZABLE transaction. Subsequent operations use World-scoped keys.
S0 guard/commit tests use minimal typed AuthorityCommit plans and synthetic saved read sets, not the complete S4 ActionCase engine. The exact same primitive is exercised again through real ActionCases at S4; do not build a parallel authority implementation merely to satisfy the early fixture.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0019](../tickets/zn-0019.md) | Create owner-scoped SQL schema and migration discipline | S0 | component | ZN-0012, ZN-0013 |
| [ZN-0020](../tickets/zn-0020.md) | Implement serializable commits with sorted domain locks | S0 | component | ZN-0019 |
| [ZN-0021](../tickets/zn-0021.md) | Implement operation idempotency with fresh replay disclosure | S0 | component | ZN-0020 |
| [ZN-0022](../tickets/zn-0022.md) | Implement complete read guards including absent-row predicates | S0 | component | ZN-0021 |
| [ZN-0023](../tickets/zn-0023.md) | Implement fenced outbox leases and idempotent consumer handoff | S0 | component | ZN-0022 |
| [ZN-0024](../tickets/zn-0024.md) | Prove commit boundaries with real process termination | S0 | chaos | ZN-0023 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[authority-concurrency-and-cuts.md](../baseline/v2/technical-blueprint/reference/authority-concurrency-and-cuts.md) · [database-access.md](../baseline/v2/technical-blueprint/reference/database-access.md) · [actions-effects-and-settlement.md](../baseline/v2/technical-blueprint/reference/actions-effects-and-settlement.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
