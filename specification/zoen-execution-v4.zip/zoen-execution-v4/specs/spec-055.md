# SPEC-055 — Cross-surface equivalence, adversarial app journeys and capacity

**Milestone:** S3 · **Accountable function:** Quality and Security · **Implementation root:** `journeys/mini-apps` · **Status:** specified, not implemented.

## Decision and intended behavior

Prove one path structurally and behaviorally. Tests compare semantic outputs at equivalent authorized context and exact basis, not prose or equal permissions for different users. Human, agent and app frontends cannot certify themselves. Fault tests must exercise actual executor, database, policies, browsers and admitted runtime where claimed.

## Owned state and storage contract

No new authority store. Synthetic fixtures, paired visibility sets, trace digests, operation identities and signed CI evidence are test artifacts. Production data is never embedded in this package. Admission reports bind commit, lock, source rights, browser/runtime/deployment profile and expected checks.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AssertEquivalentSemanticResult; AssertExecutorEntry; RunNoBypassCampaign; RunThreeAudienceAppJourney; QualifyAppWorkload. These are test harness operations, not public production tools.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Cover read/discovery, mutation/approval/replay, sharing/revocation, streams/exports and runtime publication. Include denied, invalid, stale, changed intent, Unknown and resource limits. Do not count presentation equality as semantic parity or different operation IDs as one intention. Raw traces must not expose hidden source values.

## Dependencies and sequencing

Referenced specs: [050](spec-050.md), [051](spec-051.md), [052](spec-052.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Exact fixtures, equivalence normalization and hostile cases are in [mini-app conformance](../testing/mini-app-conformance.md). Every required product check starts unrun. Local Python package-control tests do not execute these journeys.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0320](../tickets/zn-0320.md) | Prove early human-agent-declarative read and divergence equivalence | S3 | journey | ZN-0111, ZN-0300, ZN-0305 |
| [ZN-0321](../tickets/zn-0321.md) | Prove cross-surface approval, stale consent and retry identity | S4 | chaos | ZN-0134, ZN-0138, ZN-0306 |
| [ZN-0322](../tickets/zn-0322.md) | Audit data route closure and executable-app confused deputy attacks | S6 | chaos | ZN-0158, ZN-0292, ZN-0312, ZN-0319 |
| [ZN-0323](../tickets/zn-0323.md) | Measure mini-app batched reads, exports and streaming budgets | S7 | performance | ZN-0295, ZN-0312 |
| [ZN-0324](../tickets/zn-0324.md) | Prove household, professional and institutional Workshop journeys | S8 | journey | ZN-0206, ZN-0307, ZN-0313, ZN-0322, ZN-0323 |
| [ZN-0325](../tickets/zn-0325.md) | Audit v4 execution requirements through institutional final acceptance | S11 | admission | ZN-0283, ZN-0324 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[testing-and-ci.md](../baseline/v2/technical-blueprint/reference/testing-and-ci.md) · [apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
