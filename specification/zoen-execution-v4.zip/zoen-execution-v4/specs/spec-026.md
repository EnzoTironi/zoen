# SPEC-026 — REST, CLI, TypeScript SDK and MCP from one manifest

**Milestone:** S5 · **Accountable function:** Developer Platform · **Implementation root:** `packages/clients/src` · **Status:** specified, not implemented.

## Decision and intended behavior

One SurfaceManifest is the semantic contract. Clients are views and transports, never second policy/meaning engines. Runtime discovery changes without a deploy; static types describe the release against which the SDK was generated.

## Owned state and storage contract

No new authority tables. Generated contracts live in contracts/generated/<release-digest> and include operation IDs, input/output/error schemas, effect class, assurance, compatibility and manifest digest. Protocol edition and generated toolchain versions are separately admitted in execution-lock.json.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Discover(world,purpose) -> AuthorizedManifest; Invoke(operationId,contractDigest,input,operationId?) -> Result; GenerateClient(manifest,target) -> ReproducibleClient; NegotiateProtocol(clientVersions) -> SelectedVersion | UnsupportedVersion.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Generate REST/OpenAPI 3.1, CLI JSON modes, TypeScript definitions and MCP tools/resources from the same schemas. Every invocation still authorizes server-side. Reject incompatible operation digest rather than silently adapting consequential input. MCP annotations/tool approval are hints, not permission. Long operations use admitted status/SSE protocols with fresh authorization on reconnect.

V4 refinement: REST, CLI, SDK, MCP, Eve and mini-app clients are transport adapters for SPEC-007. They preserve the operation, current context, exact basis and idempotency identity; they do not duplicate policy logic. The simple semantic client is available before S5; these tickets add full generated surfaces.

## Dependencies and sequencing

Referenced specs: [013](spec-013.md), [018](spec-018.md), [025](spec-025.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0153](../tickets/zn-0153.md) | Generate REST/OpenAPI contracts and endpoint adapters | S5 | component | ZN-0081, ZN-0111, ZN-0152 |
| [ZN-0154](../tickets/zn-0154.md) | Generate CLI commands and structured failure behavior | S5 | component | ZN-0153 |
| [ZN-0155](../tickets/zn-0155.md) | Generate static TypeScript SDKs and compatibility checks | S5 | component | ZN-0154 |
| [ZN-0156](../tickets/zn-0156.md) | Implement MCP tools, resources and authorization negotiation | S5 | component | ZN-0155 |
| [ZN-0157](../tickets/zn-0157.md) | Implement resumable status streams with rights refresh | S5 | component | ZN-0156 |
| [ZN-0158](../tickets/zn-0158.md) | Prove cross-surface semantic and error parity | S5 | journey | ZN-0157, ZN-0293 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md) · [ontology-and-standards.md](../baseline/v2/technical-blueprint/reference/ontology-and-standards.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
