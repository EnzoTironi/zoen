# SPEC-016 — Foundation, household and confectionery domain packs

**Milestone:** S2 · **Accountable function:** Domain Product · **Implementation root:** `packs` · **Status:** specified, not implemented.

## Decision and intended behavior

One foundation grammar supports all audiences through release data. No customer/profession branches enter the kernel. Early pack actions requiring S4 are visible as unavailable until the normal action/effect capability is admitted, not implemented through shortcuts.

## Owned state and storage contract

Pack definitions are canonical JSON: foundation Party, Document, Event, Commitment, Location, Money and Quantity interfaces; household Bill, AccountReference and Obligation; bakery Order, OrderLine, Ingredient, Recipe, InventoryLot, ProductionSlot and Supplier. Instance storage uses shared subject/claim/link models, not one hard-coded SQL table per profession.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
InstallPack(packDigest,overlay,operationId) -> DefinitionChange; InspectHouseholdObligation(input) -> Frame; InspectBakeryOrder(input) -> Frame; PlanBakeryCapacity(input,basis) -> ReadOnlyPlan.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Household paid status distinguishes claim, transfer evidence and settlement. Bakery order quantity, produced quantity and delivered quantity are separate predicates; mass/unit conversions are explicit. Capacity accounts for time windows, yield and reserved inputs. A proposed order or recipe mutation is a governed local Action; external purchasing is disabled until S4.

## Dependencies and sequencing

Referenced specs: [013](spec-013.md), [014](spec-014.md), [015](spec-015.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0096](../tickets/zn-0096.md) | Define foundation interfaces and cross-pack mappings | S2 | component | ZN-0081, ZN-0088, ZN-0094 |
| [ZN-0097](../tickets/zn-0097.md) | Build the household obligations pack | S2 | component | ZN-0096 |
| [ZN-0098](../tickets/zn-0098.md) | Build confectionery orders and inventory pack | S2 | component | ZN-0097 |
| [ZN-0099](../tickets/zn-0099.md) | Generate audience-appropriate surfaces from one pack | S2 | component | ZN-0098 |
| [ZN-0100](../tickets/zn-0100.md) | Prove three-source bakery correction without redeployment | S2 | journey | ZN-0099 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[domain-packs-and-marketplace.md](../baseline/v2/technical-blueprint/reference/domain-packs-and-marketplace.md) · [ontology-and-standards.md](../baseline/v2/technical-blueprint/reference/ontology-and-standards.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
