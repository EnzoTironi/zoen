# SPEC-027 — Living World charts, tables, timelines and safe Focus

**Milestone:** S5 · **Accountable function:** Experience · **Implementation root:** `apps/web/src/living-world` · **Status:** specified, not implemented.

## Decision and intended behavior

Conversation and visual inspection share one semantic subject and basis. Dense views use released descriptors and authorized Frames, never direct database queries. Chart code does not become an execution escape hatch.

## Owned state and storage contract

Presentation definitions: ViewDefinition, ChartDocument, TableDefinition and FocusLens. Instance preferences remain Eve-owned data. Frame/Focus refs are opaque; browser caches include current principal/World/security revision and are discarded on logout/rebind.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
OpenFocus(focus,freshGrant) -> Historical|Newer|UnavailableView; RenderChart(chartDocument,frame) -> AccessibleView; ExportView(frame,format,destination) -> AuthorizedExportCase.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use ECharts only for declared chart primitives and data; reject executable formatters and arbitrary HTML. Preserve zero/missing/unknown/disputed states in charts. Text/table alternatives expose the same permitted data. A view move may request a newer Frame but must label it; historical intent is not silently replaced.

V4 refinement: Views and exports reuse the early SPEC-052 app renderer and shared semantic client. Do not introduce direct SQL/chart/index endpoints. Evidence references and provenance are preserved through display transformations.

## Dependencies and sequencing

Referenced specs: [012](spec-012.md), [025](spec-025.md), [026](spec-026.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0159](../tickets/zn-0159.md) | Define ChartDocument and table/timeline contracts | S5 | component | ZN-0073, ZN-0152, ZN-0158 |
| [ZN-0160](../tickets/zn-0160.md) | Render accessible multi-density inspections | S5 | journey | ZN-0159 |
| [ZN-0161](../tickets/zn-0161.md) | Preserve Focus across chat and visual deepening | S5 | journey | ZN-0160 |
| [ZN-0162](../tickets/zn-0162.md) | Make exports and shared-device behavior rights preserving | S5 | component | ZN-0161, ZN-0203 |
| [ZN-0163](../tickets/zn-0163.md) | Prove dense-view usability and basis parity | S5 | journey | ZN-0162 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
