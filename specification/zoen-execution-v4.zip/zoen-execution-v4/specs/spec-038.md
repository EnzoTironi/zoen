# SPEC-038 — Enterprise SSO, SCIM and workload identity lifecycle

**Milestone:** S9 · **Accountable function:** Enterprise Security · **Implementation root:** `packages/door/src/enterprise` · **Status:** specified, not implemented.

## Decision and intended behavior

Enterprise identity assertions do not replace World policy. Directory groups map into explicit governed membership rules. Deprovisioning is a security transition that invalidates grants, pending disclosure and new effect permits without erasing historical accountability.

## Owned state and storage contract

door.enterprise_connections(connection_id PK,organization_ref,protocol,issuer,metadata_digest,state); door.directory_subjects(connection_id,external_id PK,principal_ref,version,active); ontology.directory_mappings(mapping_id PK,world_id,connection_id,group_ref,role_scope,release_ref); audit.provisioning_events(event_id PK,connection_id,provider_event_ref,state,receipt_ref). Workloads have distinct principals, not shared human sessions.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AuthenticateEnterprise(assertion,connection) -> PresenceProof; ApplyDirectoryChange(connection,event) -> ProvisioningReceipt; ReconcileDirectory(connection,cut) -> Differences; MintWorkloadIdentity(scope) -> NarrowCredential.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Validate issuer/audience/signatures through admitted provider libraries and metadata rotation profiles. Use stable external subject IDs, not email matching. SCIM create/update/deactivate is idempotent with revision guards. Group mapping cannot auto-grant beyond released policy. Deactivation revokes access conservatively; restoring a user is a fresh authorized transition, not replay of old groups.

## Dependencies and sequencing

Referenced specs: [018](spec-018.md), [019](spec-019.md), [026](spec-026.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0219](../tickets/zn-0219.md) | Admit enterprise OIDC/SAML connections | S9 | component | ZN-0111, ZN-0117, ZN-0158 |
| [ZN-0220](../tickets/zn-0220.md) | Implement idempotent SCIM provisioning and deactivation | S9 | component | ZN-0219 |
| [ZN-0221](../tickets/zn-0221.md) | Govern directory-group to World-role mappings | S9 | component | ZN-0220 |
| [ZN-0222](../tickets/zn-0222.md) | Implement workload identities and delegated clients | S9 | component | ZN-0221 |
| [ZN-0223](../tickets/zn-0223.md) | Prove deprovisioning across in-flight work | S9 | journey | ZN-0222 |
| [ZN-0224](../tickets/zn-0224.md) | Qualify enterprise identity provider operations | S9 | admission | ZN-0223 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md) · [security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
