# SPEC-052 — Early declarative mini apps as released data

**Milestone:** S2 · **Accountable function:** Ontology and Product Runtime · **Implementation root:** `packages/ontology/src/apps` · **Status:** specified, not implemented.

## Decision and intended behavior

Most mini apps are immutable bounded definitions referencing existing semantic operations. Trusted renderer components run without generated JS, SQL or backend deployment. User and agent author the same definition/change operations; temporary presentation state is not company truth.

## Owned state and storage contract

MiniAppDefinition closes over appId, pages, approved component registry versions, query/action bindings, form schemas, requested capabilities, resource budget and accessibility labels. It is immutable release content. AppPublicationBinding(appId, manifestDigest, mode, optional artifactDigest, runtimeProfileRef) belongs to the released graph. Drafts remain existing builder_drafts; no mutable runtime latest alias is authority.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ValidateMiniApp(definition,baseRelease) -> ValidatedManifest|Errors; InstantiateAppTemplate(template,parameters) -> DefinitionChange|InstanceAction; PublishApp(change) -> existing release process; OpenView(session,bindings) -> SemanticCalls through SPEC-050.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

No eval, arbitrary HTML/script, provider URL, SQL or hidden direct data bindings in declarative mode. Operators and component versions are allowlisted and bounded. Queries use stable semantic IDs and exact authorized basis; display transformations cannot manufacture authoritative metrics. Create, publish and share are separate. Runtime compilation of an executable app is not app activation.

## Dependencies and sequencing

Referenced specs: [013](spec-013.md), [014](spec-014.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Detailed contract: [mini-app definitions and lifecycle](../architecture/mini-app-contract.md). ZN-0203 supplies the trusted renderer at S2; these tickets supply its semantic definitions. Full S8 Studio reuses both.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0302](../tickets/zn-0302.md) | Define bounded MiniAppDefinition and manifest schemas | S2 | component | ZN-0078, ZN-0291 |
| [ZN-0303](../tickets/zn-0303.md) | Bind declarative app queries and forms to published operations | S2 | component | ZN-0083, ZN-0302 |
| [ZN-0304](../tickets/zn-0304.md) | Publish app definitions through existing release activation | S2 | component | ZN-0086, ZN-0303 |
| [ZN-0305](../tickets/zn-0305.md) | Ship the private read-only mini-app first-use journey | S2 | journey | ZN-0061, ZN-0203, ZN-0299, ZN-0304 |
| [ZN-0306](../tickets/zn-0306.md) | Bind mini-app forms to host-controlled ActionCase confirmations | S4 | component | ZN-0133, ZN-0138, ZN-0299, ZN-0305 |
| [ZN-0307](../tickets/zn-0307.md) | Implement uninstall, recall and compatible app upgrades | S8 | component | ZN-0172, ZN-0215, ZN-0306 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
