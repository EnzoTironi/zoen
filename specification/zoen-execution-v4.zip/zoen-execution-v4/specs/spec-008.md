# SPEC-008 — Baseline observability, local operations and safe migration preparation

**Milestone:** S0 · **Accountable function:** Operations · **Implementation root:** `packages/telemetry/src` · **Status:** specified, not implemented.

## Decision and intended behavior

Operational visibility and recovery start with the first truthful outcome. Logs are not semantic receipts. Legacy data is never reset because a repository looks empty. A restore starts read-only with effects disabled.

## Owned state and storage contract

audit.operational_events(event_id PK,world_ref_nullable,actor_ref,kind,redacted_payload,occurred_at,retention_class); jobs.recovery_fences(cell_id PK,epoch,dispatch_enabled,deletion_ledger_cut); infra migration manifest contains legacy source commit, row counts, rights mapping and unmatched records.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Health() -> Liveness; Readiness() -> AdmittedDependencies; ExportOperationalEvidence(scope) -> RedactedReport; RestoreAdmission(backupRef,deletionCut,effectLedger) -> ReadOnlyReady | Blocked.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Attach request, World, commit, case and effect correlation IDs without recording raw documents, model prompts or hidden reasoning. Persist redaction policy tests. Backup evidence and authority coherently enough to detect unavailable objects; reconcile missing objects, never fabricate them. Disable outbound effects after restore until deletion and escaped-request reconciliation complete.

## Dependencies and sequencing

Referenced specs: [003](spec-003.md), [007](spec-007.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0047](../tickets/zn-0047.md) | Implement structured telemetry and redaction | S0 | component | ZN-0024, ZN-0046 |
| [ZN-0048](../tickets/zn-0048.md) | Implement readiness, admission flags and graceful drain | S0 | component | ZN-0047 |
| [ZN-0049](../tickets/zn-0049.md) | Prove backup and restore in a disposable environment | S0 | chaos | ZN-0048 |
| [ZN-0050](../tickets/zn-0050.md) | Create non-destructive legacy import qualification | S0 | component | ZN-0049 |
| [ZN-0051](../tickets/zn-0051.md) | Accept the S0 truth-without-chat journey | S0 | journey | ZN-0050 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md) · [capacity-economics-and-slos.md](../baseline/v2/technical-blueprint/reference/capacity-economics-and-slos.md) · [migration-and-adoption.md](../baseline/v2/technical-blueprint/reference/migration-and-adoption.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
