# SPEC-032 — Governed batch, incremental, CDC and stream data flows

**Milestone:** S7 · **Accountable function:** Data Platform · **Implementation root:** `packages/ontology/src/flows` · **Status:** specified, not implemented.

## Decision and intended behavior

A FlowDefinition is a bounded released DAG with source, transform, quality and publish nodes. It produces proposed captures/datasets, not direct authority writes. Watermarks, gaps, late events and schema evolution remain visible; unknown quality is not passing quality.

## Owned state and storage contract

ontology.flow_definitions are released data; jobs.flow_runs(run_id PK,world_id,definition_digest,input_cut,state,attempt,budget_ref); jobs.flow_partitions(run_id,partition PK,cursor,watermark,gaps_json,fence,state); ontology.lineage_edges(output_ref,input_ref,field_mapping_digest PK); ontology.quality_results(result_id PK,run_id,check_id,status,coverage,details_ref).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
RunFlow(definition,inputs) -> FlowRun; CheckpointPartition(run,partition,fence,cursor) -> Progress; EvaluateQuality(check,inputCoverage) -> pass|fail|unknown; ProposeFlowPublication(run) -> DatasetProposal | Blocked.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Persist node intents and idempotent output identities. Consume batch/incremental/CDC with source-specific replay contracts; no universal exactly-once source promise. Late changes produce new versions and invalidation. Missing partitions prevent complete aggregate/negative assertions. Track field-level transform lineage including model/executable versions. Multi-node retries reuse captured immutable inputs where valid.

## Dependencies and sequencing

Referenced specs: [031](spec-031.md), [015](spec-015.md), [020](spec-020.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0186](../tickets/zn-0186.md) | Define released flow DAGs and bounded node types | S7 | component | ZN-0094, ZN-0123, ZN-0185 |
| [ZN-0187](../tickets/zn-0187.md) | Implement durable batch and incremental flow runs | S7 | component | ZN-0186 |
| [ZN-0188](../tickets/zn-0188.md) | Implement source-specific CDC checkpoint and gap behavior | S7 | component | ZN-0187 |
| [ZN-0189](../tickets/zn-0189.md) | Implement event-time watermarks and late corrections | S7 | component | ZN-0188 |
| [ZN-0190](../tickets/zn-0190.md) | Implement field-level lineage and tri-state quality gates | S7 | component | ZN-0189 |
| [ZN-0191](../tickets/zn-0191.md) | Prove enterprise revenue reconciliation through data flows | S7 | journey | ZN-0190 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md) · [connectors-and-ingestion.md](../baseline/v2/technical-blueprint/reference/connectors-and-ingestion.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
