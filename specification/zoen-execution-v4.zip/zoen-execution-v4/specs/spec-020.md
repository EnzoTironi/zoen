# SPEC-020 — Semantic Watches, Notices and quiet attention

**Milestone:** S3 · **Accountable function:** Ontology and Eve · **Implementation root:** `packages/ontology/src/attention` · **Status:** specified, not implemented.

## Decision and intended behavior

Ontology decides whether a committed semantic change is material; Eve decides whether, when and how to interrupt. Raw ticks and arbitrary source row changes never directly wake the model. Deferred Notices contain references, not permanently authorized payloads.

## Owned state and storage contract

ontology.watches(watch_id PK,world_id,definition_digest,subject_scope,state,checkpoint_cut,materiality_state); ontology.notices(notice_id PK,watch_id,transition_identity,basis_ref,state,UNIQUE(watch_id,transition_identity)); eve.attention(notice_id,relationship_id PK,state,reason,not_before,merge_group,last_checked_rights); ontology.subscriptions(subscription_id PK,world_id,plan_digest,cursor,state).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CreateWatch(definition,scope,operationId) -> Watch; EvaluateWatch(watch,commitEnvelope) -> Checkpoint | Notice; DecideAttention(noticeRef,relationship) -> Deliver | Merge | Defer | Silence; PauseWatch/ResumeWatch/CancelWatch -> Receipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Consume complete commits with per-domain cursors. Maintain explicit stale-data transitions. Deduplicate by semantic transition identity, not a timestamp. A Notice is durable even if no message is sent. Before composition and delivery Eve fetches a freshly authorized Notice view. Revocation suppresses it; quiet hours and channel consent can defer it. Management views explain suppressions without revealing hidden changes.

V4 refinement: Mini-app subscriptions use the same released subscription operations and semantic Notice/Watch mechanisms as other clients. Reauthorize before every dispatch; revoked clients receive no data-bearing tombstone or hidden-object count.

## Dependencies and sequencing

Referenced specs: [017](spec-017.md), [018](spec-018.md), [019](spec-019.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0118](../tickets/zn-0118.md) | Implement runtime Watch definitions and lifecycle | S3 | component | ZN-0105, ZN-0111, ZN-0117 |
| [ZN-0119](../tickets/zn-0119.md) | Evaluate material changes and stale-data transitions | S3 | component | ZN-0118 |
| [ZN-0120](../tickets/zn-0120.md) | Implement Eve attention arbitration | S3 | component | ZN-0119 |
| [ZN-0121](../tickets/zn-0121.md) | Reauthorize deferred Notices before composition and send | S3 | component | ZN-0120 |
| [ZN-0122](../tickets/zn-0122.md) | Expose Watch inspector and subscription recovery | S3 | component | ZN-0121 |
| [ZN-0123](../tickets/zn-0123.md) | Prove quiet-attention journey under duplicate and delayed delivery | S3 | journey | ZN-0122 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[watches-mandates-and-outcomes.md](../baseline/v2/technical-blueprint/reference/watches-mandates-and-outcomes.md) · [messaging-channels.md](../baseline/v2/technical-blueprint/reference/messaging-channels.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
