# SPEC-051 — Authority-free continuation links and scoped application sessions

**Milestone:** S1 · **Accountable function:** Identity and Application Host · **Implementation root:** `packages/ontology/src/continuations` · **Status:** specified, not implemented.

## Decision and intended behavior

A link identifies an authorized continuation target; it is never a bearer World grant. Opening, authenticating, approving publication and sharing are distinct operations. Reuse Focus and Door; no second login or mini-app ACL database.

## Owned state and storage contract

ontology.continuations(link_ref PK,world_id,realm,focus_ref,target_kind,target_ref,version_policy,recipient_constraint_nullable,expires_at_nullable,state,creator,created_receipt); target_kind=focus|app. ontology.app_sessions(session_ref PK,world_id,realm,principal,actor,installation_ref_nullable,publication_binding,scope_digest,purpose,assurance,security_revision,expires_at,state). Relationships/World grants remain existing ontology records. Opaque handles have at least 192 random bits; logs are redacted. Door owns browser challenge records, not app business permissions.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CreateContinuation(target,scope,recipient?,expiry?,operationId) -> LinkRef; ResolveContinuation(ref) -> GenericLanding|AuthorizedTarget; OpenApp(ref,verifiedPresence) -> AppSession|Denied; RevokeContinuation(ref) -> Receipt; RevokeAppSession(ref) -> Receipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

GET/HEAD, previews and unauthenticated asset requests are generic and side-effect free. POST exchange uses CSRF/origin protections, a browser-bound challenge and verified identity before disclosure. No access token in the URL. Invitation acceptance is a separate governed operation. Every later semantic call checks current rights; link expiry and session revocation are enforced independently. Archived historical views use current rights and cannot reactivate recalled code.

## Dependencies and sequencing

Referenced specs: [002](spec-002.md), [007](spec-007.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Detailed routes, challenge states, version modes, scopes and cache behavior: [protected links](../architecture/protected-links.md). S1 only supports private Focus; S2 adds private app continuation; S3 admits sharing. Application sessions never substitute for current semantic authorization.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0296](../tickets/zn-0296.md) | Implement authority-free continuation references over Focus | S1 | component | ZN-0015, ZN-0291 |
| [ZN-0297](../tickets/zn-0297.md) | Implement browser-bound authenticated continuation exchange | S1 | component | ZN-0013, ZN-0296 |
| [ZN-0298](../tickets/zn-0298.md) | Verify link preview, logout and shared-device privacy | S1 | journey | ZN-0073, ZN-0297 |
| [ZN-0299](../tickets/zn-0299.md) | Implement scoped app-session open, expiry and revocation | S2 | component | ZN-0293, ZN-0297, ZN-0304 |
| [ZN-0300](../tickets/zn-0300.md) | Share app references without changing membership or lending rights | S3 | component | ZN-0107, ZN-0299 |
| [ZN-0301](../tickets/zn-0301.md) | Prove protected app access in deployed host and browser profiles | S3 | admission | ZN-0290, ZN-0298, ZN-0300 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
