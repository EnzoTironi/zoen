# SPEC-017 — Clarification prioritization and scoped stewardship

**Milestone:** S2 · **Accountable function:** Knowledge and Experience · **Implementation root:** `packages/ontology/src/stewardship` · **Status:** specified, not implemented.

## Decision and intended behavior

Ask the right authorized person about consequential uncertainty, not everybody about every mismatch. A deterministic rubric ranks questions; no fabricated probability of truth. Teaching a reusable rule requires its own governed change.

## Owned state and storage contract

ontology.clarifications(question_id PK,world_id,subject,predicate,scope_digest,candidate_digest,basis_ref,impact,deadline,state,steward_ref); ontology.stewardships(stewardship_id PK,world_id,scope,principal_ref,authority_kind,valid_interval); eve.question_delivery(question_id,relationship_id PK,attention_state,last_presented_digest). Deduplicate by world/subject/predicate/scope/candidate version.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
RankClarifications(scope,budget) -> QuestionQueue; AssignSteward(question,principal) -> Assignment; AnswerQuestion(question,digest,answerKind,payload,operationId) -> ScopedReceipt | RuleDraft | Stale.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Rank by consequence severity, deadline, reducibility and interruption/privacy cost using declared ordinal weights. Route only to authorized stewards with required evidence visibility. User reply kinds are assertion, identity resolution, instance decision, reusable-rule proposal and preference. Unknown/dismissal never votes. Changes to candidate set invalidate queued question versions.

## Dependencies and sequencing

Referenced specs: [006](spec-006.md), [010](spec-010.md), [014](spec-014.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0101](../tickets/zn-0101.md) | Rank and deduplicate clarification candidates | S2 | component | ZN-0041, ZN-0062, ZN-0088 |
| [ZN-0102](../tickets/zn-0102.md) | Route questions using scoped stewardship | S2 | component | ZN-0101 |
| [ZN-0103](../tickets/zn-0103.md) | Keep five reply meanings distinct | S2 | component | ZN-0102 |
| [ZN-0104](../tickets/zn-0104.md) | Support stale questions, unknown answers and reversals | S2 | component | ZN-0103 |
| [ZN-0105](../tickets/zn-0105.md) | Expose stewardship workbench and quality feedback | S2 | journey | ZN-0104 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[truth-reconciliation-and-learning.md](../baseline/v2/technical-blueprint/reference/truth-reconciliation-and-learning.md) · [runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
