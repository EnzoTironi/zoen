# SPEC-004 — Retained evidence and file-based source admission

**Milestone:** S0 · **Accountable function:** Data · **Implementation root:** `packages/ontology/src/evidence` · **Status:** specified, not implemented.

## Decision and intended behavior

Bytes are captured before semantic admission. A hash authenticates byte identity, not factual truth. The initial slice accepts authorized text/CSV/JSON and bounded attachments; rich extraction is added through isolated, attributed extractors.

## Owned state and storage contract

ontology.source_bindings(binding_id PK,world_id,definition_id,state,credential_ref,acl_revision); ontology.captures(capture_id PK,world_id,binding_id,source_namespace,external_id,revision,blob_ref,digest,acquired_at,state,UNIQUE(world_id,binding_id,external_id,revision,digest)); ontology.evidence(evidence_id PK,world_id,capture_id,rights_ref,validity_json,retention_ref,admission_commit); ontology.source_admissions(binding_id,capture_id,mapping_digest PK,receipt_id). Object keys are opaque World/realm-scoped; object digests are internal.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
StageCapture(binding,stream,declaredMetadata) -> CaptureRef | Quarantined; AdmitCapture(captureRef,mappingDigest,operationId) -> AdmissionReceipt; ReadEvidence(evidenceRef,grant) -> AuthorizedStream | HistoricalContentUnavailable.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Enforce size/type/count limits while streaming; verify final digest and durable storage before admission. Source namespace and revision form identity, not file names. Runtime records reference secrets but do not contain them. One admission writes evidence, claims, receipt and outbox atomically. Failed admission leaves a quarantined/orphaned capture with a cleanup policy. Missing source output is not deletion.

## Dependencies and sequencing

Referenced specs: [003](spec-003.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0025](../tickets/zn-0025.md) | Stage bounded artifacts with integrity and quarantine | S0 | component | ZN-0024 |
| [ZN-0026](../tickets/zn-0026.md) | Map source records into attributed evidence | S0 | component | ZN-0025 |
| [ZN-0027](../tickets/zn-0027.md) | Enforce evidence reads through current rights | S0 | component | ZN-0026 |
| [ZN-0028](../tickets/zn-0028.md) | Implement initial CSV and JSON extraction profiles | S0 | component | ZN-0027 |
| [ZN-0029](../tickets/zn-0029.md) | Handle capture orphans and retention pins safely | S0 | component | ZN-0028 |
| [ZN-0030](../tickets/zn-0030.md) | Prove the two-source file journey end to end | S0 | journey | ZN-0029 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[connectors-and-ingestion.md](../baseline/v2/technical-blueprint/reference/connectors-and-ingestion.md) · [truth-reconciliation-and-learning.md](../baseline/v2/technical-blueprint/reference/truth-reconciliation-and-learning.md) · [data-events-parquet.md](../baseline/v2/technical-blueprint/reference/data-events-parquet.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
