# SPEC-005 — Comparable claims, interpretations and scoped correction

**Milestone:** S0 · **Accountable function:** Knowledge · **Implementation root:** `packages/ontology/src/interpretation` · **Status:** specified, not implemented.

## Decision and intended behavior

Compare meaning before comparing values. Preserve selection, contestation and verification separately. Initial resolution uses deterministic released precedence, never majority voting or model confidence. Human replies are attributed claims or decisions, not automatic global rules.

## Owned state and storage contract

ontology.claims(claim_id PK,world_id,subject_id,predicate_id,value_json,unit,scope_json,valid_from,valid_until,source_family,evidence_refs,asserted_by,domain_id,knowledge_version); ontology.claim_edges(world_id,parent_id,child_id,kind PK); ontology.interpretations(interpretation_id PK,world_id,query_digest,release_digest,cut_digest,perspective,status,verification,contested,selected_refs,rival_refs,dependency_refs); ontology.corrections(correction_id PK,world_id,target_claim,successor_claim,actor,case_ref,receipt_ref). Values are immutable except governed erasure.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CompareClaims(claims,meaningProfile) -> ComparableGroups; Interpret(query,basis,perspective) -> Interpretation; ApplyScopedReply(caseId,questionDigest,answer,operationId) -> CorrectionReceipt | Stale; Explain(interpretationId,grant) -> ExplanationFrame.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Group only equal subject identity, predicate semantics, compatible scope/time/unit and version basis. Count copied/derived source families once. A declared precedence can select a claim while contested remains true. No authorized evidence yields unknown; competing unranked evidence yields unresolved. Retractions append edges and revisions. Recompute descendants with cycle detection and leave active consumers stale until their projection cut catches up.

## Dependencies and sequencing

Referenced specs: [004](spec-004.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0031](../tickets/zn-0031.md) | Implement comparability before disagreement | S0 | component | ZN-0030 |
| [ZN-0032](../tickets/zn-0032.md) | Collapse dependent source families without deleting provenance | S0 | law | ZN-0031 |
| [ZN-0033](../tickets/zn-0033.md) | Implement deterministic interpretation outcomes | S0 | component | ZN-0032 |
| [ZN-0034](../tickets/zn-0034.md) | Apply a human correction with exact scope and undo | S0 | component | ZN-0033 |
| [ZN-0035](../tickets/zn-0035.md) | Propagate correction impact and expose quality dimensions | S0 | component | ZN-0034 |
| [ZN-0036](../tickets/zn-0036.md) | Prove point-in-time and visible-perspective reconciliation | S0 | component | ZN-0035 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[truth-reconciliation-and-learning.md](../baseline/v2/technical-blueprint/reference/truth-reconciliation-and-learning.md) · [identity-and-time.md](../baseline/v2/technical-blueprint/reference/identity-and-time.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
