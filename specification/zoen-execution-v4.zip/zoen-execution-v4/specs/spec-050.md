# SPEC-050 — One semantic executor and transport-only client contract

**Milestone:** S0 · **Accountable function:** Kernel and Client Platform · **Implementation root:** `packages/ontology/src/surfaces` · **Status:** specified, not implemented.

## Decision and intended behavior

Name and extend SPEC-007 dispatch.ts as the single SemanticExecutor. No generic app API, policy clone, agent-only read path or LLM requirement. Surface adapters translate transport only. Equality is semantic at equal principal/delegation, audience, purpose, app constraints, release, cut and source rights; no requirement for byte-identical presentation.

## Owned state and storage contract

No new authority store. Reuse operation registry, grants, read guards, ActionCases, receipts and outbox. Descriptor/cache keys bind world, principal, delegation, app binding, purpose, release, query digest, cut and security revision. Cursor/chunk handles are references, not bearer permits.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
SemanticCall(envelope, verifiedRequestContext) -> tagged SemanticResult. Discover, Inspect, Propose, AnswerCase, Commit, Subscribe, Export and admitted Analysis are released operation families, not free-form repository methods.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use the existing dispatcher and current disclosure checks for every ingress including resumptions and background calls. Preserve original operationId on retry/continuation; distinct IDs are distinct intentions, not magically deduplicated. Compare normalized meaning rather than prose. Verify context at the server; transport headers never set identity. Bounded batch/async operations reuse per-item policy and exact basis.

## Dependencies and sequencing

Referenced specs: [007](spec-007.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Canonical detailed contract: [semantic path](../architecture/semantic-path.md). Tickets introduce successively richer families; early S0 use does not depend on S3/S7 work.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0291](../tickets/zn-0291.md) | Bind every structured ingress to the existing semantic dispatcher | S0 | component | ZN-0043, ZN-0044 |
| [ZN-0292](../tickets/zn-0292.md) | Enforce client-to-data import and credential boundaries | S0 | static | ZN-0003, ZN-0291 |
| [ZN-0293](../tickets/zn-0293.md) | Bind current app and delegation restrictions in verified context | S2 | component | ZN-0086, ZN-0291 |
| [ZN-0294](../tickets/zn-0294.md) | Implement bounded batch, cursor and export calls on the shared surface | S5 | component | ZN-0158, ZN-0162, ZN-0293 |
| [ZN-0295](../tickets/zn-0295.md) | Unify subscriptions, chunk leases and dense reads without bypass | S7 | component | ZN-0184, ZN-0196, ZN-0294 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[interfaces-sdk-and-mcp.md](../baseline/v2/technical-blueprint/reference/interfaces-sdk-and-mcp.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
