# SPEC-030 — Isolated runners, credential brokers and programmable analysis

**Milestone:** S6 · **Accountable function:** Platform Security · **Implementation root:** `runners` · **Status:** specified, not implemented.

## Decision and intended behavior

Trust isolation is enforced outside guest code. Use the admitted gVisor or microVM-grade profile on dedicated runner infrastructure, not a privileged Docker container. Python/R/SQL analyses are read-only over leased immutable inputs; publishing is a separate governed operation.

## Owned state and storage contract

ontology.execution_leases(lease_id PK,world_id,artifact_digest,principal,purpose,allowed_ops,input_refs,budget_ref,expires_at,epoch,state); jobs.runner_attempts(attempt_id PK,lease_id,host_profile,fence,state,output_ref,usage); ontology.analysis_artifacts(analysis_id PK,world_id,code_digest,input_cut,seed_nullable,determinism,output_ref,lineage,rights_label).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AcquireExecutionLease(installation,inputRefs,scope) -> Lease; BrokerRead(lease,resource) -> BoundedInput; BrokerCall(lease,capability,args) -> Observation; RunAnalysis(lease,artifact) -> AnalysisArtifact | Failed | Unknown.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Deny host filesystem, Docker socket, authority DB, instance metadata and ambient credentials. Validate DNS and every redirect via brokered egress; guest network has default deny. Enforce CPU, memory, time, output, file and request limits outside process. Brokers check lease/body/resource/epoch/revocation on each use. Outputs pass schema/lineage/rights validation before admission.

V4 refinement: Distinguish semantic app calls from source acquisition and provider-effect broker lanes. App-facing BrokerRead/BrokerCall resolves released semantic operations through SPEC-007 only; it cannot expose a URL, arbitrary SQL, raw database handle or provider credential. Trusted connectors and effect workers retain their separately admitted internal roles; apps cannot request those roles.

## Dependencies and sequencing

Referenced specs: [029](spec-029.md), [018](spec-018.md), [023](spec-023.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0174](../tickets/zn-0174.md) | Admit one hardened runner host profile | S6 | component | ZN-0111, ZN-0139, ZN-0173 |
| [ZN-0175](../tickets/zn-0175.md) | Implement narrow lease and capability brokers | S6 | component | ZN-0174 |
| [ZN-0176](../tickets/zn-0176.md) | Enforce SSRF, DNS rebinding and resource ceilings | S6 | component | ZN-0175 |
| [ZN-0177](../tickets/zn-0177.md) | Implement Python, R and SQL read-only analysis profiles | S6 | component | ZN-0176 |
| [ZN-0178](../tickets/zn-0178.md) | Validate outputs, revocation and cancellation | S6 | component | ZN-0177 |
| [ZN-0179](../tickets/zn-0179.md) | Prove isolation with hostile artifacts on actual infrastructure | S6 | admission | ZN-0178 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md) · [security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
