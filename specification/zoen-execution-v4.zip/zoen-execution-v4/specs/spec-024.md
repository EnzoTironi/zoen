# SPEC-024 — Budget conservation, bounded Mandates and observed outcomes

**Milestone:** S4 · **Accountable function:** Kernel and Product · **Implementation root:** `packages/ontology/src/mandates` · **Status:** specified, not implemented.

## Decision and intended behavior

A Mandate is an explicit scope of responsibility, not an unlimited agent loop. It has observable goal, deadline, allowed actions, stop conditions and conserved parent/child budgets. Tool completion never proves the business goal achieved.

## Owned state and storage contract

ontology.budgets(budget_id PK,world_id,parent_ref,unit,limit_amount,reserved_amount,spent_amount,version); ontology.reservations(reservation_id PK,budget_id,case_ref,effect_ref,amount,state); ontology.mandates(mandate_id PK,world_id,goal_definition,scope,action_allowlist,budget_ref,deadline,state,outcome,basis_ref); ontology.mandate_steps(step_id PK,mandate_id,action_case_ref,observation_ref,state).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CreateMandate(definition,scope,budget,operationId) -> Mandate; ReserveBudget(path,amount,operationId) -> Reservation | BudgetExceeded; ObserveGoal(mandate,evidence) -> pending|achieved|failed|unknown|stopped; StopMandate(id) -> StopReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Lock root-to-child budget path in deterministic order, never check cached balance alone. Enforce spend/tokens/steps/fanout/egress ceilings. Unknown financial effects retain reservations until policy and evidence justify release. Escalate or stop on deadline, repeated plan failure, missing observation or revoked scope. Child agents cannot obtain more aggregate authority/resources than the parent.

V4 refinement: Background app jobs act under an explicit workload identity/delegation and bounded Mandate. They do not reuse a departed human browser session or inherit the publisher rights.

## Dependencies and sequencing

Referenced specs: [020](spec-020.md), [022](spec-022.md), [023](spec-023.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0141](../tickets/zn-0141.md) | Implement transactional reservation conservation | S4 | component | ZN-0123, ZN-0134, ZN-0139 |
| [ZN-0142](../tickets/zn-0142.md) | Define and create bounded Mandates | S4 | component | ZN-0141 |
| [ZN-0143](../tickets/zn-0143.md) | Observe business outcome independently of step completion | S4 | component | ZN-0142 |
| [ZN-0144](../tickets/zn-0144.md) | Enforce deadlines, repetition limits and emergency stop | S4 | component | ZN-0143 |
| [ZN-0145](../tickets/zn-0145.md) | Bind household, bakery and clinic actions to shared agency | S4 | journey | ZN-0127, ZN-0144 |
| [ZN-0146](../tickets/zn-0146.md) | Prove full responsibility loop under failures | S4 | chaos | ZN-0145 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[watches-mandates-and-outcomes.md](../baseline/v2/technical-blueprint/reference/watches-mandates-and-outcomes.md) · [actions-effects-and-settlement.md](../baseline/v2/technical-blueprint/reference/actions-effects-and-settlement.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
