# SPEC-023 — Effect execution, provider evidence and honest settlement

**Milestone:** S4 · **Accountable function:** Integrations and Kernel · **Implementation root:** `packages/ontology/src/effects` · **Status:** specified, not implemented.

## Decision and intended behavior

Restate orchestrates narrow durable attempts; PostgreSQL owns EffectIntent, attempts and settlement meaning. No exactly-once claim is made for an arbitrary external provider. Ambiguous unsafe operations reconcile before retry, or stop for evidence.

## Owned state and storage contract

ontology.effect_intents(effect_id PK,world_id,receipt_id,ordinal,provider,operation,intent_digest,args_ref,deadline,UNIQUE(receipt_id,ordinal)); ontology.effect_attempts(attempt_id PK,effect_id,epoch,fence,permit_ref,state,sent_at,provider_key,observation_ref); ontology.settlements(settlement_id PK,effect_id,status,provider_state,evidence_refs,observed_at,supersedes); ontology.provider_contracts(contract_id PK,provider,api_version,idempotency_scope,horizon,reconciliation_modes,certificate_ref).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AcquireEffectPermit(intent,worker,epoch) -> Permit | Denied; AttemptEffect(intent,permit) -> AttemptObservation; ReconcileEffect(effectId) -> ObservedState | Unknown; RecordSettlement(effectId,providerEvidence) -> SettlementReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Derive stable effect identity from receipt plus ordinal. Request a narrow lease binding destination/account/amount/deadline/epoch and current deny state. Persist attempt before network. Capture exact authorized provider evidence. Provider acceptance, delivery, business success and financial settlement are distinct. Do not auto-retry a transmitted ambiguous non-idempotent request through generic ctx.run retry behavior. A compensation is a new Action.

V4 refinement: An app has no generic provider-write path through a runner broker. Consequential provider calls consume the existing committed EffectIntent and current effect permit; a runtime success response is not settlement.

## Dependencies and sequencing

Referenced specs: [022](spec-022.md), [011](spec-011.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0135](../tickets/zn-0135.md) | Admit Restate and narrow durable handler contract | S4 | component | ZN-0068, ZN-0134 |
| [ZN-0136](../tickets/zn-0136.md) | Issue just-in-time effect permits with current fences | S4 | component | ZN-0135 |
| [ZN-0137](../tickets/zn-0137.md) | Record attempt and ambiguous outcome states | S4 | component | ZN-0136 |
| [ZN-0138](../tickets/zn-0138.md) | Implement provider reconciliation and callback deduplication | S4 | component | ZN-0137 |
| [ZN-0139](../tickets/zn-0139.md) | Implement cancellation and compensation honestly | S4 | component | ZN-0138 |
| [ZN-0140](../tickets/zn-0140.md) | Qualify one actual external action and reconciliation profile | S4 | admission | ZN-0139 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[actions-effects-and-settlement.md](../baseline/v2/technical-blueprint/reference/actions-effects-and-settlement.md) · [technology-stack.md](../baseline/v2/technical-blueprint/reference/technology-stack.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
