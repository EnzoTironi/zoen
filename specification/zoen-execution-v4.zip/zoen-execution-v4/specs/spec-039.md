# SPEC-039 — Dedicated regional cells, private networking and recovery

**Milestone:** S9 · **Accountable function:** Operations Security · **Implementation root:** `infra/terraform/aws` · **Status:** specified, not implemented.

## Decision and intended behavior

Use the selected AWS regional-cell profile with service/version/extension availability verified at provisioning. Dedicated cells add measured isolation and recovery, not a marketing flag. Durable Restate/catalog state never relies on ephemeral worker storage.

## Owned state and storage contract

Infrastructure state describes account/region/cell, authority database, object namespaces, KMS keys, private endpoints, workload identities, backup policy and admitted image digests. control.cells(cell_id PK,region,profile,epoch,admission_ref,state); audit.recovery_runs(run_id PK,cell_id,backup_ref,measured_rpo,measured_rto,evidence_ref). Customer content stays out of the directory/control plane.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProvisionCell(profile,region,lock) -> StagedCell; AdmitCell(evidence) -> ActiveCell; RestoreCell(backup,ledger,profile) -> ReadOnlyCell; OpenPrivateConnector(profile) -> ScopedRoute.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Separate trusted edge/Eve/authority/effects/runner identities and networks. RDS HA/PITR, S3/KMS controls and native service availability are admitted per region. Restore effects disabled and reconcile deletion/escaped effects before write admission. Dedicated keys/account boundaries are policy-selected and tested. Self-hosted equivalence belongs to S10, not an untested Terraform claim.

## Dependencies and sequencing

Referenced specs: [038](spec-038.md), [031](spec-031.md), [049](spec-049.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0225](../tickets/zn-0225.md) | Provision dedicated cell network and identity boundaries | S9 | component | ZN-0185, ZN-0223, ZN-0289 |
| [ZN-0226](../tickets/zn-0226.md) | Configure authority, evidence and catalog durability | S9 | component | ZN-0225 |
| [ZN-0227](../tickets/zn-0227.md) | Admit durable Restate deployment and effect recovery | S9 | component | ZN-0226 |
| [ZN-0228](../tickets/zn-0228.md) | Implement residency, keys and private connectivity controls | S9 | component | ZN-0227 |
| [ZN-0229](../tickets/zn-0229.md) | Run recovery drills with measured RPO/RTO | S9 | chaos | ZN-0228 |
| [ZN-0230](../tickets/zn-0230.md) | Admit the enterprise hosted profile | S9 | admission | ZN-0229 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[deployment-cells-and-federation.md](../baseline/v2/technical-blueprint/reference/deployment-cells-and-federation.md) · [security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md) · [technology-stack.md](../baseline/v2/technical-blueprint/reference/technology-stack.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
