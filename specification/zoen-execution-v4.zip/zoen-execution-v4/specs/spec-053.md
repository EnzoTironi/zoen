# SPEC-053 — Isolated app host and transport-only bridge

**Milestone:** S6 · **Accountable function:** Platform Security and Browser Host · **Implementation root:** `packages/clients/src/app-host` · **Status:** specified, not implemented.

## Decision and intended behavior

Generated frontend code is hostile. Serve an immutable bundle on an isolated, cookieless app origin and mediate messages in trusted host chrome. A specialized backend runs outside authority with explicit leases. Bridge validation adds containment, not domain permission or business logic.

## Owned state and storage contract

No business authority store. Host-owned ephemeral bridge state records window identity, session binding, exact guest origin, channel nonce, request sequence, publication/artifact digest and bounded pending calls. Runner state keys include World/realm/principal/purpose/installation/version/session; shared collaboration is separately admitted. Private response/cache state is never keyed only by appId.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
BindAppFrame -> BridgeBinding; TransportSemanticCall(binding,request) -> existing SemanticExecutor; CloseAppSession -> close/drain; StageStaticBundle(artifact) -> nonpublic immutable asset ref. Host confirmation invokes existing ActionCase operations.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Host-only HttpOnly secure sessions; no cookies/Authorization/X-Forwarded identity reach guest code. Default deny guest network APIs, top navigation, forms, popups, downloads and service workers; browser self-navigation is not assumed preventable. Private data enters executable frontends only under the admitted disclosure profile in the host contract. Exact allowed origins/MessagePort binding and typed messages prevent confused deputy calls. No generic fetch or direct provider broker. Untrusted runtime runs in qualified external containment, never inside the authority process.

## Dependencies and sequencing

Referenced specs: [029](spec-029.md), [030](spec-030.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


[Browser and runner threat contract](../architecture/app-host-security.md). ZN-0204 composes this host with the existing application shell; it does not rewrite the bridge. Admission is independent of the declarative app path.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0308](../tickets/zn-0308.md) | Provision isolated origins and signed private asset serving | S6 | component | ZN-0171, ZN-0174, ZN-0299 |
| [ZN-0309](../tickets/zn-0309.md) | Implement strict message bridge into the existing SemanticClient | S6 | component | ZN-0293, ZN-0308 |
| [ZN-0310](../tickets/zn-0310.md) | Strip credentials and isolate backend identity and mutable state | S6 | component | ZN-0175, ZN-0176, ZN-0309 |
| [ZN-0311](../tickets/zn-0311.md) | Enforce session revocation, streaming and host confirmation boundaries | S6 | component | ZN-0157, ZN-0306, ZN-0310 |
| [ZN-0312](../tickets/zn-0312.md) | Admit the real isolated executable browser-host profile | S6 | admission | ZN-0179, ZN-0301, ZN-0311 |
| [ZN-0313](../tickets/zn-0313.md) | Qualify negotiated MCP Apps host and safe link fallback | S6 | admission | ZN-0205, ZN-0312 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
