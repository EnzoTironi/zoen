# SPEC-036 — Read-only scenarios, notebooks and evaluated model artifacts

**Milestone:** S8 · **Accountable function:** Analytics · **Implementation root:** `packages/ontology/src/scenarios` · **Status:** specified, not implemented.

## Decision and intended behavior

Scenarios branch hypothetical assumptions from an explicit retained basis without live effects. Notebooks and training runs are isolated analyses with data-use lineage. Applying a recommendation always creates a fresh live Case against current facts.

## Owned state and storage contract

ontology.scenarios(scenario_id PK,world_id,base_cut,assumptions_ref,analysis_refs,state,rights_label); ontology.model_artifacts(model_digest PK,training_manifest,code_digest,evaluation_ref,rights_label,retention_policy,admission_state); ontology.scenario_comparisons(comparison_id PK,scenario_refs,metric_definition,coverage,output_ref).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CreateScenario(base,assumptions) -> Scenario; RunScenario(scenario,analysis) -> HypotheticalResult; CompareScenarios(ids,metric) -> ComparisonFrame; ProposeFromScenario(resultRef,currentGrant) -> FreshLiveCase; AdmitModelArtifact(manifest,eval) -> CandidateModel.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Display hypothetical status, source cut, assumptions and uncertainty in every surface. A scenario cannot carry live effect leases. Point-in-time analysis excludes later revisions/identity mappings unless explicitly labeled. Training requires input rights for that purpose, is off across customers by default, and produces lineage-bound artifacts that can be recalled when data-use obligations change.

## Dependencies and sequencing

Referenced specs: [024](spec-024.md), [030](spec-030.md), [031](spec-031.md), [034](spec-034.md), [035](spec-035.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0207](../tickets/zn-0207.md) | Implement scenario branches and hypothetical data overlays | S8 | component | ZN-0146, ZN-0178, ZN-0185, ZN-0200, ZN-0206 |
| [ZN-0208](../tickets/zn-0208.md) | Compare scenarios with explicit basis and coverage | S8 | component | ZN-0207 |
| [ZN-0209](../tickets/zn-0209.md) | Create a fresh live Case from a hypothetical result | S8 | component | ZN-0208 |
| [ZN-0210](../tickets/zn-0210.md) | Implement notebook and training data-use admission | S8 | component | ZN-0209 |
| [ZN-0211](../tickets/zn-0211.md) | Register and evaluate versioned model artifacts | S8 | component | ZN-0210 |
| [ZN-0212](../tickets/zn-0212.md) | Prove point-in-time analysis and scenario isolation | S8 | journey | ZN-0211 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[models-retrieval-and-agents.md](../baseline/v2/technical-blueprint/reference/models-retrieval-and-agents.md) · [data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md) · [apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
