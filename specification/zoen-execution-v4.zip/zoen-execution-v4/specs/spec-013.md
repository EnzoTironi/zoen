# SPEC-013 — Bounded ontology grammar and deterministic release compiler

**Milestone:** S2 · **Accountable function:** Kernel · **Implementation root:** `packages/ontology/src/definitions` · **Status:** specified, not implemented.

## Decision and intended behavior

Business variation is versioned data executed by a closed, total, bounded grammar. No JavaScript, arbitrary SQL, remote schema fetch or model invocation executes inside authority. One compiler emits semantic plans and all public surface metadata.

## Owned state and storage contract

ontology.definitions(definition_digest PK,namespace,semantic_id,kind,schema_version,canonical_blob_ref); ontology.releases(release_digest PK,graph_root,surface_manifest_ref,kernel_abi,signature_ref,created_by); ontology.definition_refs(parent_digest,child_digest PK,kind). Per-user secrets and customer records never enter reusable releases.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
CompileDefinitionGraph(pinnedInputs,kernelAbi) -> WorldRelease | CompilationErrors; SemanticDiff(base,candidate) -> DiffAndImpact; ValidatePlan(plan,bounds) -> TypedPlan | UnsupportedPlan.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Parse/bound/validate; resolve pinned local namespaces; check stable semantic IDs; type-check units/cardinality/null/effects/realms; reject unsupported cycles; verify resource bounds; classify semantic/security changes; emit typed plans/SurfaceManifest; canonicalize and sign. Preserve ID only when meaning is unchanged. Labels may change; accounting basis cannot silently retain an incompatible meaning.

V4 refinement: The SurfaceManifest is the sole published operation discovery source for humans, agents and apps. SPEC-052 adds a bounded declarative app grammar over this graph, not a second DSL for business meaning.

## Dependencies and sequencing

Referenced specs: [001](spec-001.md), [003](spec-003.md), [007](spec-007.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0075](../tickets/zn-0075.md) | Define object, property, link and interface JSON grammar | S2 | component | ZN-0012, ZN-0024, ZN-0046 |
| [ZN-0076](../tickets/zn-0076.md) | Implement the bounded expression and query IR | S2 | component | ZN-0075 |
| [ZN-0077](../tickets/zn-0077.md) | Compile runtime actions, source mappings and skills | S2 | component | ZN-0076 |
| [ZN-0078](../tickets/zn-0078.md) | Emit a single canonical graph and SurfaceManifest | S2 | component | ZN-0077 |
| [ZN-0079](../tickets/zn-0079.md) | Implement semantic diff, compatibility and blast radius | S2 | component | ZN-0078 |
| [ZN-0080](../tickets/zn-0080.md) | Support explicit standards interchange profiles | S2 | component | ZN-0079 |
| [ZN-0081](../tickets/zn-0081.md) | Prove deterministic compiler and hostile-program limits | S2 | law | ZN-0080 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[ontology-and-standards.md](../baseline/v2/technical-blueprint/reference/ontology-and-standards.md) · [release-engine-and-compiler.md](../baseline/v2/technical-blueprint/reference/release-engine-and-compiler.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
