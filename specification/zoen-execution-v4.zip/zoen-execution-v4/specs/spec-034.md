# SPEC-034 — Virtual sources and distributed/GPU compute adapters

**Milestone:** S7 · **Accountable function:** Data Platform · **Implementation root:** `packages/ontology/src/compute` · **Status:** specified, not implemented.

## Decision and intended behavior

Large/distributed/GPU work runs behind a governed job contract, not inside the authority service. Virtual sources declare their external consistency and retention limitations. An external current query is not automatically a replayable historical basis.

## Owned state and storage contract

jobs.compute_runs(run_id PK,world_id,engine_profile,input_cut,artifact_digest,budget_ref,state,output_ref,usage); ontology.virtual_reads(read_id PK,world_id,source_binding,query_digest,external_snapshot_ref,observed_at,coverage,rights_ref,capture_ref_nullable). Engine configuration and scale parameters are versioned runtime data under an admitted adapter ABI.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ExecuteVirtualRead(plan,lease) -> CapturedResult | ReferenceOnlyResult; SubmitCompute(profile,artifact,inputs,budget) -> Run; ObserveCompute(run) -> State; AdmitComputeOutput(run) -> AnalysisOrDatasetProposal.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use a declared remote snapshot/transaction ID when the source supports it. Otherwise label reference-only/observed-time semantics and block actions requiring immutable retained basis. Distributed engines receive only scoped storage/compute leases and cannot publish directly. GPU nondeterminism is declared; exact output is retained while lawful, with reproducibility limits.

## Dependencies and sequencing

Referenced specs: [030](spec-030.md), [031](spec-031.md), [032](spec-032.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0197](../tickets/zn-0197.md) | Define virtual-source consistency and capture contracts | S7 | component | ZN-0178, ZN-0185, ZN-0191 |
| [ZN-0198](../tickets/zn-0198.md) | Implement governed remote query execution | S7 | component | ZN-0197 |
| [ZN-0199](../tickets/zn-0199.md) | Define distributed and GPU execution lifecycle | S7 | component | ZN-0198 |
| [ZN-0200](../tickets/zn-0200.md) | Validate reproducibility, costs and outputs | S7 | component | ZN-0199 |
| [ZN-0201](../tickets/zn-0201.md) | Qualify the selected external compute profile | S7 | admission | ZN-0200 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md) · [programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
