# SPEC-046 — Market data, portfolio analytics and pre-trade risk

**Milestone:** S11 · **Accountable function:** Finance Domain · **Implementation root:** `packs/finance/analytics` · **Status:** specified, not implemented.

## Decision and intended behavior

Quotes, trades, book depth, positions, available cash and settled holdings have distinct semantics. Analytics pin price/FX/corporate-action and model bases. Pre-trade limits are deterministic governed constraints, not an LLM’s confidence or suitability guess.

## Owned state and storage contract

Released objects: Quote, Trade, OrderBookState, Position, CashBalance, Reservation, Portfolio, Benchmark, ValuationPolicy, RiskLimit and RiskObservation. Dense feeds use exact dataset/capture references; portfolio snapshots contain declared account coverage and adjustment/valuation policy.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ValuePortfolio(portfolio,priceBasis,fxBasis,policy) -> ValuationFrame; EvaluateRisk(orderIntent,basis,limits) -> Pass|Fail|Unknown; InspectDepth(instrument,feedCut,grant) -> EntitledBook | Gapped; CaptureTradeBasis(ref,maxAge) -> EvidenceRef.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Market value uses signed exact quantity × contract multiplier × admitted price × explicit FX factor; every term has source/time/unit. Missing price or account coverage returns incomplete/unknown. Corporate adjustments use versioned policy; raw and adjusted histories stay distinct. Advanced stress/sensitivity/risk models are evaluated artifacts with declared assumptions. Risk checks include restricted lists, exposure/reservation fences and current captured market basis.

## Dependencies and sequencing

Referenced specs: [045](spec-045.md), [033](spec-033.md), [036](spec-036.md), [040](spec-040.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0267](../tickets/zn-0267.md) | Implement entitled quotes, trades and order-book depth | S11 | component | ZN-0196, ZN-0212, ZN-0235, ZN-0265 |
| [ZN-0268](../tickets/zn-0268.md) | Implement positions, balances and reservation-aware availability | S11 | component | ZN-0267 |
| [ZN-0269](../tickets/zn-0269.md) | Implement reproducible valuation, returns and benchmark basis | S11 | component | ZN-0268 |
| [ZN-0270](../tickets/zn-0270.md) | Implement pre-trade risk and restricted-list guards | S11 | component | ZN-0269 |
| [ZN-0271](../tickets/zn-0271.md) | Add evaluated stress and sensitivity analysis profiles | S11 | component | ZN-0270 |
| [ZN-0272](../tickets/zn-0272.md) | Qualify market-data and risk computation profiles | S11 | admission | ZN-0271 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[finance-domain.md](../baseline/v2/technical-blueprint/reference/finance-domain.md) · [data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
