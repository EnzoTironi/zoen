# SPEC-015 — Source inventory, OAuth bindings and declarative integration plans

**Milestone:** S2 · **Accountable function:** Integrations · **Implementation root:** `packages/ontology/src/sources` · **Status:** specified, not implemented.

## Decision and intended behavior

All company data means an explicit inventory of authorized sources with visible coverage gaps, not an assertion of universal ingestion. Integration instances and mappings are runtime data; credentials stay in the broker. Source completeness, deletions, ACL freshness and schema drift are contractual.

## Owned state and storage contract

ontology.source_inventory(source_id PK,world_id,owner,category,coverage_scope,expected_freshness,admission_state); ontology.source_bindings(binding_id PK,world_id,definition_digest,credential_ref,state,acl_policy_ref); jobs.source_cursors(binding_id,partition_id PK,cursor_json,watermark,lease_fence,schema_digest); ontology.source_health(binding_id,observed_at PK,status,gaps_json); ontology.source_tombstones(binding_id,external_id,revision PK,evidence_ref).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ConfigureSource(definition,instance,operationId) -> Binding; SyncSource(binding,cursor) -> CapturedBatch; AdmitBatch(binding,batch,expectedCursor) -> BatchReceipt; InventoryCoverage(world,scope) -> CoverageFrame.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

HTTP plans bind method/path templates, allowlisted host, pagination, schema, rate limits and auth references. URL/headers supplied by data cannot redirect credentials. Cursor advances only with durable capture/admission handoff. Detect drift before interpreting records. A missing record means deleted only for an explicitly complete authoritative snapshot. ACL outages age data rights according to policy and can fail closed.

V4 refinement: A source connector is an acquisition implementation behind admitted source operations, not an app-owned data API. Apps cannot call OAuth providers directly, ask for connector credentials or bypass evidence admission.

## Dependencies and sequencing

Referenced specs: [004](spec-004.md), [013](spec-013.md), [014](spec-014.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0089](../tickets/zn-0089.md) | Build runtime source inventory and honest coverage | S2 | component | ZN-0030, ZN-0081, ZN-0088 |
| [ZN-0090](../tickets/zn-0090.md) | Implement brokered OAuth and secret references | S2 | component | ZN-0089 |
| [ZN-0091](../tickets/zn-0091.md) | Execute constrained HTTP source plans | S2 | component | ZN-0090 |
| [ZN-0092](../tickets/zn-0092.md) | Commit incremental cursors without record loss | S2 | component | ZN-0091 |
| [ZN-0093](../tickets/zn-0093.md) | Quarantine schema drift and map ACL identities | S2 | component | ZN-0092 |
| [ZN-0094](../tickets/zn-0094.md) | Propagate explicit source tombstones safely | S2 | component | ZN-0093 |
| [ZN-0095](../tickets/zn-0095.md) | Qualify one real read-only source connection | S2 | admission | ZN-0094 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[connectors-and-ingestion.md](../baseline/v2/technical-blueprint/reference/connectors-and-ingestion.md) · [runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
