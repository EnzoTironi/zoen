# SPEC-037 — Pack registry, overlays, upgrades and marketplace governance

**Milestone:** S8 · **Accountable function:** Developer Platform · **Implementation root:** `packages/ontology/src/packs` · **Status:** specified, not implemented.

## Decision and intended behavior

Packs are signed meaning/capability bundles, not automatic grants or cross-customer data sharing. Dependency upgrades are semantic release changes. Commercial marketplace availability requires publisher, support, security and entitlement controls beyond a package installer.

## Owned state and storage contract

ontology.pack_versions(pack_digest PK,publisher,namespace,version,dependencies,requested_capabilities,artifact_refs,signature_ref,license_ref); ontology.pack_installs(install_id PK,world_id,pack_digest,overlay_ref,granted_scope,state); ontology.publisher_records(publisher_id PK,verified_identity,signing_keys,review_state); ontology.marketplace_entitlements(entitlement_id PK,world_id,pack_ref,terms_version,state). No publisher can query installed customer data by default.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ResolvePackGraph(request,pinnedBase) -> LockedGraph; InstallPack(graph,overlay) -> Change; UpgradePack(install,target) -> SemanticDiff; RemovePack(install) -> DispositionPlan; VerifyPublisher(signature) -> VerifiedOrigin | Denied.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Resolve immutable dependencies and namespace collisions. Keep local overlays distinct from upstream pack bytes. Rebase upgrades with conflict handling and migration/open-work dispositions. Removal handles dependent definitions, data, active Cases/Watches and retention rather than deleting everything. Publisher signature/reputation is not a substitute for isolated evaluation and local approval.

V4 refinement: Pack upgrade/recall covers app definitions, immutable executable bindings, sessions and open Cases. A stable link resolves the admitted publication; it never follows a vendor latest alias or restores recalled code.

## Dependencies and sequencing

Referenced specs: [016](spec-016.md), [029](spec-029.md), [035](spec-035.md), [036](spec-036.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0213](../tickets/zn-0213.md) | Implement signed pack registry and dependency lock resolution | S8 | component | ZN-0100, ZN-0173, ZN-0206, ZN-0212 |
| [ZN-0214](../tickets/zn-0214.md) | Implement local overlays and semantic dependency mapping | S8 | component | ZN-0213 |
| [ZN-0215](../tickets/zn-0215.md) | Upgrade, rebase and remove packs safely | S8 | component | ZN-0214 |
| [ZN-0216](../tickets/zn-0216.md) | Implement publisher recall and installation visibility | S8 | component | ZN-0215 |
| [ZN-0217](../tickets/zn-0217.md) | Define commercial entitlements and marketplace activation gate | S8 | admission | ZN-0216 |
| [ZN-0218](../tickets/zn-0218.md) | Prove runtime pack evolution across all audiences | S8 | journey | ZN-0216 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[domain-packs-and-marketplace.md](../baseline/v2/technical-blueprint/reference/domain-packs-and-marketplace.md) · [runtime-variation-and-releases.md](../baseline/v2/technical-blueprint/reference/runtime-variation-and-releases.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
