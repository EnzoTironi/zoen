# SPEC-031 — Dense Parquet/Iceberg datasets and atomic publication

**Milestone:** S7 · **Accountable function:** Data Platform · **Implementation root:** `packages/ontology/src/datasets` · **Status:** specified, not implemented.

## Decision and intended behavior

Use Parquet and the admitted Iceberg v2 profile, Lakekeeper REST catalog and bounded DuckDB workers. Ontology publishes exact immutable snapshot references. Catalog latest is never an authoritative or historical data basis. Dense data is installed only when this slice requires it.

## Owned state and storage contract

ontology.dataset_versions(version_id PK,world_id,dataset_id,table_uuid,snapshot_id,metadata_location,metadata_digest,schema_digest,partition_spec,input_cut,lineage_ref,rights_label,quality_ref); ontology.dataset_pins(pin_id PK,version_id,artifact_set_digest,retention_until,state); ontology.dataset_publications(publication_id PK,world_id,version_refs,commit_id); jobs.dataset_stages(stage_id PK,run_id,table_branch,version_ref,state). Catalog uses a separate database.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
StageDataset(run,inputs) -> StagedVersion; ValidateDataset(stage) -> QualityResult; PinDataset(stage,retention) -> PinProof; PublishDataset(versionSet,expectedBasis,operationId) -> PublicationReceipt; ReadDataset(versionRef,grant) -> ExactSnapshotReader.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Write staged files and isolated snapshot; validate exact metadata/schema/rights/completeness; create physical retention pins; verify pins; publish the version set in one authority transaction; finalize catalog bookkeeping asynchronously. No cross-system ACID is claimed. Orphan staging is collectible only when no authoritative/pending pin references it. Unsupported Iceberg delete/timestamp features fail admission.

V4 refinement: Bulk snapshots reach clients only through a released authorized read/export/analysis operation. Internal Iceberg/S3/DuckDB ports remain inaccessible to apps. Opaque chunk/cursor references carry no authority and are rechecked on retrieval.

## Dependencies and sequencing

Referenced specs: [015](spec-015.md), [019](spec-019.md), [030](spec-030.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0180](../tickets/zn-0180.md) | Admit the exact catalog, writer and DuckDB reader profile | S7 | component | ZN-0094, ZN-0117, ZN-0178 |
| [ZN-0181](../tickets/zn-0181.md) | Write staged immutable dataset versions | S7 | component | ZN-0180 |
| [ZN-0182](../tickets/zn-0182.md) | Enforce physical pins before authority publication | S7 | component | ZN-0181 |
| [ZN-0183](../tickets/zn-0183.md) | Publish coherent snapshot sets in one local commit | S7 | component | ZN-0182 |
| [ZN-0184](../tickets/zn-0184.md) | Read exact snapshots with bounded analytics and rights | S7 | component | ZN-0183 |
| [ZN-0185](../tickets/zn-0185.md) | Prove publication, GC and erasure races on real components | S7 | chaos | ZN-0184 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[data-events-parquet.md](../baseline/v2/technical-blueprint/reference/data-events-parquet.md) · [data-flows-and-live-data.md](../baseline/v2/technical-blueprint/reference/data-flows-and-live-data.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
