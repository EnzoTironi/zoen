# SPEC-025 — Authorized retrieval and permitted specialized agents

**Milestone:** S5 · **Accountable function:** Knowledge and Experience · **Implementation root:** `packages/ontology/src/retrieval` · **Status:** specified, not implemented.

## Decision and intended behavior

Retrieval is a rebuildable projection, not truth. Authorization logically precedes ranking/aggregation. Initial search uses exact scoring within a bounded authorized candidate set; approximate indexes require their own visibility/recall admission. Specialized agents narrow capabilities and share budgets.

## Owned state and storage contract

ontology.search_documents(document_id PK,world_id,evidence_ref,source_revision,projection_cut,rights_label,text_vector,embedding_ref); ontology.embedding_jobs(job_id PK,source_ref,model_profile,rights_basis,state); ontology.agent_definitions are released data, not unbounded executable loaders. Index records carry deletion/source ACL lineage.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Search(query,grant,bounds) -> AuthorizedSearchFrame | UnsupportedPlan; RetrieveEvidence(resultRef,freshGrant) -> Evidence; StartSpecializedAgent(definition,parentMandate,task) -> BoundedAgentRun.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Build the permitted source/object set before ranking. Do not retrieve hidden top-K then filter it afterward. Keep source cut and projection lag in results. Source text is untrusted data; it cannot redefine system instructions or install tools. Agents use the same semantic client, budget and context compiler, and cannot recurse outside released fanout limits.

V4 refinement: Retrieval and specialized agents use the single semantic executor. A vector index, cache or specialized model is an internal implementation detail, never an app-visible bypass.

## Dependencies and sequencing

Referenced specs: [018](spec-018.md), [024](spec-024.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0147](../tickets/zn-0147.md) | Build rights-carrying text and vector projections | S5 | component | ZN-0111, ZN-0146 |
| [ZN-0148](../tickets/zn-0148.md) | Enforce authorization before ranking and aggregates | S5 | component | ZN-0147 |
| [ZN-0149](../tickets/zn-0149.md) | Bind search results to evidence and freshness | S5 | component | ZN-0148 |
| [ZN-0150](../tickets/zn-0150.md) | Contain source prompt injection at tool boundaries | S5 | component | ZN-0149 |
| [ZN-0151](../tickets/zn-0151.md) | Run specialized agents under explicit definitions | S5 | component | ZN-0150 |
| [ZN-0152](../tickets/zn-0152.md) | Prove retrieval and agent policies across source revocation | S5 | journey | ZN-0151 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[models-retrieval-and-agents.md](../baseline/v2/technical-blueprint/reference/models-retrieval-and-agents.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
