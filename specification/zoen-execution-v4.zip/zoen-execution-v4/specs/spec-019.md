# SPEC-019 — Retention, erasure, legal holds and restore suppression

**Milestone:** S3 · **Accountable function:** Privacy and Operations · **Implementation root:** `packages/ontology/src/lifecycle` · **Status:** specified, not implemented.

## Decision and intended behavior

Immutability is bounded by retention and lawful deletion obligations. Retained receipts can prove an operation while payloads become unavailable. A legal hold conflict is reviewed, not solved by an autonomous model. Restores cannot revive forbidden content.

## Owned state and storage contract

ontology.retention_policies(policy_id PK,scope,purpose,expiry_rule,hold_rules,version); ontology.erasure_cases(case_id PK,scope,requested_by,state,decision_ref); ontology.erasure_tasks(task_id PK,case_id,artifact_ref,store,kind,state,receipt_ref); audit.deletion_ledger(sequence PK,scope_digest,artifact_ref,decision_ref,effective_at); ontology.holds(hold_id PK,scope,authority_evidence,expires_at,state). Deletion ledger durability is separate from a restored application backup.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
RequestErasure(scope) -> ReviewedCase; PlanErasure(case,basis) -> ArtifactClosure; ExecuteErasure(task,permit) -> DeletionReceipt; CheckRestoreSuppression(restoredCut,currentLedger) -> SuppressionPlan | Blocked.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Enumerate original and derived artifacts: raw bytes, claims payloads, extracts, indexes, embeddings, caches, summaries, dataset files, model-training manifests and exports under control. Record unsupported third-party erasure as an unresolved obligation, not success. Keep sufficient permitted non-content metadata to explain unavailable history. Apply the current deletion ledger before any restored environment opens reads or effects.

## Dependencies and sequencing

Referenced specs: [018](spec-018.md), [008](spec-008.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0112](../tickets/zn-0112.md) | Classify retention and license expiry at admission | S3 | component | ZN-0051, ZN-0111 |
| [ZN-0113](../tickets/zn-0113.md) | Build erasure closure and explicit obligation tracking | S3 | component | ZN-0112 |
| [ZN-0114](../tickets/zn-0114.md) | Execute erasure with non-content receipts | S3 | component | ZN-0113 |
| [ZN-0115](../tickets/zn-0115.md) | Route legal-hold conflicts to explicit review | S3 | component | ZN-0114 |
| [ZN-0116](../tickets/zn-0116.md) | Suppress erased data after restore | S3 | chaos | ZN-0115 |
| [ZN-0117](../tickets/zn-0117.md) | Prove correction, expiry and erasure remain distinguishable | S3 | journey | ZN-0116 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[lifecycle-privacy-and-retention.md](../baseline/v2/technical-blueprint/reference/lifecycle-privacy-and-retention.md) · [security-and-operations.md](../baseline/v2/technical-blueprint/reference/security-and-operations.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
