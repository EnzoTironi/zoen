# SPEC-043 — Federated Frames, independent approvals and partial global outcomes

**Milestone:** S10 · **Accountable function:** Platform Kernel · **Implementation root:** `packages/ontology/src/federation` · **Status:** specified, not implemented.

## Decision and intended behavior

Independent Worlds retain independent truth, policy, cuts and authority. A federated result is a vector of component bases with skew/gaps, not a global ACID snapshot. Cross-World actions coordinate local Cases and disclose partial outcomes honestly.

## Owned state and storage contract

ontology.federation_links(link_id PK,local_world,remote_world,trust_profile,permitted_ops,rights_contract,expiry); ontology.federated_frames(frame_id PK,component_refs,cuts,rights_basis,skew,gaps); ontology.coordinations(coordination_id PK,world_id,plan_digest,participants,state,outcome); ontology.coordination_parts(coordination_id,participant PK,local_case_ref,receipt_ref,external_state). No shared global grant/token.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
OpenFederatedFrame(plan,localGrant,remoteDelegations) -> FederatedFrame; ProposeCoordination(plan) -> CoordinationCase; ObserveParticipant(receipt) -> PartialState; CompensateParticipant(action) -> NewLocalCase.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Authenticate remote service and principal-bound delegated purpose independently. Reauthorize each component and retain its licenses/retention on derived data. Missing/late participants stay explicit. Each participant commits locally under its own policy and guards. Global budgets/inventory require one designated owner or explicit partitioned reservations; do not infer atomic global conservation from messages.

## Dependencies and sequencing

Referenced specs: [026](spec-026.md), [042](spec-042.md), [022](spec-022.md), [023](spec-023.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0250](../tickets/zn-0250.md) | Implement explicit federation trust and delegation contracts | S10 | component | ZN-0134, ZN-0139, ZN-0158, ZN-0249 |
| [ZN-0251](../tickets/zn-0251.md) | Build independent-cut federated Frames | S10 | component | ZN-0250 |
| [ZN-0252](../tickets/zn-0252.md) | Coordinate independent local ActionCases | S10 | component | ZN-0251 |
| [ZN-0253](../tickets/zn-0253.md) | Implement compensation and globally owned resources | S10 | component | ZN-0252 |
| [ZN-0254](../tickets/zn-0254.md) | Prove federated revocation, skew and partial outcomes | S10 | chaos | ZN-0253 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[deployment-cells-and-federation.md](../baseline/v2/technical-blueprint/reference/deployment-cells-and-federation.md) · [rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
