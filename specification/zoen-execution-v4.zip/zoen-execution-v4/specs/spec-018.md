# SPEC-018 — Fine-grained rights, delegation and audience-safe disclosure

**Milestone:** S3 · **Accountable function:** Security · **Implementation root:** `packages/ontology/src/rights` · **Status:** specified, not implemented.

## Decision and intended behavior

Permissions constrain discovery, planning, ranking, explanation and output, not only the final text. Derived artifacts inherit source restrictions. A merged identity or shared channel never broadens authority. Policy evaluation uses the actual admitted Cedar engine and an explicit bounded query-admission profile.

## Owned state and storage contract

ontology.delegations(delegation_id PK,world_id,grantor,grantee,scope,purpose,destination,assurance,expires_at,parent_ref,revoked_at); ontology.rights_labels(label_id PK,world_id,source_refs,policy_refs,license_refs); ontology.source_acls(binding_id,acl_revision,subject_ref PK,permissions,valid_until); ontology.disclosure_receipts(receipt_id PK,frame_ref,audience_digest,rights_cut,outcome). Secret role/policy metadata obeys disclosure too.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Authorize(principal,operation,resource,purpose,destination,context) -> AllowBasis | Denied; DeriveRights(inputLabels,transform) -> OutputLabel | Rejected; OpenAudienceView(frame,audience) -> IntersectionView; Delegate(scope) -> DelegationReceipt.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Explicit forbids and emergency deny prevail. Evaluate current membership/delegation and inherited source/license rights. Restrict SQL to the supported admission profile; arbitrary Cedar-to-SQL compilation is forbidden. If authorization cannot be safely pushed down, use a bounded authorized ID set or reject the plan. Hidden rivals must not influence view-local wording/counts unless a released declassification policy permits it.

V4 refinement: The common executor intersects current subject/delegation rights, admitted app capabilities, session purpose/scope and current source rights. App creators do not lend their privileges. Equal-basis noninterference includes app discovery, assets, exports, cursors, errors, counts and streams.

## Dependencies and sequencing

Referenced specs: [002](spec-002.md), [007](spec-007.md), [015](spec-015.md), [017](spec-017.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0106](../tickets/zn-0106.md) | Implement actual Cedar authorization and bounded plan admission | S3 | component | ZN-0018, ZN-0046, ZN-0094, ZN-0105 |
| [ZN-0107](../tickets/zn-0107.md) | Implement narrow delegation, assurance and caregiver access | S3 | component | ZN-0106 |
| [ZN-0108](../tickets/zn-0108.md) | Propagate rights through lineage and derived artifacts | S3 | component | ZN-0107 |
| [ZN-0109](../tickets/zn-0109.md) | Implement audience intersections and view-local interpretations | S3 | component | ZN-0108 |
| [ZN-0110](../tickets/zn-0110.md) | Expire source ACLs and suppress in-flight revoked output | S3 | component | ZN-0109 |
| [ZN-0111](../tickets/zn-0111.md) | Prove noninterference across every public surface | S3 | journey | ZN-0110 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[rights-and-access-control.md](../baseline/v2/technical-blueprint/reference/rights-and-access-control.md) · [models-retrieval-and-agents.md](../baseline/v2/technical-blueprint/reference/models-retrieval-and-agents.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
