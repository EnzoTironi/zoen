# SPEC-006 — Reversible domain identity and temporal explanations

**Milestone:** S1 · **Accountable function:** Knowledge · **Implementation root:** `packages/ontology/src/identity` · **Status:** specified, not implemented.

## Decision and intended behavior

Source record identity, human authentication and domain subject identity are different. A merge is a reversible versioned identity assertion; original source claims are never destructively reassigned.

## Owned state and storage contract

ontology.subjects(subject_id PK,world_id,created_commit); ontology.aliases(world_id,binding_id,namespace,external_id,valid_from PK,subject_ref,assertion_ref); ontology.identity_assertions(assertion_id PK,world_id,left_subject,right_subject,relation,valid_interval,knowledge_version,evidence_refs,supersedes); ontology.identity_cases(case_id PK,world_id,candidate_digest,basis_ref,state). No unique constraint on display name or email alone.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProposeIdentityResolution(candidates,basis) -> ResolutionCase; ResolveIdentity(caseId,choice,operationId) -> IdentityReceipt; ExplainIdentity(subject,cut) -> AuthorizedIdentityFrame.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Emit candidates without selecting merely by fuzzy similarity. Explicit same-as/different-from assertions are scoped and versioned. Keep durable source subjects and compute the representative under a cut. Split appends counter-assertions and recalculates identity-dependent guards. Authorization is not widened by merge: unioning subjects does not union grants.

## Dependencies and sequencing

Referenced specs: [005](spec-005.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0037](../tickets/zn-0037.md) | Implement namespaced aliases and stable subjects | S1 | component | ZN-0036 |
| [ZN-0038](../tickets/zn-0038.md) | Create guarded ambiguous-identity Cases | S1 | component | ZN-0037 |
| [ZN-0039](../tickets/zn-0039.md) | Implement merge assertions without physical destructive merge | S1 | component | ZN-0038 |
| [ZN-0040](../tickets/zn-0040.md) | Implement split and identity impact closure | S1 | component | ZN-0039 |
| [ZN-0041](../tickets/zn-0041.md) | Prove identity, label and time invariants | S1 | law | ZN-0040 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[identity-and-time.md](../baseline/v2/technical-blueprint/reference/identity-and-time.md) · [truth-reconciliation-and-learning.md](../baseline/v2/technical-blueprint/reference/truth-reconciliation-and-learning.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
