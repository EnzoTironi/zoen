# SPEC-028 — Telegram, email and cross-channel continuity

**Milestone:** S5 · **Accountable function:** Channels · **Implementation root:** `packages/adapters/src/channels/multichannel` · **Status:** specified, not implemented.

## Decision and intended behavior

Channel adapters implement a shared ingress/delivery contract but retain provider-specific verification and ambiguity behavior. Switching channels changes transport, not permissions, World meaning or the identity ceremony.

## Owned state and storage contract

Reuse channels.ingress, bindings, consent and delivery with provider/account namespaces. Email message/thread headers and Telegram chat IDs are provider-scoped references, not authenticated principals. A relationship-channel link requires separate proof and consent.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AdmitTelegramWebhook(raw,verification) -> Ingress; AdmitEmailWebhook(raw,verification) -> Ingress; LinkChannel(principalProof,challenge) -> Binding; ContinueConversation(focus,newChannel) -> FreshAuthorizedTurn.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Use actual provider verification; Telegram webhook secret and email event signatures are not interchangeable. Email From is not proof of person identity. Reject reply-to/header injection and bound attachments. Link/rebind through secure authentication. Channel recipient changes trigger fresh audience disclosure. Delivery observations remain accepted/delivered/read/unknown according to actual provider evidence.

## Dependencies and sequencing

Referenced specs: [011](spec-011.md), [018](spec-018.md), [026](spec-026.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0164](../tickets/zn-0164.md) | Implement Telegram ingress and delivery adapter | S5 | component | ZN-0068, ZN-0111, ZN-0158 |
| [ZN-0165](../tickets/zn-0165.md) | Implement email ingress, threading and attachment safety | S5 | component | ZN-0164 |
| [ZN-0166](../tickets/zn-0166.md) | Continue one relationship across independently linked channels | S5 | component | ZN-0165 |
| [ZN-0167](../tickets/zn-0167.md) | Normalize provider capabilities without false delivery guarantees | S5 | component | ZN-0166 |
| [ZN-0168](../tickets/zn-0168.md) | Qualify actual Telegram and email account journeys | S5 | admission | ZN-0167 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[messaging-channels.md](../baseline/v2/technical-blueprint/reference/messaging-channels.md) · [release-policy-eve.md](../baseline/v2/technical-blueprint/reference/release-policy-eve.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
