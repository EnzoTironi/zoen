# SPEC-054 — Rivet Dynamic Apps Core qualification and immutable runtime adapter

**Milestone:** S6 · **Accountable function:** Runtime Platform · **Implementation root:** `packages/adapters/src/app-runtime/rivet` · **Status:** specified, not implemented.

## Decision and intended behavior

Rivet Dynamic Apps Core is the first candidate specialized backend adapter, not the required substrate of declarative apps or an authority service. Current upstream Preview/API behavior must be qualified at an exact lock. Candidate deployment and Zoen publication must stay separate even if deployApp activates its internal appId.

## Owned state and storage contract

jobs.app_runtime_preparations(preparation_id PK,world_id,realm,manifest_digest,artifact_digest,profile_digest,runtime_slot_ref,host_state_partition,attempt_fence,status,attestation_ref,expires_at); jobs.app_runtime_slots(slot_ref PK,immutable_identity,digest,runner_scope,state). Public AppPublicationBinding remains in the released Ontology graph. Runtime process globals/SQLite are not authoritative company data.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
Zoen-owned port: PrepareRuntime(artifact,profile,realm) -> PreparedRuntime; ProbeRuntime(preparation) -> Attestation; ResolvePreparedRuntime(binding,session) -> IsolatedTarget; RetireRuntime(slot) -> Result. These are Zoen adapter contracts, not asserted Rivet API names.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Read the dated primary-source ledger and recheck the actual APIs before pinning. Build in an isolated build plane with a locked dependency graph and no live credentials. Internal successful deploy is not public authorization. Map candidate/version IDs immutably; the edge resolves only an approved Zoen binding. No runtime latest alias, public preview bypass, automatic namespace with production secrets or automatic generated permission config.

## Dependencies and sequencing

Referenced specs: [029](spec-029.md), [030](spec-030.md), [053](spec-053.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


Primary sources and uncertainty: [Rivet adapter contract](../architecture/rivet-adapter.md) and [source ledger](../research/v4-sources.md). This pack does not claim any Rivet probe was run.

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0314](../tickets/zn-0314.md) | Qualify the exact Rivet Core API and compatibility boundary | S6 | component | ZN-0170, ZN-0174 |
| [ZN-0315](../tickets/zn-0315.md) | Implement immutable candidate slots and public binding separation | S6 | component | ZN-0304, ZN-0310, ZN-0314 |
| [ZN-0316](../tickets/zn-0316.md) | Integrate staged app runtime with current-policy publication | S6 | component | ZN-0086, ZN-0172, ZN-0315 |
| [ZN-0317](../tickets/zn-0317.md) | Harden Rivet host configuration, build plane and credentials | S6 | component | ZN-0176, ZN-0311, ZN-0316 |
| [ZN-0318](../tickets/zn-0318.md) | Implement runtime recovery, recall and orphan retention | S6 | component | ZN-0312, ZN-0317 |
| [ZN-0319](../tickets/zn-0319.md) | Admit the Rivet specialized runtime profile or record rejection | S6 | admission | ZN-0179, ZN-0318 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[apps-charts-and-surfaces.md](../baseline/v2/technical-blueprint/reference/apps-charts-and-surfaces.md) · [programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
