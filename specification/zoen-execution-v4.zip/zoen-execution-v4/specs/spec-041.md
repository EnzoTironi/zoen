# SPEC-041 — Enterprise source recipes and domain-wide reconciliation

**Milestone:** S9 · **Accountable function:** Enterprise Data · **Implementation root:** `packs/connectors` · **Status:** specified, not implemented.

## Decision and intended behavior

Provide concrete connector qualification tracks without promising access to every proprietary system. Each recipe declares objects, pagination/CDC, schema drift, ACLs, tombstones, data-use restrictions and coverage. Missing proprietary APIs remain visible source gaps.

## Owned state and storage contract

Released ConnectorRecipe includes provider/profile, versioned object schemas, endpoint/query templates, incremental strategy, auth scopes, ACL mapping, deletion semantics, freshness and supported record kinds. Per-install source instances, credentials, cursors and data remain outside reusable recipe artifacts.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
InstallConnectorRecipe(recipe,instance) -> SourceChange; QualifyConnector(recipe,providerAccount) -> Certificate; CompareBusinessMetrics(metricDefinitions,basis) -> ReconciliationFrame.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Recipes compose existing source/flow/artifact protocols; do not create an SDK-shaped authority bypass. Every provider ticket must read the current primary API documentation and record exact supported versions/scopes before implementation. Code conformance can use explicitly labeled protocol peers; production qualification requires actual owned accounts and source rights.

## Dependencies and sequencing

Referenced specs: [015](spec-015.md), [018](spec-018.md), [030](spec-030.md), [032](spec-032.md), [038](spec-038.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0237](../tickets/zn-0237.md) | Implement Google Workspace document and change recipe | S9 | component | ZN-0094, ZN-0111, ZN-0178, ZN-0191, ZN-0223 |
| [ZN-0238](../tickets/zn-0238.md) | Implement Microsoft 365 and SharePoint document recipe | S9 | component | ZN-0237 |
| [ZN-0239](../tickets/zn-0239.md) | Implement CRM account and opportunity recipe | S9 | component | ZN-0238 |
| [ZN-0240](../tickets/zn-0240.md) | Implement ERP OData/HTTP invoice and supplier recipe | S9 | component | ZN-0239 |
| [ZN-0241](../tickets/zn-0241.md) | Implement PostgreSQL snapshot-plus-CDC source recipe | S9 | component | ZN-0240 |
| [ZN-0242](../tickets/zn-0242.md) | Implement warehouse virtual/captured read recipe | S9 | component | ZN-0241 |
| [ZN-0243](../tickets/zn-0243.md) | Qualify enterprise connectors with real accounts and scope manifests | S9 | admission | ZN-0242 |
| [ZN-0244](../tickets/zn-0244.md) | Prove company-wide metric definitions and disagreement stewardship | S9 | journey | ZN-0242 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[connectors-and-ingestion.md](../baseline/v2/technical-blueprint/reference/connectors-and-ingestion.md) · [capability-horizon.md](../baseline/v2/technical-blueprint/reference/capability-horizon.md) · [ontology-and-standards.md](../baseline/v2/technical-blueprint/reference/ontology-and-standards.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
