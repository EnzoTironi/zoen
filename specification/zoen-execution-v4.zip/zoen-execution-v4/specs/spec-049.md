# SPEC-049 — Shared hosted pilot and progressive product activation

**Milestone:** S1 · **Accountable function:** Operations · **Implementation root:** `infra/terraform/pilot` · **Status:** specified, not implemented.

## Decision and intended behavior

Consumers and prosumers must not wait for the institutional stack. Provision a minimal shared regional hosted profile for admitted early capabilities; install catalog/distributed/custom-code infrastructure only when its slice needs it. Pilot status is explicit and does not imply enterprise HA or full regulated execution.

## Owned state and storage contract

Infrastructure defines private PostgreSQL, encrypted evidence, separate edge/Eve/authority roles, hosted web, secret references, monitoring and backups under an admitted regional profile. control.capability_admissions(capability_id,profile PK,code_commit,qualification_refs,state) lists enabled versus disabled routes. No customer data in control records.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
ProvisionPilot(lock,region,profile) -> StagedPilot; EnableCapability(capability,codeEvidence,providerEvidence,approval) -> Admission | Blocked; RollbackPilot(image,compatibleSchema) -> SafeDeployment.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

The pilot has the same authority/rights/idempotency laws, smaller measured capacity and explicitly limited durability profile. Provider/channel/model admissions are independent; unqualified routes remain disabled while file/web core works. Backups, erasure suppression and incident stop are required before real sensitive data. Upgrade through the same immutable image/schema compatibility evidence.

V4 refinement: Private owner-only continuation and data-defined apps can be admitted without Rivet, dense storage or institutional SSO. User-supplied executable code remains off until its exact isolation and host gates pass.

## Dependencies and sequencing

Referenced specs: [008](spec-008.md), [012](spec-012.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.


The pilot is not dependent on S9 enterprise provisioning. Later capabilities are added through independent admission flags. Missing WhatsApp/provider admission does not prevent an otherwise qualified file/web pilot.

V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0287](../tickets/zn-0287.md) | Provision the minimal shared regional hosted topology | S1 | component | ZN-0051, ZN-0073 |
| [ZN-0288](../tickets/zn-0288.md) | Implement capability-specific deployment admission flags | S1 | component | ZN-0287 |
| [ZN-0289](../tickets/zn-0289.md) | Implement safe image/schema rollout and rollback | S1 | component | ZN-0288 |
| [ZN-0290](../tickets/zn-0290.md) | Run real-data pilot readiness and privacy drills | S1 | admission | ZN-0289 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[technology-stack.md](../baseline/v2/technical-blueprint/reference/technology-stack.md) · [deployment-cells-and-federation.md](../baseline/v2/technical-blueprint/reference/deployment-cells-and-federation.md) · [capacity-economics-and-slos.md](../baseline/v2/technical-blueprint/reference/capacity-economics-and-slos.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
