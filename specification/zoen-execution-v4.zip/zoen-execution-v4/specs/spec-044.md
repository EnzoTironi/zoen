# SPEC-044 — Offline child scopes, self-hosted equivalence and fleet policy

**Milestone:** S10 · **Accountable function:** Platform Operations · **Implementation root:** `packages/ontology/src/edge` · **Status:** specified, not implemented.

## Decision and intended behavior

Offline is a distinct leased child scope, not a second disconnected writer for the parent World. Self-hosted claims require tested equivalents for every security/storage/recovery contract. Fleet updates remain signed, evaluated and locally governed.

## Owned state and storage contract

ontology.child_leases(lease_id PK,parent_world,child_scope,epoch,resource_partition,allowed_ops,expires_at,clock_uncertainty,max_offline,state); ontology.offline_receipts(receipt_id PK,child_scope,lease_ref,sequence,intent_digest,observed_basis,reconciled_state); control.fleet_profiles(profile_id PK,version,equivalence_evidence,policy_digest,state).

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
IssueOfflineLease(scope,resourcePartition,expiry) -> ChildLease; RecordOfflineOperation(lease,intent) -> LocalReceipt | Denied; ReconcileChild(receipts) -> Admitted|Conflict|Expired; AdmitSelfHostedProfile(evidence) -> Profile; ProposeFleetUpdate(release) -> LocalChangeSet.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Offline operations need explicit bounded rights and trustworthy expiry/clock assumptions. Non-reversible external actions default denied unless resources/authority were partitioned beforehand. On reconnect, receipts are evidence for reconciliation, not commands to blindly replay. Fleet rollback is a proved prepared transition; no remote publisher may override local authority or residency.

V4 refinement: Offline execution is the same admitted semantic implementation and bounded grammar inside a distinct leased child World. Do not use disconnected mini-app caches as a second offline authority or silently queue external provider writes.

## Dependencies and sequencing

Referenced specs: [042](spec-042.md), [043](spec-043.md), [037](spec-037.md). **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0255](../tickets/zn-0255.md) | Issue distinct offline child authority leases | S10 | component | ZN-0218, ZN-0249, ZN-0254 |
| [ZN-0256](../tickets/zn-0256.md) | Record offline operations and enforce expiry | S10 | component | ZN-0255 |
| [ZN-0257](../tickets/zn-0257.md) | Reconcile child receipts without blind replay | S10 | component | ZN-0256 |
| [ZN-0258](../tickets/zn-0258.md) | Define and test self-hosted infrastructure equivalence | S10 | component | ZN-0257 |
| [ZN-0259](../tickets/zn-0259.md) | Implement fleet release and policy governance | S10 | component | ZN-0258 |
| [ZN-0260](../tickets/zn-0260.md) | Qualify edge, self-hosted and fleet operating profiles | S10 | admission | ZN-0259 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[deployment-cells-and-federation.md](../baseline/v2/technical-blueprint/reference/deployment-cells-and-federation.md) · [programmable-compute-and-skills.md](../baseline/v2/technical-blueprint/reference/programmable-compute-and-skills.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
