# SPEC-000 — Execution baseline, dependency admission and fail-closed CI

**Milestone:** S0 · **Accountable function:** Platform · **Implementation root:** `tooling` · **Status:** specified, not implemented.

## Decision and intended behavior

Adopt v2 ownership and technology families. Create a new implementation in zoen; OS remains a read-only migration source until explicit cutover approval. Do not interpret a package publication as composition proof. Python execution-pack tooling is documentation tooling, not a production service.

## Owned state and storage contract

No application tables. Track execution-lock.json, baseline-inventory.json and evidence-index.json as reviewed artifacts. Secret values never belong in these files.

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
AdmitExecutionProfile(profile, candidateVersions, integrityDigests, compatibilityReport) -> AdmittedLock | Blocked; VerifyTicket(ticketId, commit, profile) -> EvidenceReport | MissingPrerequisite.
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

Freeze repository commit identities before reuse. Admit a core lock first and extension locks just before their milestone. The lock must include Node, pnpm, TypeScript, Hono, pg, PostgreSQL, Cedar binding, schema validator, canonicalizer, test tools and image digests. One workspace; ontology submodules are directories, not dozens of independent services. Missing tests are failures, never successful empty runs.

V4 refinement: V4 is the execution source of truth. Preserve the input-v3 archive and stable IDs; compile a no-bypass import/credential graph for app, agent and human clients.

## Dependencies and sequencing

Referenced specs: None. **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.



V4 normative detail: [single semantic path](../architecture/semantic-path.md).

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
| [ZN-0001](../tickets/zn-0001.md) | Record repository and data-preservation baseline | S0 | admission | None |
| [ZN-0002](../tickets/zn-0002.md) | Admit the exact core toolchain | S0 | admission | ZN-0001 |
| [ZN-0003](../tickets/zn-0003.md) | Create workspace, strict build and dependency boundaries | S0 | static | ZN-0002 |
| [ZN-0004](../tickets/zn-0004.md) | Create real dependency test harness with explicit clocks and barriers | S0 | component | ZN-0003 |
| [ZN-0005](../tickets/zn-0005.md) | Enforce evidence-bound pull-request completion | S0 | static | ZN-0004 |
| [ZN-0006](../tickets/zn-0006.md) | Protect secrets, artifacts and merge policy | S0 | component | ZN-0005 |

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

[repository-and-modules.md](../baseline/v2/technical-blueprint/reference/repository-and-modules.md) · [technology-stack.md](../baseline/v2/technical-blueprint/reference/technology-stack.md) · [testing-and-ci.md](../baseline/v2/technical-blueprint/reference/testing-and-ci.md)

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
