# Context packet snapshots

These packets are generated from the v4 contracts and initial planned execution state. They are not permission to execute blocked work. Regenerate with `python tools/plan.py packet ZN-0001 --out /path/outside-delivery/ZN-0001.md` against current reviewed state before assigning work. The first assignment is [ZN-0001](ZN-0001.md); the shared semantic binding example is [ZN-0291](ZN-0291.md). Embedded document-relative links retain their source-document context; source paths are displayed before each excerpt.
