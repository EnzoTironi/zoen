# Zoen v4 — um mundo operacional, várias interfaces

O v4 consolida a decisão: **humanos, agentes e mini apps passam pela mesma implementação de dados, permissões, interpretação e ações da Ontology**. A ponte de um app apenas adapta o transporte; não cria uma API de negócio paralela. Uma tabela estruturada não passa por um modelo de linguagem.

## O que mudou

A entrega tem 56 especificações, 325 tickets e 975 verificações de aceitação exigidas, mantendo as 157 capacidades e a execução completa de S0 a S11. São seis specs e 35 tickets novos, quatro decisões arquiteturais e 28 requisitos adicionais de precisão. Os 290 IDs anteriores foram preservados.

Apps declarativos privados chegam em S2; compartilhamento protegido em S3; formulários com ações governadas em S4; execução isolada e qualificação Rivet em S6. O Studio de S8 reutiliza os mesmos componentes. Não é preciso esperar por dados densos, Python ou infraestrutura institucional para uma confeiteira ter um quadro de encomendas.

Links são referências sem autoridade. A sessão identifica a pessoa e restringe escopo, finalidade e versão; cada chamada verifica os direitos atuais. Compartilhar não empresta os poderes do criador. Os testes incluem prévias, encaminhamento, troca de conta, revogação, exportações, filas, caches e rotas secundárias.

Rivet Dynamic Apps Core é o primeiro candidato a adaptador de backend especializado, não a base de todos os apps. Compilar ou ativar uma versão interna na Rivet não publica o app no Zoen. A versão pública continua vinculada à release aprovada da Ontology.

## Uma correção importante de segurança

Uma interface isolada não prova que código hostil não copiará dados que recebeu. O padrão é renderização declarativa confiável. Dados privados só entram em JavaScript executável sob um perfil de divulgação explicitamente aprovado ou um ambiente de controle mais forte realmente qualificado. O plano não confunde CSP, iframe ou assinatura com garantia universal de não vazamento.

## Como executar

Comece pelo [guia](START-HERE.md). Use [um pacote de contexto por ticket](packets/ZN-0001.md), respeitando a seleção do planejador. [Busque no backlog](backlog.html), consulte a [sequência dos mini apps](architecture/mini-app-sequence.md) e verifique o [mapa de requisitos](backlog/v4-requirements.md).

O ZIP v3 está preservado byte a byte em `lineage/input-v3.zip`; o baseline v2 também foi mantido. O [relatório de migração](verification/v3-to-v4.json) identifica os contratos alterados e dependentes que precisam de revisão de evidência. Nenhum estado externo de implementação é presumido.

## Limites da entrega

Este é um bundle de arquitetura e execução, não o aplicativo funcionando. Os testes locais verificam contratos, schemas, planejamento e integridade do pacote. As 975 verificações de produto começam não executadas. Não houve alteração dos repositórios, deploy, chamada à Rivet, autenticação real de usuários nem qualificação de serviços externos.
