# Start here — Zoen execution v4

**56 specifications · 325 bounded tickets · 975 required product checks · 157 capabilities · 12 milestones · 24 gates.**

## Central contract

Human interfaces, agents and mini apps invoke **the same SemanticExecutor in SPEC-007**, not merely similar rules. Bridges translate transport; they do not implement a data API or another permission/interpretation engine. Structured app reads do not require Eve, an LLM or MCP.

V4 preserves the full S0–S11 ambition and the exact v3 input while closing the mini-app gap. Private declarative apps are S2, sharing S3, governed forms S4, isolated executable host/Rivet qualification S6 and full Studio S8. [Changes](CHANGELOG.md) · [Portuguese overview](LEIA-ME.pt-BR.md).

## Execute

```sh
python -m pip install -r tools/requirements.txt
python tools/verify.py
python tools/plan.py summary
python tools/plan.py next --limit 3
python tools/plan.py packet ZN-0001 --out packets/ZN-0001.md
```

Give the implementing agent **one dependency-ready context packet**. The target is a reviewed branch of the zoen application repository; the ZIP is an execution specification, not a runnable product scaffold. First inventory/preserve existing OS data and repository commit identities. Do not reset or infer there are no live users. Exact core/extension dependencies are admitted by actual probes, not invented from nominal version numbers.

| Need | Entry |
|---|---|
| Rules and stable ownership | [Constitution](architecture/constitution.md) · [repository](architecture/repository-contract.md) |
| One data/action implementation | [Semantic path](architecture/semantic-path.md) · [shared protocol](architecture/protocol-contract.md) |
| Mini apps, protected links, runtime and sequence | [Apps](architecture/mini-app-contract.md) · [links](architecture/protected-links.md) · [host](architecture/app-host-security.md) · [Rivet](architecture/rivet-adapter.md) · [sequence](architecture/mini-app-sequence.md) |
| Specs, tickets and offline search | [Specs](specs/README.md) · [tickets](tickets/README.md) · [backlog](backlog.html) |
| Original scope and v4 refinements | [157 capabilities](backlog/capability-coverage.md) · [28 v4 requirements](backlog/v4-requirements.md) |
| Required proof and operational admission | [Testing](testing/strategy.md) · [app conformance](testing/mini-app-conformance.md) · [gates](backlog/gates.md) |
| What ran in this delivery | [Verification](verification/report.json) · [validation limits](verification/README.md) |

## Mandatory execution discipline

Read AGENTS.md and every additional normative file in the ticket. Follow dependencies, not IDs or spec numbers. A missing semantic decision is a blocked report and reviewed spec change, not permission to improvise. A generated file or unused component is not completion. File/lock scopes are explicit. Template, publication, sharing and external effects remain separate governed operations.

A link is not authority; each use rechecks current rights. A runtime build is not publication. An app signature is not permission to receive private data. Generated execution remains disabled until the exact host/runtime/disclosure profile is admitted. Missing vendor credentials blocks its route, not independent declarative code.

No application ticket is accepted in this delivery. Reopen impacted external v3 evidence per [migration report](verification/v3-to-v4.json); do not blindly copy prior accepted state. Completion requires all named checks at the actual layer, commit/lock/profile-bound artifacts and independent review. The control tools validate structure/integrity; they cannot prove fabricated logs true.
