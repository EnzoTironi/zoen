"""Reviewed v4 refinements. Existing task identities are preserved; new work appends.
Only transport adapts: every data-bearing operation enters SPEC-007's executor.
"""
from __future__ import annotations

COMMON = 'architecture/semantic-path.md'
APPS = 'architecture/mini-app-contract.md'
LINKS = 'architecture/protected-links.md'
HOST = 'architecture/app-host-security.md'
RIVET = 'architecture/rivet-adapter.md'
TEST = 'testing/mini-app-conformance.md'


def extend_catalog(S, spec, task):
    def new(title, stem, steps, given, when, then, neg, boundary, deps, *, stage, module=None,
            caps='C124', layer='component', gate=None, reads=(), allowed=(), primary=None):
        t=task(title,stem,steps,given,when,then,caps=caps,layer=layer,risk='critical',gate=gate)
        t.update(slice=stage,negative=neg,boundary=boundary,deps_keys=deps,
                 read_more=[COMMON,*reads],allowed_more=list(allowed))
        if module:t['module']=module
        if primary:t['primary']=primary
        return t
    # Strengthen existing owners rather than adding a second policy or data engine.
    notes={
      0:'V4 is the execution source of truth. Preserve the input-v3 archive and stable IDs; compile a no-bypass import/credential graph for app, agent and human clients.',
      7:'SPEC-050 names and constrains this existing dispatcher as SemanticExecutor. It does not create another executor. Every human UI, agent, mini app and programmatic adapter resolves the same released operation and invokes this implementation. Read, discovery, mutation, subscription and export share authority and result semantics.',
      9:'Eve is a semantic client, never a prerequisite for structured application calls. No LLM is involved in a structured table read unless a released operation explicitly requests a model.',
      10:'Grounding and tool execution use the SPEC-007 SemanticExecutor through a narrow client. Model-generated principal, role, grants or provider credentials are never accepted as authority.',
      11:'ZN-0068 consumes the reusable authority-free continuation registry and browser exchange in SPEC-051. A URL, WhatsApp delivery receipt or sender number cannot confer World access. Preview GET/HEAD is generic and never redeems a challenge.',
      12:'The accessible trusted host is reused by mini apps. Secure login/logout, inspection, evidence and confirmations are not reimplemented per app.',
      13:'The SurfaceManifest is the sole published operation discovery source for humans, agents and apps. SPEC-052 adds a bounded declarative app grammar over this graph, not a second DSL for business meaning.',
      14:'MiniAppDefinition and AppPublicationBinding participate in this same release process. Runtime preparation and evaluation do not activate a public app. Publication, sharing and execution authority are distinct. Old-policy approval, prepared basis, manifest/artefact closure and emergency recall are rechecked at activation.',
      15:'A source connector is an acquisition implementation behind admitted source operations, not an app-owned data API. Apps cannot call OAuth providers directly, ask for connector credentials or bypass evidence admission.',
      18:'The common executor intersects current subject/delegation rights, admitted app capabilities, session purpose/scope and current source rights. App creators do not lend their privileges. Equal-basis noninterference includes app discovery, assets, exports, cursors, errors, counts and streams.',
      20:'Mini-app subscriptions use the same released subscription operations and semantic Notice/Watch mechanisms as other clients. Reauthorize before every dispatch; revoked clients receive no data-bearing tombstone or hidden-object count.',
      22:'Mini-app form submissions invoke the same ActionCase/approval/commit implementation as chat and SDK. Consequential confirmation is rendered by the trusted host from a server-authorized Case, never trusted from app HTML or postMessage approval=true.',
      23:'An app has no generic provider-write path through a runner broker. Consequential provider calls consume the existing committed EffectIntent and current effect permit; a runtime success response is not settlement.',
      24:'Background app jobs act under an explicit workload identity/delegation and bounded Mandate. They do not reuse a departed human browser session or inherit the publisher rights.',
      25:'Retrieval and specialized agents use the single semantic executor. A vector index, cache or specialized model is an internal implementation detail, never an app-visible bypass.',
      26:'REST, CLI, SDK, MCP, Eve and mini-app clients are transport adapters for SPEC-007. They preserve the operation, current context, exact basis and idempotency identity; they do not duplicate policy logic. The simple semantic client is available before S5; these tickets add full generated surfaces.',
      27:'Views and exports reuse the early SPEC-052 app renderer and shared semantic client. Do not introduce direct SQL/chart/index endpoints. Evidence references and provenance are preserved through display transformations.',
      29:'An executable app reuses this signed artifact/install/recall contract. Requested capabilities are not granted capabilities. Frontend-only signed bundles need not provision a backend. No credentials, private dataset or bootstrap snapshot may be compiled into an app bundle.',
      30:'Distinguish semantic app calls from source acquisition and provider-effect broker lanes. App-facing BrokerRead/BrokerCall resolves released semantic operations through SPEC-007 only; it cannot expose a URL, arbitrary SQL, raw database handle or provider credential. Trusted connectors and effect workers retain their separately admitted internal roles; apps cannot request those roles.',
      31:'Bulk snapshots reach clients only through a released authorized read/export/analysis operation. Internal Iceberg/S3/DuckDB ports remain inaccessible to apps. Opaque chunk/cursor references carry no authority and are rechecked on retrieval.',
      33:'Apps subscribe through the common executor and entitlement checks. A WebSocket or SSE handshake does not authorize the lifetime of the stream; send/resume/queue-flush reauthorize. No raw feed endpoint for a chart.',
      37:'Pack upgrade/recall covers app definitions, immutable executable bindings, sessions and open Cases. A stable link resolves the admitted publication; it never follows a vendor latest alias or restores recalled code.',
      44:'Offline execution is the same admitted semantic implementation and bounded grammar inside a distinct leased child World. Do not use disconnected mini-app caches as a second offline authority or silently queue external provider writes.',
      48:'Final acceptance includes SPEC-055 cross-surface capstones and all v4 requirement checks. A browser/runtime qualification cannot be inferred from package-control tests or transport simulations.',
      49:'Private owner-only continuation and data-defined apps can be admitted without Rivet, dense storage or institutional SSO. User-supplied executable code remains off until its exact isolation and host gates pass.'
    }
    for n,note in notes.items():
        S[n]['protocol'] += '\n\nV4 refinement: '+note
        S[n]['extra'] += '\n\nV4 normative detail: [single semantic path](../architecture/semantic-path.md).'
    S[35].update(
       title='Progressive Workshop: early declarative apps, isolated views and full Studio',
       slice='S8',deps=[14,27,29,30,31,52,53],
       decision='Studio is an advanced authoring surface over the same runtime definitions and semantic executor. Declarative runtime is delivered in S2, isolated executable delivery in S6 and rich Studio in S8. There is one app renderer/host, not a replacement at each milestone.',
       storage='MiniAppDefinition is released meaning owned by Ontology. SPEC-052 owns definition/manifest contracts; SPEC-051 owns authority-free links and scoped execution sessions; SPEC-029 owns signed artifacts; SPEC-053 owns non-authoritative bridge/runner state. eve.builder_drafts remains non-authoritative authoring state. No app authority database.',
       operations='EditDraft -> Draft; PreviewApp -> IsolatedPreview; PublishApp -> existing DefinitionChange process. AppBridgeRequest is a transport envelope for SemanticCall, not a domain data API.',
       protocol='Reuse SPEC-050..054 without business logic in the bridge. Agent and human editors use the same runtime change operations. Full Studio composes the already-shipped declarative renderer, safe host, signed executable artifact and published operation manifest. It must not route reads through Eve/LLMs, access source credentials or create a second reconciliation engine.',
       extra='\nPer-ticket stages override this full-Studio S8 label. ZN-0203 is S2; ZN-0204 and ZN-0205 are S6; ZN-0202 and ZN-0206 remain S8. Their exact DAG is normative; dense infrastructure is not required for the early renderer.\n\nRead [mini-app contract](../architecture/mini-app-contract.md), [links](../architecture/protected-links.md) and [host security](../architecture/app-host-security.md).')

    spec(50,'One semantic executor and transport-only client contract','S0','Kernel and Client Platform','packages/ontology/src/surfaces',[7],
      'interfaces-sdk-and-mcp.md;rights-and-access-control.md',
      'Name and extend SPEC-007 dispatch.ts as the single SemanticExecutor. No generic app API, policy clone, agent-only read path or LLM requirement. Surface adapters translate transport only. Equality is semantic at equal principal/delegation, audience, purpose, app constraints, release, cut and source rights; no requirement for byte-identical presentation.',
      'No new authority store. Reuse operation registry, grants, read guards, ActionCases, receipts and outbox. Descriptor/cache keys bind world, principal, delegation, app binding, purpose, release, query digest, cut and security revision. Cursor/chunk handles are references, not bearer permits.',
      'SemanticCall(envelope, verifiedRequestContext) -> tagged SemanticResult. Discover, Inspect, Propose, AnswerCase, Commit, Subscribe, Export and admitted Analysis are released operation families, not free-form repository methods.',
      'Use the existing dispatcher and current disclosure checks for every ingress including resumptions and background calls. Preserve original operationId on retry/continuation; distinct IDs are distinct intentions, not magically deduplicated. Compare normalized meaning rather than prose. Verify context at the server; transport headers never set identity. Bounded batch/async operations reuse per-item policy and exact basis.',
      [
       new('Bind every structured ingress to the existing semantic dispatcher','executor-binding',
        'Define a small SemanticClient port in packages/contracts; connect it to SPEC-007 dispatch.ts, do not create a second dispatch engine || Wire web/CLI and trusted internal adapters to the same registration table and operation handlers || Add instrumented executor-entry witness for component tests; production logs contain opaque IDs and digests only',
        'The S0 Frame dispatcher and two authorized conflicting records exist', 'Web and CLI issue the same Inspect under equal verified context and pinned basis',
        'Both enter SPEC-007 dispatch.ts and return the same authorized interpretation, rival references, basis and result tag; no model invocation occurs',
        'A client-supplied principal, raw SQL or source URL is rejected before repository access',
        'A duplicate operation with the same identity preserves its existing result; changing surface is not a new idempotency namespace',
        ['SPEC-007:dispatch','SPEC-007:discovery'],stage='S0',caps='C094 C097 C013',reads=[TEST],
        allowed=['packages/ontology/src/surfaces/dispatch.ts','packages/contracts/src/semantic-client.ts','packages/clients/src/semantic-client.ts','packages/clients/src/index.ts','apps/edge/src/composition.ts']),
       new('Enforce client-to-data import and credential boundaries','no-bypass-graph',
        'Classify trusted executor/repository composition and untrusted human, agent, app and runner client roots || Deny imports of repositories, SQL/index clients and source credentials from client roots; account for reexports and dynamic imports || Define a network/secret allowlist regression fixture and fail on any new unreviewed data ingress',
        'The declared module graph and all S0 client roots', 'A mini-app or Eve module imports a raw pg adapter through a barrel',
        'The static gate fails with the forbidden edge; ordinary SemanticClient imports remain valid',
        'An import alias or dynamic import cannot evade the same dependency gate',
        'A disconnected checker or zero selected files fails rather than certifying an empty graph',
        ['SPEC-050:executor-binding','SPEC-000:workspace'],stage='S0',layer='static',caps='C094 C103',
        module='tooling/semantic-boundaries',allowed=['.dependency-cruiser.cjs','eslint.config.mjs','apps/edge/src/composition.ts']),
       new('Bind current app and delegation restrictions in verified context','effective-context',
        'Intersect subject/delegation rights, installed app ceiling, session scope and current source rights in the shared grant admission || Store no grant in URLs or UI state; reject forged app, World, purpose, operation and recipient substitutions || Attach subject, actor, application, installation and purpose to audit attribution without changing the core idempotency key',
        'A private owner opens an app whose admitted ceiling excludes the money field', 'The app requests production data and then tries a money operation available to the owner outside this app',
        'Production is returned and money is denied under the same owner authorizer plus app ceiling; app capabilities cannot expand rights. S3 separately proves worker sharing',
        'An attacker setting creatorPrincipal or changing installationId cannot increase access',
        'Revoke the owner app session after admission but before final disclosure; no new protected result is dispatched',
        ['SPEC-050:executor-binding','SPEC-014:activate'],stage='S2',caps='C054 C082 C124',reads=[LINKS],
        allowed=['packages/ontology/src/surfaces/dispatch.ts','packages/contracts/src/semantic-client.ts','packages/ontology/src/rights/app-context.ts']),
       new('Implement bounded batch, cursor and export calls on the shared surface','bounded-reads',
        'Add versioned batch-inspect/query descriptors with bounded operations/rows/output and an explicit coherent read basis || Implement opaque cursor and export handles bound to the same authorized plan; each page/chunk retrieval rechecks rights || Keep async work admission separate from result retrieval and respect cancellation/backpressure; never expose SQL or a public presigned data URL',
        'A permitted 200-row page and a restricted finance field exist', 'The app and SDK ask for the same authorized aggregate, page and export',
        'Results carry equivalent basis/provenance and contain no forbidden field/count; over-limit requests receive QuotaExceeded without partial undisclosed truncation',
        'A cursor from another principal, World, query or security revision is rejected without disclosing its dataset',
        'Revoke after export generation but before download; download is denied and retry cannot reuse the old authorization',
        ['SPEC-050:effective-context','SPEC-026:surface-conformance','SPEC-027:view-export'],stage='S5',caps='C094 C097 C082',reads=[TEST],
        allowed=['packages/ontology/src/surfaces/dispatch.ts','packages/contracts/src/semantic-client.ts']),
       new('Unify subscriptions, chunk leases and dense reads without bypass','streaming-path',
        'Route SSE/WebSocket/resume and dense snapshot retrieval through the same released operations || Check current visibility before each send/queue flush; apply bounded buffers and gap semantics || Keep blob/catalog/feed credentials internal; lease data to analysis only after semantic authorization and validate derivative rights',
        'An app stream is backpressured and a dataset chunk was staged', 'Membership is revoked before queued delivery and the client reconnects with the old cursor',
        'No queued private payload is dispatched, cursor replay cannot reveal a tombstone/count, and permitted clients retain exact pinned snapshot semantics',
        'Direct raw-feed, object-store and catalog URLs are unreachable from app roots',
        'Revocation or authorization-store outage closes protected delivery fail-closed; already emitted bytes are not claimed to be retractable',
        ['SPEC-050:bounded-reads','SPEC-033:live-journey','SPEC-031:dataset-read'],stage='S7',caps='C094 C109 C110',reads=[HOST,TEST])
      ],extra='\nCanonical detailed contract: [semantic path](../architecture/semantic-path.md). Tickets introduce successively richer families; early S0 use does not depend on S3/S7 work.')

    spec(51,'Authority-free continuation links and scoped application sessions','S1','Identity and Application Host','packages/ontology/src/continuations',[2,7],
      'interfaces-sdk-and-mcp.md;rights-and-access-control.md',
      'A link identifies an authorized continuation target; it is never a bearer World grant. Opening, authenticating, approving publication and sharing are distinct operations. Reuse Focus and Door; no second login or mini-app ACL database.',
      'ontology.continuations(link_ref PK,world_id,realm,focus_ref,target_kind,target_ref,version_policy,recipient_constraint_nullable,expires_at_nullable,state,creator,created_receipt); target_kind=focus|app. ontology.app_sessions(session_ref PK,world_id,realm,principal,actor,installation_ref_nullable,publication_binding,scope_digest,purpose,assurance,security_revision,expires_at,state). Relationships/World grants remain existing ontology records. Opaque handles have at least 192 random bits; logs are redacted. Door owns browser challenge records, not app business permissions.',
      'CreateContinuation(target,scope,recipient?,expiry?,operationId) -> LinkRef; ResolveContinuation(ref) -> GenericLanding|AuthorizedTarget; OpenApp(ref,verifiedPresence) -> AppSession|Denied; RevokeContinuation(ref) -> Receipt; RevokeAppSession(ref) -> Receipt.',
      'GET/HEAD, previews and unauthenticated asset requests are generic and side-effect free. POST exchange uses CSRF/origin protections, a browser-bound challenge and verified identity before disclosure. No access token in the URL. Invitation acceptance is a separate governed operation. Every later semantic call checks current rights; link expiry and session revocation are enforced independently. Archived historical views use current rights and cannot reactivate recalled code.',
      [
       new('Implement authority-free continuation references over Focus','continuation-registry',
        'Define scoped random references for Focus/app targets with immutable target and recipient constraints || Create/revoke through existing governed operations and global operationId rules || Resolve unauthenticated GET/HEAD to a generic no-store page; do not render private names, manifests or evidence',
        'Two links point to different private Worlds', 'A crawler or unauthenticated browser requests both references',
        'Both receive the same generic landing schema with no protected metadata; neither request grants membership, redeems a challenge or mutates a target',
        'A guessed ref, wrong realm or forwarded recipient-bound ref reveals no existence data before authentication',
        'Repeated GET/HEAD and preview requests leave challenge/link state unchanged',
        ['SPEC-050:executor-binding','SPEC-002:world-entry'],stage='S1',caps='C013 C052',reads=[LINKS],
        allowed=['apps/edge/src/routes/continuations.ts','apps/edge/src/composition.ts']),
       new('Implement browser-bound authenticated continuation exchange','browser-exchange',
        'Reuse Door login/passkey/SSO profiles and bind a single-use challenge to an HttpOnly host-only browser session and target digest || Require POST with CSRF and exact Origin checks for exchange; rotate session after authentication and validate recipient || Scrub tokens from history, referrers, telemetry and redirects; allow only local registered return targets',
        'A recipient-specific reference is opened in two unrelated browsers', 'The wrong browser posts a copied challenge while the intended browser authenticates',
        'Only the correctly bound authenticated recipient can exchange; possession of the reference alone is insufficient',
        'Open redirect, login CSRF, challenge replay, forwarded OTP alone and mismatched recipient fail without protected content',
        'Race two valid redemption attempts; only one transition succeeds and neither GET nor preview consumes the challenge',
        ['SPEC-051:continuation-registry','SPEC-002:presence'],stage='S1',module='packages/door/src/continuation',caps='C013 C052',reads=[LINKS],
        allowed=['apps/edge/src/routes/continuations.ts','apps/edge/src/composition.ts','apps/web/src/experience/continuation.tsx','apps/web/src/routes.tsx']),
       new('Verify link preview, logout and shared-device privacy','continuation-browser-proof',
        'Exercise real browser storage/history/referrer/cache behavior against the trusted host || Verify owner-only Focus continuation before app runtime exists || Log out then navigate back and reopen the original link under a second account',
        'A protected bill was viewed and the same device is then used by another person', 'Logout, history-back, link preview and second-account login occur',
        'The host clears its private views and cached session state; the second user must independently authorize; preview never reveals bill metadata',
        'No token or private title appears in URL, referrer, shared cache or analytics fixture',
        'A challenge that expires during navigation cannot redeem; the host offers a fresh login path without guessing success',
        ['SPEC-051:browser-exchange','SPEC-012:shared-device'],stage='S1',layer='journey',caps='C013 C060',reads=[LINKS,TEST]),
       new('Implement scoped app-session open, expiry and revocation','app-sessions',
        'Bind a session to verified actor/subject, World/realm, current published manifest/artifact, purpose and admitted app ceiling || Keep only an opaque host-side session handle; never disclose a World token to a guest || Recheck active publication/recall/security state on every semantic call, refresh and resume',
        'A private app is published and the same owner opens two purpose-scoped sessions', 'The owner opens the stable link and one purpose-scoped session expires or is revoked',
        'Each permitted session is independently scoped; expired/revoked sessions cannot call any data operation or regain authority through a refresh token',
        'Changing app, World, artifact digest or purpose through a query parameter is rejected',
        'A published version changes while the form is open; the pinned session gets compatible refresh or ContractChanged/Stale, never silent new action semantics',
        ['SPEC-051:browser-exchange','SPEC-052:app-publication','SPEC-050:effective-context'],stage='S2',caps='C124 C054',reads=[LINKS,APPS]),
       new('Share app references without changing membership or lending rights','app-sharing',
        'Add governed share UI using existing invitation/delegation operations separately from CreateContinuation || Bind optional recipient restriction and permitted audience context; no app-owned ACL grants || Explain reauthentication and missing access without disclosing hidden target metadata',
        'A bakery owner creates a production-only view for a worker', 'The worker forwards the same link to an external person',
        'The worker sees only permitted production fields; the external person receives no access unless a separate invitation/grant is approved and accepted',
        'Publisher role, channel-group membership and possession of the link never create domain membership',
        'Revoke the grant while the share dialog is open; sending the link cannot resurrect the permission',
        ['SPEC-051:app-sessions','SPEC-018:delegation'],stage='S3',caps='C054 C060 C124',reads=[LINKS],
        module='apps/web/src/mini-apps',allowed=['apps/web/src/routes.tsx']),
       new('Prove protected app access in deployed host and browser profiles','protected-link-admission',
        'Qualify TLS/DNS, cookie separation, edge/cache headers, CSRF/origin and challenge handling on a real deployed host || Run device/browser matrix including unavailable storage and embedded-browser fallback; never require a third-party cookie to reach a direct host link || Record independent security evidence and disable only protected app delivery when it fails',
        'A real shared pilot and the complete protected-link journey', 'The exact host/browser profile requests admission',
        'Admission cites deployed configuration, browser traces, revocation results and negative tests; missing evidence leaves the route disabled',
        'A localhost-only simulation or unverified DNS/cookie profile cannot satisfy G-APP-LINKS',
        'Cookie, domain, IdP or host changes invalidate the corresponding profile evidence until requalified',
        ['SPEC-051:app-sharing','SPEC-049:pilot-readiness','SPEC-051:continuation-browser-proof'],stage='S3',layer='admission',gate='G-APP-LINKS',caps='C124 C052',reads=[LINKS,TEST])
      ],extra='\nDetailed routes, challenge states, version modes, scopes and cache behavior: [protected links](../architecture/protected-links.md). S1 only supports private Focus; S2 adds private app continuation; S3 admits sharing. Application sessions never substitute for current semantic authorization.')

    spec(52,'Early declarative mini apps as released data','S2','Ontology and Product Runtime','packages/ontology/src/apps',[13,14],
      'apps-charts-and-surfaces.md;runtime-variation-and-releases.md',
      'Most mini apps are immutable bounded definitions referencing existing semantic operations. Trusted renderer components run without generated JS, SQL or backend deployment. User and agent author the same definition/change operations; temporary presentation state is not company truth.',
      'MiniAppDefinition closes over appId, pages, approved component registry versions, query/action bindings, form schemas, requested capabilities, resource budget and accessibility labels. It is immutable release content. AppPublicationBinding(appId, manifestDigest, mode, optional artifactDigest, runtimeProfileRef) belongs to the released graph. Drafts remain existing builder_drafts; no mutable runtime latest alias is authority.',
      'ValidateMiniApp(definition,baseRelease) -> ValidatedManifest|Errors; InstantiateAppTemplate(template,parameters) -> DefinitionChange|InstanceAction; PublishApp(change) -> existing release process; OpenView(session,bindings) -> SemanticCalls through SPEC-050.',
      'No eval, arbitrary HTML/script, provider URL, SQL or hidden direct data bindings in declarative mode. Operators and component versions are allowlisted and bounded. Queries use stable semantic IDs and exact authorized basis; display transformations cannot manufacture authoritative metrics. Create, publish and share are separate. Runtime compilation of an executable app is not app activation.',
      [
       new('Define bounded MiniAppDefinition and manifest schemas','app-definition',
        'Add declarative routes, components, form bindings, read/action references and declared capability ceiling to the released grammar || Validate stable IDs, dependency closure, labels, bounded nodes and per-view query budgets || Refuse executable expressions and external fetch URLs; use a template instance lane only when the existing policy explicitly covers exact parameters',
        'An admitted order type, production view and existing Inspect operation', 'A model proposes a board with table/detail/filter widgets and released bindings',
        'A deterministic validated manifest is emitted without adding TypeScript domain code or a new backend',
        'Unknown widget, script tag, SQL, principal field, prototype-polluting key or unbounded query rejects the draft',
        'Reorder equivalent maps and recompile; digest stays equal; exceed component/query limits and validation fails explicitly',
        ['SPEC-013:compiler','SPEC-050:executor-binding'],stage='S2',layer='component',caps='C030 C124',reads=[APPS],
        allowed=['packages/contracts/src/mini-app.ts','contracts/mini-app-definition.schema.json']),
       new('Bind declarative app queries and forms to published operations','app-bindings',
        'Resolve every binding against the same released SurfaceManifest used by agents and SDK || Validate field schemas, disclosure, operation class and resource budget without materializing forbidden data || Compile only display plan and operation arguments; never compile policy or business truth into the renderer',
        'Two comparable sources disagree about one order deadline', 'The app, Eve and CLI inspect the exact same pinned Frame',
        'The board shows the same selected/unresolved interpretation and allowed evidence; a hidden rival is absent from all visible metadata',
        'A binding naming an unadmitted operation or a denied field does not trigger a fallback source query',
        'Activation removes a referenced operation; the app receives ContractChanged rather than inventing a replacement',
        ['SPEC-052:app-definition','SPEC-014:evaluation-world'],stage='S2',caps='C124 C097',reads=[APPS,TEST]),
       new('Publish app definitions through existing release activation','app-publication',
        'Attach manifest and required artifact closure to DefinitionChange evaluation and preparation || Reuse current-policy approval and atomic head activation; do not add an app-local activate flag || Pin existing sessions, classify open Cases and provide explicit compatible refresh; separate public routing binding from runtime staging',
        'A candidate app changes one permitted presentation binding', 'The user or agent evaluates, approves and activates it',
        'Only the approved prepared definition becomes routable; historical release and evaluation remain separate; no server redeploy is needed',
        'A candidate requesting extra permissions cannot use its own rules to approve publication',
        'Head changes between preparation and activation yield PreparationStale; a previously successful runtime stage remains nonpublic',
        ['SPEC-052:app-bindings','SPEC-014:activate'],stage='S2',caps='C034 C124',reads=[APPS,RIVET],
        allowed=['packages/ontology/src/releases/app-bindings.ts','packages/ontology/src/releases/index.ts']),
       new('Ship the private read-only mini-app first-use journey','private-app-journey',
        'Use Eve structured draft generation with the same editor operations and the early trusted renderer || Open an authenticated owner-only link to a bakery board and a household bill view || Demonstrate missing data, divergent sources, evidence inspection, keyboard access and 200-percent zoom without executable runtime',
        'A household World and bakery World contain authorized synthetic divergent records', 'Each owner asks Eve to create a read-only app, evaluates it and opens the supplied link',
        'Both apps work without Rivet, dense storage, full Studio or arbitrary tools; meanings remain equivalent to CLI and Eve at the same basis',
        'A request to call a bank API directly or expose the app publicly is refused or becomes an explicit separate governed change',
        'A failed definition activation leaves the previous app visible; reauth or missing source produces an honest accessible state',
        ['SPEC-035:declarative-app','SPEC-052:app-publication','SPEC-051:app-sessions','SPEC-010:composition'],stage='S2',layer='journey',caps='C124 C013',reads=[APPS,LINKS,TEST]),
       new('Bind mini-app forms to host-controlled ActionCase confirmations','app-actions',
        'Map form submission to existing propose/answer/commit operations using the shared semantic client || Render consequence, expiry, basis and approval in trusted host chrome fetched from the server || Carry operation identity across chat-to-app handoff; retain Unknown external results and re-propose stale consent explicitly',
        'A user begins one action in chat and opens the same Case in an app', 'The form confirms it with the same identity while a retry arrives from chat',
        'At most one decision receipt/effect intent is committed; the host displays the authoritative consequence and settlement remains separately observed',
        'Guest-supplied approved=true, changed principal or a different hidden consequence cannot commit',
        'Insert a newly matching dependency between display and approval; every surface returns Stale with no receipt/effect',
        ['SPEC-052:private-app-journey','SPEC-051:app-sessions','SPEC-022:approval-surfaces','SPEC-023:effect-reconcile'],stage='S4',caps='C066 C124',reads=[APPS,HOST,TEST],
        module='apps/web/src/mini-apps',allowed=['apps/web/src/approvals/host-confirmation.tsx','apps/web/src/routes.tsx']),
       new('Implement uninstall, recall and compatible app upgrades','app-lifecycle',
        'Classify link/session/form behavior for upgrade, retirement, recall and historical rendering || Reuse pack release and artifact revocation; clear owned private caches and block new calls when recalled || Retain audit receipts without resurrecting erased data or older unsafe executable code',
        'An app has active links, forms and a pinned old release', 'The publisher recalls the executable artifact or the owner uninstalls the app',
        'New sessions are blocked and active sessions stop protected calls; historical evidence uses a safe admitted renderer or explicit unavailability',
        'An old stable URL, stale runtime cache or rollback cannot reactivate a recalled artifact',
        'Crash after revocation before cache invalidation; per-call current-state checks still deny access on every host instance',
        ['SPEC-052:app-actions','SPEC-037:pack-upgrade','SPEC-029:artifact-recall'],stage='S8',caps='C124 C125 C128',reads=[APPS,LINKS,HOST])
      ],extra='\nDetailed contract: [mini-app definitions and lifecycle](../architecture/mini-app-contract.md). ZN-0203 supplies the trusted renderer at S2; these tickets supply its semantic definitions. Full S8 Studio reuses both.')

    spec(53,'Isolated app host and transport-only bridge','S6','Platform Security and Browser Host','packages/clients/src/app-host',[29,30],
      'apps-charts-and-surfaces.md;programmable-compute-and-skills.md',
      'Generated frontend code is hostile. Serve an immutable bundle on an isolated, cookieless app origin and mediate messages in trusted host chrome. A specialized backend runs outside authority with explicit leases. Bridge validation adds containment, not domain permission or business logic.',
      'No business authority store. Host-owned ephemeral bridge state records window identity, session binding, exact guest origin, channel nonce, request sequence, publication/artifact digest and bounded pending calls. Runner state keys include World/realm/principal/purpose/installation/version/session; shared collaboration is separately admitted. Private response/cache state is never keyed only by appId.',
      'BindAppFrame -> BridgeBinding; TransportSemanticCall(binding,request) -> existing SemanticExecutor; CloseAppSession -> close/drain; StageStaticBundle(artifact) -> nonpublic immutable asset ref. Host confirmation invokes existing ActionCase operations.',
      'Host-only HttpOnly secure sessions; no cookies/Authorization/X-Forwarded identity reach guest code. Default deny guest network APIs, top navigation, forms, popups, downloads and service workers; browser self-navigation is not assumed preventable. Private data enters executable frontends only under the admitted disclosure profile in the host contract. Exact allowed origins/MessagePort binding and typed messages prevent confused deputy calls. No generic fetch or direct provider broker. Untrusted runtime runs in qualified external containment, never inside the authority process.',
      [
       new('Provision isolated origins and signed private asset serving','app-origins',
        'Separate trusted host and guest on distinct registered-site boundaries under an admitted TLS/DNS profile || Serve digest-addressed audited bundles only after host authorization; no data or secrets inside bundle || Enforce CSP, sandbox flags, no shared cookies, no-store private assets fetched by the trusted host and transferred to a generic guest loader over the bound MessageChannel; no third-party cookies or URL grants; deny controlled egress APIs/top navigation/forms/workers and require the explicit executable data-disclosure profile',
        'Two users with different rights load the same signed generated app', 'The browser requests HTML, scripts, assets, icons and source maps directly and through the host',
        'Only the authorized bundle is served; no source map, manifest, private title or data appears through an unauthenticated route',
        'A guest iframe cannot read host cookies, storage or parent DOM and cannot register a service worker controlling the trusted host',
        'Domain/asset cache changes fail admission until the exact profile is rechecked; executable code is not enabled by a DNS name alone',
        ['SPEC-029:artifact-install','SPEC-051:app-sessions','SPEC-030:runner-profile'],stage='S6',caps='C125 C103',reads=[HOST],
        allowed=['apps/edge/src/routes/app-assets.ts','apps/edge/src/composition.ts','infra/terraform/app-host/main.tf','infra/terraform/app-host/variables.tf']),
       new('Implement strict message bridge into the existing SemanticClient','bridge-transport',
        'Bind exact frame window, random session channel and artifact digest before accepting messages || Validate strict operation envelopes, bounded sizes/sequences and replay identity; then call existing SemanticClient || Permit only advertised released operations intersected with session capabilities; no fetch/proxy/open-url/data-query escape method',
        'A bound app iframe and an unrelated sibling iframe exist', 'Both send a well-formed Inspect message',
        'Only the bound frame can forward to the existing executor; output uses the same authorized result contract as web/CLI',
        'Forged source window, origin, nonce, prototype key, principal or unrecognized message kind is rejected before dispatch',
        'Reload/navigation replaces the frame; old messages and pending callbacks cannot bind to the replacement session',
        ['SPEC-053:app-origins','SPEC-050:effective-context'],stage='S6',caps='C125 C094',reads=[HOST,TEST],
        allowed=['packages/contracts/src/app-bridge.ts','packages/contracts/src/semantic-client.ts']),
       new('Strip credentials and isolate backend identity and mutable state','guest-backend',
        'Treat guest HTTP routes as untrusted computation, not a new database API || Strip Cookie, Authorization, forwarded identity, internal grant and hop-by-hop headers; strip guest Set-Cookie and unsafe redirect response headers || Provide a server-brokered request-bound semantic binding and per-subject execution state, with no provider/source/authority credentials',
        'A worker and an owner alternate calls to one logical appId', 'Generated code retains a module variable and echoes inbound headers',
        'No owner data, token or identity header is available in the worker execution; guest cannot choose principal/partition; protected data is withheld when executable disclosure is not separately admitted',
        'Direct guest /api, WebSocket upgrade, error page and debug/log routes cannot invoke any data path without authenticated host mediation',
        'Warm runner reuse or restored snapshot across mismatched subject/purpose/rights is denied or freshly isolated',
        ['SPEC-053:bridge-transport','SPEC-030:capability-broker','SPEC-030:runner-limits'],stage='S6',caps='C125 C102 C103',reads=[HOST,RIVET],
        module='runners/apps',allowed=['apps/edge/src/routes/app-proxy.ts','apps/edge/src/composition.ts']),
       new('Enforce session revocation, streaming and host confirmation boundaries','host-revocation',
        'Check current auth/recall at each read, action, export chunk, stream flush and resumed call || Cancel host-owned tasks and purge host caches on logout/recall; close or recreate guest contexts after rights reduction || Keep actionable confirmation in trusted chrome; deny private guest disclosure absent an admitted profile; report self-navigation/copying limits and do not claim to retract disclosed data',
        'A live guest has a queued private update and a stale approval form', 'Rights are revoked before the queue flush or form commit',
        'No new protected frame/chunk is dispatched; form commit is denied or stale by the same central executor; guest HTML cannot synthesize approval',
        'A stale cursor, retained session ref or token copied from another app cannot bypass revocation',
        'Authorization service unavailable during a flush blocks protected output rather than relying on a stale allow cache',
        ['SPEC-053:guest-backend','SPEC-052:app-actions','SPEC-026:status-stream'],stage='S6',caps='C125 C054 C066',reads=[HOST,TEST]),
       new('Admit the real isolated executable browser-host profile','host-admission',
        'Run hostile frontend/backend fixtures in actual browsers and the qualified runner substrate || Verify cookie/site separation, CSP, message source, data egress, private asset access, state partition and revocation || Bind evidence to host domain topology, browser matrix, artifact digest and runner lock; keep failed profiles disabled',
        'The full executable app host is deployed under its intended isolation profile', 'Independent security review exercises the documented adversarial matrix',
        'G-APP-HOST is admitted only with real browser/runner evidence and bounded workload limits; a contract test alone is insufficient',
        'A passing local bridge test without containment or deployed-origin evidence cannot admit generated execution',
        'Changing origin layout, runner build, cookies, CSP or external host version invalidates relevant admission evidence',
        ['SPEC-053:host-revocation','SPEC-030:runner-security-proof','SPEC-051:protected-link-admission'],stage='S6',layer='admission',gate='G-APP-HOST',caps='C125 C103',reads=[HOST,TEST]),
       new('Qualify negotiated MCP Apps host and safe link fallback','mcp-host-admission',
        'Negotiate the exact supported MCP Apps dialect and host capabilities without inventing universal support || Exercise shared SemanticClient tool calls and isolate host/provider scopes; mediate external host egress and confirmations || For insufficient host controls return structured text or a protected Zoen link, not a raw token/resource bypass',
        'One admitted external host and one unsupported host request the same app', 'The tool returns its UI resource under each negotiated profile',
        'The admitted host respects source rights/session limits; the unsupported host receives the declared safe text/link fallback with no hidden data',
        'A host that cannot enforce required isolation, current rights or trusted confirmation cannot receive consequential app capabilities',
        'Host/SDK/protocol change reopens G-MCP-APPS evidence; pinned old resources cannot preserve revoked access',
        ['SPEC-035:mcp-apps','SPEC-053:host-admission'],stage='S6',layer='admission',gate='G-MCP-APPS',caps='C126',reads=[HOST,TEST])
      ],extra='\n[Browser and runner threat contract](../architecture/app-host-security.md). ZN-0204 composes this host with the existing application shell; it does not rewrite the bridge. Admission is independent of the declarative app path.')

    spec(54,'Rivet Dynamic Apps Core qualification and immutable runtime adapter','S6','Runtime Platform','packages/adapters/src/app-runtime/rivet',[29,30,53],
      'apps-charts-and-surfaces.md;programmable-compute-and-skills.md',
      'Rivet Dynamic Apps Core is the first candidate specialized backend adapter, not the required substrate of declarative apps or an authority service. Current upstream Preview/API behavior must be qualified at an exact lock. Candidate deployment and Zoen publication must stay separate even if deployApp activates its internal appId.',
      'jobs.app_runtime_preparations(preparation_id PK,world_id,realm,manifest_digest,artifact_digest,profile_digest,runtime_slot_ref,host_state_partition,attempt_fence,status,attestation_ref,expires_at); jobs.app_runtime_slots(slot_ref PK,immutable_identity,digest,runner_scope,state). Public AppPublicationBinding remains in the released Ontology graph. Runtime process globals/SQLite are not authoritative company data.',
      'Zoen-owned port: PrepareRuntime(artifact,profile,realm) -> PreparedRuntime; ProbeRuntime(preparation) -> Attestation; ResolvePreparedRuntime(binding,session) -> IsolatedTarget; RetireRuntime(slot) -> Result. These are Zoen adapter contracts, not asserted Rivet API names.',
      'Read the dated primary-source ledger and recheck the actual APIs before pinning. Build in an isolated build plane with a locked dependency graph and no live credentials. Internal successful deploy is not public authorization. Map candidate/version IDs immutably; the edge resolves only an approved Zoen binding. No runtime latest alias, public preview bypass, automatic namespace with production secrets or automatic generated permission config.',
      [
       new('Qualify the exact Rivet Core API and compatibility boundary','rivet-api-probe',
        'Read current upstream Core/deploy/routing/security contracts and resolve an exact extension lock || In real disposable Core instances test build failure, successful internal activation, data hooks, release invalidation and isolation configuration || Record incompatibilities as Blocked; do not invent an inactive-deploy flag or call a documented deploy method a dry run',
        'An exact candidate @rivet-dev/dynamic-apps-core lock and disposable environment', 'The probe runs against actual packages rather than a protocol simulator',
        'A commit/lock-bound compatibility report records observed activation and routing behavior; missing required hooks block this adapter without blocking declarative apps',
        'Nominal package availability, vendor marketing or a fake adapter cannot count as runtime behavior evidence',
        'Dependency/API/profile changes force the probe to run again; no wildcard or latest version remains admitted',
        ['SPEC-029:artifact-build','SPEC-030:runner-profile'],stage='S6',caps='C125 C103',reads=[RIVET],
        allowed=['pnpm-lock.yaml','execution-lock.json','packages/adapters/package.json','admissions/spec-054/extension-lock.json']),
       new('Implement immutable candidate slots and public binding separation','rivet-preparation',
        'Implement the Zoen AppRuntimePort against the observed admitted Core API || Assign an internal immutable slot per artifact and host-enforced state partition; forbid overwrite after successful preparation || Stage/probe only in evaluation realm, then record a nonpublic attestation; serving public requests resolves a released binding, not vendor latest',
        'Version A is approved and visible; candidate B builds successfully internally', 'B is prepared but not approved in Ontology',
        'All public opens still resolve A; B is reachable only by authorized evaluation sessions and cannot call live sources or channels',
        'Direct slot URL, guessed appId and a latest alias cannot reveal or activate B',
        'Crash after internal deployment but before attestation creates an orphan eligible for bounded cleanup, never an implicit publication',
        ['SPEC-054:rivet-api-probe','SPEC-052:app-publication','SPEC-053:guest-backend'],stage='S6',caps='C125 C034',reads=[RIVET,APPS],
        allowed=['packages/contracts/src/app-runtime-port.ts','apps/edge/src/composition.ts']),
       new('Integrate staged app runtime with current-policy publication','rivet-binding',
        'Bind runtime preparation and digest attestation into the existing DefinitionChange proof/preparation closure || Activate only by Ontology head transition after current rights, exact profile and artifact recall recheck || Require all edge instances to resolve authoritative binding under a fail-closed cache/version policy; private session stays version-bound',
        'B is prepared and a live author loses publishing authority before activation', 'The author attempts to promote B',
        'Activation is denied and A remains active; an unrelated Core deployment or warm VM refresh cannot override the Zoen binding',
        'Candidate policy self-approval, mismatched digest/realm/profile and stale base all block activation',
        'Head changes or store timeout between prepare and commit leaves explicit PreparationStale/Unavailable; no double active pointer',
        ['SPEC-054:rivet-preparation','SPEC-014:activate','SPEC-029:artifact-recall'],stage='S6',caps='C125 C034',reads=[RIVET,APPS]),
       new('Harden Rivet host configuration, build plane and credentials','rivet-host-profile',
        'Generate trusted VM/namespace config only from admitted policy; never merge untrusted manifest permissions into host config || Run backend executor outside the authority process under qualified external containment; broker the semantic client only || Disable default production mounts, registry secrets and unrestricted network; sanitize request/response headers and logs',
        'Hostile generated code attempts environment reads, SSRF, state reuse and expensive work', 'It runs under the exact proposed Rivet runtime profile',
        'No authority/source credentials or cross-user state are obtainable; CPU/memory/output/egress limits are externally enforced and observable',
        'An agent-provided network allow rule, VM mount, namespace key or dependency install script cannot widen the host policy',
        'Warm VM replay or container restart checks the same realm/session binding and cannot revive a recalled installation',
        ['SPEC-054:rivet-binding','SPEC-053:host-revocation','SPEC-030:runner-limits'],stage='S6',caps='C125 C102 C103',reads=[RIVET,HOST],
        allowed=['runners/apps/rivet-entry.ts','runners/apps/rivet-profile.json','runners/oci/Dockerfile','infra/terraform/app-host/main.tf']),
       new('Implement runtime recovery, recall and orphan retention','rivet-recovery',
        'Keep immutable runtime slots non-authoritative and garbage collect only after publication/session/evaluation retention checks || Exercise runtime loss, split cache, old prepared state, recalled artifacts and safe stop/recreate || Prefer unavailable to silently serving another version; preserve receipts/Unknown effects outside the guest',
        'App A is active and app B is staged; one runner and one routing cache fail', 'The runtime restarts and cleanup runs concurrently',
        'Only a currently admitted A session is served; B remains nonpublic; failed slots do not destroy pinned active artifacts or resurrect recalls',
        'Restoring an old runtime snapshot cannot restore revoked sessions, source credentials or company truth',
        'A missing slot yields an explicit unavailable state while owner-confirmed re-preparation occurs; no unproved automatic rollback',
        ['SPEC-054:rivet-host-profile','SPEC-053:host-admission'],stage='S6',caps='C125 C104',reads=[RIVET,HOST]),
       new('Admit the Rivet specialized runtime profile or record rejection','rivet-admission',
        'Collect real Core/runner/browser/activation/recovery evidence against the exact selected deployment || Have an independent security/runtime owner approve supported capabilities and measured bounds || Mark the adapter disabled on any failed mandatory proof; replacement requires an explicit ADR and rerun of the same contracts',
        'All required real Rivet adapter and host proofs are available for one profile', 'Runtime admission is requested',
        'G-RIVET-DYNAMIC is approved only for that profile and immutable lock, or explicitly remains blocked with reasons; no generic claim of Rivet safety or production readiness',
        'An execution-pack test, simulator, SDK compile or upstream feature list cannot satisfy the gate',
        'Profile, vendor API, containment, host config or artifact policy changes invalidate qualification; declarative mode remains independently usable',
        ['SPEC-054:rivet-recovery','SPEC-030:runner-security-proof'],stage='S6',layer='admission',gate='G-RIVET-DYNAMIC',caps='C125 C103',reads=[RIVET,HOST,TEST])
      ],extra='\nPrimary sources and uncertainty: [Rivet adapter contract](../architecture/rivet-adapter.md) and [source ledger](../research/v4-sources.md). This pack does not claim any Rivet probe was run.')

    spec(55,'Cross-surface equivalence, adversarial app journeys and capacity','S3','Quality and Security','journeys/mini-apps',[50,51,52],
      'testing-and-ci.md;apps-charts-and-surfaces.md',
      'Prove one path structurally and behaviorally. Tests compare semantic outputs at equivalent authorized context and exact basis, not prose or equal permissions for different users. Human, agent and app frontends cannot certify themselves. Fault tests must exercise actual executor, database, policies, browsers and admitted runtime where claimed.',
      'No new authority store. Synthetic fixtures, paired visibility sets, trace digests, operation identities and signed CI evidence are test artifacts. Production data is never embedded in this package. Admission reports bind commit, lock, source rights, browser/runtime/deployment profile and expected checks.',
      'AssertEquivalentSemanticResult; AssertExecutorEntry; RunNoBypassCampaign; RunThreeAudienceAppJourney; QualifyAppWorkload. These are test harness operations, not public production tools.',
      'Cover read/discovery, mutation/approval/replay, sharing/revocation, streams/exports and runtime publication. Include denied, invalid, stale, changed intent, Unknown and resource limits. Do not count presentation equality as semantic parity or different operation IDs as one intention. Raw traces must not expose hidden source values.',
      [
       new('Prove early human-agent-declarative read and divergence equivalence','early-parity',
        'Seed paired household/bakery Worlds with two comparable disagreements and one denied rival || Call through web, CLI, Eve structured tools and declarative mini-app at a pinned coherent basis || Assert shared executor-entry and canonical semantic output before each renderer; use real database and current policy profile',
        'Owner sees two deadline claims and worker sees only production-safe evidence', 'Equivalent-authority clients inspect and explain the same order',
        'Each equivalence class has identical permitted meaning/basis/result tags; differences in text and layout do not alter facts or reveal hidden evidence',
        'Insert or remove only denied rivals; worker-visible confidence, counts and errors remain equivalent',
        'Switch World, purpose, rights or cut and the harness refuses to claim equal-context parity',
        ['SPEC-052:private-app-journey','SPEC-051:app-sharing','SPEC-018:rights-noninterference'],stage='S3',layer='journey',caps='C124 C013 C082',reads=[TEST]),
       new('Prove cross-surface approval, stale consent and retry identity','action-parity',
        'Create one operation in chat and continue its exact Case/operation identity in the app and shared structured SemanticClient (full generated SDK conformance follows in S5) || Race retries and insert a relevant predicate match before a second independent Case commits || Verify same handler, complete read guards, one receipt for same key and current reauthorization',
        'A bakery action has one valid Case and another whose dependency will change', 'App and chat concurrently confirm the first and then attempt the stale second',
        'The first has one receipt/effect; all paths reject the second as Stale; missing/changed operationId is not falsely deduplicated',
        'A revoked client cannot obtain a prior receipt by replay, even if a permitted client already committed it',
        'Provider accepted but lost reply stays Unknown until actual reconciliation; no surface invents completion',
        ['SPEC-052:app-actions','SPEC-022:action-chaos','SPEC-023:effect-reconcile'],stage='S4',layer='chaos',caps='C066 C124',reads=[TEST]),
       new('Audit data route closure and executable-app confused deputy attacks','no-bypass-campaign',
        'Inventory every app-serving route, asset, error page, export, callback and websocket upgrade || Inject forged context, hostile bundles, direct source URLs, leaked cookies and cross-user runtime reuse || Demonstrate one central executor entry per data operation and no alternate handler/policy implementation',
        'All isolated host/runtime paths and generated client surfaces are installed', 'Hostile frontend/backend and direct network probes target each data boundary',
        'No raw data/source/index route is exposed; data-bearing guest calls use only the same semantic executor and current grants',
        'An intentionally added app-only SQL endpoint makes the campaign and import gate fail',
        'Revocation, stalled queue, oversized payload and runtime restart do not open an emergency bypass',
        ['SPEC-053:host-admission','SPEC-054:rivet-admission','SPEC-050:no-bypass-graph','SPEC-026:surface-conformance'],stage='S6',layer='chaos',caps='C124 C125 C103',reads=[TEST,HOST,RIVET]),
       new('Measure mini-app batched reads, exports and streaming budgets','app-workload',
        'Run declared W-APP fixtures with explicit rows, fields, users, queries, costs, hardware and rights selectivity || Measure bounded query count and memory at the executor, not only frontend rendering time || Exercise revoked exports, fanout backpressure and live gaps; publish proposed-versus-measured results honestly',
        'A dedicated reproducible workload and admitted data/host profile', '100 concurrent sessions read 200-row pages and an export is revoked mid-download',
        'No N-per-cell query pattern or unbounded buffers; actual latency/cost/limits are reported and the selected profile meets its recorded targets or remains unadmitted',
        'Fast results achieved by bypassing policy or omitting conflicts fail regardless of latency',
        'Saturation returns explicit quota/backpressure; no partial financial totals or hidden truncation',
        ['SPEC-050:streaming-path','SPEC-053:host-admission'],stage='S7',layer='performance',caps='C124 C125 C139',reads=[TEST]),
       new('Prove household, professional and institutional Workshop journeys','three-audience-apps',
        'Use one core grammar for a household bill helper, bakery production board and enterprise discrepancy workbench || Include runtime definition edit, scoped sharing, conflicting-source correction and governed action || Include clinical separation in a professional fixture and missing-provider/unknown data honestly',
        'The same accepted runtime and domain packs with different rights/density profiles', 'An authorized human and Eve create/change apps, share links and operate them',
        'No profession-specific kernel branch or alternate data path appears; user corrections preserve scope and runtime changes follow current-policy activation',
        'An agent cannot create a hidden CRM/bank integration or promote a local draft into organizational truth',
        'Recall, membership loss and incompatible upgrade stop or refresh affected views without altering historical receipts',
        ['SPEC-035:app-journey','SPEC-052:app-lifecycle','SPEC-055:no-bypass-campaign','SPEC-053:mcp-host-admission','SPEC-055:app-workload'],stage='S8',layer='journey',caps='C123 C124 C125 C126',reads=[TEST,APPS]),
       new('Audit v4 execution requirements through institutional final acceptance','v4-final-audit',
        'Resolve every R4 requirement to its current ticket checks and reviewed implementation evidence || Extend enterprise/finance/federation capstones to use app, human and agent surfaces without authority forks || Reopen evidence after affected code, policy, artifact, runtime or host changes; reject unsupported parity claims',
        'All v4 mini-app requirements and original C001-C157 scope are traced', 'The final release candidate requests full-scope acceptance',
        'Every required check and applicable host/runtime gate has current independent evidence; no plan-control result is mistaken for product evidence',
        'An omitted stream/export route, unqualified Rivet profile or fabricated host report blocks the affected full-scope acceptance',
        'A new surface cannot be enabled until its same-path and current-rights conformance suite is qualified',
        ['SPEC-055:three-audience-apps','SPEC-048:enterprise-capstone'],stage='S11',layer='admission',caps='C157 C124 C125',reads=[TEST])
      ],extra='\nExact fixtures, equivalence normalization and hostile cases are in [mini-app conformance](../testing/mini-app-conformance.md). Every required product check starts unrun. Local Python package-control tests do not execute these journeys.')

    # Existing tasks keep IDs and semantic identity, but use the now-explicit path/sequence.
    def amend(n,stem,**kw):
        t=next(t for t in S[n]['tasks'] if t['stem']==stem);t.update(kw)
    amend(35,'declarative-app',slice='S2',module='apps/web/src/mini-apps',
      deps_keys=['SPEC-052:app-bindings','SPEC-052:app-publication','SPEC-051:app-sessions','SPEC-012:accessibility'],
      steps=['Render only the versioned MiniAppDefinition with trusted accessible component registry; do not generate arbitrary JavaScript','Use the common SemanticClient and SPEC-007 executor for data and discovery; do not call Eve/model for structured reads','Reuse host continuation and Focus; owner-only private runtime ships before sharing, custom code, dense analytics and full Studio'],
      then='An authenticated owner uses a read-only bakery board and household view whose facts, conflicts and basis match the common semantic path; no Rivet/runner/Iceberg/full-Studio dependency is needed',
      negative='Script/eval/SQL/provider URL or unadmitted operation in the manifest is rejected; no fallback data backend is created',
      boundary='A failed or incompatible release leaves the prior publication intact; a pinned view cannot silently change the meaning of an open form',
      read_more=[COMMON,APPS,LINKS,TEST])
    amend(35,'studio-editors',deps_keys=['SPEC-014:runtime-change-journey','SPEC-027:view-journey','SPEC-052:private-app-journey','SPEC-053:host-revocation','SPEC-031:dataset-chaos'],
      steps=['Compose advanced Studio from the shipped declarative renderer, definition editor and isolated host; do not replace them','Expose semantic diff, source lineage, requested capabilities and same-path operation bindings','Agent and human edits use the existing definition/release lifecycle; preview remains evaluation-only'],read_more=[COMMON,APPS,HOST])
    amend(35,'app-bridge',slice='S6',module='apps/web/src/app-host',deps_keys=['SPEC-053:host-revocation','SPEC-035:declarative-app'],
      steps=['Wire the SPEC-053 transport-only bridge and signed bundle origin into Living World and the app opener','Reuse current AppSession and SemanticClient, with confirmations outside guest content','Prove data operations enter the existing executor and isolate guest state; no app-specific policy/data handler'],read_more=[COMMON,HOST,LINKS,TEST])
    amend(35,'mcp-apps',slice='S6',module='packages/clients/src/mcp-apps',deps_keys=['SPEC-035:app-bridge','SPEC-026:mcp'],read_more=[COMMON,HOST,LINKS,TEST])
    amend(35,'app-journey',deps_keys=['SPEC-035:studio-editors','SPEC-035:mcp-apps','SPEC-055:action-parity','SPEC-054:rivet-admission'],read_more=[COMMON,APPS,HOST,TEST])
    # References below are resolved by stable task identity, never numeric position.
    extra_deps={
      (7,'first-surface'):['SPEC-050:executor-binding','SPEC-050:no-bypass-graph'],
      (11,'continuation'):['SPEC-051:browser-exchange'],
      (26,'surface-conformance'):['SPEC-050:effective-context'],
      (27,'view-export'):['SPEC-035:declarative-app'],
      (48,'coverage-audit'):['SPEC-055:v4-final-audit'],
    }
    for (n,stem),deps in extra_deps.items():
        ts=[t for t in S[n]['tasks'] if t['stem']==stem]
        if not ts:raise ValueError(f'Unknown existing task {n}:{stem}')
        ts[0]['deps_more']=deps
    for n in notes:
        for t in S[n]['tasks']:
            t['read_more']=list(dict.fromkeys(t.get('read_more',[])+[COMMON]))
    for n in [11,12,35]:
        for t in S[n]['tasks']:t['read_more']=list(dict.fromkeys(t.get('read_more',[])+[LINKS]))
    # Do not create a new transport implementation inside each adapter's ticket.
    for n,stem in [(7,'dispatch'),(26,'rest-openapi'),(26,'cli-generation'),(26,'sdk-generation'),(26,'mcp'),(26,'status-stream')]:
        t=next(t for t in S[n]['tasks'] if t['stem']==stem)
        t['steps'].append('V4: use the existing SPEC-007 dispatcher and shared SemanticClient; validate no per-surface authorization or reconciliation implementation is introduced')


def refine_tickets(specs,tickets,source):
    """Apply per-task dependencies after all stable IDs are allocated."""
    key_to_id={t['spec_id']+':'+source[int(t['spec_id'][5:])]['tasks'][t['source_task_index']]['stem']:t['id'] for t in tickets}
    for t in tickets:
        s=source[int(t['spec_id'][5:])];raw=s['tasks'][t['source_task_index']]
        if 'deps_keys' in raw:t['depends_on']=[key_to_id[x] for x in raw['deps_keys']]
        t['depends_on']=sorted(set(t['depends_on']+[key_to_id[x] for x in raw.get('deps_more',[])]))
        t['required_read']=list(dict.fromkeys(t['required_read']+raw.get('read_more',[])))
        t['allowed_paths']=list(dict.fromkeys(t['allowed_paths']+raw.get('allowed_more',[])))
        if any(p.endswith('composition.ts') or p=='apps/web/src/routes.tsx' for p in raw.get('allowed_more',[])):
            t['resource_locks']=list(dict.fromkeys(t['resource_locks']+['composition:trusted-roots']))
        if any(p.endswith('dispatch.ts') or p.startswith('packages/contracts/src/semantic') for p in t['allowed_paths']):
            t['resource_locks']=list(dict.fromkeys(t['resource_locks']+['contract:semantic-executor']))
        if any(p.startswith('infra/terraform/app-host/') for p in t['allowed_paths']):t['resource_locks'].append('infra:app-host')
        if any(p.startswith('packages/ontology/src/continuations') for p in t['allowed_paths']):t['resource_locks'].append('contract:continuation')
        t['resource_locks']=sorted(set(t['resource_locks']))
    return key_to_id
