"""Deterministically render the reviewed execution catalog. Never marks work accepted."""
from __future__ import annotations
import csv,hashlib,json,re,sys
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).parent))
from catalog import SPECS
from v4_catalog import refine_tickets
from render_v4 import render as render_v4

def put(path,content):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(content.rstrip()+'\n',encoding='utf8')
def js(path,value):put(path,json.dumps(value,indent=2,ensure_ascii=False,sort_keys=True))
def slug(s):return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
def rel(link,prefix='../'):return prefix+link

def build():
 specs=[];tickets=[];by_spec={};serial=0
 for s in SPECS:
  ids=[]
  for i,t in enumerate(s['tasks']):
   serial+=1;tid=f'ZN-{serial:04d}';ids.append(tid)
   module=t.get('module',s['module'])
   if s['n']==2 and i>0:module='packages/ontology/src/worlds'
   if t['layer']=='admission':primary=f"admissions/{s['id'].lower()}/{t['stem']}.json"
   elif t['layer'] in ('journey','chaos','performance'):primary=f"tests/{t['layer']}/{s['id'].lower()}/{t['stem']}.test.ts"
   elif module.startswith('infra/'):primary=f"{module}/{t['stem']}.tf"
   elif module.startswith('packs'):primary=f"{module}/{s['id'].lower()}/{t['stem']}.json"
   else:primary=f"{module}/{t['stem']}.ts"
   if t.get('primary'):primary=t['primary']
   test=f"tests/{t['layer']}/{s['id'].lower()}/{t['stem']}.test.ts"
   runbook=f"runbooks/{s['id'].lower()}/{t['stem']}.md"
   contract=f"contracts/{s['id'].lower()}/{t['stem']}.schema.json"
   allowed=list(dict.fromkeys([primary,test,runbook,contract,f"tests/fixtures/{s['id'].lower()}/{t['stem']}.json"]))
   if t['layer'] not in ('admission','law','static','journey','chaos','performance') and s['storage'][:2]!='No':
    allowed += [f"db/migrations/{tid.lower()}_{t['stem']}.sql", f"tests/migrations/{tid.lower()}.test.ts"]
   if s['n']==0:
    specials={0:['admissions/baseline-inventory.json'],1:['package.json','pnpm-lock.yaml','execution-lock.json','.npmrc'],2:['package.json','pnpm-workspace.yaml','tsconfig.json','eslint.config.mjs','.dependency-cruiser.cjs'],3:['vitest.config.ts','playwright.config.ts','compose.test.yaml'],4:['.github/workflows/verify.yml'],5:['.github/workflows/release.yml','CODEOWNERS']}
    allowed+=specials.get(i,[])
    if i==2:
     roots=['apps/edge','apps/web','apps/eve-worker','apps/authority-worker','apps/effect-worker','packages/kernel','packages/contracts','packages/door','packages/ontology','packages/eve','packages/clients','packages/adapters','packages/telemetry']
     for root in roots:allowed += [root+'/package.json',root+'/tsconfig.json',root+'/src/index.ts']
    if i in (1,3,5):allowed += ['package.json','pnpm-lock.yaml','execution-lock.json']
   if t['layer'] not in ('admission','journey','chaos','performance') and any(word in t['title'].lower() for word in ('admit','integrate','profile')):
    allowed += ['pnpm-lock.yaml','execution-lock.json',f"admissions/{s['id'].lower()}/extension-lock.json"]
    parts=module.split('/')
    if parts[0] in ('apps','packages') and len(parts)>1:allowed.append('/'.join(parts[:2])+'/package.json')
   # A task must be able to wire its component, not merely create an unused file.
   integration=[]
   if t['layer'] not in ('admission','journey','chaos','performance'):
    if module.startswith('infra/'):
     integration=[f'{module}/main.tf',f'{module}/variables.tf',f'{module}/outputs.tf',f'{module}/versions.tf']
    elif module.startswith('packs'):
     integration=[f"{module}/{s['id'].lower()}/pack.json"]
     if s['n']==16:integration += ['packs/foundation/pack.json','packs/household/pack.json','packs/bakery/pack.json']
     if s['n']==21:integration += ['packs/clinic/pack.json']
    elif s['n']!=0:
     integration=[f'{module}/index.ts',f'{module}/ports.ts',f'{module}/types.ts']
     if s['n'] in (2,38):integration += ['apps/edge/src/composition.ts']
     elif module.startswith('packages/ontology'):
      integration += ['apps/authority-worker/src/composition.ts',f"apps/authority-worker/src/registrations/{s['id'].lower()}.ts"]
     elif module.startswith('packages/eve'):integration += ['apps/eve-worker/src/composition.ts']
     elif module.startswith('packages/adapters/src/channels') or module.startswith('packages/clients'):integration += ['apps/edge/src/composition.ts']
     elif module.startswith('apps/web'):integration += ['apps/web/src/routes.tsx',f"apps/web/src/registrations/{s['id'].lower()}.tsx"]
    if s['n']==3:integration += ['packages/ontology/src/authority/commit.ts','packages/ontology/src/authority/guards.ts','packages/ontology/src/authority/plan.ts']
    if s['n']==23:integration += ['apps/effect-worker/src/composition.ts']
    if s['n']==30:integration += ['runners/python/entry.py','runners/r/entry.R','runners/sql/entry.ts','runners/oci/Dockerfile','runners/oci/profile.json']
   allowed=list(dict.fromkeys(allowed+integration))
   locks=[f"module:{module}"]
   if any('/composition.ts' in path or path=='apps/web/src/routes.tsx' for path in integration):locks.append('composition:trusted-roots')
   if any(p.startswith('db/migrations/') for p in allowed):locks.append('schema:authority')
   if s['n'] in [0,1,13]:locks.append('contract:kernel-and-tooling')
   if 'pnpm-lock.yaml' in allowed:locks.append('dependency:admitted-lock')
   ticket=dict(id=tid,title=t['title'],spec_id=s['id'],slice=t.get('slice',s['slice']),owner=s['owner'],kind=t['layer'],risk=t['risk'],capabilities=t['caps'],external_gate=t['gate'],source_task_index=i,
      intent=s['decision'],steps=t['steps'],acceptance=dict(given=t['given'],when=t['when'],then=t['then']),
      primary_artifact=primary,test_file=test,runbook=runbook,allowed_paths=allowed,resource_locks=locks,
      required_read=[f"specs/{s['id'].lower()}.md",'architecture/constitution.md','architecture/repository-contract.md','architecture/protocol-contract.md','testing/strategy.md'],
      checks=[{'id':f'{tid}-AC','purpose':'Observable outcome','oracle':t['then'],'layer':t['layer']},
              {'id':f'{tid}-NEG','purpose':'Invalid/denied input or false evidence','oracle':negative(s,t),'layer':t['layer']},
              {'id':f'{tid}-BOUNDARY','purpose':'Failure/replay/limit boundary','oracle':boundary(s,t),'layer':t['layer']}],
      status='planned',review='independent-required' if t['risk']=='critical' else 'peer-required',
      product_test_command=f"pnpm verify:ticket --ticket {tid} --profile <admitted-{t['layer']}-profile>")
   tickets.append(ticket)
  by_spec[s['n']]=ids
  specs.append({k:v for k,v in s.items() if k not in ['tasks']})
  specs[-1]['tickets']=ids
 # Dependencies separate code completion from external qualifications.
 index={t['id']:t for t in tickets}
 def core(n):
  choices=[x for x in by_spec[n] if index[x]['kind']!='admission']
  return choices[-1] if choices else by_spec[n][-1]
 for s in SPECS:
  ids=by_spec[s['n']]
  deps=[core(x) for x in s['deps']]
  if s['n']==3:deps=[core(1),by_spec[2][0]]
  prev=None
  for i,tid in enumerate(ids):
   t=index[tid];required=list(deps) if prev is None else [prev]
   if s['n']==2 and i==1:required.append(core(3))
   if s['n']==24 and t['source_task_index']==4:required.append(core(21))
   t['depends_on']=sorted(set(required))
   if t['kind']!='admission' or s['n']==0:prev=tid
 refine_tickets(specs,tickets,SPECS)
 # Final audit must require all previous qualification tasks, not merely code.
 final_audit=by_spec[48][-2]
 index[final_audit]['depends_on']=sorted(set(index[final_audit]['depends_on']+[t['id'] for t in tickets if t['kind']=='admission' and t['spec_id']!='SPEC-048']))
 index[by_spec[48][-1]]['depends_on']=[final_audit]
 return specs,tickets,by_spec

def negative(s,t):
 if t.get('negative'):return t['negative']
 if t['layer']=='admission':return 'Submit an incomplete, expired or mismatched qualification artifact for this exact scope. Admission remains blocked; the missing requirement and still-disabled route are explicit.'
 if t['layer']=='static':return 'Introduce the forbidden dependency, missing check or altered manifest described by this task. The checker exits nonzero and does not certify the candidate.'
 if t['layer']=='law':return 'Supply an invalid type, incompatible unit/time/realm or unsupported scalar to this task’s pure boundary. It returns the specified tagged error without coercion or I/O.'
 v={
 0:'Remove a required tool, secret reference or test dependency. The harness fails as missing prerequisite and cannot pass by skipping.',
 1:'Reject invalid or duplicate-key envelopes before branding or any repository call; no implicit numeric/time conversion.',
 2:'Use revoked presence or the wrong principal/audience. No World grant, membership change or protected disclosure occurs.',
 3:'Use a stale head/domain/epoch/fence or changed intent. No partial receipt, mutation or outbox progress commits.',
 4:'Use a wrong-World ref, missing durable bytes or expired rights. No evidence is admitted or disclosed.',
 5:'Change only forbidden rival evidence. Authorized interpretation output and confidence must not leak its presence.',
 6:'Provide ambiguous identities or incompatible intervals. No silent merge, reassignment or destructive temporal rewrite.',
 7:'Read an opaque ref without current permission. No data, row count, existence metadata or evidence URL leaks.',
 8:'Include secrets in telemetry or restore without required ledger/dependencies. Redaction/restore admission fails safely.',
 9:'Resume with an old turn fence or a revoked tool permit. No second settled reply or authorized operation results.',
 10:'Place instructions in retrieved evidence asking for a forbidden tool or secret. They remain untrusted content and produce no authority.',
 11:'Submit unverified provider ingress or bind a number without the required proof/consent. No identity or protected reply is created.',
 12:'Open the flow on a shared device after logout or without access. No previous person’s context appears; accessible denial remains usable.',
 13:'Compile a remote reference, unknown opcode, cyclic dependency or unbounded expression. Compilation fails before activation.',
 14:'Let the candidate policy approve itself or address a live destination from evaluation. Both are denied under current authority.',
 15:'Attempt unauthorized egress/SSRF, an expired source lease or incomplete ACL coverage. Quarantine/disable rather than admit guessed completeness.',
 16:'Install a pack with unresolved references, incompatible units or extra privilege. Activation fails; no customer-specific kernel branch is added.',
 17:'Submit an answer for the wrong question digest/kind/scope. No local or reusable knowledge changes.',
 18:'Use hidden evidence, stale source ACL or channel membership as authority. Deny before retrieval/ranking/disclosure.',
 19:'Erase held material without authorized disposition or read erased bytes from a derivative. No prohibited deletion/disclosure occurs.',
 20:'Deliver a Notice after revocation or compose from stale authorized payload. Suppress or freshly redact; do not leak count/existence.',
 21:'Give a receptionist a clinical or ambiguous-patient query. Clinical content/existence stays hidden and identity is not guessed.',
 22:'Approve a changed/expired Case or use candidate permission. No DecisionReceipt or EffectIntent commits.',
 23:'Retry an escaped effect with Unknown outcome or a revoked execution permit. No unsafe duplicate external call is made.',
 24:'Exceed scope, root budget, deadline or action allowlist. The step remains blocked without spending or widening authority.',
 25:'Let forbidden candidates influence top-k, counts or generated answers. Paired authorized output remains noninterfering.',
 26:'Call an undiscovered/unreleased verb or stale SDK contract. Return Unsupported/Denied without bypassing semantic operations.',
 27:'Render a chart/table/export using a direct unauthorized index query. No data appears outside the pinned authorized Frame.',
 28:'Treat email From, Telegram group presence or an old channel binding as proof of identity. No authority is inherited.',
 29:'Install unsigned, tampered, revoked or privilege-expanding artifacts. Installation/activation is blocked.',
 30:'Probe host metadata, Docker sockets, authority credentials or undeclared network destinations. The actual isolation boundary denies access.',
 31:'Publish an unsupported format or unpinned snapshot, or use catalog latest for historical reads. Reject rather than silently reinterpret.',
 32:'Treat failed source/quality checks as a completed empty dataset. Mark unknown/incomplete and prevent authoritative destructive updates.',
 33:'Use an unentitled, gapped or unpinned live value for consequential action. Block capture/action or disclose the exact incomplete basis.',
 34:'Exceed a query lease’s rights, budget, output or time limits. Cancel/bound execution and never publish partial output as complete.',
 35:'A runtime app requests host authority, secret access or unreleased operations. The broker/renderer rejects it.',
 36:'A scenario or notebook attempts a live effect or trains across unauthorized tenants. It has no such authority.',
 37:'An upgrade expands privileges or violates a dependency/license constraint. Require current-policy approval or block.',
 38:'A stale SCIM membership or wrong-tenant issuer asserts enterprise authority. Deny; do not inherit groups without mapping.',
 39:'Attempt cross-region data transfer, broad credential access or restore-before-erasure suppression. Infrastructure/promotion denies it.',
 40:'A tenant exceeds quota or support requests content without authority. Bound resource use and require audited narrow access.',
 41:'A connector omits required ACL/tombstone coverage or sends data outside permitted scope. Mark coverage incomplete; do not infer authorization.',
 42:'Switch directory to a new cell without source fencing. The destination cannot become writable.',
 43:'Treat remote approval or a timestamp as local authority/coherent global cut. Reject the implied authority and preserve independent bases.',
 44:'An expired offline lease or edge artifact requests live secret/authority reuse. Deny and retain pending local work separately.',
 45:'Resolve a security by bare ticker or mix restated/as-reported data without basis. Ambiguity and rights remain explicit.',
 46:'Use stale/gapped data or an unqualified model outside its licensed scope. Risk output is unavailable/unqualified, not falsely precise.',
 47:'Treat broker acknowledgement/cancel request as settlement or blindly resubmit an Unknown order. Reject that transition and keep exposure reserved.',
 48:'Mark a capability complete with design-only, wrong-commit or wrong-profile evidence. Final acceptance must fail.',
 49:'Enable a channel/model without its admission or bypass privacy/backup prerequisites. Only qualified routes become available.'}
 return v[s['n']]+' Exercise this against the component delivered by this ticket; do not require a later-stage feature to implement an early negative check.'

def boundary(s,t):
 if t.get('boundary'):return t['boundary']
 if t['layer']=='admission':return 'Re-run qualification selection with a changed version, provider, region or expired approval. Previous evidence cannot transfer silently; record the exact newly blocked scope.'
 if t['layer']=='static':return 'Run from two clean workspaces and then remove one required check. Equal inputs produce equal artifacts; missing checks fail, including a zero-test run.'
 if t['layer']=='law':return 'Exercise empty/minimum/maximum/overflow and reordered equivalent inputs using recorded seeds. Exact semantics are deterministic; unsupported limits yield explicit errors, not truncation.'
 if s['n'] in [2,3,4,5,6,13,14,15,16,17,18,19,20,21,22,24,29,31,32,35,37,38,41,45]:
  return 'For this operation, race duplicate delivery/replay and a relevant dependency change at a named commit boundary. At most one same-intent semantic result commits; stale work is rejected. For read-only/validation work, prove deterministic output at the same basis and explicit stale/unsupported output at the changed basis.'
 if s['n'] in [9,10,11,23,28,47]:
  return 'Interrupt after durable admission or provider acceptance but before acknowledgement. Retry with the same identity and an old worker fence. No duplicate committed result or unsafe resend occurs; ambiguity stays Unknown until observed.'
 if s['n'] in [30,34,36]:return 'Terminate execution after output staging or resource exhaustion. Leases expire, unadmitted output stays non-authoritative, and no resumed sandbox acquires broader authority.'
 if s['n'] in [39,42,43,44,49]:return 'Inject source/process/network loss during rollout or restore. Reject unsafe writes until required fencing and recovery evidence exists; preserve explicit partial or unknown external outcomes.'
 return 'Repeat with duplicate/reordered input, revoked access and the profile limit at the task boundary. Preserve the declared oracle; report unsupported/incomplete state rather than silent truncation, disclosure or fabricated success.'

def main():
 specs,tickets,by_spec=build();index={x['id']:x for x in tickets}
 identities={t['id']:t['spec_id']+':'+SPECS[int(t['spec_id'].split('-')[1])]['tasks'][t['source_task_index']]['stem'] for t in tickets}
 identity_path=ROOT/'source/stable-identities.json'
 if identity_path.exists():
  prior=json.loads(identity_path.read_text())
  if any(identities.get(k)!=v for k,v in prior.items()):raise ValueError('Stable ticket identity changed. Preserve IDs; append new work or review an explicit migration.')
 old_path=ROOT/'backlog/backlog.json';state_path=ROOT/'backlog/state.json'
 if old_path.exists() and state_path.exists():
  previous={t['id']:t for t in json.loads(old_path.read_text())['tickets']}
  state=json.loads(state_path.read_text())
  for tid,e in state.get('tickets',{}).items():
   if e.get('status')=='accepted' and previous.get(tid)!=index.get(tid):raise ValueError('Accepted ticket changed without reopening evidence: '+tid)
 js('source/stable-identities.json',identities)
 with (ROOT/'baseline/v2/technical-blueprint/capability-matrix.csv').open() as f:caps=list(csv.DictReader(f))
 gates=sorted({t['external_gate'] for t in tickets if t['external_gate']})
 backlog={'schema_version':'1.0','design_date':'2026-09-04','status':'design-only','specs':specs,'tickets':tickets,'gates':gates}
 js('backlog/backlog.json',backlog)
 if not (ROOT/'backlog/state.json').exists():
  js('backlog/state.json',{'schema_version':'1.0','tickets':{},'gates':{g:{'status':'unapproved','evidence_refs':[]} for g in gates},'profiles':{}})
 checks=[]
 for t in tickets:
  for check in t['checks']:checks.append({**check,'ticket_id':t['id'],'spec_id':t['spec_id'],'test_file':t['test_file'],'status':'not-run'})
 js('testing/check-catalog.json',checks)
 coverage=[]
 for c in caps:
  ts=[t for t in tickets if c['id'] in t['capabilities']]
  coverage.append({**c,'status':'Specified / not implemented','spec_ids':sorted(set(t['spec_id'] for t in ts)), 'ticket_ids':[t['id'] for t in ts], 'check_ids':[x['id'] for t in ts for x in t['checks']]})
 # Preserve historical stage metadata while exposing the actual v4 first-delivery stage.
 for c in coverage:
  if c['id'] in {'C124','C125','C126'}:
   c['baseline_slice']=c['slice'];c['slice']={'C124':'S2','C125':'S6','C126':'S6'}[c['id']]
   c['full_integration_slice']='S8';c['v4_amendments']=['062','063','064','065']
   c['baseline_audience']=c.get('audience','');c['audience']='Consumer; Prosumer; Enterprise'
 js('backlog/capability-coverage.json',coverage)
 put('backlog/capability-coverage.md','# Capability traceability\n\nEvery row is structurally specified, not implemented or admitted. Final acceptance requires current evidence for the enabled profile, not this table. Mini-app capabilities C124/C125/C126 retain their original stage as `baseline_slice` in JSON; v4 first delivery is S2/S6/S6 respectively, with full integration in S8.\n\n| ID | Capability | Tickets | Required checks |\n|---|---|---|---|\n'+'\n'.join(f"| {c['id']} | {c['capability']} | "+', '.join(f"[{x}](../tickets/{x.lower()}.md)" for x in c['ticket_ids'])+f" | {len(c['check_ids'])} |" for c in coverage))
 for s in specs:
  srcs=[x.strip() for x in s['source'].split(';') if x.strip()]
  related=' · '.join(f'[{p}](../baseline/v2/technical-blueprint/reference/{p})' for p in srcs)
  tasktable='\n'.join(f"| [{tid}](../tickets/{tid.lower()}.md) | {index[tid]['title']} | {index[tid]['slice']} | {index[tid]['kind']} | {', '.join(index[tid]['depends_on']) or 'None'} |" for tid in s['tickets'])
  put(f"specs/{s['id'].lower()}.md",f"""# {s['id']} — {s['title']}

**Milestone:** {s['slice']} · **Accountable function:** {s['owner']} · **Implementation root:** `{s['module']}` · **Status:** specified, not implemented.

## Decision and intended behavior

{s['decision']}

## Owned state and storage contract

{s['storage']}

Physical indexes, composite World-scoped foreign keys, bounded field types and migrations must preserve this logical schema and [repository ownership](../architecture/repository-contract.md). The implementing migration ticket produces executable SQL and upgrade/role tests. No model may silently omit a constraint because the table description is concise.

## Operations and outputs

```text
{s['operations']}
```

Use [common envelopes, errors, scalars and authorization](../architecture/protocol-contract.md). Inputs are schema-validated; grant/principal come from verified server context. Operation-specific fields are elaborated into the ticket's schema source and reviewed against this contract before implementation. New domain semantics require a spec amendment, not an invented default.

## Normative execution protocol

{s['protocol']}

## Dependencies and sequencing

Referenced specs: {', '.join(f'[{d:03d}](spec-{d:03d}.md)' for d in s['deps']) or 'None'}. **Actual readiness follows ticket dependencies**, not numeric spec order or this overview. External admission is separate from independent code work.

{s['extra']}

## Bounded work and required proof

| Ticket | Deliverable | Milestone | Evidence layer | Required completed tickets |
|---|---|---|---|---|
{tasktable}

## Failure, rights and resource behavior

Every implementation must exercise its own invalid/denied input and boundary oracle listed in the ticket. All constitutional laws apply at introduced boundaries. No network/model I/O inside authority transactions; no replayed credential from conversation; no unbounded query or implied external success. Read-only components prove basis/rights stability; mutation components prove atomicity, same-intent replay and stale-basis rejection. Required provider/operating gates remain disabled until qualified.

## Rollout and repair

Default new externally consequential capabilities off. Evaluate against authorized synthetic data through ordinary ports, admit the exact profile and activate with current-policy approval. Preserve predecessor data and receipts. Rollback is a compatible code rollback or a proved forward data/release repair; unknown external effects must reconcile before retry. Each ticket delivers a runbook specific to its failure boundary.

## Sources and architecture lineage

{related}

Read [constitution](../architecture/constitution.md) for explicit v4 refinements and [test strategy](../testing/strategy.md) for evidence limits.
""")
 for t in tickets:
  s=specs[int(t['spec_id'].split('-')[1])]
  checktable='\n'.join(f"| `{c['id']}` | {c['purpose']} | {c['oracle']} |" for c in t['checks'])
  extra_reads=' · '.join(f'[{Path(p).name}](../{p})' for p in t['required_read'] if p not in [f"specs/{t['spec_id'].lower()}.md",'architecture/constitution.md','architecture/protocol-contract.md','architecture/repository-contract.md','testing/strategy.md'])
  steps='\n'.join(f'{i+1}. {x}' for i,x in enumerate(t['steps']))
  files='\n'.join(f'- `{p}`' for p in t['allowed_paths'])
  deps=', '.join(f'[{x}]({x.lower()}.md)' for x in t['depends_on']) or 'None — first work item.'
  gate=f"`{t['external_gate']}`; see [gate register](../backlog/gates.md). This is qualification work; no local simulator can satisfy the external gate." if t['external_gate'] else 'No extra external gate on this code ticket. Promotion may still require its feature/profile admission.'
  put(f"tickets/{t['id'].lower()}.md",f"""# {t['id']} — {t['title']}

**Status:** planned; no code or product evidence is claimed. **Milestone:** {t['slice']}. **Layer:** {t['kind']}. **Risk:** {t['risk']}. **Owner:** {t['owner']}.

## Read first and stop conditions

Read [{t['spec_id']}](../specs/{t['spec_id'].lower()}.md), [constitution](../architecture/constitution.md), [protocol](../architecture/protocol-contract.md), [repository contract](../architecture/repository-contract.md), and [test strategy](../testing/strategy.md). Execute only this bounded task. If required behavior is ambiguous or contradictory, submit a [blocked report](../prompts/blocked-report.md) before inventing an operation or broadening scope.

Additional normative read set: {extra_reads or "None beyond the common contract."}

## Prerequisites

Completed and evidence-accepted tickets: {deps}

External admission: {gate}

Relevant capability IDs: {', '.join(t['capabilities']) or 'Shared enabling work; supports dependent capability tickets without inventing another product feature.'}

A required real dependency must be available in the admitted target profile. Do not substitute a success stub. Independent coding may proceed behind disabled feature admission where explicitly allowed. Exact schemas from the owning spec and existing dependency outputs must be inspected before editing.

## Bounded implementation procedure

{steps}

Before coding, create the failing acceptance and invalid/boundary checks below. Wire the delivered component into its named registration/entry point; an unused implementation file is not a finished behavior. Composition-file edits may only bind declared ports and routes for this ticket, never broaden credentials. Implement only the contract; no unrelated refactoring, new framework, generic agent tool, customer fork or new authority owner. Extend an existing shared primitive rather than duplicate it. Any needed shared-file change outside this allowlist requires a ticket amendment.

## Exact outputs and write allowlist

Primary implementation/proof artifact: `{t['primary_artifact']}`. Required test file: `{t['test_file']}`. Required operation/repair notes: `{t['runbook']}`. Contract/fixture/migration paths below are allowed when required by this task; do not create empty files merely to fill the list.

{files}

Exclusive resources: {', '.join('`'+x+'`' for x in t['resource_locks'])}. Paths are in the target application repository, not this execution ZIP. Use [scope checker](../tools/README.md) against the actual diff.

## Acceptance oracle

**Given:** {t['acceptance']['given']}

**When:** {t['acceptance']['when']}

**Then:** {t['acceptance']['then']}

| Required check ID | Purpose | Observable result |
|---|---|---|
{checktable}

Implement these check IDs as collected named tests or explicitly evidenced admission checks at layer `{t['kind']}`. A successful generic build, missing test selection or skipped check is not acceptance. For an early-stage pack, test released declarations now; runtime behavior explicitly deferred to a dependent ticket must remain disabled.

## Verification command and evidence

Target command (implemented by SPEC-000, not by this documentation pack):

```sh
{t['product_test_command']}
```

Evidence must include source commit, admitted lock/profile, fixture version/seed, commands, all three check outputs, artifact SHA-256 digests, nonzero executed counts, zero skipped required checks and review bound to that commit. {t['review']}; the reviewer is not the author. An external qualification also binds provider/API, region, permission/license scope and expiry. Completion is accepted through the evidence protocol, never a model's statement that tests passed.

## Failure, rollback and finish

On failure preserve the last known committed state, do not fabricate external success, and revoke/expire temporary leases. Clean staged artifacts only after checking pins and pending admissions. Document a compatible rollback or explicit forward repair and any unknown effects requiring reconciliation. Stop if the test oracle must change; do not weaken it.

Finish with the changed-file list, executed evidence references, independent review and still-disabled operating scopes. The ticket is not accepted until its exact evidence is checked. Follow [implementation prompt](../prompts/implement-one-ticket.md).
""")
 # Spec/phase indexes.
 put('specs/README.md','# Specification index\n\nNormative execution contracts; no module is marked implemented. Numbers are stable identifiers, not a build order.\n\n| Spec | Milestone | Contract | Tickets |\n|---|---|---|---|\n'+'\n'.join(f"| [{s['id']}]({s['id'].lower()}.md) | {s['slice']} | {s['title']} | {len(s['tickets'])} |" for s in specs))
 stages={
 'S0':('One truthful outcome','Create a private World; admit two authorized records; show their honest interpretation through web/CLI; prove atomicity and restore with real roles.'),
 'S1':('Continuous accessible relationship and hosted pilot','Continue across WhatsApp/web when qualified; correct a scoped ambiguity; preserve turn/permission integrity and accessible shared-device behavior.'),
 'S2':('Teach and configure the World at runtime','Change a mapping, rule, domain pack or private read-only declarative app without image deployment; prove isolated evaluation, current-policy approval and exact atomic activation. Mini apps reuse one semantic executor; no Rivet or dense prerequisite.'),
 'S3':('Shared Worlds, privacy and quiet attention','Share Worlds and protected app links narrowly, prove current-rights session isolation and early human/agent/app parity; respect clinical separation, erase/suppress correctly and deliver useful freshly authorized Notices.'),
 'S4':('Accountable action and bounded responsibility','Approve and execute a consequential action; distinguish local receipt, attempted effect, observed settlement and desired outcome under loss/retry.'),
 'S5':('Search, inspect and program one semantic world','Use authorized retrieval, Living World, SDK/CLI/API/MCP and multiple channels without a second authority path.'),
 'S6':('Safe executable extensions','Build, install, recall and run signed computational artifacts and isolated executable apps under real containment. Qualify protected host, MCP Apps and Rivet candidate profiles independently from declarative apps.'),
 'S7':('Dense history, live feeds and data operations','Publish exact pinned snapshots, maintain incremental flows, capture licensed live observations and bound remote/distributed computation.'),
 'S8':('Runtime applications, scenarios and ecosystem','Complete rich Studio using the S2 renderer and S6 host; prove three-audience apps, scenarios, models and upgrades without a second authority or silently expanding privileges.'),
 'S9':('Institutional operations and enterprise data estate','Qualify enterprise identity/connectors, regional dedicated cells, privacy/recovery, tenant fairness and measured cost/capacity.'),
 'S10':('Fenced mobility, federation and edge','Move a World without two writers; coordinate independent Worlds honestly; support bounded offline/self-hosted scopes and fleet upgrades.'),
 'S11':('Complete financial lifecycle and full-ambition acceptance','Qualify reference/market data, risk, orders through custody, supervision and three-audience capstones with exact provider/operating evidence.')}
 milestone_data=[]
 for name,(title,outcome) in stages.items():
  ts=[t for t in tickets if t['slice']==name];ext=sorted(set(t['external_gate'] for t in ts if t['external_gate']))
  m={'id':name,'title':title,'outcome':outcome,'tickets':[t['id'] for t in ts],'external_gates':ext,'status':'planned','previous_milestone':None if name=='S0' else f'S{int(name[1:])-1}'};milestone_data.append(m)
  put(f'milestones/{name.lower()}.md',f"# {name} — {title}\n\n## Whole user outcome\n\n{outcome}\n\n## Scope and acceptance\n\n{len(ts)} tickets. All listed code checks must be accepted for the candidate commit/profile. Admission tickets additionally require their exact external gate. Overall milestone acceptance follows earlier milestones; dependency-ready code may be developed earlier behind disabled capabilities. No calendar/staffing estimate is implied.\n\nExternal gates: {', '.join(ext) or 'None beyond admitted core dependencies and independent review.'}\n\n"+'\n'.join(f"- [{t['id']}](../tickets/{t['id'].lower()}.md) — {t['title']} ({t['kind']})" for t in ts)+"\n\n## Exit evidence\n\nCommit/lock/profile bound check results; required provider/operating approvals; schema/upgrade/recovery proof; accessible user journey; source coverage/rights report; measured limits and costs where applicable; operator stop/repair runbook. Remove temporary privileged paths and success placeholders. Reconcile unknown effects rather than suppressing them.\n\n## No partial-success inflation\n\nA demo or code-complete subset does not admit the entire milestone. Unsupported integrations, unlicensed datasets, unqualified regions and unmeasured scale remain explicitly disabled in the support matrix. All C001–C157 are required in the final intended scope; any agreed exclusion must be a reviewed scope change, not silently dropped work.\n")
 js('backlog/milestones.json',milestone_data)
 put('milestones/README.md','# Milestone index\n\n| Milestone | Outcome | Tickets |\n|---|---|---|\n'+'\n'.join(f"| [{m['id']}]({m['id'].lower()}.md) | {m['title']} | {len(m['tickets'])} |" for m in milestone_data))
 # Storage catalog as deliberate target, not pretend executable SQL.
 put('architecture/storage-catalog.md','# Logical state and owner catalog\n\nThese are normative logical state requirements. Physical SQL/schema compilation, constraints, roles and migrations are deliverables in the owning tickets, not already executed migrations. SPEC-003 owns the bootstrap ontology tables from SPEC-002. Every reference is World/realm scoped; no source secret appears as plaintext data.\n\n'+'\n\n'.join(f"## {s['id']} — {s['title']}\n\nOwner: {s['owner']}.\n\n{s['storage']}" for s in specs))
 # Compact spec graph reflects exceptional task-level bootstrap via annotation, not a false cycle.
 graph=['flowchart TD']
 for s in specs:graph.append(f"  S{s['n']}[\"{s['id']} {s['slice']}\"]")
 for s in specs:
  for dep in s['deps']:
   if s['n']==3 and dep==2:graph.append('  S2 -. "presence only; genesis waits for authority" .-> S3')
   else:graph.append(f"  S{dep} --> S{s['n']}")
 put('architecture/spec-dependencies.mmd','\n'.join(graph))
 js('backlog/ticket-dependencies.json',{'nodes':[t['id'] for t in tickets],'edges':[{'from':d,'to':t['id']} for t in tickets for d in t['depends_on']]})
 put('tickets/README.md','# Ticket index\n\nUse the planner, not numeric ID order. All tickets are initially planned. Core admission precedes implementation; external provider qualifications are separate gates.\n\n| Ticket | Milestone | Deliverable | Layer |\n|---|---|---|---|\n'+'\n'.join(f"| [{t['id']}]({t['id'].lower()}.md) | {t['slice']} | {t['title']} | {t['kind']} |" for t in tickets))
 # Preserve source inventory, excluding nonexistent fabricated files.
 manifest={str(p.relative_to(ROOT/'baseline/v2')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'baseline/v2').rglob('*')) if p.is_file()}
 if not (ROOT/'baseline/v2-manifest.json').exists():js('baseline/v2-manifest.json',manifest)
 js('backlog/statistics.json',{'specifications':len(specs),'tickets':len(tickets),'required_checks':len(checks),'capabilities':len(coverage),'milestones':len(milestone_data),'external_gates':len(gates),'product_tests_executed':0,'code_implemented_by_this_pack':False})
 render_v4(specs,tickets)
 print(f'Rendered {len(specs)} specs, {len(tickets)} tickets, {len(checks)} required checks, {len(coverage)} capabilities.')

if __name__=='__main__':main()
