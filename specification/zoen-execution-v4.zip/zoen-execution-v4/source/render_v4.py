"""Deterministic derived v4 indexes, migration report, browser, and state tables."""
from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def put(p,s):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.strip()+'\n',encoding='utf8')
def js(p,d):put(p,json.dumps(d,indent=2,ensure_ascii=False,sort_keys=True))
def old(path):
 with zipfile.ZipFile(ROOT/'lineage/input-v3.zip') as z:return z.read('zoen-execution-v3/'+path)
def oldjson(p):return json.loads(old(p))

def render(specs,tickets):
 idx={t['id']:t for t in tickets}
 # Gates are profile-scoped obligations, all still unapproved.
 gates=oldjson('backlog/gate-register.json')
 for gid,owner,evidence in [
 ('G-APP-LINKS','Identity/security and operations','Actual deployed host/TLS/DNS, private continuation login/session, recipient binding, preview/CSRF/open redirect/replay, shared-device logout and no third-party cookie dependence. Profile-bound browser traces and independent review.'),
 ('G-APP-HOST','Application platform security','Real isolated guest origin/bridge/asset bootstrap, browser profile, backend containment, no shared private state, credential scrubbing, stream/export revocation and explicit guest disclosure mode. No blanket browser DLP assertion.'),
 ('G-MCP-APPS','Client platform security','Exact real host and MCP Apps dialect, resource/tool session constraints, current permission checks, user confirmations, information-flow mode and tested safe text/protected-link fallback.'),
 ('G-RIVET-DYNAMIC','Runtime platform and security','Exact actual Dynamic Apps Core lock, observed deploy semantics, immutable nonpublic slot/public-binding separation, hosted isolation, configuration/credentials, state partition, recall/recovery and measured profile limits. Failure keeps adapter disabled; replacement needs reviewed ADR.')]:
  gates.append({'id':gid,'owner_function':owner,'status':'unapproved','approved_scope':None,'review_due':None,'provider_recheck_required':True,'required_evidence':evidence})
 gates=sorted(gates,key=lambda g:g['id']);js('backlog/gate-register.json',gates)
 put('backlog/gates.md','# Admission gate register — v4\n\nAll gates start unapproved. Code-ready is not provider/browser/operating qualification. The final intended scope requires its selected profiles and all applicable evidence; an unqualified candidate can only be replaced by reviewed change control. Declarative apps do not wait for the Rivet gate.\n\n| Gate | Owner | Required evidence |\n|---|---|---|\n'+'\n'.join(f"| {g['id']} | {g['owner_function']} | {g['required_evidence']} |" for g in gates))
 state_path=ROOT/'backlog/state.json';state=json.loads(state_path.read_text())
 for g in gates:state['gates'].setdefault(g['id'],{'status':'unapproved','evidence_refs':[]})
 js('backlog/state.json',state)

 requirements=[
 ('One shared implementation, not copied policy','ZN-0291 ZN-0043 ZN-0158 ZN-0320'),
 ('No structured-call dependency on Eve, models or MCP','ZN-0291 ZN-0203'),
 ('No direct client SQL/source/index/storage path','ZN-0292 ZN-0322'),
 ('Verified context and app capability intersection','ZN-0293 ZN-0106 ZN-0109'),
 ('Same interpretation, evidence, basis and hidden-rival behavior','ZN-0303 ZN-0320'),
 ('Cross-surface exact operation identity and stale consent','ZN-0306 ZN-0321'),
 ('Batch/cursor/export constraints and current rights','ZN-0294 ZN-0323'),
 ('Streams/chunks/live-data current disclosure and gap semantics','ZN-0295 ZN-0311'),
 ('Authority-free link, generic preview and immutable target','ZN-0296 ZN-0068'),
 ('Browser-bound challenge, recipient, CSRF and no bearer login shortcut','ZN-0297 ZN-0298'),
 ('Version-bound scoped AppSession with current permissions','ZN-0299 ZN-0311'),
 ('Sharing is separate from publishing and membership','ZN-0300 ZN-0301'),
 ('Data-defined app grammar and no executable escape','ZN-0302 ZN-0203'),
 ('Publish through existing old-policy release activation','ZN-0304 ZN-0316'),
 ('S2 first useful app without dense/runtime/full Studio dependencies','ZN-0305 ZN-0203'),
 ('Host-owned consequence/consent and no guest approval flag','ZN-0306 ZN-0311'),
 ('Upgrade, recall, unlink and history without revived authority','ZN-0307 ZN-0318'),
 ('Isolated origin and private host-mediated asset bootstrap','ZN-0308 ZN-0312'),
 ('Exact message-channel binding and transport-only bridge','ZN-0309 ZN-0204'),
 ('Credential stripping and per-subject backend state','ZN-0310 ZN-0317'),
 ('Explicit executable disclosure mode, not imaginary universal browser DLP','ZN-0311 ZN-0312 ZN-0322'),
 ('Actual browser-host qualification and protected links','ZN-0301 ZN-0312'),
 ('MCP Apps negotiation and safe host fallback','ZN-0205 ZN-0313'),
 ('Rivet actual API probe and exact dependency admission','ZN-0314 ZN-0319'),
 ('Immutable runtime stage distinct from authorized publication','ZN-0315 ZN-0316'),
 ('Qualified external containment and runtime recall/recovery','ZN-0317 ZN-0318 ZN-0319'),
 ('Three audiences, measured workloads, one runtime grammar','ZN-0323 ZN-0324 ZN-0206'),
 ('Full original ambition and all v4 evidence survive to S11','ZN-0325 ZN-0285 ZN-0286')]
 rows=[]
 for i,(title,ids) in enumerate(requirements,1):
  tids=ids.split();rows.append({'id':f'R4-{i:03d}','requirement':title,'ticket_ids':tids,'check_ids':[c['id'] for tid in tids for c in idx[tid]['checks']],'status':'specified-not-implemented'})
 js('backlog/v4-requirements.json',rows)
 put('backlog/v4-requirements.md','# v4 requirement traceability\n\nThese 28 refinements sharpen the existing C001–C157 scope; they are not additional production-complete capabilities. Every new ticket and all three required checks are linked.\n\n| Requirement | Contract | Tickets | Checks |\n|---|---|---|---|\n'+'\n'.join(f"| {r['id']} | {r['requirement']} | "+', '.join(f"[{t}](../tickets/{t.lower()}.md)" for t in r['ticket_ids'])+f" | {len(r['check_ids'])} |" for r in rows))

 # State machine refinements use the original source plus four new machines; no duplicate runtime activation state.
 machines=oldjson('architecture/state-machines.json')
 def tr(a,e,b,g,x):return dict(zip(['from','event','to','guard','atomic_effect'],[a,e,b,g,x]))
 machines += [
 {'name':'ContinuationRef','owner':'Ontology','initial':'active','states':['active','revoked','expired'],
  'transitions':[tr('active','GET-or-HEAD','active','No authenticated target disclosure','No state mutation; generic landing only'),tr('active','authorized-open','active','Verified current recipient/session/target rights','Create scoped AppSession through same semantic operation'),tr('active','revoke','revoked','Current authorized revoker and operation identity','Receipt and deny new opens; invalidate derived sessions'),tr('active','expiry','expired','Current time reaches configured expiry','Deny new opens/refresh; terminate derived sessions by policy')],
  'notes':'Reference possession confers no authority. Sharing/invitation acceptance are separate governed operations. Terminal refs never auto-revive.'},
 {'name':'BrowserContinuationChallenge','owner':'Door','initial':'pending','states':['pending','redeemed','expired','locked'],
  'transitions':[tr('pending','preview','pending','Unauthenticated GET/HEAD','No challenge consume or protected disclosure'),tr('pending','exchange','redeemed','POST; CSRF; exact Origin; bound browser; verified recipient; current target admission','Consume once atomically, rotate session and issue target session'),tr('pending','bad-proof','pending','Attempts below limit','Increment attempt count only'),tr('pending','attempt-limit','locked','Max attempts reached','Deny further redemption'),tr('pending','expiry','expired','Challenge deadline reached','Deny redemption')],
  'notes':'A forwarded URL/OTP by itself is not binding. Failed/expired challenges require a new challenge; active domain authority is never stored in the challenge.'},
 {'name':'AppSession','owner':'Ontology','initial':'active','states':['active','closed','revoked','expired','contract-changed'],
  'transitions':[tr('active','semantic-call','active','Current rights, purpose, app ceiling, source rights, publication and recall valid','Invoke existing semantic executor; no session-local policy'),tr('active','compatible-refresh','active','New authorized Frame; unchanged action semantics; current authority','Update view/session revision without inheriting old rights'),tr('active','incompatible-publication','contract-changed','Meaning/schema/action contract no longer compatible','Block pending operation; require new session/intent'),tr('active','logout','closed','Subject or authorized host logout','Cancel owned work and clear controlled cache'),tr('active','revoke','revoked','Membership/link/installation/security deny','Block future disclosure/operations, close queues'),tr('active','expiry','expired','Idle/absolute session bound reached','Deny refresh/calls until new authenticated open')],
  'notes':'Terminal session cannot be refreshed into active. New session requires current authority. Already disclosed/network-in-flight bytes are not retractable.'},
 {'name':'AppRuntimePreparation','owner':'Jobs; not domain authority','initial':'staging','states':['staging','prepared','failed','unknown','retired'],
  'transitions':[tr('staging','probe-success','prepared','Exact immutable artifact/profile/realm/partition verified','Record nonpublic runtime attestation'),tr('staging','build-fail','failed','Observed bounded build failure','Record diagnostic; active Ontology binding unchanged'),tr('staging','lost-reply','unknown','Runtime may have accepted slot; outcome not observed','Record need for exact slot reconciliation'),tr('unknown','probe-success','prepared','Observed same slot/digest/profile','Record attestation, still nonpublic'),tr('unknown','probe-rejection','failed','Explicit observed rejection/no successful stage','Record failure, no invented rollback'),tr('prepared','retire','retired','No active/evaluation/session retention pin and current cleanup fence','Retire only nonrequired slot; no change to domain receipts'),tr('failed','cleanup','retired','No pins/leases and authorized cleanup','Clean staging bytes'),tr('prepared','retain-for-publication','prepared','Existing release process separately approves binding','No local activation authority added')],
  'notes':'No active/public state here. App publication is an existing DefinitionChange/head transition. Unknown cannot be blindly retried; a runtime internal deploy may already have activated its private slot.'}
 ]
 js('architecture/state-machines.json',machines)
 text='# Normative state machines — v4\n\nStates specify product behavior, not an implemented engine. V4 adds links, challenges, app sessions and non-authoritative runtime preparation; publication reuses the existing release machine.\n'
 for m in machines:
  text+=f"\n## {m['name']}\n\nOwner: {m['owner']}. Initial: `{m['initial']}`.\n\n{m['notes']}\n\n| From | Event | To | Guard | Atomic effect |\n|---|---|---|---|---|\n"+'\n'.join(f"| {t['from']} | {t['event']} | {t['to']} | {t['guard']} | {t['atomic_effect']} |" for t in m['transitions'])+'\n'
 put('architecture/state-machines.md',text)
 faults=oldjson('testing/fault-matrix.json')
 more=[
 ('Link challenge','before POST redemption','Race copied browser proofs and preview fetches','Only bound authenticated POST may consume once; previews never consume','SPEC-051'),
 ('App disclosure','before final authorization/send','Commit revocation and fail auth store','No new authorized data dispatch; explicit deny/unavailable','SPEC-051'),
 ('Bridge identity','after iframe navigation','Replay old source window/channel messages','No dispatch under replacement session','SPEC-053'),
 ('Guest state','before warm instance reuse','Alternate owner/worker and restore snapshot','No cross-subject/purpose private state or stale grant','SPEC-053'),
 ('App export','after generation before download','Revoke source rights','Download denied; handle cannot authorize','SPEC-050'),
 ('Runtime staging','after internal deploy before proof write','Kill runtime host','Reconcile immutable slot; public binding unchanged','SPEC-054'),
 ('Runtime publication','after prepare before activation','Revoke author or advance release head','Denied/PreparationStale; no public promotion','SPEC-054'),
 ('Runtime recall','after recall before routing cache invalidation','Send request to stale host','Current recall blocks data/calls; no latest fallback','SPEC-054'),
 ('App action','before authority commit','Insert predicate match and replay same ID across surfaces','Stale or one prior result as applicable; no duplicate effect','SPEC-055'),
 ('Guest disclosure','before supplying protected Frame','Remove executable disclosure admission','No protected guest payload; trusted renderer/fail-closed','SPEC-053'),
 ('MCP host','during resource/tool negotiation','Host omits required security capability','Text/protected-link fallback without authority leak','SPEC-053'),
 ('App load','during bounded batch/fanout','Saturate workload, buffer and cancel','Explicit quota/gaps, bounded memory and no raw-source bypass','SPEC-055')]
 for i,(boundary,barrier,injection,oracle,sid) in enumerate(more,len(faults)+1):faults.append({'id':f'F-{i:02d}','boundary':boundary,'barrier':barrier,'injection':injection,'oracle':oracle,'spec_id':sid})
 js('testing/fault-matrix.json',faults)
 put('testing/fault-matrix.md','# Fault injection matrix — v4\n\nProduct execution required at each boundary; none has run in this package. Test-only barriers must not appear as production endpoints.\n\n| ID | Boundary | Barrier | Injection | Oracle | Spec |\n|---|---|---|---|---|---|\n'+'\n'.join(f"| {f['id']} | {f['boundary']} | {f['barrier']} | {f['injection']} | {f['oracle']} | [{f['spec_id']}](../specs/{f['spec_id'].lower()}.md) |" for f in faults))

 # Compare exact contracts to frozen v3, preserve stable IDs and classify reopening without fabricated progress.
 prev=oldjson('backlog/backlog.json');pi={t['id']:t for t in prev['tickets']}
 changed=[]
 for tid,a in pi.items():
  fields=sorted(k for k in set(a)|set(idx[tid]) if a.get(k)!=idx[tid].get(k))
  if fields:changed.append({'id':tid,'changed_fields':fields,'old_stage':a['slice'],'new_stage':idx[tid]['slice'],'review':'reopen affected implementation evidence before reuse'})
 direct={x['id'] for x in changed};impacted=set(direct)
 while True:
  more={t['id'] for t in tickets if set(t['depends_on'])&impacted}
  if more<=impacted:break
  impacted|=more
 new=[t['id'] for t in tickets if t['id'] not in pi]
 oldids=oldjson('source/stable-identities.json');now=json.loads((ROOT/'source/stable-identities.json').read_text())
 report={'input_archive_sha256':hashlib.sha256((ROOT/'lineage/input-v3.zip').read_bytes()).hexdigest(),'input_file_count':len(oldjson('PACKAGE-MANIFEST.json'))+1,'preserved_old_ticket_ids':len(pi),'stable_task_identities_preserved':all(now.get(k)==v for k,v in oldids.items()),'removed_old_ticket_ids':sorted(set(pi)-set(idx)), 'original_capability_ids_preserved':[f'C{i:03d}' for i in range(1,158)],'new_specs':[s['id'] for s in specs if s['n']>=50],'new_ticket_ids':new,'changed_existing_tickets':changed,'transitively_impacted_tickets':sorted(impacted),'all_supplied_tickets_still_planned':all(t['status']=='planned' for t in tickets),'product_checks_executed':0,'note':'Global constitution/protocol changes also require reviewer triage of any prior accepted evidence. This bundle has no accepted implementation state; do not copy external accepted v3 records without review.'}
 with zipfile.ZipFile(ROOT/'lineage/input-v3.zip') as z:report['input_file_count']=len([n for n in z.namelist() if not n.endswith('/')])
 js('verification/v3-to-v4.json',report)
 stages=[('S0','One executor and no-bypass graph','ZN-0291 ZN-0292'),('S1','Private Focus links, browser binding and shared-device safety','ZN-0296 ZN-0297 ZN-0298 ZN-0068'),('S2','Private app definitions, publication, scoped sessions and first renderer','ZN-0293 ZN-0299 ZN-0302 ZN-0303 ZN-0304 ZN-0203 ZN-0305'),('S3','Sharing, fine-grained rights and early parity','ZN-0300 ZN-0301 ZN-0320'),('S4','Host-owned consequential forms and retry parity','ZN-0306 ZN-0321'),('S5','Batch/export and full generated clients','ZN-0294 ZN-0158'),('S6','Isolated host, MCP and qualified specialized runtime','ZN-0308 ZN-0309 ZN-0310 ZN-0311 ZN-0312 ZN-0204 ZN-0205 ZN-0313 ZN-0314 ZN-0315 ZN-0316 ZN-0317 ZN-0318 ZN-0319 ZN-0322'),('S7','Dense/stream path and measured app load','ZN-0295 ZN-0323'),('S8','Complete Studio, lifecycle and three-audience apps','ZN-0202 ZN-0206 ZN-0307 ZN-0324'),('S9–S11','Institutional profiles through final full-scope review','ZN-0325 ZN-0285 ZN-0286')]
 put('architecture/mini-app-sequence.md','# Progressive mini-app execution — v4\n\nNo early milestone depends on later work. Task-specific stage and exact dependency DAG govern, not a spec-level grouping or numeric ID. The early renderer and app sessions are reused in full Studio. Protected app delivery, generated execution and provider channels stay independently gated.\n\n| Stage | Outcome | Anchor tickets |\n|---|---|---|\n'+'\n'.join(f"| {stage} | {label} | "+', '.join(f'[{tid}](../tickets/{tid.lower()}.md)' for tid in ids.split())+' |' for stage,label,ids in stages)+'\n\nOriginal ID preservation: ZN-0203 remains declarative runtime, now S2; ZN-0204 remains isolated host integration, now S6; ZN-0205 remains MCP Apps, now S6. ZN-0202 and ZN-0206 are full S8 composition. Do not create duplicate early and advanced implementations. [Change report](../verification/v3-to-v4.json) records exact differences.\n\nS2 real hosted private data uses the existing qualified pilot/identity profile; G-APP-LINKS expands and qualifies the S3 sharing surface. Executable-host/runtime gates are not prerequisites for declarative apps. Any future provider replacement requires an ADR and the same behavior proofs.\n')

 count=len(tickets);nchecks=sum(len(t['checks']) for t in tickets)
 put('CHANGELOG.md',f'''# v4 change log

Date: 2026-09-04. Design/specification changes only; no application implementation or remote writes.

## Scope

{len(specs)} specs, {count} tickets, {nchecks} required product checks, original 157 capabilities, 12 milestones and {len(gates)} admission gates. Added six specs (050–055), 35 tickets (0291–0325), 105 required checks, 28 explicitly traced v4 requirements and ADRs 062–065. Preserved all 290 previous IDs and every original task identity; no retired capability.

## Architectural changes

One SPEC-007 executor for every human/agent/app surface. Declarative apps arrive in S2, secure sharing in S3, consequential forms in S4 and executable host in S6. Rich Studio remains S8 but reuses early components. Link/session/current-rights, private asset bootstrap, host-owned consent, export/stream closure, per-subject runtime state and qualified Rivet staging/publication now have explicit contracts and task oracles.

Rivet Dynamic Apps Core is a candidate specialized adapter, not the data authority or a dependency for declarative apps. Actual vendor behavior/containment/browser profiles must be qualified. Private data in executable browser code needs an explicit approved disclosure profile; an iframe or CSP is not claimed to guarantee universal data-loss prevention.

## Execution migration

{len(changed)} existing ticket records changed (including added normative read sets). See [machine-readable diff](verification/v3-to-v4.json). Import any external v3 execution state only after independent review of changed contracts and impacted dependencies; never automatically preserve accepted status. The supplied state has no accepted tickets. The full v3 input ZIP and v2 baseline remain byte-for-byte preserved.

## Validation limits

`tools/verify.py` validates this package and schema/control tests, not Zoen runtime behavior. All {nchecks} target product checks remain unrun. No real PostgreSQL/Cedar/browser/Rivet/provider/cloud or production-capacity proof is supplied by this delivery.
''')
 put('START-HERE.md',f'''# Start here — Zoen execution v4

**{len(specs)} specifications · {count} bounded tickets · {nchecks} required product checks · 157 capabilities · 12 milestones · {len(gates)} gates.**

## Central contract

Human interfaces, agents and mini apps invoke **the same SemanticExecutor in SPEC-007**, not merely similar rules. Bridges translate transport; they do not implement a data API or another permission/interpretation engine. Structured app reads do not require Eve, an LLM or MCP.

V4 preserves the full S0–S11 ambition and the exact v3 input while closing the mini-app gap. Private declarative apps are S2, sharing S3, governed forms S4, isolated executable host/Rivet qualification S6 and full Studio S8. [Changes](CHANGELOG.md) · [Portuguese overview](LEIA-ME.pt-BR.md).

## Execute

```sh
python -m pip install -r tools/requirements.txt
python tools/verify.py
python tools/plan.py summary
python tools/plan.py next --limit 3
python tools/plan.py packet ZN-0001 --out packets/ZN-0001.md
```

Give the implementing agent **one dependency-ready context packet**. The target is a reviewed branch of the zoen application repository; the ZIP is an execution specification, not a runnable product scaffold. First inventory/preserve existing OS data and repository commit identities. Do not reset or infer there are no live users. Exact core/extension dependencies are admitted by actual probes, not invented from nominal version numbers.

| Need | Entry |
|---|---|
| Rules and stable ownership | [Constitution](architecture/constitution.md) · [repository](architecture/repository-contract.md) |
| One data/action implementation | [Semantic path](architecture/semantic-path.md) · [shared protocol](architecture/protocol-contract.md) |
| Mini apps, protected links, runtime and sequence | [Apps](architecture/mini-app-contract.md) · [links](architecture/protected-links.md) · [host](architecture/app-host-security.md) · [Rivet](architecture/rivet-adapter.md) · [sequence](architecture/mini-app-sequence.md) |
| Specs, tickets and offline search | [Specs](specs/README.md) · [tickets](tickets/README.md) · [backlog](backlog.html) |
| Original scope and v4 refinements | [157 capabilities](backlog/capability-coverage.md) · [28 v4 requirements](backlog/v4-requirements.md) |
| Required proof and operational admission | [Testing](testing/strategy.md) · [app conformance](testing/mini-app-conformance.md) · [gates](backlog/gates.md) |
| What ran in this delivery | [Verification](verification/report.json) · [validation limits](verification/README.md) |

## Mandatory execution discipline

Read AGENTS.md and every additional normative file in the ticket. Follow dependencies, not IDs or spec numbers. A missing semantic decision is a blocked report and reviewed spec change, not permission to improvise. A generated file or unused component is not completion. File/lock scopes are explicit. Template, publication, sharing and external effects remain separate governed operations.

A link is not authority; each use rechecks current rights. A runtime build is not publication. An app signature is not permission to receive private data. Generated execution remains disabled until the exact host/runtime/disclosure profile is admitted. Missing vendor credentials blocks its route, not independent declarative code.

No application ticket is accepted in this delivery. Reopen impacted external v3 evidence per [migration report](verification/v3-to-v4.json); do not blindly copy prior accepted state. Completion requires all named checks at the actual layer, commit/lock/profile-bound artifacts and independent review. The control tools validate structure/integrity; they cannot prove fabricated logs true.
''')
 put('README.md','# Zoen execution v4\n\n[Start here](START-HERE.md) · [Leia em português](LEIA-ME.pt-BR.md) · [Backlog](backlog.html) · [Changes](CHANGELOG.md)\n\nOne semantic implementation. Every human, agent and mini app uses it. The full institutional ambition remains specified through S11; no product implementation is claimed.\n')
 put('LEIA-ME.pt-BR.md',f'''# Zoen v4 — um mundo operacional, várias interfaces

O v4 consolida a decisão: **humanos, agentes e mini apps passam pela mesma implementação de dados, permissões, interpretação e ações da Ontology**. A ponte de um app apenas adapta o transporte; não cria uma API de negócio paralela. Uma tabela estruturada não passa por um modelo de linguagem.

## O que mudou

A entrega tem {len(specs)} especificações, {count} tickets e {nchecks} verificações de aceitação exigidas, mantendo as 157 capacidades e a execução completa de S0 a S11. São seis specs e 35 tickets novos, quatro decisões arquiteturais e 28 requisitos adicionais de precisão. Os 290 IDs anteriores foram preservados.

Apps declarativos privados chegam em S2; compartilhamento protegido em S3; formulários com ações governadas em S4; execução isolada e qualificação Rivet em S6. O Studio de S8 reutiliza os mesmos componentes. Não é preciso esperar por dados densos, Python ou infraestrutura institucional para uma confeiteira ter um quadro de encomendas.

Links são referências sem autoridade. A sessão identifica a pessoa e restringe escopo, finalidade e versão; cada chamada verifica os direitos atuais. Compartilhar não empresta os poderes do criador. Os testes incluem prévias, encaminhamento, troca de conta, revogação, exportações, filas, caches e rotas secundárias.

Rivet Dynamic Apps Core é o primeiro candidato a adaptador de backend especializado, não a base de todos os apps. Compilar ou ativar uma versão interna na Rivet não publica o app no Zoen. A versão pública continua vinculada à release aprovada da Ontology.

## Uma correção importante de segurança

Uma interface isolada não prova que código hostil não copiará dados que recebeu. O padrão é renderização declarativa confiável. Dados privados só entram em JavaScript executável sob um perfil de divulgação explicitamente aprovado ou um ambiente de controle mais forte realmente qualificado. O plano não confunde CSP, iframe ou assinatura com garantia universal de não vazamento.

## Como executar

Comece pelo [guia](START-HERE.md). Use [um pacote de contexto por ticket](packets/ZN-0001.md), respeitando a seleção do planejador. [Busque no backlog](backlog.html), consulte a [sequência dos mini apps](architecture/mini-app-sequence.md) e verifique o [mapa de requisitos](backlog/v4-requirements.md).

O ZIP v3 está preservado byte a byte em `lineage/input-v3.zip`; o baseline v2 também foi mantido. O [relatório de migração](verification/v3-to-v4.json) identifica os contratos alterados e dependentes que precisam de revisão de evidência. Nenhum estado externo de implementação é presumido.

## Limites da entrega

Este é um bundle de arquitetura e execução, não o aplicativo funcionando. Os testes locais verificam contratos, schemas, planejamento e integridade do pacote. As {nchecks} verificações de produto começam não executadas. Não houve alteração dos repositórios, deploy, chamada à Rivet, autenticação real de usuários nem qualificação de serviços externos.
''')

 # Standalone, offline browser with data from this exact catalog; no remote fonts or scripts.
 simple=[{k:t[k] for k in ['id','title','slice','spec_id','kind','risk','depends_on','external_gate','capabilities','acceptance']} for t in tickets]
 data=json.dumps(simple,ensure_ascii=False).replace('<','\\u003c')
 html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Zoen v4 — execution backlog</title>
<style>:root{font-family:system-ui,sans-serif;color:#172b36;background:#f3f5f5}body{max-width:1180px;margin:32px auto;padding:0 24px}header{padding:28px 0;border-bottom:3px solid #236b66}h1{font-size:38px;line-height:1.15;margin:.3em 0}.eyebrow{letter-spacing:.12em;font-size:12px;font-weight:700;color:#236b66}p{line-height:1.55}a{color:#175f6b}nav{display:flex;flex-wrap:wrap;gap:12px;margin:24px 0;align-items:center}input,select,button{font:inherit;border:1px solid #bdcbcf;border-radius:6px;padding:11px;background:white}#q{flex:1;min-width:250px}.hint{font-size:14px;color:#526b74}article{border:1px solid #cdd9db;border-radius:9px;padding:20px 24px;margin:14px 0;background:white}h2{font-size:20px;margin:8px 0}.meta{font-size:13px;color:#526b74}.delta{border-left:4px solid #236b66}.links{display:flex;gap:15px;flex-wrap:wrap}button{cursor:pointer}a:focus-visible,input:focus-visible,select:focus-visible,button:focus-visible{outline:3px solid #1c716f}footer{margin:32px 0}</style></head><body>
<header><div class="eyebrow">ZOEN / EXECUTION V4</div><h1>One semantic path. Every surface.</h1><p>__COUNTS__</p><p class="hint">Planned specifications, not a production dashboard. All product acceptance checks start unrun. Mini apps do not own a parallel data API.</p><div class="links"><a href="START-HERE.md">Start here</a><a href="LEIA-ME.pt-BR.md">Português</a><a href="architecture/mini-app-sequence.md">App sequence</a><a href="backlog/v4-requirements.md">v4 requirements</a><a href="testing/mini-app-conformance.md">Test plan</a><a href="CHANGELOG.md">Changes</a></div></header>
<nav aria-label="Filter tickets"><input id="q" aria-label="Search tickets" placeholder="Search ID, capability, title or acceptance…"><select id="stage" aria-label="Milestone"><option value="">All milestones</option></select><select id="kind" aria-label="Evidence layer"><option value="">All evidence layers</option></select><label><input id="apps" type="checkbox"> Mini-app refinements</label></nav><p id="count" aria-live="polite"></p><main id="results"></main><button id="more" type="button">Show more</button><footer class="hint">Exact work and proof: tickets → specifications → normative contracts. Stable IDs, dependency-ready execution, no invented qualification.</footer>
<script id="data" type="application/json">__DATA__</script><script>
'use strict';const tickets=JSON.parse(document.getElementById('data').textContent);let limit=40;const q=document.getElementById('q'),stage=document.getElementById('stage'),kind=document.getElementById('kind'),apps=document.getElementById('apps'),results=document.getElementById('results'),more=document.getElementById('more');
for(const s of [...new Set(tickets.map(t=>t.slice))].sort((a,b)=>+a.slice(1)-+b.slice(1))){let o=document.createElement('option');o.value=s;o.textContent=s;stage.append(o)}
for(const s of [...new Set(tickets.map(t=>t.kind))].sort()){let o=document.createElement('option');o.value=s;o.textContent=s;kind.append(o)}
function isApp(t){return +t.spec_id.slice(5)>=50||t.spec_id==='SPEC-035'||t.id==='ZN-0068'}
function text(tag,value,cls){let e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e}
function render(){const term=q.value.trim().toLowerCase();const rows=tickets.filter(t=>(!stage.value||t.slice===stage.value)&&(!kind.value||t.kind===kind.value)&&(!apps.checked||isApp(t))&&(!term||JSON.stringify(t).toLowerCase().includes(term)));results.replaceChildren();document.getElementById('count').textContent=`${rows.length} matching tickets · showing ${Math.min(limit,rows.length)} · all planned`;
for(const t of rows.slice(0,limit)){let a=document.createElement('article');if(isApp(t))a.className='delta';a.append(text('div',`${t.slice} · ${t.spec_id} · ${t.kind} · ${t.risk}`,'meta'));let h=text('h2','');let link=document.createElement('a');link.href=`tickets/${t.id.toLowerCase()}.md`;link.textContent=`${t.id} — ${t.title}`;h.append(link);a.append(h,text('p',t.acceptance.then),text('p','Dependencies: '+(t.depends_on.join(', ')||'none'),'meta'));if(t.external_gate)a.append(text('p','Admission gate: '+t.external_gate,'meta'));a.append(text('p',t.capabilities.join(' · '),'meta'));results.append(a)}more.hidden=limit>=rows.length}
for(const el of [q,stage,kind,apps])el.addEventListener('input',()=>{limit=40;render()});more.addEventListener('click',()=>{limit+=40;render()});render();
</script></body></html>'''
 html=html.replace('__COUNTS__',f'{len(specs)} specs · {len(tickets)} tickets · {nchecks} required checks · 157 capabilities · {len(gates)} gates').replace('__DATA__',data)
 put('backlog.html',html)
