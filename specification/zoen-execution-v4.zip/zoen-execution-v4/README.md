# Zoen execution v4

[Start here](START-HERE.md) · [Leia em português](LEIA-ME.pt-BR.md) · [Backlog](backlog.html) · [Changes](CHANGELOG.md)

One semantic implementation. Every human, agent and mini app uses it. The full institutional ambition remains specified through S11; no product implementation is claimed.
