# Immutable v3 input

`input-v3.zip` is a byte-for-byte copy of the supplied execution v3 bundle. Its SHA-256 is recorded in [input manifest](input-v3-manifest.json). It preserves every prior file, including v3 plan-control reports; those reports do not certify v4.

Active instructions are at the v4 root and linked from START-HERE. The v2 baseline remains separately preserved at its original internal paths. V3's stable IDs are retained; before/after ticket changes and evidence-reopen impact are recorded in [v3-to-v4](../verification/v3-to-v4.json). Never execute specifications directly from this historical ZIP as if they were the current contract.
