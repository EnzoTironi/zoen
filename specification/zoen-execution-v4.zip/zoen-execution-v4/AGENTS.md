# Agent execution rules

Read [START-HERE.md](START-HERE.md) and the one context packet assigned to you. Work only on an evidence-ready ticket and inside its allowed paths. The normative order is constitution → protocol/owning spec → ticket/test oracle → v2 baseline examples. Do not treat v2 sample SQL as complete migrations.

Never infer live-data emptiness, reset OS, install a new framework family, expose arbitrary tools, give an agent new authority, change a test oracle to match code, or report a provider outcome that was not observed. Preserve current authorization, complete dependency guards, atomic receipts/outbox, fenced recovery, hidden-rival noninterference and evaluation isolation.

Required real dependencies must actually run. Simulators prove only protocol behavior. Empty/skipped required tests fail. Source and lock must match evidence and independent review. A local structural verifier cannot certify the honesty of externally supplied evidence; use trusted CI and accountable reviewers.

Use [the bounded implementation prompt](prompts/implement-one-ticket.md). Ambiguity or missing capability yields [a blocked report](prompts/blocked-report.md), never architectural improvisation. Obtain [independent review](prompts/review-one-ticket.md). Regenerate derived docs only from reviewed source and preserve stable IDs; accepted contracts require evidence reopening.

Do not create remote issues, send messages, change provider accounts or deploy infrastructure merely because a ticket file exists. Such work requires the specific task, credentials, environment, permissions and operating gate.


## v4 mandatory mini-app discipline

Read [semantic path](architecture/semantic-path.md) and all additional normative files listed in your ticket. Do not build a mini-app data backend, a duplicate policy engine or an Eve-dependent typed read. Human, agent and app calls use the exact SPEC-007 implementation. Follow [mini-app sequencing](architecture/mini-app-sequence.md), not SPEC-035's overall S8 label.

Never confuse a runtime build with authorized publication, an opaque link with access, or an artifact signature with a trusted data recipient. Protected assets and secondary routes require current rights. No private data in unapproved guest code. Preserve old ticket IDs and reopen changed evidence before resuming v3 work.
