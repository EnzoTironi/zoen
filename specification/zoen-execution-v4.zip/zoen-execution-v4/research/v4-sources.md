# v4 primary-source ledger

Reviewed **2026-09-04**. These sources inform boundary design, not admission of any implementation. Recheck at exact dependency/profile admission. Summaries are deliberately short; no copied vendor implementation is included.

| Ref | Primary source | Observation relevant to the design | Consequence / qualification |
|---|---|---|---|
| RIVET-CORE | [Dynamic Apps Core](https://rivet.dev/dynamic-apps/docs/core/) | Core exposes host-controlled storage/loading responsibilities. | Probe actual hooks at an exact lock; no assumed compatibility. |
| RIVET-DEPLOY | [Deploy](https://rivet.dev/dynamic-apps/docs/deploy/) | A successful deploy persists and activates its runtime release; failed build does not replace the active one. | Immutable nonpublic slot staging; Ontology activation remains separate. |
| RIVET-ARCH | [Architecture](https://rivet.dev/dynamic-apps/docs/architecture/) | Documentation discusses embedded VM execution and routing. Dynamic Apps is marked Preview. | Keep host outside authority, qualify external containment and mutable state partition. |
| RIVET-AUTH | [Authentication](https://rivet.dev/dynamic-apps/docs/authentication/) | Authentication is the hosting server's responsibility. | Authenticate all routes and strip host credentials before guest forwarding. |
| AGENTOS | [Security model](https://rivet.dev/agentos/docs/security-model/) | Beta security model distinguishes trusted host configuration and untrusted code; V8-based isolation is described. | Generated policy/config is untrusted to Zoen; independently qualify host and runtime. |
| MCP-APPS | [MCP Apps overview](https://modelcontextprotocol.io/extensions/apps/overview) | App UI resources and host-mediated JSON-RPC/postMessage extend MCP; support is client-dependent. | Qualified host/dialect matrix and safe text/link fallback, not generic trust. |
| OWASP-AUTH | [Authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html) | Least privilege, per-request authorization and protected static resources are distinct requirements. | Check every operation/asset/resume, not only link or first HTML load. |
| MDN-MESSAGE | [postMessage](https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage) | Sender origin/window and message handling require explicit verification. | Bind exact origin/window plus per-session channel and typed payload. |
| MDN-IFRAME | [iframe](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe) | Nested browsing contexts support navigation; sandbox options constrain specific capabilities. | Do not claim arbitrary hostile frontend data is universally non-exfiltratable. |
| MDN-CSP | [connect-src](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/connect-src) | This directive limits specified connection APIs. | It is not a universal navigation or information-flow firewall. |

No current dependency versions are invented here. ZN-0314 selects an exact extension lock after real compatibility probes. No Rivet, provider, remote MCP host or deployed browser security test was executed while creating this package.
