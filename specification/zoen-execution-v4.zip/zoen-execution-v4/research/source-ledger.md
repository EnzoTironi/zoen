# Source and verification ledger

Accessed 2026-09-04. These primary sources informed test and boundary design. They are not compatibility evidence for an exact future lock. Provider terms, API behavior and operating scopes must be rechecked at admission. Public repository inspection did not execute code or establish a live-data inventory.

| Source | Use in this pack | Boundary |
|---|---|---|
| https://github.com/EnzoTironi/OS | Existing implementation as migration/reference input. | No repository writes, deployments or proven production state. |
| https://github.com/EnzoTironi/zoen | Intended greenfield execution repository. | Actual commit inventory is the first ticket; no assumed empty production estate. |
| https://www.postgresql.org/docs/current/transaction-iso.html | SERIALIZABLE/repeatable-read behavior and required retry/fault tests. | Exact schema/locking algorithm must be proven with real concurrency. |
| https://docs.cedarpolicy.com/auth/authorization.html | Explicit authorization boundary and deny behavior. | Application schema/entity construction still requires tests. |
| https://docs.restate.dev/develop/ts/durable-steps | Durable steps and retries. | Does not certify exactly-once external side effects. |
| https://iceberg.apache.org/spec/ | Snapshot metadata and format interoperability. | Exact writer/catalog/reader features require a compatibility matrix. |
| https://modelcontextprotocol.io/docs/2026-07-28/learn/versioning | Version-negotiated MCP integration. | Implementation must admit supported revision and app extensions explicitly. |
| https://playwright.dev/docs/test-assertions | Browser assertion/test harness. | Browser tests alone do not establish backend isolation. |
| https://fast-check.dev/docs/introduction/ | Generated pure-law checks and reproducible failing cases. | Property tests supplement real integration and fault testing. |
| https://www.w3.org/TR/WCAG22/ | Accessibility acceptance design. | Automated checks are not a complete accessibility audit. |
| https://developers.google.com/workspace/drive/api/reference/rest/v3/changes/list | Drive incremental source recipe. | ACL completeness and token reset behavior must be separately qualified. |
| https://learn.microsoft.com/en-us/graph/delta-query-overview | Microsoft source delta behavior. | Delta semantics vary by resource; never assume complete ACL synchronization. |
| https://learn.microsoft.com/en-us/graph/api/driveitem-delta?view=graph-rest-1.0 | Drive item continuation/reset and tombstones. | Real connector account tests before activation. |
| https://docs.snowflake.com/en/developer-guide/sql-api/intro | Bounded warehouse SQL source adapter. | Credentials, rights, licensing and real workload admission remain external. |

The immutable v2 package contains the broader Palantir/Bloomberg/product research and architecture decisions. The new execution pack translates them into verifiable work rather than claiming competitive or commercial parity. See [baseline](../baseline/v2/technical-blueprint/README.md).

## v4 mini-app research

See [v4 primary-source ledger](v4-sources.md) for the reviewed Rivet/MCP/browser/authorization contracts and their qualification boundaries. These observations do not admit a vendor runtime.
