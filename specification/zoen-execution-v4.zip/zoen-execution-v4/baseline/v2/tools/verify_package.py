#!/usr/bin/env python3
"""Local package verification, not production architecture validation.

Requires Python >= 3.10 and jsonschema. TypeScript checks run when `tsc` is available.
Does not use the network, databases, provider accounts or a Mermaid renderer.
"""
from __future__ import annotations
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'technical-blueprint/verification/report.json'
errors: list[str] = []
checks: dict[str, object] = {}


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def fail(message: str) -> None:
    errors.append(message)


def run_command(args: list[str], timeout: int = 45) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=ROOT, text=True, capture_output=True, timeout=timeout,
                          env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})


def check_links() -> None:
    count = 0
    docs = [p for p in ROOT.rglob('*.md') if not p.is_relative_to(ROOT/'baseline/original')]
    pattern = re.compile(r'\[[^\]\n]+\]\(([^)\n]+)\)')
    for path in docs:
        for target in pattern.findall(path.read_text(encoding='utf-8')):
            target = target.strip().split(' "', 1)[0].strip('<>')
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) or target.startswith('#'):
                continue
            target = unquote(target.split('#',1)[0])
            if not target:
                continue
            resolved = (path.parent/target).resolve()
            count += 1
            if not resolved.is_relative_to(ROOT):
                fail(f'Non-portable active link: {path.relative_to(ROOT)} -> {target}')
            elif not resolved.exists() and resolved != REPORT:
                fail(f'Missing active link: {path.relative_to(ROOT)} -> {target}')
    checks['active_markdown_links'] = {'documents':len(docs),'local_links_checked':count,
                                       'scope':'Target file existence/portability; anchors and external URLs not revalidated'}


def check_json() -> None:
    files = [p for p in ROOT.rglob('*.json') if p != REPORT]
    for p in files:
        try: read_json(p)
        except (ValueError, OSError) as exc: fail(f'Invalid JSON {p.relative_to(ROOT)}: {exc}')
    try:
        from jsonschema import Draft202012Validator, FormatChecker
    except ImportError:
        fail('jsonschema missing: install jsonschema to validate the reference schemas')
        return
    directory = ROOT/'technical-blueprint/contracts'
    schemas = list(directory.glob('*.schema.json'))
    for path in schemas:
        try: Draft202012Validator.check_schema(read_json(path))
        except Exception as exc: fail(f'Invalid schema {path.name}: {exc}')
    index=read_json(ROOT/'technical-blueprint/examples/index.json')
    examples_dir=ROOT/'technical-blueprint/examples'
    for entry in index:
        try:
            schema=read_json(examples_dir/entry['schema'])
            data=read_json(examples_dir/entry['path'])
            Draft202012Validator(schema,format_checker=FormatChecker()).validate(data)
        except Exception as exc: fail(f'Example {entry["path"]}: {exc}')
    # Structural negative controls; these do not check runtime permission validity.
    schema=read_json(directory/'claim.schema.json')
    validator=Draft202012Validator(schema,format_checker=FormatChecker())
    example=read_json(examples_dir/'household-claim.json')
    negatives=[{**example,'value':'NaN'},{**example,'value':'1e3'},
               {**example,'realm':'other'},{**example,'secretToken':'not-allowed'},
               {**example,'validFrom':'not-a-date'}]
    for i,data in enumerate(negatives):
        if validator.is_valid(data): fail(f'Negative schema fixture unexpectedly accepted: {i}')
    checks['json_schemas']={'json_files_parsed':len(files),'schemas_checked':len(schemas),
                             'valid_examples':len(index),'invalid_examples_rejected':len(negatives)}


def check_traceability() -> None:
    decisions=read_json(ROOT/'technical-blueprint/research/decision-index.json')
    adr_ids={d['id'] for d in decisions}
    journeys=read_json(ROOT/'technical-blueprint/research/journey-index.json')
    journey_ids={j['id'] for j in journeys}
    slices=read_json(ROOT/'technical-blueprint/research/slice-index.json')
    slice_ids={s['id'] for s in slices}
    with (ROOT/'technical-blueprint/capability-matrix.csv').open(newline='',encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    if len({r['id'] for r in rows}) != len(rows): fail('Duplicate capability ID')
    for row in rows:
        if row['adr'] not in adr_ids: fail(f'Unknown ADR in {row["id"]}')
        if row['proof'] not in journey_ids: fail(f'Unknown journey in {row["id"]}')
        if row['slice'] not in slice_ids: fail(f'Unknown slice in {row["id"]}')
        if not (ROOT/'technical-blueprint'/row['contract']).is_file(): fail(f'Missing contract in {row["id"]}')
        if row['status'] != 'DesignOnly': fail(f'Unsubstantiated capability status in {row["id"]}')
    for d in decisions:
        if not (ROOT/'technical-blueprint'/d['path']).is_file(): fail(f'Missing ADR {d["id"]}')
    if adr_ids != {f'{i:03}' for i in range(30,61)}: fail('ADR index must cover 030–060 exactly')
    checks['traceability']={'capabilities':len(rows),'new_adrs':len(decisions),'journeys':len(journeys),
                            'slices':len(slices),'scope':'References complete; journeys are acceptance specs, not executed production tests'}


def check_archive() -> None:
    manifest=read_json(ROOT/'baseline/input-manifest.json')
    for item in manifest['files']:
        p=ROOT/'baseline'/item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
            fail(f'Archived Markdown changed or missing: {item["path"]}')
    checks['baseline_preservation']={'markdown_files':len(manifest['files']),
                                      'original_zip_sha256':manifest['sha256'],'scope':'Preserved Markdown hashes; original ZIP not bundled'}


def check_reference_code() -> None:
    result=run_command([sys.executable,'-m','unittest','discover','-s','technical-blueprint/verification','-p','test_reference.py','-v'])
    output=result.stdout+result.stderr
    found=re.search(r'Ran (\d+) tests',output)
    checks['reference_law_tests']={'passed':result.returncode==0,'tests':int(found.group(1)) if found else None,
                                   'output':output,'scope':'Synthetic single-domain in-memory laws only'}
    if result.returncode: fail('Reference Python tests failed')
    tsc=shutil.which('tsc')
    if tsc:
        version=run_command([tsc,'--version']).stdout.strip()
        types=run_command([tsc,'--noEmit','--strict','--target','ES2022','--module','ESNext',
                           'technical-blueprint/contracts/types.ts','technical-blueprint/contracts/type-tests.ts'])
        checks['typescript']={'status':'passed' if types.returncode==0 else 'failed','compiler':version,
                               'output':types.stdout+types.stderr,
                               'scope':'Reference type slice only; not target TypeScript/Node stack integration'}
        if types.returncode: fail('Reference TypeScript checks failed')
    else:
        checks['typescript']={'status':'not-run','reason':'tsc not installed'}
    node=shutil.which('node')
    checks['local_environment']={'python':sys.version.split()[0],
                                 'node':run_command([node,'--version']).stdout.strip() if node else None}


def check_integrity() -> None:
    path=ROOT/'package-manifest.json'
    if not path.exists():
        checks['package_integrity']={'status':'not-run','reason':'Manifest not yet generated'}
        return
    manifest=read_json(path)
    indexed=set()
    for item in manifest['files']:
        indexed.add(item['path']); p=ROOT/item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
            fail(f'Package hash mismatch: {item["path"]}')
    ignored={'package-manifest.json','technical-blueprint/verification/report.json'}
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
            and str(p.relative_to(ROOT)) not in ignored}
    for extra in sorted(actual-indexed): fail(f'Unindexed package file: {extra}')
    checks['package_integrity']={'files_checked':len(indexed),'excluded':sorted(ignored)}


def main() -> int:
    for check in [check_links,check_json,check_traceability,check_archive,check_reference_code,check_integrity]:
        try: check()
        except Exception as exc: fail(f'{check.__name__}: {type(exc).__name__}: {exc}')
    report={'generatedAt':datetime.now(timezone.utc).isoformat(),'status':'passed' if not errors else 'failed',
            'evidenceLevel':'LocalReferencePassed' if not errors else 'LocalReferenceFailed',
            'checks':checks,'errors':errors,
            'not_executed':['Complete application install/build','Node 24 / target TypeScript stack compatibility',
                            'PostgreSQL SQL/transaction/RLS tests','Cedar authorization engine','AWS deployment/restore/failover',
                            'WhatsApp or other real providers','Restate external effect recovery','Iceberg/catalog/GC races',
                            'Sandbox isolation/security audit','Mermaid rendering','Licensed financial data or legal/commercial admission']}
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'traceability':checks.get('traceability'),
                      'reference_tests':checks.get('reference_law_tests',{}).get('tests'),'errors':errors},indent=2))
    return 0 if not errors else 1

if __name__=='__main__': raise SystemExit(main())
