# Zoen from zero — a world that learns

**Architecture proposal 2.0 · 4 September 2026 · successor to the supplied `zoen-greenfield.zip`.**

Institutional depth. Personal simplicity. Runtime variation. Evidence that survives disagreement.

Zoen gives people and organizations one continuous way to understand what is happening, improve what is known, watch what matters, and act within explicit authority. It begins in a conversation, not an integration project. Its underlying ontology is an evolving, governed representation of a world—not a universal database of unquestionable facts.

## Read this package

1. [Resumo em português](LEIA-ME.pt-BR.md) states the design and material changes.
2. [Product synthesis](synthesis.md) defines the experience and irreducible product loop.
3. [Technical constitution](technical-blueprint/README.md) fixes ownership and technical choices.
4. [Decision register](technical-blueprint/decision-register.md) records every governing decision and links its rationale.
5. [Execution sequence](technical-blueprint/implementation-sequence.md) turns the architecture into outcome-based slices and gates.
6. [Implementation handoff](HANDOFF.md) tells an implementation agent exactly where to start and what not to infer.

[Three audiences](product/three-audiences.md), [canonical journeys](product/journeys.md), [capability coverage](technical-blueprint/capability-matrix.csv), [contracts](technical-blueprint/contracts/README.md), and [source ledger](technical-blueprint/sources.md) complete the package.

## Precedence

This root and `technical-blueprint/` are the **proposed v2 baseline**. `baseline/` contains unchanged Markdown from the supplied ZIP for traceability only; it is not an additional active constitution. [Supersession](technical-blueprint/supersession.md) accounts for the original ADRs. New ADR numbering continues at 030. In a conflict, use the new decision register and its successor ADR, not the archived rule.

Sources establish what reference products or technologies document. They do not prove that Zoen has implemented those capabilities. Every new capability is a design contract until its execution gate passes. No production code was deployed, no external accounts were connected, and no repository was modified to produce this package.

## Artifacts, not promises

The package includes Markdown specifications, editable Mermaid architecture sources, a machine-readable capability matrix, representative TypeScript contracts, JSON Schemas and examples, a SQL reference slice, and a runnable synthetic reconciliation, dependency-guard and idempotency specification. These are implementation inputs. The reference slice is explicitly not a complete application, migration suite, or security certification.

Run `python tools/verify_package.py` to check local integrity, links, JSON examples, coverage references, and executable examples. Read [verification scope](technical-blueprint/verification/README.md) before interpreting a passing result.
