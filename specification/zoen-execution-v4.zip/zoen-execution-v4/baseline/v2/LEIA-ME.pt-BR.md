# Zoen — um mundo que aprende

**Proposta de arquitetura 2.0 · 4 de setembro de 2026**

## A decisão central

Construir um núcleo pequeno e estável que interprete definições versionadas. Dados, ontologias, integrações, regras de reconciliação, skills, agentes, acompanhamentos, ações e interfaces evoluem em runtime. O núcleo não precisa ser reimplantado a cada variação de negócio. Novas capacidades computacionais ou mudanças nos limites de confiança continuam exigindo engenharia.

O produto não promete que todas as fontes concordem nem que uma resposta humana seja infalível. Ele preserva as evidências, distingue interpretações e aprende de forma rastreável. “Dados perfeitos” torna-se um objetivo operacional: menos ambiguidades relevantes, melhor cobertura, mais atualidade, explicações mais claras e decisões menos arriscadas — sem apagar divergências legítimas.

## A experiência

Uma avó encaminha um comprovante e pergunta se uma conta foi paga. Uma confeiteira cruza encomendas, estoque, conversas e recebimentos. Uma clínica distingue agenda, cobrança e prontuário. Uma corporação reconcilia ERPs, CRMs, planilhas, documentos e dados de mercado. São diferentes pacotes de domínio e políticas sobre a mesma gramática: evidência, entendimento, acompanhamento e ação.

A entrada prioritária é WhatsApp. Quando necessário, a mesma conversa abre uma visão visual do mesmo assunto. A pessoa não precisa saber o que é uma ontologia, uma política Cedar ou um snapshot. Ela precisa compreender o que o Zoen sabe, o que falta, por que está perguntando e o que acontecerá se autorizar algo.

## O que foi redesenhado

**Reconciliação passa a ser uma capacidade central.** Uma divergência é classificada: pode ser identidade errada, períodos diferentes, unidades distintas, duas definições de um indicador ou um conflito genuíno. Respostas humanas geram evidência e decisões com escopo; não sobrescrevem indiscriminadamente as fontes.

**Variação em runtime passa a ter um protocolo completo.** Há três caminhos em runtime: corrigir um fato; publicar uma definição; instalar um artefato executável isolado. Uma quarta categoria — mudar uma operação privilegiada do núcleo — continua exigindo alteração de código e deploy revisado. Usuário e agente usam os mesmos caminhos, com permissões diferentes. O agente não pode conceder poderes a si próprio nem aprovar uma política usando a própria política proposta.

**A escala deixa de depender de um contador global de alterações do World.** O head governa a configuração e a autoridade. Dados são versionados em domínios de commit, e uma leitura consistente registra um corte desses domínios. Não se promete uma transação global entre regiões ou empresas.

**A infraestrutura densa usa padrões existentes.** PostgreSQL sustenta autoridade e fatos operacionais; evidências brutas ficam em armazenamento de objetos; Parquet com Apache Iceberg sustenta datasets densos quando essa capacidade é ativada. Não é necessário transformar cada linha bruta em um nó operacional nem reconstruir um lakehouse proprietário.

**Eve continua sendo o produto, não uma dependência obrigatória de um pacote homônimo.** A proposta usa um journal e uma máquina de estados de turnos sob responsabilidade da Eve, com AI SDK como adaptador de modelos. O runtime anterior permanece documentado como alternativa, não como condição que paralisa todo o produto. Essa mudança aumenta a responsabilidade de implementação da Zoen e tem provas próprias.

**A segurança se estende a cada derivação.** Quem pode ver um resultado depende também das fontes que o sustentam. A busca, os gráficos, os SDKs, as skills e os agentes não são atalhos para contornar esse limite.

**Os três públicos não são três sistemas.** Compartilham o núcleo, mas usam diferentes pacotes, políticas, experiências e perfis operacionais. Uma única máquina não é apresentada como infraestrutura adequada a uma Fortune 500.

## Como executar

O primeiro ciclo de produto, de S0 a S4, não é instalar toda a infraestrutura. É reconciliar uma conta ou encomenda a partir de fontes divergentes, explicar a conclusão, aceitar uma correção com escopo e acompanhar uma mudança relevante. S0 começa pela menor fatia dessa experiência: duas fontes e uma interpretação honesta pelo caminho semântico. A primeira integração e a primeira alteração em runtime entram cedo; a arquitetura não adia indefinidamente a principal promessa.

A sequência posterior adiciona colaboração, ações externas, extensões isoladas, dados densos e live, aplicações, operação institucional, federação e execução financeira especializada. Cada etapa tem contratos, adversidades e critérios de saída.

A documentação principal permanece em inglês, como o ZIP de origem, para manter continuidade com os nomes e contratos técnicos. Este resumo e o handoff de produto não substituem a constituição técnica.

**Limite da entrega:** arquitetura especificada, exemplos de contrato e verificações locais; não implementação integral ou prova de capacidade institucional. Versões verificadas e versões herdadas ainda não verificadas estão distinguidas. Instalação, testes reais de recuperação, licenças de dados, contratos de canal e validações operacionais continuam sendo gates de execução.
