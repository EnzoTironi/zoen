# Three audiences, one semantic system

## Decision

Audience differences belong primarily to packs, policy, language, progressive disclosure and deployment profile. They do not justify three conflicting definitions of evidence, identity or authorization. They also do not imply that every audience shares one database or identical onboarding.

## Consumer and family

The entry is a message, voice note, document or question. The first useful World can contain one bill and an incomplete payment history. Eve speaks in everyday language and offers “não sei”, “não lembro” and “deixar para depois” as legitimate answers. A follow-up question explains why the distinction matters.

**Canonical case:** a grandmother forwards a bill and a receipt. The system identifies issuer, payer, amount, reference period and payment evidence. Matching is provisional when the reference differs. “É a conta de agosto” becomes an attributed clarification, not permission to mark every bill from the issuer as paid. A reminder is derived from the interpreted obligation, not from a hallucinated calendar entry.

**Authority:** private by default; a verified caregiver relationship is an explicit scoped delegation. Shared phone access is not assumed private. The person can review and revoke connected accounts, accepted facts, reminders and delegated actions. Optional voice transcription has its own retention and consent controls; a voice match never authorizes a payment by itself.

**UX:** readable text, large controls on web, source links described in plain language, text fallback for audio, no graph navigation requirement, no automatic group disclosure. Secure step-up is reserved for consequential operations, not every ordinary message.

**Not in the initial pack:** diagnosis, changing medication, credential sharing, account takeover recovery by conversation, or treating family ties as legal authority.

## Professional and small business

Confectioner, dentist, consultant and independent operator use different packs. Common operational objects include Counterparty, Commitment, Appointment, Order, Item, Invoice and Settlement, but they are composed through interfaces rather than forced into one giant universal Customer record.

**Confectioner case:** WhatsApp says 100 portions, spreadsheet says 80, and a later authorized confirmation says 100. The system determines whether these describe the same order revision. A bank receipt covers a deposit, not the full invoice. The owner can clarify one instance, then separately approve a rule that deposit status requires settlement evidence. Inventory, production slot and delivery promise remain linked, not conflated.

**Dental clinic case:** an appointment note, billing code and clinical note may conflict. Administrative staff can see schedule and billing without seeing clinical detail. The dentist is authorized to amend the clinical record under a purpose-specific policy; an assistant cannot infer or publish a diagnosis from a billing code. A clinical automation pack remains blocked until professional, legal, security and operational requirements are satisfied.

**UX:** chat for intake and everyday follow-up; shared schedule, cash and order views for density; a small exception inbox instead of an enterprise data-quality dashboard. Staff invitations expose responsibilities in ordinary language.

**Deployment:** pooled authority with strong tenant boundaries, optionally dedicated database/cell for confidentiality or contractual requirements. Billing includes integration and notification budgets that cannot silently stop critical monitors.

## Medium and Fortune 500 organizations

The organization begins with a bounded business outcome and a source/ownership inventory. An enterprise administrator can import directory identities and source ACLs, but those do not automatically grant every employee a World role. IT, data stewards, business owners and compliance teams have explicit and separate responsibilities.

**Canonical case:** CRM bookings, ERP invoices and bank settlements produce different numbers for “sales.” The first task is to define comparable metrics, time periods, consolidation scope, currency basis and accounting adjustments. Disagreement remaining after semantic alignment becomes a ResolutionCase. A local steward's decision applies only to the owned scope and time interval. A group policy change runs impact analysis before activation.

**Capabilities:** SSO/SCIM, object/field/evidence permissions, segregated environments, source/field lineage, incremental processing, schema-drift handling, approvals, sovereign retention and compute routing, customer-controlled encryption profiles, operational evidence, dedicated cells and cross-World agreements.

**Scale:** a multinational may use Worlds per legal entity, region or information compartment. Federation can present a consolidated view while preserving component cuts, licenses and missing regions. There is no claim of one worldwide serializable transaction or unrestricted cross-border replication.

**Delivery:** a departmental proof does not certify group-wide readiness. Production gates include restore drills, revocation tests, throughput measurements on representative data, incident processes, and named commercial/data owners.

## Shared acceptance law

For all three audiences, the system must answer: What is known? According to which definition? With which evidence and time basis? What remains ambiguous? Who may decide? What did we authorize? What actually happened? What are we still watching? Who can stop it?

The presentation changes. The answers' integrity does not.
