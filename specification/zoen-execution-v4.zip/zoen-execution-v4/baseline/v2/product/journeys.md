# Canonical product journeys

These are executable acceptance specifications to implement, not claims of shipped behavior. Tests must use the three audiences without creating three incompatible kernels. Local reference tests in this ZIP cover only selected laws.

## J01 — A grandmother brings one bill

**First proving slice:** S0–S1.

**Situation:** A person sends a bill and asks whether it is already paid. Two retained records disagree.

**Acceptance:** Show amount/currency/period/source and the unresolved state; ask one scoped question or admit an honest unknown. A reply creates an attributed claim, not a fabricated bank settlement.

**Failure cases:** Wrong reply; shared phone; missing source; oversized attachment.

## J02 — A confectioner reconciles an order

**First proving slice:** S1–S2.

**Situation:** An order sheet, WhatsApp instruction and supplier invoice disagree about quantity or delivery date.

**Acceptance:** Compare the same order/units/time; preserve variants; a correction updates only that instance unless a separate rule change is approved.

**Failure cases:** Copied sources double-counted; kilograms vs grams; stale source; duplicate webhook.

## J03 — A dentist separates operations from clinical data

**First proving slice:** S3.

**Situation:** Reception needs to reschedule appointments without reading restricted clinical notes.

**Acceptance:** Authorized availability and operational details are returned; hidden notes and their existence do not leak through explanations or counts.

**Failure cases:** Revocation mid-answer; group conversation; ambiguous patient identity.

## J04 — An enterprise asks why revenue differs

**First proving slice:** S2–S7.

**Situation:** CRM bookings, ERP invoices and bank receipts produce different totals.

**Acceptance:** Define metrics and time basis before reconciliation; explain legitimate differences; resolve only comparable claims. Publish complete/partial coverage honestly.

**Failure cases:** Currency conversion; backdated correction; missing subsidiary; changing query predicates.

## J05 — A user teaches a reusable rule

**First proving slice:** S2.

**Situation:** The user says ERP determines issued invoices but a signed amendment controls delivery date.

**Acceptance:** Generate a scoped DefinitionChange with semantic diff, examples and blast radius; evaluate and activate through current policy without application redeploy.

**Failure cases:** Agent tries to approve own escalation; rule changes an open Case; concurrent user edit.

## J06 — A custom connector is installed

**First proving slice:** S6.

**Situation:** An authorized builder adds an integration not covered by the HTTP/OAuth grammar.

**Acceptance:** Signed isolated artifact receives a narrow source lease; data is quarantined/admitted; no authority DB credential or unrestricted network.

**Failure cases:** Metadata SSRF; dependency malware; infinite loop; excessive source reads; revoked lease.

## J07 — A meaningful change earns attention

**First proving slice:** S3–S4.

**Situation:** A supplier delay threatens an order that the person asked Zoen to watch.

**Acceptance:** One semantic Notice; Eve merges/defer/suppresses with fresh disclosure, channel consent and budget. Ordinary noise remains silent.

**Failure cases:** Duplicate change; permission lost while deferred; outside channel messaging window.

## J08 — An action completes ambiguously

**First proving slice:** S4.

**Situation:** The user approves sending a supplier purchase; provider times out after receiving it.

**Acceptance:** One local receipt, stable effect ID, explicit Unknown; reconcile before unsafe retry. Report provider outcome separately from business success.

**Failure cases:** Lost response; duplicate callback; partial acceptance; cancellation race.

## J09 — Conversation becomes a visual investigation

**First proving slice:** S5–S8.

**Situation:** The user opens the evidence behind a financial or operational answer.

**Acceptance:** Same authorized subject/basis or clearly labeled newer Frame; accessible chart/table/timeline, no source/license bypass; scenario remains hypothetical.

**Failure cases:** Stolen Focus; expired grant; unavailable historical content; unsupported app client.

## J10 — An enterprise changes meaning while operating

**First proving slice:** S7–S9.

**Situation:** A new customer identity rule and dataset generation must become active.

**Acceptance:** Immutable proof, prepared generation and exact catch-up; atomic head switch or explicit bounded write fence. No mixed old/new meaning.

**Failure cases:** GC deletes staged snapshot; duplicate CDC; late source event; head/cut race.

## J11 — A World moves and a federated decision is partial

**First proving slice:** S10.

**Situation:** A regional cell moves while another company participates in a joint process.

**Acceptance:** Single fenced authority epoch; independent federated cuts and local approvals; honest partial global outcome.

**Failure cases:** Network partition; stale directory; escaped external request; offline lease expiry.

## J12 — History is corrected and erased lawfully

**First proving slice:** S3–S9.

**Situation:** A wrong human correction is reversed and a data subject later requires deletion.

**Acceptance:** Retained factual history remains explainable until lawfully removed; deletion cascades to projections, snapshots and restore workflows without reviving access.

**Failure cases:** Old backup restored; hidden copied embedding; conflicting legal hold; third-party retention.

## J13 — A finance order is filled but not settled

**First proving slice:** S11.

**Situation:** A broker acknowledges and partially fills an order, then corrects an execution.

**Acceptance:** Separate approval/order/fill/bust/settlement states, exact quantities, exposure and source evidence. No invented finality.

**Failure cases:** Expired quote entitlement; cancellation/fill race; rejected allocation; settlement failure.

## J14 — A mandate stops instead of running forever

**First proving slice:** S4.

**Situation:** The user delegates monitoring a deadline within a budget.

**Acceptance:** Explicit observable goal, terminal conditions, deadline, sub-budgets and stop/escalation. Completed steps are not automatically goal success.

**Failure cases:** Unknown outcome; repeated failed plan; child-agent budget fanout; revoked action rights.
