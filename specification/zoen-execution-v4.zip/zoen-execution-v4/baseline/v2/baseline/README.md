# Archived original design — non-normative

This directory preserves the supplied ZIP's Markdown **byte-for-byte** under `original/` for traceability. It is not a second active constitution. Original machine-specific paths, old version claims and obsolete links have deliberately not been rewritten; the active v2 documents use portable relative paths and a new source ledger.

Rendered images, Mac resource metadata and generated caches from the original ZIP are not duplicated. The original archive hash and every preserved Markdown hash are in [input-manifest.json](input-manifest.json). The original ZIP was read, not modified.

Use [supersession](../technical-blueprint/supersession.md), not an old ADR alone, for implementation decisions. The v2 verifier checks archived bytes against the input manifest but excludes historical Markdown links from active-link validation.
