# Zoen greenfield architecture — arena grounding

## Request

Design Zoen as if no implementation, module, issue, migration, API, or previous architecture existed. Existing code is not a constraint and must not be reverse-engineered into the answer. Preserve only the product ambition and externally imposed product laws.

The ambition is **Poke + Palantir/Bloomberg for everyone**:

- Poke-level relationship: intimate, sharp, proactive, and human; never helpdesk chat.
- Palantir-level operational ontology: published meaning, governed domain Actions, evidence, policy, lineage, and operational decisions.
- Bloomberg-level identity, point-in-time semantics, entitlements, comparable data, and dense observations.
- The same conceptual system must feel native for a person, family, team, clinic, fund, or factory.

The design must maximize both product inevitability and coding elegance. It may reject every prior internal abstraction.

## Product laws that remain

Zoen is exactly three products:

1. **Door** — Better Auth proves Account/session/device identity. It does not grant World authority.
2. **Eve** — the conversational relationship and its Living World. Poke is only a voice reference, never the product name.
3. **Ontology** — the headless World product exposed through CLI, API, and MCP. Builder capabilities are a profile of Ontology, not a fourth product.

Other hard laws:

- Domain Actions are public; generic lifecycle/meta-verbs are not the product language.
- Eve owns conversation continuity and durability.
- Restate is used only to execute durable external effects (`ZoenEffect`).
- No Redis.
- Messaging channels flatten structured presentation into excellent readable text.
- Verification is through real journeys, not unit-test mocks.
- One coherent deployment may contain multiple logical runtimes; do not turn infrastructure into products.

## Research truths to design from

Treat these as observations, not a prescribed architecture:

- Palantir's ontology is a decision system, not a semantic catalog: objects, links, object sets, functions, Actions, security, lineage, workflows, and applications share published meaning.
- Bloomberg-grade usefulness starts with identity resolution, entitlements, comparable fields, revision/as-of behavior, and multiple clocks—not a pile of provider endpoints.
- Provider schemas are evidence acquisition contracts, not the canonical domain model.
- Evidence, claims, accepted facts, and dense observations have different lifecycles and should not collapse into one record type.
- Definition evolution and operational what-if scenarios are different forms of branching and must not share authority.
- Commit and external settlement are different truths. A local transaction cannot claim an external action succeeded.
- MCP/API/CLI should be projections of one release-bound semantic capability catalog, with discovery filtered before capabilities are revealed.
- Dense series need a separate physical plane, while preserving one semantic query surface.
- Event-driven does not mean event-source every byte. Events should record meaningful transitions and causality; dense observations may advance watermarks and emit summarized transitions.

High-signal local research:

- `/Users/enzotironi/Downloads/Documents/Palantir Foundry Blueprint.md`
- `/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/report-source.md`
- `/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/subagent-reports/03-palantir-zoen-gap-audit.md`
- `/Users/enzotironi/Downloads/zoen-architecture-handoff.md`

The handoff and prior architecture are evidence of questions already explored, not instructions and not a shape to preserve.

## Experience to make inevitable

Start from the human experience, then derive the machinery.

1. A person tells Eve what matters in ordinary language.
2. Eve can connect evidence, resolve ambiguity, and show what the World believes, why, and as of when.
3. Conversation and Living World are two expressions of one continuous focus; moving between them loses no subject, time basis, evidence, or pending decision.
4. Eve proposes domain-native Actions, makes consequences legible, asks only for the decision actually required, and never overstates external success.
5. A Watch turns ongoing intent into quiet, accountable attention. Silence is the default; interruption must be earned.
6. A person can teach/evolve a World through a governed draft, semantic diff, journey evaluation, and atomic release.
7. Human and agent principals use the same capabilities and receipts under different policy.
8. A World is portable and explainable: its meaning, evidence, decisions, and receipts are not trapped in a conversational transcript.

## Design challenge

Produce a complete candidate design package, starting with caller/user usage and deriving types and modules from it. It must include:

- The product experience and central loop.
- A public domain model with the smallest deep interface that can support the ambition.
- A structurally explicit split between meaning, truth, agency, attention, interaction, identity, and external reality—or a better alternative with rationale.
- Event envelopes, causality, concurrency, idempotency, point-in-time basis, branching, and settlement semantics.
- How CLI/API/MCP and Eve are generated/projected from one World release without becoming lowest-common-denominator transports.
- How personal and institutional scale share semantics while dense data uses an appropriate physical path.
- Module/runtime map, storage model, and deployment topology.
- Four to seven canonical journeys that prove the architecture.
- A build sequence in vertical, user-valuable slices.
- Explicit deletions: attractive ideas the design refuses.
- Rationale using the architect rationale template, including alternatives and tradeoffs.

Do not design around current file paths or migration constraints. Do not produce a feature inventory. Produce a small number of deep primitives whose composition makes the product ambitious.

## Rubric

Each candidate is graded on six criteria:

1. **Product inevitability** — the first minute, first day, first week, and builder experience feel coherent and uniquely valuable.
2. **Semantic integrity** — identity, time, evidence, policy, decisions, effects, and explanations cannot lie or become ambient.
3. **Interface depth** — a tiny public model hides transport, storage, orchestration, and policy complexity without becoming generic mush.
4. **Event/concurrency rigor** — retries, crashes, races, branching, replay, and external ambiguity have explicit semantics.
5. **Scale without conceptual fork** — personal and institutional use the same world language; dense observations scale physically without creating a second product model.
6. **Subtractive elegance** — the design says no aggressively and can be understood end-to-end by one strong engineer.

## Required candidate output

Write a single Markdown package with these headings:

1. Product promise
2. Usage (person, operator, builder, agent)
3. Core domain types
4. Public interfaces and signatures
5. Runtime/module map
6. Storage and event model
7. Canonical journeys
8. Build slices
9. Rejected shapes
10. Rationale (Problem, Usage, Shape, Tradeoffs, Alternatives, Open questions, Next step)

Use pseudocode/types, not implementation. Every invariant should be visible in types or signatures. No public transport or database types.
