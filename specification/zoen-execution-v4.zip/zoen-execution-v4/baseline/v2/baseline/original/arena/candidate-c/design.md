# Candidate C — Zoen as a world compiler and adjudication kernel

## 1. Product promise

Zoen is the calm operating system for a life or an institution. A person says what matters once. Zoen keeps the relevant World current, distinguishes evidence from belief, stays silent until change is material, asks for the smallest decision actually required, and leaves a receipt saying exactly what became true and what remains uncertain.

Four product objects make that promise tangible:

- A **Frame** is what this World is allowed to show this principal, under this meaning, purpose, effective time, and knowledge cut.
- A **Case** is one domain-native decision with its basis, consequences, uncertainty, and choices.
- A **Receipt** is the durable truth of a decision, separate from later external settlement.
- A **Watch** is continuing intent that may create a worthy Notice or prepare a Case, but cannot manufacture urgency or authority.

Exactly three products remain:

| Product | Promise and ownership | Forbidden ownership |
|---|---|---|
| **Door** | Better Auth proves account/session/device identity. | World membership, business authority, agent delegation. |
| **Eve** | Relationship, conversation continuity, focus, attention delivery, Living World. | Canonical truth, provider authority, mutations, external-success claims. |
| **Ontology** | Releases, identity, evidence, belief, Frames, domain Actions, Watches, Cases, Receipts, effects; CLI/API/MCP. | Chat personality and channel state. |

One deployment may host all three. They differ because they make different promises, not because they require different clusters.

The central loop is:

```text
Say what matters
  → Eve preserves intent and opens a Lens
  → Ontology produces an honest Frame
  → Watch observes without demanding attention
  → material Notice explains “why now”
  → domain Case asks for one choice
  → decision creates a semantic Receipt
  → external settlement evolves independently
  → outcome improves the next Frame and future attention
```

**First minute:** “Quero seis meses de caixa; só me chama se estiver realmente em risco.” Eve connects sources, shows what it knows, and asks only about an ambiguous account. It does not hide uncertainty to look helpful.

**First day:** Living World opens the exact conversational focus—subjects, time basis, evidence, excluded rivals, Watch, and pending Case—rather than a generic home/dashboard.

**First week:** silence is success. When a confirmed payment reduces runway materially, Eve interrupts once, explains the delta and freshness, and offers the relevant domain Action. After a decision it may correctly say, “Enviado ao banco; resultado ainda desconhecido.”

**Builder:** define nouns, fields, links, belief rules, domain Actions, Watches, policies, sources, and presentation once. A compiler produces semantic diff, real-journey proof, and native CLI/API/MCP/Eve/Living World projections, then atomically publishes one release.

The product vocabulary is domain-native: `TransferFunds`, `RebalancePortfolio`, `RescheduleVisit`, `ReleaseBatch`. Generic lifecycle verbs remain protocol mechanics, not the ontology users learn.

## 2. Usage (person, operator, builder, agent)

### Person

```text
Enzo: Quero manter seis meses de caixa. Só me chama se isso realmente estiver em risco.

Eve: Hoje confirmo 7,4 meses com duas contas. “Reserva” apareceu em dois bancos;
preciso saber qual entra: [Itaú · 1842] [BTG · 9031].

Enzo: A do Itaú.

Eve: Feito. Vou avisar quando o caixa confirmado cair abaixo de seis meses,
ou quando dados incompletos puderem mudar essa conclusão. Fora disso, fico quieta.
```

Opening Living World reuses this `FocusHandle`. Changing to an historical as-of view visually changes the shared focus, so Eve can later say, “Você está olhando a posição conhecida em 31 de agosto.”

### Operator

The release-generated client exposes domain capabilities; transport types remain private.

```ts
const session = await zoen.enter({
  world: WorldId("family.tironi"), identity: betterAuthProof,
  purpose: Purpose("personal-treasury"),
});

const cash = await session.treasury.cashRunway.frame({
  household: Household.ref("tironi"), basis: Basis.live(),
});

const transfer = await session.treasury.transferFunds.prepare(
  { from: Account.ref("reserve-1842"), to: Account.ref("checking-7710"), amount: BRL("20000") },
  { from: cash.ref, idempotency: IdempotencyKey.random() },
);

const result = await transfer.decide(transfer.choices.moveNow, IdempotencyKey.random());
if (result.kind === "committed") {
  show(result.receipt.semanticOutcome);
  follow(result.receipt.effects); // no aggregate “success” boolean
}
```

Equivalent generated CLI:

```text
zoen treasury cash-runway --household tironi --as-of now
zoen treasury transfer-funds --from reserve-1842 --to checking-7710 --brl 20000 --prepare
zoen case decide case_01... --choice move-now
zoen receipt show receipt_01... --follow-effects
```

### Builder

```ts
const treasury = defineWorld("personal-treasury", w => {
  const Account = w.object("Account", {
    fields: { institution: w.text(), lastFour: w.text().sensitive(),
      balance: w.series(w.money(), { clock: "observed", unitFrom: "currency" }) },
  });
  const Household = w.object("Household", { links: { accounts: w.many(Account) } });
  const CashRunway = w.function("CashRunway", {
    input: { household: Household.ref(), at: w.basis() },
    output: w.struct({ months: w.decimal(), projectedExpenses: w.money() }),
    reads: [Household, Account.fields.balance], compute: component("sha256:cash-runway-v1"),
  });
  const TransferFunds = w.action("TransferFunds", {
    input: { from: Account.ref(), to: Account.ref(), amount: w.money() },
    reads: [Account.fields.balance],
    choices: { moveNow: "Transferir agora", cancel: "Agora não" },
    records: [w.object("TransferInstruction")],
    effect: w.external("BankTransfer", { driver: "banking.v1" }), risk: "moves-money",
  });
  w.watch("CashRunwayRisk", {
    observes: CashRunway, materialWhen: expr`months < minimum || confidenceChangedMaterially`,
    evidenceGate: { freshness: "PT2H", confidence: 0.95 },
    may: [w.notice(), w.prepare(TransferFunds)], mayNever: [w.decide(), w.effect()],
  });
  w.source("OpenBankingBalances", {
    provides: Account.fields.balance, identity: resolver("bank-account-v1"),
    acquire: adapter("sha256:open-banking-v3"), map: mapper("sha256:balance-map-v2"),
    rights: rights("personal-bank-data-v1"),
  });
  w.policy(policyBundle("sha256:treasury-policy-v4"));
  w.presentation(presentation("sha256:treasury-language-v2"));
});

const draft = await studio.begin({ world: "family.tironi", from: Release.active() });
draft.replace(treasury);
const candidate = await studio.compile(draft);
const proof = await studio.prove(candidate, realJourneys);
await studio.publish(proof.requirePassing(), ReleaseDecision.approvedBy(builderGrant), key);
```

### Agent

MCP initially reveals only a compact, permission-filtered capability index. An agent searches for “reduce cash risk without selling investments,” activates `treasury.cash_runway`, `treasury.transfer_funds`, and `treasury.compare_funding_options`, then receives typed tools. `treasury.transfer_funds` returns a Case. The agent decides it only with explicit, effective-dated delegation for that Action, accounts, amount, purpose, and interval; otherwise Eve presents the same Case to the person. Human and agent receive the same Receipt under different policy.

## 3. Core domain types

The public model centers `WorldRelease`, `Lens`, `Frame`, `Case`, `Receipt`, and `Watch`. Storage, wire, framework, provider-response, and model-message types never cross it.

```ts
type WorldId = Opaque<"WorldId">; type ReleaseId = Digest<WorldRelease>;
type SubjectId<T> = Opaque<"SubjectId", T>; type FrameId<T> = Digest<Frame<T>>;
type CaseId<A> = Opaque<"CaseId", A>; type ReceiptId = Opaque<"ReceiptId">;
type EventId = Opaque<"EventId">; type ArtifactDigest = Digest<Artifact>;
type IdempotencyKey = Opaque<"IdempotencyKey">;

// Better Auth issues this; it proves identity only.
type IdentityProof = Opaque<"BetterAuthIdentityProof">;
type Principal = Person | DelegatedAgent | SourceWorkload;
type WorldGrant = Opaque<"WorldGrant"> & {
  world: WorldId; principal: Principal; membership: MembershipRevision;
  purposes: NonEmpty<Purpose>; delegation?: DelegationRef;
  session: SessionBinding; expiresAt: Instant;
};

type WorldRelease = Readonly<{
  id: ReleaseId; parent: ReleaseId | null;
  semanticGraph: SemanticGraph; capabilities: CapabilityCatalog;
  beliefPolicies: BeliefPolicyBundle; accessPolicies: AccessPolicyBundle;
  sourceContracts: SourceContractBundle; components: ComponentBundle;
  presentation: PresentationBundle; acceptanceSuite: JourneySuiteDigest;
}>;

type CapabilitySpec<K, I, O> = Readonly<{
  id: CapabilityId<K, I, O>; domainName: DomainName; kind: K;
  input: DomainShape<I>; output: DomainShape<O>; basis: BasisRequirement;
  authorization: PolicyRef; risk: RiskClass; presentation: PresentationRef;
  implementation: ComponentRef;
}>;

type WorldCut = { transition: bigint; observationManifest: ManifestId };
type FrameBasis = {
  release: ReleaseId; effectiveAt: Instant; knownAt: WorldCut;
  belief: BeliefPolicyRef; purpose: Purpose;
};
type ReleaseBinding = FixedRelease | CompatibleReleaseTrack;
type Lens<T> = {
  selection: ObjectPlan<T> | FunctionCall<T> | SituationPlan<T>;
  basis: FrameBasis | LiveBasis<ReleaseBinding>; focus: FocusPath;
};
type Frame<T, M extends "real" | "simulated" = "real"> = Readonly<{
  id: FrameId<T>; mode: M; lens: Lens<T>; basis: FrameBasis;
  access: AccessStamp; value: AuthorizedView<T>; freshness: Freshness;
  gaps: readonly DisclosableGap[]; availableActions: readonly DomainActionRef[];
  why: ExplanationRef; readSet: ReadSetStamp;
}>;
```

A release is a Merkle-closed executable contract: changing meaning, source mapping, belief, policy, code, Action, Watch, or human language changes its digest. A Frame is the atomic read product, reusable by every surface and as the exact concurrency basis of a Case.

Identity is explicit, typed, scoped, and effective-dated:

```ts
type ObjectRef<T> = { world: WorldId; type: ObjectTypeId<T>; subject: SubjectId<T> };
type TypeMembership<T> = {
  subject: SubjectId<T>; type: ObjectTypeId<T>; valid: Interval;
  evidence: NonEmpty<EvidenceRef>; acceptedBy: ResolutionReceiptRef;
};
type IdentifierAssignment<T> = {
  scheme: IdentifierScheme; value: string; identityLevel: IdentityLevel;
  scope: IdentityScope; subject: SubjectId<T>; valid: Interval;
  authority: SourceRef; evidence: NonEmpty<EvidenceRef>;
  status: "candidate" | "resolved" | "superseded" | "conflicted";
};
type ResolutionResult<T> = None | Unique<ObjectRef<T>> |
  Ambiguous<NonEmpty<ResolutionCandidate<T>>, CaseRef<ResolveIdentity>>;
```

Internal IDs are never tickers, names, emails, CIKs, FIGIs, or provider slugs. `sameAs` is not a primitive; resolution may return multiple candidates and evidence.

Evidence and belief have distinct lifecycles:

```ts
type EvidenceTime =
  | { kind: "state"; valid: Interval }
  | { kind: "measurement"; economicPeriod: Interval; observedAt: Instant }
  | { kind: "event"; announcedAt?: Instant; effectiveAt: Instant }
  | { kind: "filing"; economicPeriod: Interval; publishedAt: Instant; accession: string };
type SparseAssertion<V> = {
  id: AssertionId<V>; subject: UntypedObjectRef; field: FieldRevision<V>; value: V;
  time: EvidenceTime; recordedAt: Instant; source: AttestedSourceRef;
  artifact: ArtifactDigest; mapping: MappingDigest; rights: UsageRightsRef; cause: Cause;
};
type SeriesKey<V> = {
  subject: UntypedObjectRef; field: FieldRevision<V>; dimensions: DimensionTuple;
  unit: Unit; calendar: CalendarRef; adjustment: AdjustmentPolicyRef;
};
type ObservationManifest<V> = {
  id: ManifestId; series: SeriesKey<V>; segments: NonEmpty<ObservationSegmentRef<V>>;
  coverage: Interval; watermark: SourceWatermark; schema: ObservationSchemaDigest;
  mapping: MappingDigest; rights: UsageRightsRef; lineage: NonEmpty<EvidenceRef>;
};
type EvidenceRef = AssertionRef | ObservationSliceRef | ArtifactRef | DerivationRef;
type Belief<V> = {
  selected: V | Unknown; support: readonly EvidenceRef[];
  rivals: readonly DisclosableRival<V>[]; resolution: ResolutionReceiptRef;
  quality: QualityAssessment;
};
```

Sparse assertions and dense observations share identity, semantics, policy, and explanation, not their physical record unit. Belief selects for a released purpose/basis without deleting rivals. Provider-field equivalence is itself a governed assertion.

```ts
type PreparedCase<A> = Readonly<{
  id: CaseId<A>; action: DomainActionRef<A>; input: A; from: FrameRef;
  basis: FrameBasis; readSet: ReadSetStamp; preview: ConsequencePreview;
  choices: ChoiceSet<A>; requiredDecision: DecisionRequirement;
  authorization: PolicyDecisionRef; expiresAt: Instant; why: ExplanationRef;
}>;
type DecisionResult<A> =
  | { kind: "committed"; receipt: DecisionReceipt<A> }
  | { kind: "declined"; receipt: DeclineReceipt<A> }
  | { kind: "rebase-required"; stale: StaleCase<A>; current: FrameRef }
  | { kind: "not-found-or-not-disclosable" };
type DecisionReceipt<A> = {
  id: ReceiptId; case: CaseId<A>; action: DomainActionRef<A>; choice: ChoiceOf<A>;
  transition: WorldTransitionRef; semanticOutcome: DomainOutcome<A>;
  effects: EffectSetRef; actor: Principal; policy: PolicyDecisionRef;
  release: ReleaseId; cause: Cause; committedAt: Instant;
};
type EffectState<R, O> = Queued | Attempting | Accepted<R> | Rejected | Unknown | Reconciled<R, O>;
```

Preparing never mutates or calls outside. Deciding rechecks read set and policy, then atomically records semantic changes and deterministic effect intents. Restate executes only these intents. A local commit cannot claim an external outcome.

```ts
type WatchSpec<T> = {
  name: HumanName; lens: Lens<T>; release: ReleaseBinding; advance: BasisAdvancePolicy;
  materialWhen: DeltaPredicate<T>; evidenceGate: EvidenceGate;
  deduplicateBy: NoticeIdentityRule; may: readonly (EmitNotice | PrepareDomainCase)[];
  owner: Principal; purpose: Purpose;
};
type Notice<T> = {
  id: NoticeId; watch: WatchId; before: FrameRef<T>; after: FrameRef<T>;
  materialDelta: MaterialDelta<T>; whyNow: ExplanationRef;
  preparedCases: readonly CaseRef<unknown>[];
};
```

Ontology owns Watch materiality and Notice truth. Eve owns delivery, defer, merge, quiet hours, channel, and interruption budget. A Watch may notice or prepare; it cannot decide or dispatch.

Definition evolution and operational imagination are unrepresentably different:

```ts
type DefinitionDraft = { id: DraftId; base: ReleaseId; changes: SemanticPatch };
type ReleaseCandidate = { draft: DraftId; compiled: WorldRelease; semanticDiff: SemanticDiff;
  migration: MigrationPlan; surfaceDiff: SurfaceDiff };
type ProvenCandidate = ReleaseCandidate & { proof: PassingJourneyAttestation };
type Scenario<T> = { id: ScenarioId; base: FrameRef<T>; hypothetical: HypotheticalTransition[] };
type SimulatedFrame<T> = Frame<T, "simulated"> & { scenario: ScenarioId; effectsForbidden: true };
```

No signature accepts both Draft and Scenario. A Scenario can only prepare a fresh live Case after re-evaluation; it cannot publish meaning or emit effects.

```ts
type Cause = Origin<InvocationId> | Reaction<EventId> | Import<ArtifactDigest, AttestedSourceRef>;
type WorldEvent<K, P> = {
  id: EventId; world: WorldId; transition: bigint; ordinal: number;
  kind: K; payload: P; payloadDigest: Digest<P>; actor: Principal;
  release: ReleaseId; recordedAt: Instant; cause: Cause;
  correlation: CorrelationId; visibility: ClassificationSet;
};
type WorldEventKind = "EvidenceAdmitted" | "IdentityResolved" | "BeliefChanged" |
  "DecisionCommitted" | "EffectStateChanged" | "ObservationSegmentAccepted" |
  "ObservationWatermarkAdvanced" | "WatchBecameMaterial" | "ReleasePublished";
```

Dense points never become individual World events. Conversation events use Eve’s separate stream and refer to Frames/Cases/Receipts rather than pretending a sentence changed reality.

## 4. Public interfaces and signatures

```ts
interface Door {
  prove(session: BetterAuthSession): Promise<IdentityProof>;
  end(proof: IdentityProof): Promise<void>;
}
interface Ontology {
  enter(input: { world: WorldId; identity: IdentityProof; purpose: Purpose;
    delegation?: DelegationPresentation }): Promise<WorldSession>;
}
interface WorldSession {
  catalog(intent?: CapabilityIntent): Promise<ScopedCapabilityCatalog>;
  frame<T>(lens: Lens<T>): Promise<Frame<T>>;
  prepare<A>(action: DomainAction<A>, from: FrameRef,
    idempotency: IdempotencyKey): Promise<PreparedCase<A>>;
  decide<A>(caseId: CaseId<A>, choice: ChoiceOf<A>,
    idempotency: IdempotencyKey): Promise<DecisionResult<A>>;
  watch<T>(spec: WatchSpec<T>, idempotency: IdempotencyKey): Promise<WatchReceipt>;
  explain(target: ExplainableRef, depth?: ExplanationDepth): Promise<Explanation>;
}
interface WorldStudio {
  begin(input: { world: WorldId; from: ReleaseId }): Promise<DraftHandle>;
  rebase(draft: DraftId, onto: ReleaseId): Promise<RebasedDraft | SemanticConflicts>;
  compile(draft: DraftId): Promise<ReleaseCandidate>;
  prove(candidate: ReleaseCandidate, suite: JourneySuite): Promise<JourneyProof>;
  publish(candidate: ProvenCandidate, decision: ReleaseDecision,
    idempotency: IdempotencyKey): Promise<ReleaseReceipt>;
}
```

The six-operation `WorldSession` is deliberately deep: it hides identity resolution, authorization before discovery, belief selection, sparse/dense planning, concurrency, transactions, event publication, and effect formation. Callers never coordinate load/authorize/reduce/validate/write/enqueue. Generated domain methods carry a stable `CapabilityId`, locally validate domain input, and invoke this kernel; they do not reimplement business logic.

```ts
interface SourceAdapter<Q, Raw, E extends EvidencePackage> {
  readonly contract: SourceContract<Q, E>;
  acquire(request: AttestedSourceRequest<Q>, checkpoint: SourceCheckpoint | null): Promise<Artifact<Raw>>;
  normalize(artifact: Artifact<Raw>, release: WorldRelease): Promise<E>;
}
interface EvidenceGateway {
  admit(workload: SourceWorkloadGrant, package: EvidencePackage,
    idempotency: SourceOperationKey): Promise<EvidenceAdmissionReceipt>;
}
interface EffectDriver<I, R, O> {
  attempt(intent: EffectIntent<I>, attempt: AttemptNumber): Promise<ProviderDisposition<R>>;
  reconcile(intent: EffectIntent<I>, last: EffectState<R, O>): Promise<ProviderDisposition<R, O>>;
}
```

An adapter owns a provider’s acquisition and normalization knowledge; normalization has no authority. Admission binds workload, Artifact, adapter, mapper, allowed semantic scope, rights, and release. Restate calls effect drivers with `EffectId = hash(decisionReceipt, ordinal)`; timeout becomes `unknown`, never inferred failure/success.

Eve’s event loop is:

```text
append user event
  → deterministically assemble Focus + relevant interaction history
  → exchange Door proof for a turn-bounded WorldGrant
  → ask the model for an untrusted plan over the scoped catalog
  → validate/invoke WorldSession capabilities
  → append Frame/Case/Receipt references
  → render natively for web, Living World, WhatsApp, or Telegram
```

The model cannot mint authority, IDs, releases, operation keys, evidence, or success. Messaging flattens structured chrome into excellent text.

One rich semantic capability IR generates native surfaces rather than a lowest-common-denominator protocol: CLI gets composable commands; API gets strong contracts/subscriptions/sealed cursors; MCP gets permission-filtered progressive activation; Eve gets elicitation and explanation language; Living World gets object/set/situation/decision/scenario/teach presentation. No surface can bypass Frame, Case, Receipt, policy, or basis.

## 5. Runtime/module map

```text
Person / operator / agent / source
  → Door: Better Auth → IdentityProof
  → Eve: interaction, Focus, harness, attention, channels, Living World
  → Ontology: proof+membership+purpose → WorldGrant
      release-compiler → executable WorldRelease
      world-kernel → Frame / Case / Receipt
      evidence-gateway → identity + sparse/observation admission
      frame-engine → objects/sets/series + belief + explanation
      case-engine → preview + OCC + semantic commit
      attention-engine → Watch evaluation + Notice
      effect-runtime → Restate settlement
      surface-compilers → CLI / API / MCP
```

Modules are grouped by owned knowledge, not temporal stages. `world-kernel` is not a pass-through: it owns authorization order, release binding, idempotency, read-set validation, transaction boundaries, Receipt formation, causality, and effect-intent creation. Normal trace depth is surface → kernel → owning module/store.

Living World has six modes over one `FocusHandle`: Object, Set, Situation, Decision, Scenario, and Teach. Navigation changes focus, not authority; every opaque deep link is re-authorized and reconstructed.

Logical stores/modules:

```text
domain/     IO-free IDs, time, release, Frame, Case, Watch, causality
ontology/   compiler, kernel, evidence, frame, case, attention, effect, surfaces
eve/        interaction log, focus, context assembler, harness, attention gate, renderers
door/       Better Auth and IdentityProof
adapters/   PostgreSQL, object store, columnar query, Restate, providers
journeys/   deployed user journeys only; no mocks/fakes/toy kernel
```

Personal and institutional Worlds use identical semantics. Sparse facts/decisions remain transactional; dense observations use immutable segments; ObjectPlans compile to authorized relational and columnar operators; entitlements push down before enumeration/scan; search, embeddings, caches, and materialized views are disposable projections.

Deploy initially as one Fly app with Door+Eve, Ontology API/MCP, Ontology reactors, and a Restate-connected effect worker; durable dependencies are PostgreSQL, S3-compatible content-addressed storage, and Restate. No Redis, Kafka, graph DB, vector DB, or conversation workflow engine. PostgreSQL outbox is the internal event boundary.

Use Rust for the IO-free domain, compiler, Ontology kernel/query/effects; TypeScript for Better Auth, Eve/model/channels, and Living World; generated digest-pinned bindings make the boundary explicit. Keep one monorepo so releases, generated surfaces, and journeys change atomically.

## 6. Storage and event model

Four durable planes have different lifecycles:

| Plane | Durable units |
|---|---|
| Meaning | Releases, drafts, semantic diffs, journey attestations, active-track receipts. |
| Authority | Membership, assertions, identity/belief resolutions, decisions, Watches, Notices, effects, events. |
| Observation | Raw Artifacts, immutable Arrow/Parquet segments, manifest DAGs, correction overlays. |
| Interaction | Eve events, focus events, delivery receipts, provenance-linked relationship projections. |

For an accepted semantic transition, one PostgreSQL transaction validates `IdempotencyKey → IntentDigest`, rechecks policy and the exact Case read set, writes semantic changes + Receipt + deterministic effect intents, advances one World sequence, and writes ordered World events + outbox. All records share `(world, transition)`. Cross-World atomicity is deliberately unsupported; independent authorities get linked Receipts, not distributed-transaction fiction.

Dense admission is `source request → raw CAS Artifact → deterministic normalization → identity/validation → immutable segment → authority accepts manifest delta → SegmentAccepted/WatermarkAdvanced`. A crash before acceptance leaves quarantined unreachable objects; after acceptance, replay finds the same digest. Corrections publish replacement/tombstone overlays, never edits. `WorldCut.observationManifest` closes the dense evidence visible at a semantic cut.

Events are durable transition/audit/subscription records, not the only reconstruction mechanism. The DB transaction is exactly-once for state/Receipt/event/outbox; reactors are at-least-once and checkpoint `(world, transition, ordinal)`. Reactor output keys derive from causal event + reactor version.

Idempotency rules:

- Same scope/key/intent digest returns the original Receipt; same key/different digest conflicts.
- Source keys derive from provider, capability, normalized query, cursor/window, adapter digest, raw digest.
- Effect IDs derive from Decision Receipt + ordinal.
- Watch evaluation keys derive from Watch revision + input watermark/cut.

`PreparedCase.readSet` hashes exactly the fields, links, manifests, policy decisions, and belief receipts used by its preview. Irrelevant changes do not stale it; changed dependencies return a permission-safe `rebase-required`. Consequences are never silently recomputed under an already-given choice.

A reproducible answer is `Release × effectiveAt × WorldCut × BeliefPolicy × Principal × Purpose × policy/entitlement decision`. Evidence separately retains validity, economic period, observed time, event effective time, publication/accession, and server-recorded time. “Latest” is always a released policy, never raw storage order.

An Explanation is an authorized causal graph across Release, Artifact, Assertion, Observation slice, mapping, resolution, function, policy, Case, Receipt, and effect attempts. A protected gap is mentioned only if policy permits revealing its existence.

Definition drafts form a Merkle DAG with semantic three-way merge. Candidates run through real surfaces/stores in disposable Worlds. Publication atomically advances a release track. Scenarios remain overlays on a Frame: pure computation only, no acquisition, authority mutation, or effect; realization requires a fresh live Case.

Rights are enforced during capability discovery, candidate planning, field/series scan, derivation/cache, lineage/citation, render, export/redistribution, and retention. Revocation changes disclosure, not historical Receipt identity.

## 7. Canonical journeys

All journeys drive real Door, Eve, Living World, CLI/API/MCP, PostgreSQL, object storage, adapters, and Restate.

1. **Sentence → honest Frame.** “Acompanhe IBM, a ação dos EUA.” Multiple candidates are retained; venue context produces a governed resolution Case; Eve and CLI show the same release/basis/evidence. Proves identity cannot silently collapse and explanation reconstructs raw evidence.
2. **Watch earns interruption.** Repeated non-material/duplicate updates stay silent. One threshold-crossing creates one Notice; Eve defers during quiet hours, merges a related update, and delivers a prepared Case. Proves World materiality vs relationship delivery, evidence gates, and dedupe.
3. **Decision committed, bank unknown.** A balance change stales the first Case; a fresh Case commits one transfer instruction/Receipt/effect intent. Provider timeout becomes unknown; Restate later reconciles without duplicating transfer. Proves OCC, atomicity, idempotency, and commit/settlement separation.
4. **Conversation ↔ Living World continuity.** WhatsApp discussion opens desktop focus, changes to historical basis, creates a Scenario, and returns to chat without losing subject/basis or confusing simulation with reality. Proves Eve durability, shared focus, and native rich/text rendering.
5. **Bloomberg-scale series.** Two providers supply OHLCV with explicit identity, currency, venue, calendar, adjustment, observation time, and rights. Range/downsample, rivals, correction manifest, and derived volatility retain exact lineage without one event per cell.
6. **Institutional entitlement.** One principal gets screen-only field access, another cannot discover field/capability/count/cursor/lineage, and an allowed aggregate inherits rights. Eve/CLI/API/MCP agree. Proves pre-discovery and derived-output enforcement under the same personal/institutional model.
7. **Teach without confusing what-if.** Mapping/Action changes semantically rebase, expose impacted Watches/surfaces/history, pass real journeys, and publish atomically. An incompatible Watch pauses; an operational Scenario remains pinned and cannot publish/execute.

## 8. Build slices

1. **One honest thing:** Door→WorldGrant, tiny release compiler, explicit object/identity, raw Artifact, sparse Assertion, belief, Frame/Explanation, one capability generated into all four headless/conversational surfaces. Exit: Journey 1.
2. **Quiet attention:** Watch basis advancement, dependency index, evidence gate, Notice identity, Eve AttentionGate/channel receipt. Exit: Journey 2, including asserted silence.
3. **Accountable Action:** released Action, Frame read set, Case, decision OCC, atomic Receipt/effect intent, Restate state machine/reconciliation. Exit: Journey 3.
4. **Living World:** Eve streams, shared Focus, deterministic context, Object/Decision/Scenario modes, rich-to-text renderers. Exit: Journey 4.
5. **Dense reality:** source contracts, segments/manifests, range plans, correction overlays, series belief/lineage, columnar query. Exit: Journey 5.
6. **Teach the World:** drafts, semantic rebase/diff, release closure, impact, real candidate environments, publication/rollback, Teach mode. Exit: Journey 7.
7. **Institutional breadth:** ObjectPlan set algebra/aggregation, property/series/purpose rights, pre-discovery planning, export rights, authorized audit, workload delegation. Exit: Journey 6 in personal and institutional Worlds.
8. **Ecosystem last:** signed release packages, provider/effect SDKs, portable World export, third-party installation only through Studio proof and World policy—never ambient tools or writes.

## 9. Rejected shapes

- **Seven generic verbs as public architecture:** regular internally but makes callers learn lifecycle instead of domain; Frame–Case–Receipt hides more complexity.
- **Chat as truth:** transcripts mix language, uncertainty, and presentation; Eve references World authority but cannot create it.
- **One autonomous super-agent:** prompts/tools are not policy or workflow; models propose plans, deterministic modules authorize and commit.
- **Event-source every byte:** conflates decisions, ticks, tokens, and rendering; meaningful transitions are events, dense data is segments.
- **Provider routes as ontology:** route shape does not establish identity, equivalence, time, rights, or belief.
- **One universal fact table:** sparse decisions and dense observations have incompatible access/governance units.
- **Graph DB as canonical answer:** storage does not solve identity, belief, policy, time, or Actions; graph indexes may be projections.
- **Microservices/Kafka/Redis/workflow engine first:** multiply partial failure before a product boundary requires it.
- **Definition branch = Scenario:** evolution and imagination have different authority and terminal operations.
- **Always-on MCP tools:** wastes context and leaks semantics; discovery is scoped and progressive.
- **Fourth dashboard/app-builder product:** Living World belongs to Eve; headless building belongs to Ontology Studio.
- **Vector DB as memory/truth:** similarity is not causality; embeddings remain disposable authorized projections.
- **Optimistic external success:** `unknown` is preferable to a polished lie.

## 10. Rationale

### Problem

Zoen must combine an intimate relationship with an operational ontology and Bloomberg-grade integrity while remaining coherent for one person and a regulated institution. The hard part is hiding identity, time, evidence, policy, causality, concurrency, and external uncertainty without making them ambient conventions. It must keep exactly three product promises, Eve-owned continuity, Restate-only effects, and domain-native Actions.

### Usage

A person states enduring intent; Eve preserves focus; Ontology returns an honest Frame; a Watch stays silent until a material delta; a Case asks only for the required choice; a Receipt separates decision from settlement. Operators/agents use the same generated domain capability. Builders define meaning once, prove real journeys, and atomically publish every surface.

### Shape

The recommended architecture is a **world compiler plus adjudication kernel**, centered on `WorldRelease → Lens → Frame → Case → Receipt`, with `Watch → Notice` as its continuing loop. Release is the single source of semantic truth. Frame concentrates authorized identity/time/belief/query/explanation. Case captures an exact read set; Receipt captures the semantic transition and independent effects. Sparse assertions and dense segments share semantics, not physical rows. Per-conversation interaction streams avoid ambient agent state. Surface compilers consume semantic IR rather than wire schemas. Distinct Draft/Scenario types prevent authority leakage.

The stable `WorldSession` has six deep operations and hides substantially more than it exposes. Normal trace depth is surface→kernel→owner/store. Modules own domain knowledge across time rather than load/validate/save stages. Boundaries remain only where they add attestation, policy, compilation, or external adaptation; transport/storage types remain private.

### Synthesis decision

Candidate C chooses Frame–Case–Receipt because it makes user experience and integrity the same shape. Its distinctive bet is that the atomic read product is a complete permission-scoped Frame, not an object record, and the atomic change product is Case/Receipt, not CRUD or a generic verb sequence. Retain it in synthesis if interface depth and Eve↔Ontology continuity outrank superficial protocol regularity.

### Tradeoffs

- We accept a richer compiler in exchange for eliminating drift across meaning, policy, sources, code, presentation, and surfaces.
- We accept rival evidence/resolution receipts in exchange for explainability without destructive overwrite.
- We accept two evidence planes in exchange for one semantic model across household and institution.
- We accept OCC conflicts in exchange for never deciding against silently changed consequences.
- We accept unknown/reconciliation in exchange for never lying about external settlement.
- We accept repeated policy evaluation in exchange for correct revocation, purpose, delegation, and rights.
- We accept Rust+TypeScript in one monorepo in exchange for rigorous authority and first-class relationship/UI ecosystems.
- We accept a modular monolith in exchange for comprehensibility and atomic evolution.
- We accept pausing incompatible Watches in exchange for not silently changing ongoing intent.
- We accept no cross-World transaction in exchange for real authority boundaries.

### Alternatives

1. **Seven-verb kernel:** simple routing, but exposes lifecycle sequencing and hides less domain complexity.
2. **Actor/event-sourced World:** simple narrative log, but couples institutional throughput to one mailbox and exposes replay/partitioning; chosen storage follows access patterns while retaining transition events.
3. **Knowledge graph + agent planner:** easy open-ended traversal, but leaves identity/belief/time/rights/concurrency/effects as conventions; chosen typed IR centralizes them.
4. **Eve as ordinary third-party MCP client:** clean surface abstraction, but loses first-class focus/Notice/Case continuity; chosen protocol stays non-authoritative while deeper.

### Open questions

- Which first domain has real evidence and external Action access sufficient to prove the complete loop without demo semantics?
- What release-track compatibility proof lets a Watch advance automatically?
- Which purpose/right categories must be primitive in release one?
- How much of a denied field’s existence may explanation reveal without a side channel?
- What is the smallest expression language for belief, materiality, policy, and pure transitions without becoming a general language?
- Which model calls and relationship memories may be retained, under what privacy contract?
- When must World sequence allocation partition without weakening `WorldCut`?
- How does portable export represent evidence whose rights forbid moving bytes?

### Next step

Build Slice 1 as a real `ticker + venue → resolved Listing → authorized Frame → explanation` journey compiled into Eve, CLI, API, and progressive MCP; it forces identity, release, evidence, basis, policy, interface depth, and surface parity to become true before breadth.
