# Candidate B — One frame, seven records

## 1. Product promise

Zoen is a world you can **inspect, challenge, decide in, and entrust with attention**. Eve is the relationship with that world. The Ontology is the world itself. Door proves who arrived. Nothing else is a product.

The characteristic experience is not “chat with your data” and not “configure a graph.” It is this loop:

```text
ordinary intent
  → a portable Focus (what, when, why)
  → an authorized WorldFrame (meaning + knowledge + audience)
  → an Answer, a domain Action, or a Watch
  → evidence and consequences made legible
  → only the decision actually required
  → a DecisionReceipt for the world change
  → separate SettlementReceipts for external reality
  → quiet attention until an interruption earns its cost
  → the same Focus continues in conversation or Living World
```

The organizing idea is **one frame, seven records**.

- A `WorldFrame` is an immutable, authorized view of a World at an explicit release, valid-time coordinate, knowledge cut, belief policy, and purpose. Every answer, action preview, cursor, scenario, citation, and receipt is pinned to a frame.
- Seven records own seven different kinds of truth: **meaning, identity, truth, agency, attention, interaction, and external reality**. No “agent state,” transcript, event bus, graph database, or generic workflow row is allowed to impersonate more than one of them.

This yields a product that can be small for a person and exact for an institution without changing its conceptual language. “Keep an eye on this medication,” “warn me if our runway falls under six months,” “rebalance this portfolio,” and “stop line 4 if defect risk crosses the release threshold” are all released domain capabilities over a WorldFrame. Their volume, policy, and consequence differ; the model does not.

### The first minute, day, week, and builder hour

**First minute.** A person tells Eve, “I hold IBM and I care if something material changes.” Eve does not pretend `IBM` is a unique subject. She shows the two or three economically meaningful candidates, asks the smallest clarifying question, explains the selected listing, and offers a Watch in the person's words. No ontology setup screen appears.

**First day.** Eve stays silent until new evidence changes the answer enough to justify interruption. The notification says what changed, why it matters, which evidence supports it, what is still uncertain, and as of when. Opening it lands on exactly the same subject and time basis in Living World.

**First week.** Eve proposes a domain Action, such as “rebalance to the risk budget.” The person sees before/after state, assumptions, rivals, policy consequences, and which external effects would be attempted. Confirming commits the decision. A broker timeout is reported as **unknown**, never as success. Later reconciliation updates settlement without rewriting the decision.

**Builder hour.** A builder adds a domain concept, a provider mapping, an Action, and a Watch template in one World draft. Zoen produces a semantic diff, replays real journeys, shows policy and surface impact, and publishes one atomic release. CLI, API, MCP, Eve, and Living World acquire native projections of the same capabilities.

### Three products, hard boundaries

| Product | Owns | Must never own |
|---|---|---|
| **Door** | Account, session, device, channel-to-account proof via Better Auth | World membership, entitlements, domain authority |
| **Eve** | Relationship, turns, focus continuity, voice, presentation, Living World | Accepted facts, World policy, minted authority, effect settlement |
| **Ontology** | Released meaning, identity, evidence, belief, queries, domain Actions, Watches, receipts, CLI/API/MCP | Conversational memory or channel-specific behavior |

The user experiences one Zoen. The code preserves three authorities.

## 2. Usage (person, operator, builder, agent)

The usage is the specification. Types and modules below exist only to make these calls honest.

### Person — Eve and Living World

```text
Enzo: Tenho IBM e quero saber se algo realmente importante mudar.

Eve: “IBM” pode ser a empresa, a ação negociada em Nova York,
     uma listagem em outro mercado ou até um título de dívida.
     Você quer acompanhar a ação IBM na NYSE, em dólar?

Enzo: Sim.

Eve: Entendi. Estou acompanhando a listagem XNYS, ligada à classe
     de ações da IBM. Vou falar apenas quando uma mudança puder alterar
     sua decisão — e vou mostrar evidência, divergências e o horário
     do que eu sabia. [Abrir no Living World]
```

The link carries an authority-free `FocusRef`, not a credential. Living World opens the same focus through a fresh Door proof and receives a fresh authorized frame. Subject, time, belief basis, evidence selection, and pending decision survive the move; pixels do not.

When action is required:

```text
Eve: Sua concentração passou do limite de 12% depois da queda das
     outras posições. O dado de preço está 4 min atrasado; dois
     fornecedores concordam dentro de 0,03%. Reduzir para 10% venderia
     aproximadamente 18 ações. Imposto estimado: R$ 1.240–1.510.

     Decisão necessária: usar ordem limitada a US$ 286,20 ou não agir?

Enzo: Pode usar a limitada.

Eve: A decisão foi registrada. A corretora recebeu duas pernas; uma foi
     aceita e a outra está sem resultado conclusivo. Ainda não vou chamar
     isso de concluído. Estou reconciliando.
```

### Operator — native domain surface, explicit basis

The operator never orchestrates “load, authorize, resolve, query, reduce, cite.” One released call hides those stages.

```ts
const zoen = await Zoen.connect({ purpose: "portfolio-management" });
const portfolio = await zoen.world("family").open();

const answer = await portfolio.holdings.exposure({
  groupBy: "issuer",
  at: "2026-09-04T14:00:00-03:00",
  knownAsOf: "2026-09-04T14:05:00-03:00",
});

answer.value;                 // only authorized comparable values
answer.basis;                 // exact release/time/cut/belief/purpose
answer.explanation.summary;   // support, rivals, gaps, transformations
answer.focus;                 // portable, authority-free continuation
```

The same capability in CLI is domain language, not a generic query DSL forced on the person:

```text
$ zoen portfolio exposure --group-by issuer --at 2026-09-04T14:00:00-03:00

IBM  12.4%   ↑ 1.8 pp
Basis: Family World r18 · known through 14:05 · portfolio-management
Evidence: 2 price sources agree; FX known through 14:03
```

A domain Action may finish automatically under policy or return the exact unresolved decision:

```ts
const outcome = await portfolio.portfolio.rebalance({
  portfolio: portfolio.id,
  target: { kind: "riskBudget", annualVolatility: 0.12 },
  constraints: { maxIssuerWeight: 0.10 },
  requestKey: RequestKey.new(),
});

if (outcome.kind === "needs-decision") {
  render(outcome.case.consequences);
  const receipt = await outcome.case.answer(
    { kind: "choose-limit", price: Money.usd("286.20") },
    RequestKey.new(),
  );
  receipt.commit;             // authoritative world decision
  receipt.effects;            // pending/unknown/succeeded independently
}
```

`case.answer` is a continuation of the named domain Action, not a second public “Approve” product verb.

### Builder — one release closure

The builder authors domain meaning, not endpoints. A draft may change schema, identity policy, mappings, Actions, Watches, policy programs, functions, and presentation hints together because they must be tested and released together.

```ts
const candidate = await studio.prepare({
  world: "clinic",
  base: ReleaseId("clinic@31"),
  changes: ChangeSet.from("./diabetes-followup.world"),
  journeys: [
    Journey.ref("resolve-patient-with-colliding-name"),
    Journey.ref("detect-dangerous-a1c-trend"),
    Journey.ref("schedule-followup-with-unknown-ehr-result"),
    Journey.ref("hide-restricted-condition-from-contractor"),
  ],
});

candidate.semanticDiff;       // meaning and identity changes
candidate.dataImpact;         // claims/series/views affected
candidate.policyImpact;       // newly visible/hidden capabilities and data
candidate.surfaceDiff;        // CLI/API/MCP/Eve/Living World projections
candidate.journeyReport;      // real journey results, no mocks

await studio.publish(candidate, {
  expectedHead: ReleaseId("clinic@31"),
  decision: reviewDecision,
});
```

Only an `EvaluatedCandidate` can be published. Publishing switches one World head atomically. Existing receipts retain their old release. Rollback is a new head selection, not history deletion.

### Agent — progressive, permission-scoped MCP

An agent first sees semantic neighborhoods, not hundreds of provider routes:

```text
resources/list
  world://portfolio/objects
  world://portfolio/decisions
  world://portfolio/attention

tools/list after selecting “portfolio risk”
  portfolio_exposure
  portfolio_explain_exposure
  portfolio_rebalance
```

```json
{
  "tool": "portfolio_rebalance",
  "arguments": {
    "portfolio": "obj_…",
    "targetAnnualVolatility": 0.12,
    "maxIssuerWeight": 0.10,
    "requestKey": "req_…"
  }
}
```

The tool returns either a typed DecisionReceipt or a typed decision request. The agent cannot discover a capability, subject, field, count, cursor, citation, or explanation outside its delegated permit. A human and an agent call the same released capability and receive the same receipt shape; policy determines what each may discover, propose, and decide.

## 3. Core domain types

The public model has one coordinate (`WorldFrame`), three forms of work (`inspect`, released domain Action, `watch`), and one universal result property (`Receipt`). The seven records are internal authorities, not seven APIs the caller coordinates.

### Nominal identities and digests

```ts
type Brand<T, Name extends string> = T & { readonly __brand: Name };

type WorldId            = Brand<string, "WorldId">;
type AccountId          = Brand<string, "AccountId">;
type PrincipalId        = Brand<string, "PrincipalId">;
type ObjectId<T>        = Brand<string, `ObjectId:${T & string}`>;
type TypeId<T>          = Brand<string, `TypeId:${T & string}`>;
type FieldId<T>         = Brand<string, `FieldId:${T & string}`>;
type ActionId<A>        = Brand<string, `ActionId:${A & string}`>;
type WatchId            = Brand<string, "WatchId">;
type CaseId<D>          = Brand<string, `CaseId:${D & string}`>;
type DecisionId         = Brand<string, "DecisionId">;
type EffectId           = Brand<string, "EffectId">;
type EventId            = Brand<string, "EventId">;
type CommitId           = Brand<string, "CommitId">;
type KnowledgeCut       = Brand<bigint, "KnowledgeCut">;
type StreamRevision     = Brand<bigint, "StreamRevision">;
type Digest             = Brand<string, "ContentDigest">;
type RequestKey         = Brand<string, "RequestKey">;
type PurposeId          = Brand<string, "PurposeId">;
type BeliefPolicyId     = Brand<string, "BeliefPolicyId">;
type ReleaseId          = Brand<string, "WorldReleaseId">;
type FocusRef           = Brand<string, "FocusRef">;
```

Identifiers are opaque and never derived from names, tickers, email addresses, provider IDs, or database keys. External identifiers are evidence-bearing assignments to objects.

### One frame

```ts
type ValidCoordinate =
  | { kind: "at"; instant: Instant }
  | { kind: "during"; interval: Interval };

type KnowledgeCoordinate =
  | { kind: "cut"; cut: KnowledgeCut }
  | { kind: "as-known-at"; instant: Instant };

type WorldBasis = Readonly<{
  release: ReleaseId;
  valid: ValidCoordinate;
  knowledge: KnowledgeCoordinate;
  belief: BeliefPolicyId;
  purpose: PurposeId;
}>;

type AudienceReceipt = Readonly<{
  principal: PrincipalId;
  delegation?: Digest;
  policyDecision: Digest;
  entitlementSnapshot: Digest;
}>;

type Focus = Readonly<{
  world: WorldId;
  target:
    | { kind: "subject"; subject: AnyObjectRef }
    | { kind: "set"; query: ReleasedQueryRef }
    | { kind: "answer"; answer: ReceiptRef }
    | { kind: "case"; case: AnyCaseRef }
    | { kind: "watch"; watch: WatchId };
  temporalIntent: "now" | ValidCoordinate;
  preferredBelief?: BeliefPolicyId;
}>;

interface WorldFrame<Mode extends "live" | "scenario"> {
  readonly world: WorldId;
  readonly basis: WorldBasis;
  readonly focus: FocusRef;
  readonly mode: Mode;
  // An unexported, short-lived permit is held server-side.
}
```

`Focus` is durable and portable but grants nothing. `WorldFrame` is authorized but short-lived and cannot be serialized as a credential. Door supplies account proof; Ontology derives a permit from membership, delegation, purpose, release, and policy. Eve never fabricates either.

### Seven records

| Record | Product authority | Canonical types | Sole authority over |
|---|---|---|---|
| **Meaning** | Ontology | `WorldRelease`, `EvaluatedCandidate` | What nouns, fields, links, Actions, functions, identity rules, belief policies, sources, entitlements, Watches, and presentation mean |
| **Identity** | Ontology | `WorldObject<T>`, `IdentifierAssignment`, `Resolution` | Which enduring subject an external reference may denote and which types it inhabits |
| **Truth** | Ontology | `Artifact`, `Claim<T>`, `ObservationManifest`, `Belief<T>` | What was asserted, observed, derived, disputed, and accepted for a purpose |
| **Agency** | Ontology | `ActionCase<D>`, `Decision`, `DecisionReceipt` | Which governed world change was considered and committed |
| **Attention** | Ontology | `Watch`, `Finding`, `AttentionReceipt` | Which ongoing intent was evaluated and why Zoen stayed silent or interrupted |
| **Interaction** | Eve | `Relationship`, `Turn`, `Focus` | What was said and what the relationship is currently attending to |
| **External reality** | Ontology | `EffectIntent`, `EffectAttempt`, `Settlement` | What an external system actually accepted, rejected, completed, or left unknown |

No record may infer another record's authority. A transcript can support a claim that “Enzo said X,” but cannot directly become accepted World truth. A Decision can request an effect, but cannot claim settlement. A provider artifact can support an identity candidate, but cannot silently assign identity. A release can define a policy, but cannot grant a membership.

### Meaning record

```ts
type WorldRelease = Readonly<{
  id: ReleaseId;
  parent?: ReleaseId;
  content: Digest;
  schema: Digest;              // object/link/field/value definitions
  capabilities: Digest;        // queries, domain Actions, Watch templates
  functions: Digest;           // deterministic executable artifacts
  identityRules: Digest;
  beliefPolicies: Digest;
  sourceMappings: Digest;
  qualityRules: Digest;
  policyPrograms: Digest;
  presentationSemantics: Digest;
  journeyEvidence: Digest;
}>;

type EvaluatedCandidate = Opaque<{
  base: ReleaseId;
  candidate: WorldRelease;
  semanticDiff: SemanticDiff;
  dataImpact: ImpactReport;
  policyImpact: ImpactReport;
  surfaceDiff: SurfaceDiff;
  journeyReport: JourneyReport;
}>;
```

`WorldRelease` is a content-addressed closure, not merely a schema version. Dynamic facts such as current membership and effective-dated entitlements remain records at a cut; the release pins the rules that interpret them. Transport descriptions and database schemas are not part of its public model.

### Identity record

```ts
type WorldObject<T extends string> = Readonly<{
  id: ObjectId<T>;
  type: TypeId<T>;
  createdBy: DecisionId;
  life: Interval;
}>;

type IdentifierAssignment<T extends string> = Readonly<{
  object: ObjectId<T>;
  scheme: IdentifierSchemeId;
  value: ExactIdentifierValue;
  level: IdentityLevel;
  context: IdentityContext;       // venue, jurisdiction, currency, role, etc.
  valid: Interval;
  authority: SourceRef;
  evidence: NonEmpty<ArtifactRef | ClaimRef>;
  status:
    | { kind: "candidate" }
    | { kind: "accepted"; decision: DecisionId }
    | { kind: "disputed"; case: CaseId<"identity"> }
    | { kind: "superseded"; by: IdentifierAssignmentRef };
}>;

type Resolution<T extends string> =
  | { kind: "none"; searched: ResolutionReceipt }
  | { kind: "unique"; object: ObjectRef<T>; receipt: ResolutionReceipt }
  | { kind: "ambiguous"; candidates: NonEmpty<IdentityCandidate<T>>;
      question: DisambiguationQuestion; receipt: ResolutionReceipt };
```

There is no `resolveOrFirst`, implicit case folding, or universal `sameAs`. Links are typed, directional on each named side, cardinality-checked at admission, and promoted only after both endpoint memberships are proven. When a relationship itself has time, evidence, confidence, or rights, it is an object rather than a decorated edge.

### Truth record: evidence is not belief

```ts
type Artifact = Readonly<{
  digest: Digest;
  source: SourceRef;
  request: Digest;
  adapter: Digest;
  acquiredAt: Instant;
  publishedAt?: Instant;
  providerHeaders: Digest;
  usageRights: UsageRightsRef;
}>;

type ClaimClocks = Readonly<{
  valid: Interval;                // when true in the modeled world
  observedAt?: Instant;           // when the source observed it
  publishedAt?: Instant;          // when the source asserted it
  receivedAt: Instant;            // when Zoen acquired it
}>;

type Claim<T> = Readonly<{
  id: ClaimId;
  subject: AnyObjectRef;
  field: FieldRef<T>;
  value: T;
  dimensions: ExactDimensions;
  clocks: ClaimClocks;
  evidence: NonEmpty<ArtifactRef | ClaimRef | ObservationRangeRef>;
  mapper: Digest;
  quality: QualityAssessment;
  rights: UsageRightsRef;
}>;

type ObservationManifest<T> = Readonly<{
  series: SeriesRef<T>;
  subject: AnyObjectRef;
  field: FieldRef<T>;
  semantics: ObservationSemantics; // unit, currency, timezone, calendar,
                                    // periodicity, adjustments, dimensions
  revision: StreamRevision;
  coverage: Interval;
  segments: readonly ObservationSegmentRef[];
  sources: NonEmpty<SourceRef>;
  mapping: Digest;
  rights: UsageRightsRef;
  content: Digest;
}>;

type Belief<T> = Readonly<{
  value: T | null;
  support: readonly ClaimRef[];
  rivals: readonly ClaimRef[];
  gaps: readonly EvidenceGap[];
  policy: BeliefPolicyId;
  resolution: ResolutionReceipt;
}>;

type Answer<T> = Readonly<{
  value: T;
  basis: WorldBasis;
  audience: AudienceReceipt;
  explanation: ExplanationSummary;
  receipt: ReadReceipt;
  focus: FocusRef;
}>;
```

Sparse facts, identity adjudications, decisions, exceptions, and deliberately materialized metrics are claims. Dense ticks, candles, telemetry, and large tabular vintages are immutable segments referenced by an `ObservationManifest`; they are not millions of tiny claims. A range or computation can still be cited as evidence through an exact manifest revision and range digest.

A `Belief` is purpose-specific. A released policy selects from preserved claims without overwriting rivals. Mechanical resolutions are reproducible from policy and cut; manual adjudications are Decisions. A resolution receipt names winners, rivals, exclusions, quality decisions, rights decisions, release, and cut.

### Agency record

```ts
type ActionBasis = Readonly<{
  frame: WorldBasis;
  audience: AudienceReceipt;
  readSet: Digest;
  expectedRevisions: readonly AggregateRevision[];
  expiresAt?: Instant;
}>;

type Consequence = Readonly<{
  before: AuthorizedProjection;
  after: AuthorizedProjection;
  assumptions: readonly Assumption[];
  uncertainty: readonly Uncertainty[];
  worldChanges: readonly TypedChange[];
  proposedEffects: readonly EffectPreview[];
}>;

type DecisionQuestion<D> =
  | { kind: "confirm"; prompt: DomainSentence; answer: "yes" | "no" }
  | { kind: "choose"; prompt: DomainSentence; options: NonEmpty<D> }
  | { kind: "supply"; prompt: DomainSentence; schema: ValueSchema<D> }
  | { kind: "quorum"; prompt: DomainSentence; rule: ApprovalRule };

type ActionCase<D> = Readonly<{
  id: CaseId<D>;
  action: ReleasedActionRef;
  basis: ActionBasis;
  consequences: Consequence;
  question: DecisionQuestion<D>;
  policy: PolicyReceipt;
}>;

type ActionOutcome<D, O> =
  | { kind: "decided"; receipt: DecisionReceipt<O> }
  | { kind: "needs-decision"; case: DecisionHandle<D, O> }
  | { kind: "impossible"; explanation: SafeFailure };

type DecisionReceipt<O> = Readonly<{
  decision: DecisionId;
  action: ReleasedActionRef;
  basis: ActionBasis;
  answer: Digest;
  commit: { id: CommitId; cut: KnowledgeCut; changes: readonly ChangeRef[] };
  output: O;
  effects: readonly EffectStatus[];
  causality: Causality;
}>;
```

The Action engine discovers data, resolves beliefs, computes consequences, evaluates policy, determines whether any decision remains, and commits atomically. Callers do not coordinate these stages. A stale read set yields a typed `StaleCase` with the material semantic difference; it never silently replays a previous answer against new state.

### Attention record

```ts
type InterruptionContract = Readonly<{
  significance: ReleasedPredicateRef;
  noveltyWindow: Duration;
  cooldown: Duration;
  quietHours: readonly LocalInterval[];
  budget: InterruptionBudget;
  escalation?: EscalationRule;
  channels: NonEmpty<ChannelPreference>;
}>;

type Watch<Q, F> = Readonly<{
  id: WatchId;
  owner: PrincipalId;
  question: Q;
  scope: ReleasedQueryRef;
  detector: ReleasedFunctionRef<F>;
  contract: InterruptionContract;
  basisPolicy: WatchBasisPolicy;
  cursor: WatchCursor;
}>;

type AttentionDecision<F> =
  | { kind: "silent"; reason: SilenceReason; nextEligibleAt?: Instant }
  | { kind: "interrupt"; finding: F; evidence: ExplanationSummary;
      proposedCase?: AnyCaseRef; delivery: EffectId };

type AttentionReceipt<F> = Readonly<{
  watch: WatchId;
  evaluated: { from: KnowledgeCut; through: KnowledgeCut };
  basis: WorldBasis;
  finding?: F;
  decision: AttentionDecision<F>;
  policy: Digest;
}>;
```

A Watch is not “run an agent every five minutes.” It is a released question plus a deterministic or digest-pinned detector and an interruption contract. It evaluates meaningful World transitions and observation-manifest advances. Every evaluation advances a cursor transactionally and records why it remained silent or interrupted. An LLM may phrase an authorized finding after the interruption decision; it may not invent significance or bypass the budget.

### Interaction record

```ts
type Relationship = Readonly<{
  id: RelationshipId;
  account: AccountId;
  channelBindings: readonly ChannelBindingRef[];
  retention: RetentionPolicyRef;
}>;

type Turn = Readonly<{
  id: TurnId;
  relationship: RelationshipId;
  revision: StreamRevision;
  input: ContentRef;
  focusBefore?: FocusRef;
  disclosedCapabilities: Digest;
  invocations: readonly InvocationReceiptRef[];
  output: ContentRef;
  focusAfter: FocusRef;
  causality: Causality;
}>;
```

Eve event-sources relationship turns because replay, cross-channel ordering, retention, and failure recovery are intrinsic to conversation. The interaction record stores capability/result references, not copies of World truth. Living World and messaging consume the same `FocusRef`; messaging flattens structure into excellent prose.

### External-reality record

```ts
type EffectIntent = Readonly<{
  id: EffectId;                   // deterministic from decision + effect ordinal
  decision: DecisionId;
  kind: ReleasedEffectKind;
  payload: Digest;
  destination: DestinationRef;
  policy: PolicyReceipt;
}>;

type Settlement =
  | { kind: "not-dispatched" }
  | { kind: "attempting"; attempt: number }
  | { kind: "acknowledged"; externalRef: RedactedExternalRef }
  | { kind: "succeeded"; evidence: ExternalEvidenceRef }
  | { kind: "rejected"; evidence: ExternalEvidenceRef }
  | { kind: "unknown"; lastAttempt: EffectAttemptRef; reconcileAfter: Instant }
  | { kind: "compensated"; original: EffectId; compensation: EffectId };
```

Only the effect runtime may advance Settlement, and only from provider evidence. “HTTP 200,” “accepted,” “queued,” and “succeeded” are distinct if the destination makes them distinct. An unknown outcome remains unknown until reconciliation. Compensation is a new governed effect, never a fictional rollback of external history.

### Branches that cannot be confused

```ts
interface ReleaseDraft {
  readonly base: ReleaseId;
  readonly changes: ChangeSet;
  // Can become EvaluatedCandidate; cannot query live data or emit effects.
}

interface ScenarioFrame extends WorldFrame<"scenario"> {
  inspect<Q extends ReleasedQuery>(query: Q): Promise<Answer<Q["output"]>>;
  consider<A extends ReleasedAction>(action: A): Promise<ScenarioConsequence<A>>;
  // No decide(), no publish(), no EffectIntent.
}

type Scenario = Readonly<{
  basis: WorldBasis;
  hypotheses: readonly Hypothesis[];
  sequence?: readonly HypotheticalAction[];
}>;
```

Definition evolution is a `ReleaseDraft` DAG with rebase/conflict/review/publish. Operational what-if is a `ScenarioFrame` pinned to a live basis. A scenario can produce a plan, but executing it requires a new live Action consideration against current state. The type system makes “publish a scenario” and “settle an effect from a scenario” impossible.

### Event envelope and causality

```ts
type Causality = Readonly<{
  request: RequestKey;
  correlation: CorrelationId;
  causedBy?: EventId | TurnId | DecisionId | EffectAttemptRef;
}>;

type DomainEvent<B extends DomainEventBody> = Readonly<{
  id: EventId;
  world: WorldId;
  stream: StreamRef;
  revision: StreamRevision;
  commit: CommitId;
  cut: KnowledgeCut;
  release: ReleaseId;
  actor: PrincipalId;
  recordedAt: Instant;
  effectiveAt?: Instant;
  causality: Causality;
  body: B;
  digest: Digest;
}>;
```

`recordedAt` orders no business truth. `KnowledgeCut` orders admitted World commits. Domain payloads carry their own valid, observed, publication, economic-period, event-effective, and settlement clocks. One optional timestamp is not asked to mean six things.

## 4. Public interfaces and signatures

### The deep public interface

```ts
interface Zoen {
  open(request: OpenWorld): Promise<LiveWorld>;
}

type OpenWorld = Readonly<{
  world: WorldId;
  purpose: PurposeId;
  focus?: FocusRef;
  at?: ValidCoordinate;
  known?: KnowledgeCoordinate;
  belief?: BeliefPolicyId;
  doorProof: AccountProof; // adapted at the boundary; never stored as authority
}>;

interface ReadWorld {
  readonly frame: WorldFrame<"live" | "scenario">;

  inspect<Q extends ReleasedQuery>(query: Q): Promise<Answer<Q["output"]>>;
  explain(target: ExplainableRef): Promise<Explanation>;
}

interface LiveWorld extends ReadWorld {
  invoke<A extends ReleasedAction>(
    action: A,
    key: RequestKey,
  ): Promise<ActionOutcome<A["decision"], A["output"]>>;

  watch<W extends ReleasedWatch>(
    specification: W,
    key: RequestKey,
  ): Promise<WatchReceipt>;

  scenario(hypotheses: readonly Hypothesis[]): Promise<ScenarioWorld>;
}

interface ScenarioWorld extends ReadWorld {
  consider<A extends ReleasedAction>(action: A): Promise<ScenarioConsequence<A>>;
}

interface DecisionHandle<D, O> {
  readonly case: ActionCase<D>;
  answer(decision: D, key: RequestKey): Promise<DecisionReceipt<O>>;
}

interface Studio {
  prepare(input: PrepareRelease): Promise<EvaluatedCandidate>;
  publish(candidate: EvaluatedCandidate, authorization: PublishDecision):
    Promise<ReleaseReceipt>;
}
```

This interface is deliberately asymmetric. Reads, Actions, Watches, and explanations are deep operations; their internal acquisition, resolution, policy, computation, concurrency, persistence, and citation stages are hidden. `DecisionHandle.answer` exists because human or quorum input is a genuine pause in the domain, not because the implementation was decomposed into workflow steps.

The generic interface is kernel vocabulary. Users and agents receive generated domain projections:

```ts
interface PortfolioWorld {
  holdings: {
    exposure(input: ExposureInput): Promise<Answer<Exposure>>;
  };
  portfolio: {
    rebalance(input: RebalanceInput & Idempotent):
      Promise<ActionOutcome<RebalanceChoice, RebalanceResult>>;
  };
  attention: {
    concentration(input: ConcentrationWatchInput & Idempotent):
      Promise<WatchReceipt>;
  };
}
```

There are no public `create/update/delete/link/approve/commit/execute` meta-tools. A released domain Action may internally produce typed changes and effects; the public name remains `rebalancePortfolio`, `scheduleFollowup`, `stopLine`, or `renewPrescription`.

### Capability catalog and native projections

```ts
type ReleasedCapability<I, O> = Readonly<{
  id: CapabilityId;
  kind: "query" | "action" | "watch-template";
  domainName: DomainName;
  input: SemanticSchema<I>;
  output: SemanticSchema<O>;
  preconditions: ReleasedPredicateRef;
  policyResource: PolicyResourceRef;
  explanationContract: ExplanationContract;
  presentation: PresentationSemantics;
}>;

interface SurfaceCompiler {
  compile(
    release: WorldRelease,
    disclosed: AuthorizedCapabilitySubgraph,
  ): NativeSurfaceBundle;
}

type NativeSurfaceBundle = Readonly<{
  sdk: TypedSdkArtifact;
  api: ApiArtifact;
  cli: CliArtifact;
  mcp: ProgressiveMcpArtifact;
  eve: EveAffordanceArtifact;
  livingWorld: ViewArtifact;
}>;
```

The release contains semantic types and domain capabilities, not OpenAPI, MCP, CLI, or chat schemas as source truth. Policy filters the capability graph **before compilation or discovery**. Each compiler preserves the same semantic identity and receipt contract while using the surface's native strengths:

- API gets typed resources, streaming where meaningful, and sealed basis-aware pagination.
- CLI gets composable domain commands, pipes, and explicit basis flags.
- MCP gets resources for orientation, progressive tools for selected semantic neighborhoods, and bounded descriptions.
- Eve gets a capability lexicon, clarification rules, consequence language, and structured presentation that messaging can flatten.
- Living World gets object/set/decision/watch views, not a separate dashboard model.

Transport decoders turn wire values into domain types at the edge. No HTTP, protobuf, JSON Schema, MCP, SQL, or provider type crosses into the kernel.

### Internal ports

The kernel depends on a small set of knowledge-owning ports, not repositories for every table:

```ts
interface WorldRecord {
  read(frame: AuthorizedFrame, plan: SemanticPlan): Promise<AuthorizedFacts>;
  commit(intent: GovernedIntent, expected: RevisionSet): Promise<CommitReceipt>;
  events(after: KnowledgeCut, interest: SemanticInterest): AsyncIterable<DomainEvent>;
}

interface EvidenceVault {
  contribute(request: ReleasedSourceRequest, permit: SourcePermit):
    Promise<NormalizedContributionReceipt>;
  replay(artifact: ArtifactRef, mapping: ReleasedMapping):
    Promise<ReplayedContribution>;
}

interface ObservationPlane {
  publish(segment: ValidatedSegment, expected: ManifestRevision):
    Promise<ObservationPublishReceipt>;
  query<T>(request: AuthorizedObservationQuery<T>): Promise<ObservationResult<T>>;
}

interface PolicyOracle {
  authorize(intent: AccessIntent, basis: WorldBasis): Promise<PolicyReceipt>;
}

interface EffectDestination {
  attempt(intent: EffectIntent, attempt: AttemptContext): Promise<ExternalOutcome>;
  reconcile(intent: EffectIntent, evidence: ReconciliationContext):
    Promise<ExternalOutcome>;
}
```

`WorldRecord.commit` owns atomicity, cuts, optimistic comparisons, idempotency, events, and outbox publication. The caller cannot partially write one record. `EvidenceVault.contribute` performs acquisition, immutable capture, validation, normalization, and rights binding as one deep operation; `replay` exists for audit and migration, not as the second half of ordinary ingestion. `ObservationPlane` owns immutable segments, manifests, overlap/correction rules, and range execution. These are deep boundaries rather than pass-through persistence methods.

## 5. Runtime/module map

```text
┌────────────────────────────────── ONE ZOEN EXPERIENCE ───────────────────────────────┐
│                                                                                      │
│  Door product                         Eve product                                    │
│  ┌──────────────────────┐             ┌───────────────────────────────────────────┐  │
│  │ Better Auth          │ AccountProof│ Relationship runtime · Interaction record │  │
│  │ session/device/link  ├────────────►│ channels · turns · Focus · Living World   │  │
│  └──────────────────────┘             │            │                              │  │
│                                       │ fresh proof│ + FocusRef                   │  │
│                                       └────────────┼──────────────────────────────┘  │
│                                                    ▼                                 │
│  Ontology product                                                                    │
│  ┌────────────────────────────────────────────────────────────────────────────────┐  │
│  │ Access boundary: membership + delegation + purpose → short-lived World permit │  │
│  ├────────────────────────────────────────────────────────────────────────────────┤  │
│  │ Surface compiler/gateways: CLI · API · progressive MCP · Eve · Living World   │  │
│  ├──────────────────────────────┬─────────────────────────────────────────────────┤  │
│  │ WorldFrame kernel            │ Release studio/compiler                         │  │
│  │ inspect · invoke · watch     │ draft → diff → journeys → candidate → publish  │  │
│  │ explain · scenario           │                                                 │  │
│  ├──────────────────────────────┴─────────────────────────────────────────────────┤  │
│  │ Six World records (Interaction remains exclusively in Eve)                     │  │
│  │ meaning · identity · truth · agency · attention · external reality             │  │
│  ├──────────────────────────────┬───────────────────────┬─────────────────────────┤  │
│  │ Sparse authority/control     │ Dense observation     │ External-effect runtime │  │
│  │ transactions + causal log   │ immutable segments    │ Restate only             │  │
│  └──────────────────────────────┴───────────────────────┴─────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────────┘

         PostgreSQL authority       content-addressed objects       Restate
         + Eve interaction log      + columnar observations          Effects only
```

### Knowledge-owned modules

| Module | Owns | Explicitly does not own |
|---|---|---|
| `door` | Better Auth adaptation and channel/account proof | World roles or capabilities |
| `relationship` | Eve interaction stream, focus transitions, context assembly, voice, channel rendering | Semantic truth or authorization |
| `release` | World drafts, semantic compiler, journeys, impact, publication | Operational scenarios or live facts |
| `frame` | Basis pinning, authorized query/action/watch/explain orchestration | Storage protocols or LLM planning |
| `identity` | Objects, membership, identifier candidates, resolution evidence | Provider transport |
| `truth` | artifacts, claims, observations, beliefs, lineage | decisions or effects |
| `agency` | cases, consequence computation, policy, stale detection, decision commit | external success |
| `attention` | watch cursors, detectors, significance, interruption budget | prose generation or channel delivery |
| `reality` | effect intent, attempts, reconciliation, settlement | world decision authority |
| `surface` | capability disclosure and native projection | semantic definitions |

The central flows cross at most three knowledge boundaries:

```text
read:    surface → frame → identity/truth
action:  surface → frame/agency → WorldRecord     (reality continues asynchronously)
turn:    relationship → frame → relationship presenter
watch:   attention → frame/truth → reality(delivery)
release: studio → release compiler → atomic head publication
```

There is no service/controller/use-case/repository chain where every layer forwards the same arguments. Each boundary changes the kind of knowledge being handled.

### Eve's runtime

For each incoming turn:

1. Door adapts the channel/session proof to `AccountProof`.
2. Eve appends the input idempotently to the relationship stream.
3. Eve passes `AccountProof + FocusRef + purpose` to Ontology; Ontology returns a short-lived `WorldFrame` and an already-filtered capability neighborhood.
4. Eve's model chooses among disclosed domain capabilities and drafts typed inputs. A deterministic invocation boundary parses and validates them.
5. Ontology returns `Answer`, `ActionCase`, or `DecisionReceipt`; Eve does not infer their authority.
6. Eve renders the result in her voice, with citations and uncertainty preserved, then appends the output and new Focus.

If the model crashes after a capability call, the invocation receipt and RequestKey make turn recovery replay-safe. If two channel messages race, the relationship stream uses an expected revision and deterministically forks or orders the turns before focus advances.

## 6. Storage and event model

### Physical model

```text
PostgreSQL — authoritative sparse/control plane
  releases + release heads + evaluated candidates
  memberships + delegations + effective entitlements
  objects + type membership + identifier assignments
  artifact metadata + sparse claims + adjudications
  world commits + cuts + causal events + transactional outbox
  action cases + decisions + effect intents + settlement index
  watches + cursors + findings + attention receipts
  Eve relationships + ordered turn events + focus refs

Content-addressed object storage — immutable bytes
  raw provider/user/document artifacts
  release/function/mapping bundles
  large explanation payloads and signed export packages
  Arrow/Parquet observation segments and immutable manifests

Columnar query/index runtime — derived, rebuildable acceleration
  observation range scans, downsampling, aggregations
  object/set indexes and permitted search projections

Restate — only external-effect execution
  effect attempt/retry/reconciliation workflows
```

PostgreSQL is the transactional authority, not the universal analytical store. Object storage is immutable content, not an authority database. Columnar indexes are replaceable projections, never sources of truth. Restate knows effect workflows, not conversation continuity. No Redis exists. No cache can mint a receipt or change a cut.

### Selective event orientation

Zoen is event-oriented but not universally event-sourced.

- Eve's interaction stream is event-sourced because ordered conversation, recovery, and retention are the domain.
- Meaning publication, identity adjudication, claim admission, Decisions, Watch evaluations, and settlement transitions emit immutable domain events in the same transaction as authoritative current state.
- Current World state is stored transactionally and need not be reconstructed from every event for ordinary reads.
- Dense observations publish one `ObservationSegmentAdmitted` or `ManifestAdvanced` event per meaningful immutable slice, never one event per point.
- Derived indexes consume the transactional outbox. Delivery may be at least once; consumers are idempotent by `EventId` and manifest/commit digest.

An event is a meaningful transition with causality, not an internal function call serialized for fashion.

### Concurrency and idempotency

**World commits.** Every ActionCase carries a minimal read set and expected aggregate revisions. Decision commit runs one serializable transaction that:

1. verifies `RequestKey` has not been used with a different intent digest;
2. reauthorizes the decision at the pinned release and current membership/entitlements;
3. compares the read set and expected revisions;
4. returns `StaleCase(materialDiff)` if any decision-relevant state changed;
5. writes all semantic changes, Decision, effect intents, domain events, and outbox rows;
6. advances one World-local `KnowledgeCut`;
7. returns the same receipt on an identical retry.

There is no global database lock. Writes serialize only on the aggregates whose invariants they change; immutable contributions from independent sources do not contend. Multi-object domain Actions use one transaction and an explicit revision set.

**Release publication.** `publish(candidate, expectedHead)` is compare-and-swap on the World head. A concurrent release produces a semantic rebase requirement. Publishing never mutates an existing release.

**Observations.** Segments are immutable and uploaded before publication. Manifest advancement compare-and-swaps one series revision. Overlapping corrections produce a new segment and manifest; a released selection policy chooses the active vintage. Orphan uploads are unreachable content and safely collectible after a grace period. Readers see either the previous complete manifest or the new complete manifest, never partial publication.

**Interaction.** Inbound channel delivery uses a channel delivery ID plus content digest. Duplicate delivery returns the prior turn receipt. Competing turns use relationship revision; focus advances only once. Tool invocations have their own RequestKeys so a response retry cannot duplicate an Action.

**Effects.** `EffectId = hash(DecisionId, effect ordinal, released effect kind)`. Restate retries the same ID. A connector uses destination idempotency when available; without it, timeout becomes `unknown` and reconciliation is mandatory. The World Decision never rolls back because a network response was lost.

**Watches.** Evaluation atomically advances `(WatchId, throughCut)` with its AttentionReceipt. Reprocessing the same cut range returns the same receipt and cannot deliver twice. Delivery is an Effect with a deterministic ID.

### Point-in-time and multiple clocks

Every semantic result is a function of:

```text
WorldRelease
× valid coordinate
× knowledge cut/as-known-at
× belief policy
× principal/delegation
× purpose
× effective entitlements
```

This basis is sealed into cursors, cases, scenarios, answers, and receipts. Pagination authorization happens before candidate discovery; hidden objects cannot alter counts or cursors. Derivations and exports are reauthorized because rights may constrain purpose, display, retention, and redistribution differently.

Claims and observations preserve the clocks required by their domain. Financial facts may carry economic period, accession/publication, provider observation, retrieval, listing validity, and corporate-action effective time. Clinic data may carry specimen, result, filing, and correction time. The release defines the clock vocabulary and query policies; the core never invents a universal “timestamp.”

### Personal to institutional scale

Scale changes placement, not semantics.

- A World is the unit of authority, release head, and knowledge cut. It may represent one person, a family, a clinic, a fund, or a factory.
- Sparse authority partitions by World and aggregate; dense observations partition by series, time, and access domain.
- Shared provider artifacts can be content-deduplicated while each World holds its own semantic bindings, belief policy, rights, and decisions.
- `ObjectView<T>` contains typed scalar beliefs, links, available Actions, and `SeriesRef`s. The same semantic query planner chooses transactional or columnar physical paths behind one Answer contract.
- Personal reads may run against a handful of rows; institutional reads may compile an authorized object-set plan into vectorized scans. Both return the same basis and explanation shape.
- A rights-aware `WorldArchive` exports releases, identity, permitted evidence, decisions, Watch definitions, and receipts. Licensed bytes that cannot move remain referenced with a legible portability gap instead of being silently copied.

### Deployment topology

One coherent Fly application contains independently supervised logical runtimes:

```text
edge ingress
  ├─ Door / Better Auth
  ├─ Eve HTTP + messaging channels + Living World
  ├─ Ontology API + CLI tunnel + MCP
  ├─ release/attention/ingestion workers
  └─ effect gateway to Restate

durable services
  ├─ PostgreSQL
  ├─ content-addressed object storage
  └─ Restate (Effects only)
```

These are process boundaries for failure isolation, not microservice products. The default deployment is a modular monolith with explicit ports. Components may scale independently when workload proves it, while release identity, receipts, and policy remain one kernel contract.

## 7. Canonical journeys

These are executable product journeys against real products and stores. They replace neither semantics nor production observability with mocks.

### Journey 1 — from ordinary language to earned attention

1. A new person tells Eve, “Tell me if anything material changes about my IBM position.”
2. Door proves Account; Ontology proves World membership.
3. Identity resolution returns many IBM candidates. Eve asks one venue/currency question and records an accepted assignment through a domain identity Action.
4. Eve creates a concentration/material-change Watch with a visible interruption contract.
5. Duplicate source deliveries advance no duplicate manifest or notification.
6. Unimportant changes produce inspectable `silent` AttentionReceipts.
7. A material change produces one interruption with basis, evidence, rivals, and a Focus that opens identically in Living World.

**Proof:** first-minute usefulness, explicit ambiguity, quiet-by-default attention, cross-surface continuity, idempotent delivery.

### Journey 2 — challengeable truth and as-of reconstruction

1. Two providers assert different closing prices for one resolved listing under explicit venue, currency, calendar, adjustment, and publication semantics.
2. Raw artifacts are content-addressed; mappings and rights are pinned.
3. A belief policy selects one value for portfolio-management while retaining the rival.
4. The user asks “why?” and sees source, mapping, quality, exclusion, and uncertainty without unauthorized fields.
5. A provider correction creates a new claim/segment vintage.
6. `knownAsOf` before and after the correction reproduces both answers.

**Proof:** evidence is not belief, four-clock discipline, resolution receipts, no historical overwrite, entitlement-safe explanation.

### Journey 3 — one semantic field, institutional observation volume

1. A fund ingests one year of OHLCV for 10,000 listings as immutable columnar segments.
2. One manifest commit advances each admitted synchronization slice; no scalar event exists per cell.
3. An authorized object-set query computes exposure and downsamples a series at a pinned frame.
4. A personal World runs the same query over five holdings and receives the same Answer type.
5. A 20-day volatility claim cites exact manifest revisions, ranges, function digest, and basis.
6. A principal with display-only rights can inspect but cannot export; an unauthorized principal cannot infer hidden population from counts or cursors.

**Proof:** physical scale without conceptual fork, field comparability, pre-discovery entitlements, causal derived metrics.

### Journey 4 — governed decision, ambiguous external reality

1. Eve or an MCP agent invokes `rebalancePortfolio` under its own policy.
2. The Action engine builds before/after consequences and detects that a limit price is the only unresolved decision.
3. The person answers. Commit atomically changes the World and records deterministic broker EffectIntents.
4. A retry returns the same DecisionReceipt and does not submit twice.
5. One broker leg succeeds; another times out. The receipt says `unknown`.
6. Restate reconciles later and appends settlement evidence; the Decision remains unchanged.
7. Running the proposal inside a Scenario can never emit the orders.

**Proof:** exact decision request, stale/read-set safety, commit versus settlement, effect idempotency, scenario/live separation.

### Journey 5 — conversation continuity without conversational authority

1. A person investigates a patient, portfolio, or machine in Living World, selecting a historical basis and opening a rival claim.
2. They continue in WhatsApp or Telegram. The message contains readable text, not UI chrome.
3. Eve receives an authority-free FocusRef and opens it using a fresh channel/account proof.
4. Revoking membership before the turn causes capability disclosure to shrink; the old Focus reveals nothing.
5. Eve answers from the same semantic subject/time basis or explicitly says which basis was advanced.
6. A model crash after an Action call resumes from the invocation receipt without duplicating the world change.

**Proof:** zero semantic context loss, no credential in focus, revocation safety, Eve durability, channel flattening.

### Journey 6 — teach a World and release it atomically

1. A clinic builder adds `DiabetesFollowup`, a patient-link constraint, an A1C trend function, an EHR mapping, an Action, a Watch, and field-level policy in one draft.
2. Semantic diff reveals an identifier/cardinality conflict and an MCP disclosure change.
3. Real journeys run against isolated draft meaning and representative evidence.
4. A concurrent draft publishes first; the second cannot overwrite head and receives a semantic rebase.
5. After review, publication atomically moves the World head; all native surfaces acquire the same new capability IDs.
6. Rollback moves head to a prior release while old decisions and explanations remain pinned to their original releases.

**Proof:** release closure, builder comprehensibility, policy/surface impact, atomic publication, historical explainability.

## 8. Build slices

Each slice ends in a user-visible journey and leaves no transitional API behind.

### Slice 0 — one honest frame

Build Door proof adaptation, World membership, minimal released object/field/query, `WorldBasis`, `Answer`, `FocusRef`, Eve turn persistence, and one Living World object view.

**User value:** ask Eve one question and open the exact answer in Living World.  
**Exit proof:** membership revocation, as-of basis, restart recovery, and no authority in Focus.

### Slice 1 — identity before convenience

Build explicit object membership, identifier assignments, plural resolution, raw artifacts, and one identity adjudication Action.

**User value:** Eve resolves an ambiguous real-world subject instead of guessing.  
**Exit proof:** the IBM-style ambiguity journey from raw acquisition to explanation.

### Slice 2 — truth you can challenge

Build sparse Claims, released belief policy, rivals, resolution receipts, causal Explain, source-bound admission, and property/purpose rights.

**User value:** every important answer says what Zoen believes, why, what disagrees, and as of when.  
**Exit proof:** two providers plus correction, with no discovery/cursor/citation leak.

### Slice 3 — attention that earns interruption

Build Watch templates, transition interests, deterministic detectors, cursors, significance/cooldown/budget policy, silent receipts, and effect-backed channel delivery.

**User value:** the first Personal Watch works end to end and is quiet by default.  
**Exit proof:** duplicate/reordered events, quiet hours, one material interruption, exact Focus continuation.

### Slice 4 — decisions that do not lie

Build released domain Actions, consequence cases, typed decision questions, read-set staleness, atomic DecisionReceipt, EffectIntent, and Restate settlement/reconciliation.

**User value:** Eve helps make and carry out one consequential real decision safely.  
**Exit proof:** multi-leg operation with one unknown result, retry safety, and later reconciliation.

### Slice 5 — dense reality

Build observation semantics, immutable segments/manifests, columnar range execution, correction vintages, derived-claim lineage, incremental projection, and rights-aware export.

**User value:** Bloomberg-grade comparable series and institutional-scale analysis without changing the personal product model.  
**Exit proof:** 10,000-listing journey plus the same query in a family World.

### Slice 6 — Worlds can evolve

Build release drafts, semantic/data/policy/surface impact, real journey evaluation, typed `EvaluatedCandidate`, compare-and-swap publish, rollback, ScenarioFrame, and native surface compiler.

**User value:** a builder can teach Zoen a new operational domain and publish it safely to Eve, CLI, API, MCP, and Living World.  
**Exit proof:** clinic release journey, surface semantic parity, concurrent draft rebase, historical receipts intact.

## 9. Rejected shapes

The architecture explicitly deletes these attractive ideas:

- **A universal event-sourced database.** Interaction and effect workflows merit replay logs; ordinary sparse state and dense observations do not need every byte reconstructed through events.
- **A generic seven-verb product language.** Discover/query/propose/approve/commit/execute are implementation lifecycle words. Users get released domain Actions. One internal invocation protocol is enough.
- **A universal graph/triple store.** Typed objects, links, fields, and object-set plans hide more complexity and enforce more invariants. Provenance can be graph-shaped without making RDF the mutation API.
- **Provider endpoints as ontology.** Providers acquire evidence. Their route trees, symbols, payloads, and “extra fields” do not define subjects, comparable fields, or truth.
- **A transcript, vector database, or LLM memory as the World.** Conversation preserves relationship context; World records preserve meaning and authority. Embeddings are rebuildable indexes only.
- **One record type for artifact, claim, observation, accepted belief, and decision.** Their lifecycles, clocks, rights, and authorities differ. A tagged mega-record would spread optional-field rules everywhere.
- **A `Context` bag passed through every layer.** `WorldFrame` pins semantic coordinates; a server-side permit carries authority. Focus carries continuity. No object contains arbitrary transport/session/provider state.
- **The same branch abstraction for releases and scenarios.** Meaning drafts can publish; scenarios can hypothesize. Their type capabilities are intentionally incompatible.
- **Agent-direct mutation.** Agents invoke the same released Actions as people under delegated policy. No tool gets raw CRUD, arbitrary SQL, or ambient World credentials.
- **Commit equals external success.** A DecisionReceipt and a Settlement are separate forever.
- **One claim/event per market tick or telemetry point.** Dense data advances immutable manifests; semantic events summarize meaningful transitions.
- **Always-on MCP tool exhaust.** Capabilities are filtered and progressively disclosed by semantic neighborhood before descriptions enter context.
- **A fourth governance, dashboard, studio, or data product.** Builder and Living World experiences are modes of Ontology and Eve, not new products.
- **Microservices, Kafka, Redis, and distributed sagas by default.** One modular deployment, PostgreSQL transactional outbox, immutable object storage, and Restate for Effects cover the actual authority boundaries. Distribution is earned by measured workload.
- **Cloning Palantir breadth or Bloomberg's terminal chrome.** Adopt operational meaning, governed Actions, identity, entitlements, point-in-time rigor, and dense-data discipline; delete their organizational surface area from the initial product.
- **A plugin marketplace before one irreplaceable journey.** First make Personal Watch, challengeable truth, and one real Action inevitable. Extensibility follows release semantics, not the reverse.
- **Compatibility layers for a product that has not launched.** Each build slice replaces its temporary predecessor atomically. No aliases, dual writes, or legacy mental models survive.

## 10. Rationale

### Problem

The ambition combines an intimate relationship, an operational decision ontology, and institution-grade identity/data semantics without producing three disconnected mental models or a platform-sized codebase. The non-obvious part is authority: conversation, evidence, accepted belief, decisions, attention, and external settlement all feel continuous to a person but cannot safely share one mutable “state.” Dense observations also require a different physical path from sparse governed truth. The design must make those distinctions unavoidable while keeping the caller's surface smaller than the machinery it hides.

### Usage

A person expresses intent once, receives a precise clarification only when identity is ambiguous, and gets a Watch that stays silent until evidence materially changes the decision. An operator invokes released domain capabilities and receives basis-pinned Answers or the one remaining DecisionQuestion. A builder prepares and publishes one evaluated WorldRelease closure. An agent discovers only authorized semantic neighborhoods through MCP and receives the same receipts as a human. Conversation and Living World exchange an authority-free FocusRef and independently open a fresh authorized WorldFrame.

### Shape

The recommended shape is **one frame, seven records**. `WorldFrame` is the single evaluation coordinate; it eliminates ambient time, release, belief, purpose, and authority from call chains, per boundary-discipline. Meaning, identity, truth, agency, attention, interaction, and external reality have separate records because each answers a different authoritative question, per model-the-domain and separate-before-serializing-shared-state. Evidence, claims, observations, beliefs, decisions, and settlements are distinct types, so forbidden transitions are unrepresentable, per encode-lessons-in-structure and type-system-discipline.

The public interface is deep: open a World, inspect, invoke a released domain Action, install a Watch, explain, or create a read-only Scenario. It hides identity resolution, rights filtering, belief selection, query planning, concurrency, persistence, causality, and native surface adaptation. The only staged continuation, `case.answer`, corresponds to a real unresolved human/quorum decision rather than temporal implementation decomposition. Release authoring is separately deep: `prepare` absorbs compilation, diff, impact, and real journey evaluation; `publish` accepts only an evaluated candidate.

Selective event orientation records meaningful transitions without forcing dense values or current state through universal replay. A World-local cut, release-pinned basis, explicit clocks, revision read sets, scoped RequestKeys, immutable observation manifests, and Decision-versus-Settlement receipts make retries, races, corrections, and uncertainty visible. Semantic capability compilation gives every surface native ergonomics without making any transport the source of truth. This concentrates complexity in the kernel and keeps call chains short, per minimize-reader-load.

### Synthesis decision

Pending arena synthesis. Candidate B proposes `WorldFrame` plus seven authority records as the base shape. Its distinctive bets are authority-free Focus continuity, Action calls that return only the unresolved decision, receipt-bearing silence for Watches, and compile-time separation of release drafts, live frames, and scenario frames.

### Tradeoffs accepted

- We accept more explicit domain types in exchange for making false equivalence between evidence, belief, decision, and settlement impossible.
- We accept a content-addressed release closure larger than a schema revision in exchange for reproducible meaning across mappings, policies, functions, and surfaces.
- We accept a transactionally authoritative PostgreSQL control plane plus a separate columnar observation plane in exchange for scale without a second semantic product.
- We accept that some answers vary by purpose and principal in exchange for honest entitlements and purpose-specific belief; receipts make the variation explainable.
- We accept ActionCase persistence and optimistic revalidation in exchange for human deliberation that can safely span seconds or days.
- We accept durable silent AttentionReceipts in exchange for accountable proactivity and debuggable non-notification.
- We accept native per-surface compilers in exchange for avoiding a lowest-common-denominator API or hundreds of always-on tools.
- We accept a modular monolith initially in exchange for one-engineer comprehensibility and transactional clarity; physical runtimes can split behind stable ports when measured load requires it.

### Alternatives considered

**One universal append-only event log.** It simplifies the slogan and makes replay attractive, but exposes ordering, partitioning, projection lag, and per-point volume to every caller and module. It hides less domain complexity than the seven-record model and makes dense observations pathological.

**Palantir-shaped object/action platform plus a separate chat agent.** It provides familiar nouns and powerful infrastructure, but conversation continuity, attention, decision questions, and external uncertainty remain application glue. Callers must coordinate ontology APIs, agent sessions, workflows, and notification systems. The frame/record shape hides those joins while preserving Palantir's useful semantic rigor.

**A single `WorldState` graph with generic mutations.** It is initially easy to implement and extremely shallow: every caller must know identity, provenance, authorization, cardinality, concurrency, and settlement rules. Generic CRUD leaks internal representation and makes domain Actions optional. It loses on interface depth.

**Actor-per-object event sourcing.** It gives elegant local concurrency but makes multi-object Actions, purpose-specific belief, set queries, and institutional analytics cross-actor orchestration problems. The chosen design uses immutable source contributions plus transactional revision sets, keeping conflicts local without turning reads into distributed merges.

### Open questions and risks

- Which first World makes Personal Watch emotionally indispensable while still exercising identity ambiguity, evidence rivalry, and one meaningful Action?
- Which belief policies must be universal kernel primitives, and which should always be released domain functions?
- Should a World-local KnowledgeCut remain a single monotonic sequence at the highest expected institutional write rate, or should federated cuts be introduced only after measured contention?
- What minimum portable archive is legally useful when licensed observations cannot leave their provider's access domain?
- Which domain Action deserves the first real external-effect integration where `unknown` settlement can be tested honestly?
- How much of an Attention detector must be deterministic, and when is a digest-pinned model acceptable if its uncertainty and evidence are retained?
- Should shared identity objects exist only inside each World for sovereignty, or can an explicitly federated identity authority be referenced without becoming a fourth product?
- Which semantic presentation hints are sufficient for Eve and Living World without smuggling layout configuration into the release core?

### Next implementation step

Build Slice 0 as one executable journey—Door proof → Eve turn → authorized WorldFrame → basis-pinned Answer → authority-free Focus → identical Living World continuation—before designing any additional provider, dashboard, or workflow surface.
