# Zoen greenfield architecture — cross-judge verdict

## Verdict

Use **Candidate B, “one frame, seven records,” as the base architecture**, but do not ship Candidate B unchanged. It has the strongest product-to-kernel correspondence and the deepest public interface: an authority-free `Focus` opens an authorized `WorldFrame`; the frame yields an `Answer`, domain `ActionCase`, `Watch`, or read-only scenario; a decision yields a `DecisionReceipt`; external settlement remains a separate truth. The seven records are useful because they are seven authorities, not seven APIs, services, or database tables.

The mandatory correction is to replace Candidate B's attention/delivery ownership with Candidate C's strict **Watch → Notice → Eve** boundary. Candidate B currently lets Ontology decide interruption budgets/channels and models delivery as an external Effect. That contradicts its own three-product boundary. Ontology should decide only that a World change is materially worth consideration and may prepare a Case; Eve alone should decide silence, defer, merge, timing, channel, wording, and delivery within the relationship.

Then graft a small set of Candidate A's concurrency and admission invariants into B. Do not import A's entire public vocabulary or module inventory. The resulting architecture is one recognizable shape, not an average:

```text
authority-free Focus
    ↓ fresh Door proof + World membership/purpose/delegation
authorized WorldFrame
    ├─ Answer + explanation
    ├─ domain Action → ActionCase → DecisionReceipt
    │                                  └─ EffectIntent → Settlement
    ├─ Watch + semantic delta → Notice → Eve attention/delivery
    └─ read-only Scenario → fresh live ActionCase if applied
```

Meaning, identity, truth, agency, attention, interaction, and external reality remain separate authorities. Interaction belongs exclusively to Eve; the other six belong to Ontology. Door proves account/session/device identity and nothing more.

## Scorecard

Scores are diagnostic, on a 10-point scale. The total does not substitute for the structural decision; a fatal ownership leak matters more than a decimal.

| Grounding criterion | Candidate A | Candidate B | Candidate C |
|---|---:|---:|---:|
| Product inevitability | 9.4 | **9.8** | 9.5 |
| Semantic integrity | **9.7** | 9.1 | 8.5 |
| Interface depth | 8.7 | **9.6** | 9.0 |
| Event/concurrency rigor | **9.8** | 9.5 | 9.0 |
| Personal-to-institutional scale | **9.8** | 9.7 | 9.1 |
| Subtractive elegance | 8.0 | 8.8 | **9.4** |
| **Total** | **55.4** | **56.5** | **54.5** |

## Criterion-by-criterion judgment

### 1. Product inevitability

**Candidate A — 9.4.** The household-runway promise is coherent from first sentence through Watch, Living World, consequential Action, and settlement. It makes “silence is success” tangible and gives the builder a credible release workflow. Its weakness is presentational: the product experience is followed by so much architecture vocabulary that the irreducible product object is less memorable than in B or C.

**Candidate B — 9.8.** Best candidate on this criterion. The IBM ambiguity, material-change Watch, exact rebalance decision, unknown broker leg, and builder hour all feel like one product rather than a feature inventory. `Focus` is especially strong: conversation and Living World preserve subject/time/evidence/pending decision without carrying authority. “One frame, seven records” gives the user experience and engineering model the same spine.

**Candidate C — 9.5.** `Frame → Case → Receipt` is the clearest product vocabulary of the three, and its cash-runway experience is excellent. `Watch → Notice` is also the cleanest proactivity model. It loses a little because the first build journey falls back to ticker/venue resolution and because the `Lens` abstraction is less self-evidently a product object than B's authority-free Focus.

### 2. Semantic integrity

**Candidate A — 9.7.** Strongest overall semantics. It makes Door proof and World authority different types; pins release, valid time, knowledge cut, belief and policy; separates artifacts, assertions, belief, identity resolution, decisions, effects, and settlement; authorizes before discovery; and preserves rivals. The one substantial flaw is attention ownership: `AttentionContract` includes quiet hours, budget, urgency, and escalation inside Ontology while the prose also assigns those decisions to Eve. That is duplicated policy and must be removed.

**Candidate B — 9.1.** Its seven authority records are a powerful defense against ambient truth, and its short-lived authorized frame plus authority-free Focus is better than passing a generic context bag. However, its Watch contract includes quiet hours, interruption budget, and channels; `AttentionDecision` decides interrupt versus silence inside Ontology; and delivery is modeled as an `EffectId`. That lets Ontology impersonate Eve's relationship authority. It is a serious but localized defect. B also needs to distinguish release compilation from per-principal disclosure more sharply; authorization should filter discovery at runtime, not cause a new compiled surface artifact for every audience.

**Candidate C — 8.5.** C gets the key authority boundaries right, especially Watch materiality versus Eve delivery and scenario versus release. Its integrity losses are specific: `WorldGrant` can carry multiple purposes, creating a confused-deputy risk; `EvidenceTime` is a tagged union that can discard simultaneous observed, published, retrieved, economic-period, and effective clocks; and `WorldCut { observationManifest: ManifestId }` is underspecified for a World containing many independent series unless that ID is explicitly a snapshot-root digest. Those are foundational, not documentation polish.

### 3. Interface depth

**Candidate A — 8.7.** Five kernel operations hide a great deal of policy, temporal selection, resolution, query planning, transactions, effects, and proof. But `prepare<A: ActionOrWatchCapability> → ActionOffer<A>` collapses two different product promises into generic machinery. Its public `Basis` also carries more authority plumbing than callers should need to understand. The many named modules are individually defensible but increase reader load.

**Candidate B — 9.6.** Best deep interface. `open`, `inspect`, domain `invoke`, `watch`, `scenario`, and `explain` correspond to complete user intentions, not load/validate/save phases. `DecisionHandle.answer` is justified because it represents a genuine human or quorum pause. Generated domain methods retain native vocabulary while the kernel hides transport, storage, resolution, policy, concurrency, and settlement. The seven records are internal authorities and do not force the caller to coordinate seven services.

**Candidate C — 9.0.** `Frame`, `Case`, `Receipt`, and `Notice` are excellent deep results. The weakness is that public `Lens<T>` admits `ObjectPlan | FunctionCall | SituationPlan`, which risks leaking compiler/query-plan representation into callers. `SourceAdapter.acquire`, `normalize`, then `EvidenceGateway.admit` is also stage-shaped: an ordinary ingestion caller must coordinate a temporal pipeline instead of invoking one source-owned contribution operation.

### 4. Event and concurrency rigor

**Candidate A — 9.8.** Most complete treatment. It specifies a serializable World transaction, exact read sets, sorted aggregate locking, typed idempotency identity, deterministic Effect IDs, transactional outbox, causal roots and parents, at-least-once consumers, immutable artifact-before-admission semantics, orphan collection, manifest cuts, and honest `Unknown` settlement. It also correctly refuses per-point events.

**Candidate B — 9.5.** Nearly as rigorous, with compare-and-swap release heads and manifests, precise retry semantics for interactions/actions/effects/Watches, and explicit knowledge cuts. Its weak point is durable `AttentionReceipt` for every silent evaluation: that risks turning unchanged observation progress into authority-log write amplification. Silence should remain reconstructable from immutable inputs and compact checkpoints without an append-only receipt for every poll or cut.

**Candidate C — 9.0.** It has exact Case read sets, intent-digest idempotency, deterministic reactor keys, transactional receipt/event/outbox writes, immutable segment admission, and correct external ambiguity. The manifest component of `WorldCut` and the multi-clock model need correction before the replay/as-of claim is fully credible. It is also less explicit than A about root causality and aggregate lock ordering.

### 5. Personal-to-institutional scale

**Candidate A — 9.8.** Best physical detail while preserving semantics. Sparse authority remains temporal/relational; dense observations use immutable columnar segments and manifest DAGs; both return the same `Basis`, `Frame`, and proof. It explains corrections, compaction, rights, point-in-time cuts, federation, and a 10,000-listing journey without creating an enterprise-only product model.

**Candidate B — 9.7.** Equally strong conceptually: the World is the authority/release/cut unit, physical execution changes behind the same Answer and domain capability, and rights are enforced before enumeration. It is slightly less explicit than A about observation manifest proof equivalence and admission ordering, but its external conceptual model is cleaner.

**Candidate C — 9.1.** The two-plane design, object-plan compilation, rights pushdown, and shared Frame contract are correct. It has less detail about concurrent manifest families, comparable-field governance, and high-volume cut mechanics. The mandated Rust/TypeScript split is also premature complexity rather than a scale invariant.

### 6. Subtractive elegance

**Candidate A — 8.0.** A is exceptionally complete but not yet the smallest coherent explanation. `WorldRelease`, two Basis halves, five protocol methods, Studio, ten Ontology modules, six Eve modules, multiple receipt varieties, bundle portability, federation, and eight slices are too much to hold before the central shape becomes obvious. Much of it should remain implementation detail or later capability, not architecture headline.

**Candidate B — 8.8.** The “one frame, seven records” rule compresses the system well and the public interface remains small. The score is reduced by the attention ownership duplication, by possible per-audience surface compilation, and by the risk that teams literalize seven records into seven services/stores. Those are removable without changing B's shape.

**Candidate C — 9.4.** Most concise and best at naming the atomic read and change products. Its rejected-shapes list is disciplined. It stops short of a higher score because `Lens`, the staged source adapter, a multi-purpose grant, and a prescribed Rust/TypeScript boundary add complexity at exactly the boundaries the design claims to simplify.

## Design-red-flag screen

### Candidate A

- **Information leakage — material.** Quiet hours, interruption budget, urgency, and escalation appear in Ontology's `AttentionContract` while Eve also owns relationship arbitration. One decision would require coordinated changes across products.
- **Generic-mush risk — material.** Treating `ActionOrWatchCapability` uniformly as `ActionOffer` hides the fact that a Watch is an ongoing promise and an Action is a proposed state transition.
- **Shallow/pass-through risk — moderate.** `protocol` can become a forwarding façade over authority/reality/agency unless it alone owns binding release, basis, authorization order, and receipt conformance. Generated domain methods must adapt domain semantics, not merely relay identical arguments.
- **Reader-load risk — high, though not one of the four mechanical red flags.** Too many correct concepts are elevated into the main architecture. Portability, federation, and some proof taxonomy should remain behind the selected primitives until a journey requires them.

### Candidate B

- **Information leakage — critical as written.** Ontology owns quiet hours/budgets/channels and decides interruption while Eve owns the relationship. `watch: attention → reality(delivery)` additionally turns conversation delivery into Ontology settlement. This must be redesigned, not documented around.
- **Information leakage — moderate.** `SurfaceCompiler.compile(release, disclosed)` can couple principal-specific authorization to build artifacts. Compile semantic/native projections from the release; filter capability discovery and data at runtime using the frame permit.
- **Shallow-module risk — moderate.** “Seven records” must stay an authority partition. Creating one repository/service/event stream per record would expose lots of coordination while hiding little.
- **Write-amplification risk — moderate.** Appending a permanent silent receipt for every Watch evaluation approaches universal event sourcing. Persist a compact cursor/checkpoint; emit durable Notice/meaningful state events only when semantic state changes.

### Candidate C

- **Information leakage — material.** Public `Lens` exposes `ObjectPlan`, `FunctionCall`, and `SituationPlan`. Those are private compiler/query IR; callers should use released domain capabilities and Focus.
- **Temporal decomposition — material.** `SourceAdapter.acquire → normalize → EvidenceGateway.admit` makes the caller orchestrate provider stages and know intermediate representations. One ingress operation should own acquisition, immutable capture, deterministic mapping, validation, rights binding, and admission; replay may be a separate audit operation.
- **Pass-through risk — moderate.** Generated bindings across a mandatory Rust/TypeScript boundary may become wrappers that repeat the same shapes without adding policy or adaptation. Language/process placement should follow measured needs, not define the domain architecture.
- **Authority leakage — material.** A `WorldGrant` containing multiple purposes invites code to choose purpose after authority is minted. Mint one grant/frame for one purpose.
- **Temporal semantic loss — critical.** A tagged `EvidenceTime` alternative cannot represent all simultaneously applicable clocks. Use a common multi-clock envelope plus released domain-specific clocks.
- **Cut ambiguity — material.** One `observationManifest` field is insufficient unless it names a content-addressed snapshot root over every visible manifest. Do not imply a single series manifest closes World knowledge.

## Exact synthesis

### Keep from Candidate B — the base

1. **The organizing rule:** one authorized `WorldFrame`; seven non-interchangeable authority records.
2. **Authority-free continuity:** `FocusRef` contains subject, semantic target, temporal intent, evidence selection, and pending Case/Watch references, but never credentials or permits. Every surface reopens it with fresh authority.
3. **The public spine:** generated domain queries and Actions over `LiveWorld`, plus `watch`, `scenario`, and `explain`; no public CRUD or lifecycle verbs.
4. **The genuine continuation:** an Action returns either a committed result, an impossible safe explanation, or exactly one `ActionCase`; `case.answer` is the only staged continuation because it represents a real unresolved decision.
5. **Seven authorities:** Meaning, Identity, Truth, Agency, Attention, Interaction, External Reality. Keep these as ownership rules, not deployables.
6. **Release-native surfaces:** one semantic capability catalog with native CLI/API/MCP/Eve/Living World facets and stable semantic identities.
7. **Personal/institutional sameness:** sparse and dense physical planes behind the same Frame, Answer, rights, and explanation contract.

### Graft from Candidate C — without changing B's shape

1. Replace B's `AttentionDecision` with C's **`Notice`**. Ontology may produce `Notice { before, after, materialDelta, whyNow, preparedCases }`; it may not choose a channel, quiet hour, relationship budget, prose, or dispatch.
2. Make the Watch capability explicit: it may **notice or prepare**, never decide or cause an external effect. Creation/update/cancel remain governed domain operations, but Watch evaluation is not an ActionCase.
3. Put `defer`, `merge`, `silence`, interruption budget, quiet hours, channel choice, and delivery receipt exclusively in Eve's interaction authority.
4. Preserve C's explicit unforgeable scenario mode: a scenario can inspect and consider, but its type cannot decide, publish, acquire new evidence, or form `EffectIntent`. Applying it always prepares a fresh live ActionCase.
5. Use a disclosure-safe terminal result equivalent to `not-found-or-not-disclosable` wherever revealing which condition failed would leak ontology or entitlement structure.

### Graft from Candidate A — invariants, not extra surface

1. Internally mint one short-lived `ExecutionGrant` for exactly one World, principal, purpose, release constraint, membership revision, delegation chain, audience partition, and expiry. Door proof cannot construct it; Focus cannot carry it.
2. Make each ActionCase opaque, signed/content-bound, expiring, and pinned to release, authorized audience, exact intent digest, policy decision, and read set. The read set includes relevant object/link revisions, belief receipts, and observation watermarks/manifests.
3. Use typed/scoped `OperationKey + intent digest`: identical replay returns the original receipt; key reuse with different intent is a conflict.
4. Commit semantic changes, DecisionReceipt, deterministic EffectIntents, meaningful events, and outbox entries in one serializable transaction. Acquire locks in stable aggregate-key order; no partial multi-object Action.
5. Give every meaningful event a World cut, stream revision, actor, release, root cause, immediate parent, payload digest, and recorded time. Promise at-least-once delivery with consumer idempotency, not exactly-once messaging.
6. Use source-specific acquisition identity over provider/capability/canonical request/window/checkpoint/adapter/source-contract. Persist raw immutable bytes before admission; deterministically map under the release; atomically admit assertions or manifest deltas; collect unreachable objects later.
7. For Watches, persist compact checkpoints/watermarks and deterministic detector versions. Do not append an authority event for each unchanged point or poll. A material Notice is durable and deduplicated.
8. Preserve A's settlement rule: a provider timeout may become `Unknown`; automatic retry is allowed only when the connector contract proves idempotency, otherwise reconcile or ask for a new decision.

## Exact rejections

These shapes do not survive synthesis:

- Reject Candidate B's Ontology-owned quiet hours, interruption budget, channels, `AttentionDecision`, and Effect-backed conversation delivery.
- Reject Candidate B's per-principal compilation interpretation. Compile release semantics once; authorize before runtime discovery and execution.
- Reject any interpretation of B's seven records as seven services, seven databases, seven public APIs, or seven event streams.
- Reject Candidate A's `ActionOrWatchCapability → ActionOffer` unification. An ongoing Watch is not a disguised one-shot Action.
- Reject Candidate A's public exposure of an authority-heavy Basis. Callers need the reproducible World basis and an explanation/audience receipt; the live grant remains opaque and server-side.
- Reject Candidate A's ontology-level relationship settings and the temptation to elevate portability/federation into first-slice primitives.
- Reject Candidate C's caller-authored `ObjectPlan`/`FunctionCall` inside public Lens. Planning is private; public calls are released domain capabilities.
- Reject Candidate C's multi-purpose WorldGrant. Purpose is selected before grant/frame issuance.
- Reject Candidate C's tagged-union clock model. Evidence may carry several clocks simultaneously, with domain-released extensions.
- Reject Candidate C's caller-orchestrated acquire/normalize/admit pipeline.
- Reject Candidate C's mandatory Rust/TypeScript split. A language boundary is not a product or semantic invariant; earn it through measured constraints.
- Reject a single observation-manifest coordinate unless it is explicitly a Merkle snapshot root over every manifest visible at the cut.
- Reject across all candidates: universal event sourcing, provider APIs as ontology, generic public lifecycle verbs, graph storage as product model, chat/model memory as truth, definition drafts reused as scenarios, commit equated with settlement, and infrastructure promoted into a fourth product.

## Canonical target shape

The synthesized architecture should be explainable to one strong engineer in this order:

1. **Door proves identity.** Ontology derives one purpose-bound World grant. Eve never mints authority.
2. **Focus preserves continuity without authority.** Conversation and Living World open the same semantic focus through fresh authorization.
3. **WorldRelease defines executable meaning.** It closes over identity rules, evidence contracts, belief/policy programs, domain capabilities, functions, presentation facets, and real journey attestations.
4. **WorldFrame is the atomic read.** It pins release, valid-time coordinate, knowledge cut, belief policy, purpose, authorized audience, value, gaps, explanation, and exact read dependencies.
5. **ActionCase is the atomic deliberation.** It contains consequences, uncertainty, the one required choice, policy proof, expiry, and exact concurrency basis.
6. **DecisionReceipt is the atomic World change.** It proves what was decided and committed. `Settlement` separately proves what external reality later did or failed to reveal.
7. **Watch is durable intent.** Ontology turns a material semantic delta into a Notice; Eve decides whether the relationship should be interrupted.
8. **Seven authorities prevent lies.** Meaning, Identity, Truth, Agency, Attention, Interaction, and External Reality cannot overwrite or impersonate one another.
9. **Events record meaningful causal transitions.** Temporal relational authority serves current/as-of state; immutable sparse evidence and dense segments preserve history; Eve alone event-sources interaction.
10. **Scale changes execution, not language.** A household and a fund use the same Frame, Case, Watch, Receipt, proof, and entitlements; dense observations take a columnar physical path.

## Recommended first proof

The first vertical proof should combine the best first-minute wedge with the hardest invariants, without building platform breadth:

> A person tells Eve to protect six months of household runway. One ambiguous account requires one identity decision. Eve returns an evidence-backed, as-of WorldFrame and the same Focus opens in Living World. A Watch remains silent through ordinary variation, produces one Notice on a material/staleness threshold, and Eve decides when/how to interrupt. The proposed `ProtectReserve` domain Action becomes stale after a relevant balance change, is safely reprepared, commits one DecisionReceipt and EffectIntent, survives retry, reports a bank timeout as Unknown, and later reconciles.

That one journey proves the product promise, all three authority boundaries, explicit identity, evidence versus belief, point-in-time Frames, quiet attention, exact concurrency, idempotency, honest settlement, and conversation/Living World continuity. The release compiler and native surface projection should be built only as far as required to express this journey without hand-maintained semantic drift.

## Final decision

Candidate B supplies the architecture's identity. Candidate C repairs the relationship/attention boundary and sharpens the product primitives. Candidate A supplies the non-negotiable transaction, causality, admission, and settlement invariants. Keep that asymmetry. Do not merge their public models, module maps, or naming systems wholesale.

The selected sentence is:

> **Zoen is an authority-free Focus opening one authorized WorldFrame; the Frame can answer, form one domain Case, or sustain one Watch; Decisions create World Receipts, external systems create separate Settlements, and only Eve decides when the relationship should be interrupted.**
