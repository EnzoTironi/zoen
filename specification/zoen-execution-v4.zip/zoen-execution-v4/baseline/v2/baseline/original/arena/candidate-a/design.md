# 1. Product promise

Zoen is a relationship with an executable world behind it.

To a person, it feels like Eve: someone attentive enough to remember what matters, quiet enough not to demand attention, and competent enough to turn a consequential moment into one clear decision. To an operator, it feels like a living operational model: every object has identity, every value has a time basis and evidence, every available Action is lawful, and every outcome is explainable. To a builder, it is a compiler: describe the world's nouns, evidence contracts, resolution rules, domain Actions, Watches, policies, and journeys; Zoen publishes one immutable `WorldRelease` from which all usable surfaces follow.

The central loop is deliberately small:

```text
tell Eve what matters
        ↓
see a coherent Frame of the World — what, why, and as of when
        ↓
choose only when a domain Action truly needs a decision
        ↓
receive a Receipt that separates committed intent from external settlement
        ↓
let a Watch keep attending; silence unless reality changes enough to matter
```

The first minute is not configuration. The person says, “Keep an eye on our household runway. Only interrupt me if it falls below six months or one of the assumptions becomes unreliable.” Eve resolves the people, accounts, and meaning she can; asks one question only if an identity or authority ambiguity blocks the request; then shows a compact Watch contract: what is watched, which evidence is used, what earns an interruption, who may see it, and when it expires.

The first day, the same concern can be opened in Living World. It is not a dashboard next to the conversation. It is the same `FocusCapsule` rendered spatially: household, accounts, obligations, time basis, evidence, disagreements, Watch status, and available domain Actions. Returning to chat retains the subject, selected interval, evidence basis, and pending decision.

The first week, Eve may say nothing. If runway crosses the threshold, she explains the change in human terms, cites the new evidence and its freshness, and offers a domain-native Action such as “Move the tax reserve to the protected account.” If external execution is requested, the receipt first says that the World committed the decision; it says the bank confirmed, rejected, or remains uncertain only when that is actually known.

The ambition is not “personal Palantir” as a smaller enterprise console. It is a single World protocol whose scale changes physically, not conceptually. A person, family, fund, clinic, or factory uses the same meanings: resolved identity, evidence versus belief, point-in-time Frames, governed domain Actions, accountable Watches, and causal Receipts. Small Worlds have a few objects and short series. Institutional Worlds have billions of observations and complex entitlements. Neither gets a weaker ontology.

Three products are sufficient:

1. **Door** uses Better Auth to prove Account, session, and device identity. It never grants World authority.
2. **Eve** owns the relationship: conversation continuity, channels, Living World, focus, and interruption judgment.
3. **Ontology** owns Worlds: published meaning, identity, evidence, belief, queries, domain Actions, Watches, policy, receipts, external effects, and the CLI/API/MCP plus builder profile.

There is no platform product, workflow product, SDK product, data product, or governance dashboard hiding as a fourth product. Those are capabilities or projections of Ontology.

# 2. Usage (person, operator, builder, agent)

## Person

The primary interface is an ordinary conversation with unusually precise consequences.

```text
Enzo
  Keep an eye on our household runway. Don't ping me for normal variation.
  Tell me if it drops below six months, or if any account becomes stale enough
  that the number is no longer trustworthy.

Eve
  I can do that. I found two accounts called “Reserve”: your joint savings
  account and the company tax account. Should the company account be excluded?

Enzo
  Yes.

Eve
  Done. I’ll use the joint checking and savings accounts, recurring household
  obligations, and a 30-day spending baseline. I’ll stay quiet above six months.
  I’ll also tell you if a source is more than 48 hours stale. This Watch expires
  in six months unless you keep it.

  Current view: 7.4 months, known through 4 Sep at 09:12.
  [Open in Living World] [Why 7.4?] [Change the Watch]
```

The ambiguity question is not conversational flourish. Identity resolution returned two candidates, so the Watch could not be created with a `ResolvedEntity<Account>` until the person made the required decision. The confirmation creates a receipt; it does not edit a chat-memory blob.

When Living World opens, Eve and the visual surface share a `FocusCapsule`:

```text
focus: Household runway
subjects: Household:Enzo, Account:JointChecking, Account:JointSavings
valid time: today
knowledge cut: 2026-09-04T09:12:31Z / cut 1,842
belief policy: household-finance.standard@4
pending: none
watch: runway-below-six-months
```

Changing the visible period in Living World and returning to chat changes the focus event, not the World. Eve can say “that dip in February” without reconstructing context from prose.

If an Action needs a decision, Eve presents consequences and uncertainty, not a generic approval ceremony:

```text
Eve
  Moving R$20,000 to the protected account restores 8.1 months of runway.
  It leaves R$13,400 available for bills due before 15 Sep. The bank quote is
  37 seconds old. Do you want me to make that transfer?

Enzo
  Do it.

Eve
  The World committed your transfer decision as operation op_7K… .
  The bank has not confirmed settlement yet; I’m reconciling it.
```

The product never converts “committed” into “the bank succeeded.” A later message updates the same receipt when settlement is known.

## Operator

An operator uses generated domain objects and Actions rather than a generic evidence API. The following is the caller-facing client generated by an Ontology release; no transport or database type appears.

```ts
const zoen = await FamilyWorld.connect({ accountProof, purpose: "household-planning" });

const household = await zoen.households
  .byName("Enzo household")
  .at({ validAt: "2026-09-04", knownAt: "latest" })
  .open();

household.runway.value;             // MoneyDuration.months(7.4)
household.runway.basis;             // release, valid time, cut, belief policy
household.runway.why;               // authorized ProofRef, not an eagerly leaked graph
household.runway.rivals;            // visible rival assertions, if entitled

const offer = await household.actions.protectReserve({
  amount: Money.brl(20_000),
  destination: household.accounts.protected,
});

switch (offer.decision.kind) {
  case "none":
    // Policy says this Action can commit without another human choice.
    break;
  case "confirm":
    console.log(offer.consequences, offer.uncertainties);
    break;
  case "choose":
    console.log(offer.decision.choices);
}

const receipt = await offer.confirm({
  choice: "proceed",
  operation: OperationKey.random(),
});

receipt.worldCommit;                // authoritative local decision
receipt.effects[0].settlement;      // pending | confirmed | rejected | unknown
await receipt.explain();
```

The equivalent CLI is generated as domain language:

```text
zoen household show "Enzo household" --valid-at 2026-09-04 --known-at latest
zoen household protect-reserve "Enzo household" --amount BRL:20000
```

The second command previews consequences and asks inline for the required decision. There is no public `approve`, `commit-relation`, `record-claim`, or seven-verb lifecycle for a person to learn.

For an institutional operator, the call shape is unchanged:

```ts
const portfolio = await FundWorld.portfolios.byId(portfolioId).at(basis).open();
const scenario = await portfolio.scenarios.rebalance({ targets, constraints });
const offer = await scenario.actions.applyRebalance();
const receipt = await offer.confirm({ choice: "proceed", operation });
```

The larger World changes the data volume, decision policy, and number of approvals. It does not replace `Frame`, `ActionOffer`, `Basis`, or `Receipt` with an enterprise-only model.

## Builder

A builder authors one semantic source package. The builder does not hand-maintain CLI commands, API schemas, MCP tools, Eve prompts, and views independently.

```ts
const source = world("household-finance", ({ object, link, measure, rule, view, action, watch }) => {
  const Account = object("Account", {
    identity: identity.external("bank-account", { scopedBy: "institution" }),
    fields: {
      owner: link.to("Person").many(),
      balance: measure.money().evidenceRequired(),
      freshness: measure.duration(),
    },
  });

  const Household = object("Household", {
    identity: identity.native(),
    fields: {
      members: link.to("Person").many(),
      accounts: link.to(Account).many(),
      runway: measure.duration().derivedBy("calculate-household-runway"),
    },
  });

  view("Household focus", Household, ({ field, timeline, actions, evidence }) => [
    field("runway"), timeline("runway"), evidence("runway"), actions.for(Household),
  ]);

  action("Protect reserve", Household)
    .input({ amount: money("BRL"), destination: ref(Account) })
    .previewWith("preview-protect-reserve")
    .transitionWith("commit-protect-reserve")
    .effect("bank.transfer")
    .decision("explicit-confirmation");

  watch("Runway risk", Household)
    .condition("runway-below-threshold-or-stale")
    .attention("household-finance-attention");
});

const draft = await studio.build({ base: currentRelease, source });
const candidate = await studio.evaluate(draft, {
  journeys: HouseholdFinanceJourneys,
  evidenceCorpus: signedProductionArtifacts,
});

candidate.semanticDiff;
candidate.dataImpact;
candidate.surfaceDiff;
candidate.journeyProofs;

const release = await studio.publish(candidate.requirePassing(), {
  decision: builderDecision,
  operation: OperationKey.random(),
});
```

The DSL is illustrative, not a mandate that runtime meaning be TypeScript. It compiles into canonical, content-addressed domain declarations. Functions, policies, mappings, and experience facets are pinned artifacts. The compiler rejects a link whose target type is not provable, an Action that can bypass policy, a Watch without a bounded attention contract, or a field whose evidence/time semantics are missing.

Eve may help a non-programmer produce the same draft conversationally. Her model proposes a `WorldChangeSet`; it cannot publish it. The user sees a semantic diff and runs the same journey evaluation as a code author.

## Agent

An agent is a principal, not a magical exception. A human or organization delegates an attenuated, expiring capability lease:

```ts
const lease = await membership.delegate({
  to: AgentPrincipal("cash-operator"),
  world: householdWorld,
  purpose: "maintain-household-runway",
  allow: [
    capability("Household.open"),
    capability("Household.protectReserve", { maxAmount: Money.brl(25_000) }),
  ],
  deny: [capability("Account.exportTransactions")],
  expiresAt: tomorrow,
});
```

Through MCP, discovery is progressive and permission-filtered before names or schemas are revealed:

```text
agent → discover("household runway")
      ← Household.open, Household.protectReserve, RunwayRisk.watch

agent → load capability Household.protectReserve
      ← typed input, consequences contract, decision contract, examples

agent → call Household.protectReserve(...)
      ← ActionOffer; no state mutation

agent → confirm offer using lease
      ← Receipt, only if amount/purpose/current basis remain within delegation
```

Every call records the agent principal, delegator chain, purpose, release, policy decision, basis, and operation identity. The agent receives the same domain capability and receipt as the human-facing client. MCP is not a privileged back door and does not expose every provider endpoint as a tool.

# 3. Core domain types

The design is built around five public concepts: `WorldRelease`, `Basis`, `Frame`, domain `Action`, and `Watch`. `Receipt` and `ProofRef` make their consequences accountable. Objects, links, measures, sources, policies, and functions are compiled ingredients, not a grab bag of public services.

The pseudocode below uses algebraic types. Constructors marked `private` can be called only by the owning module.

## Typed identity and immutable references

```rust
struct Id<T>(Opaque128, PhantomData<T>);
struct Digest<T>(Hash256, PhantomData<T>);

struct Ref<T> {
    id: Id<T>,
    digest: Digest<T>,
}

struct NonEmpty<T> {
    head: T,
    tail: Vec<T>,
}

struct Interval<T> {
    from_inclusive: T,
    until_exclusive: Option<T>,
}
```

An `Id<T>` cannot be substituted for another type of ID. A `Ref<T>` says both which durable thing and which immutable version. Mutable “latest” aliases are resolved at a boundary and never appear inside a receipt.

Door identity and World authority are distinct types:

```rust
struct AccountProof {                 // private constructor: Door only
    account: AccountId,
    session: SessionId,
    device: Option<DeviceId>,
    authenticated_at: Instant,
    expires_at: Instant,
    proof_digest: Digest<AccountProof>,
}

enum Principal {
    Human(AccountId),
    Agent(AgentId),
    Workload(WorkloadId),
}

struct ExecutionGrant {               // private constructor: Ontology policy only
    world: WorldId,
    principal: Principal,
    membership: Ref<Membership>,
    delegation: Vec<Ref<Delegation>>, // complete, non-ambient chain
    purpose: PurposeId,
    release_scope: ReleaseConstraint,
    authority: CapabilityConstraintSet,
    expires_at: Instant,
    audience_key: AudienceKey,        // safe cache/cursor partition, no raw secrets
}
```

An `AccountProof` cannot call the World. It must resolve to an `ExecutionGrant` through effective-dated membership, delegation, purpose, and entitlement policy. Eve receives a short-lived, per-turn grant; no prompt, environment variable, or model output can manufacture one.

## Meaning as an executable release

```rust
struct WorldSource {
    meaning: SemanticModel,
    sources: Vec<SourceContract>,
    rules: Vec<RuleArtifact>,
    policies: PolicyProgram,
    capabilities: CapabilityAtlasSource,
    experiences: Vec<ExperienceFacet>,
    required_journeys: JourneyContractSet,
}

struct WorldRelease {
    world: WorldId,
    release: ReleaseId,
    digest: Digest<WorldRelease>,
    parent: Option<Ref<WorldRelease>>,
    source: Ref<WorldSource>,
    model: CompiledSemanticModel,
    source_contracts: Map<SourceId, Ref<SourceContract>>,
    rule_artifacts: Map<RuleId, Ref<RuleArtifact>>,
    policy_program: Ref<PolicyProgram>,
    atlas: Ref<CapabilityAtlas>,
    experience_facets: Vec<Ref<ExperienceFacet>>,
    migration: Option<Ref<DataMigrationPlan>>,
    journey_proofs: NonEmpty<Ref<JourneyProof>>,
}

enum CapabilityDefinition {
    View(ViewCapability),
    DomainAction(ActionCapability),
    WatchTemplate(WatchCapability),
}
```

`WorldRelease` is a closure, not just a schema version. It pins every executable decision that can change meaning: source/mapping contracts, identity and belief resolvers, policy programs, function digests, capabilities, experience facets, migrations, and journey proofs. Runtime grants and evidence remain effective-dated World data, but the code interpreting them is pinned.

`CapabilityAtlas` is the only source from which public surfaces are projected. Each capability has a stable semantic ID, release-bound input/output shapes, required authority, point-in-time behavior, proof contract, and optional surface-specific facets. CLI grammar, MCP disclosure, API bindings, and Eve language may be richer in different ways, but all carry the same semantic fingerprint.

## Basis: no ambient “now” or “truth”

```rust
enum ValidScope {
    At(DomainInstant),
    During(Interval<DomainInstant>),
}

enum CutRequest {
    CurrentStrong,
    At(KnowledgeCut),
    KnownAt(AuthorityInstant),
    AtLeast(KnowledgeCut, Deadline),
}

struct KnowledgeBasis {
    world: WorldId,
    release: Ref<WorldRelease>,
    valid: ValidScope,
    cut: KnowledgeCut,
    belief: Ref<ResolutionProfile>,
    policy_cut: PolicyCut,
    scenario: Option<ScenarioRef>,
}

struct AuthorityBasis {
    principal: Principal,
    membership: Ref<Membership>,
    delegation_digest: Digest<DelegationChain>,
    purpose: PurposeId,
    audience_key: AudienceKey,
}

struct Basis {
    knowledge: KnowledgeBasis,
    authority: AuthorityBasis,
}
```

The kernel resolves a friendly `BasisRequest` into this complete `Basis` before executing. Results never merely say “latest.” The basis distinguishes domain validity from knowledge arrival, belief-selection policy from underlying assertions, and identity proof from World authority. Cursors, caches, Action offers, Watch evaluations, scenarios, explanations, and exports are all bound to a basis digest.

Evidence carries the clocks that belong to the evidence rather than pretending one timestamp is universal:

```rust
struct EvidenceTime {
    validity: ValidScope,                 // when proposition is true in the domain
    source_observed_at: Option<Instant>,  // when source observed it
    source_published_at: Option<Instant>, // when source asserted/revised it
    retrieved_at: Instant,                // when adapter acquired it
    admitted_at: AuthorityInstant,        // when World learned it
}
```

Financial instruments may additionally carry listing validity, economic period, and corporate-action effective time as typed domain fields. No clock is overloaded.

## Identity, evidence, and belief

Native object identity is opaque and typed. External identifiers are assignments with scope and evidence, never the object key.

```rust
struct Entity<T> {
    key: EntityId<T>,
    membership: Ref<TypeMembership<T>>,
}

struct QualifiedIdentifier {
    scheme: IdentifierScheme,
    value: IdentifierValue,
    level: IdentityLevel,
    scope: IdentifierScope,       // venue, institution, jurisdiction, provider, etc.
}

struct IdentifierAssignment<T> {
    identifier: QualifiedIdentifier,
    candidate: Entity<T>,
    valid: Interval<DomainInstant>,
    assertion: Ref<Assertion<IdentifierProposition<T>>>,
    disposition: AssignmentDisposition,
}

enum AssignmentDisposition {
    Candidate,
    Resolved(Ref<ResolutionReceipt>),
    Conflicted(NonEmpty<Ref<AssertionId>>),
    Superseded(Ref<IdentifierAssignment>),
}

enum IdentityResolution<T> {
    None { proof: ProofRef },
    Ambiguous { candidates: NonEmpty<IdentityCandidate<T>>, proof: ProofRef },
    Resolved(ResolvedEntity<T>),
}

struct ResolvedEntity<T> {        // private constructor: Identity module only
    entity: Entity<T>,
    receipt: Ref<ResolutionReceipt>,
}
```

Actions that require a unique subject accept `ResolvedEntity<T>`, not a ticker, name, external ID, or candidate. A first-party object created with a native identity receives a `NativeIdentityReceipt`. There is no unqualified `sameAs`; issuer, instrument, share class, listing, venue, and provider symbol are different types connected by typed links.

The truth model has four deliberately non-interchangeable records:

```rust
struct ArtifactReceipt {
    artifact: Ref<RawArtifact>,
    acquisition: AcquisitionKey,
    source_contract: Ref<SourceContract>,
    adapter: Digest<AdapterArtifact>,
    bytes_digest: Digest<Bytes>,
    time: AcquisitionTime,
    terms: Ref<UsageTerms>,
}

struct Assertion<P> {
    id: AssertionId,
    proposition: P,
    evidence_time: EvidenceTime,
    source: SourceId,
    artifact: Ref<ArtifactReceipt>,
    mapping: Digest<MappingRule>,
    derivation: Option<DerivationRef>,
}

enum Belief<T> {
    Accepted {
        value: T,
        support: NonEmpty<AssertionRef>,
        rivals: Vec<VisibleRival>,
        resolution: Ref<ResolutionReceipt>,
    },
    Contested {
        candidates: NonEmpty<VisibleCandidate<T>>,
        reason: ContestReason,
        proof: ProofRef,
    },
    Unknown {
        gaps: NonEmpty<EvidenceGap>,
        proof: ProofRef,
    },
}
```

An artifact proves acquisition, an assertion records what a source claimed, and a belief is the result of a named resolution profile at a basis. A belief receipt never deletes rivals. The term “fact” is reserved for user language, not a storage type.

Policy happens before candidate discovery. Internally, only the policy engine can construct `ReadPermit<T>`; the query planner cannot enumerate objects, fields, series, counts, proof nodes, or capabilities without it. Denied population structure therefore cannot alter cursors or aggregates. A sealed cursor includes the release, basis, normalized query, policy decision, and `AudienceKey`; it cannot be replayed by another audience.

## Frames, objects, sets, and dense observations

```rust
struct Frame<T> {
    value: T,
    basis: Basis,
    proof: ProofRef,
    actions: Vec<BoundAction>,
    continuation: Option<SealedCursor<T>>,
}

struct ObjectView<T> {
    subject: ResolvedEntity<T>,
    properties: PropertiesOf<T, Belief>,
    links: LinksOf<T, AuthorizedObjectSet>,
    series: SeriesOf<T, SeriesHandle>,
}

struct ObjectSet<T> {
    plan: AuthorizedPlan<T>,  // lazy filter/traverse/set/order/aggregate plan
    basis: Basis,
}

struct SeriesHandle<V> {
    series: SeriesId<V>,
    subject: EntityRef,
    measure: Ref<MeasureDefinition<V>>,
    semantics: SeriesSemantics,
}

struct SeriesSemantics {
    dimensions: DimensionSet,
    unit: Unit,
    currency: Option<Currency>,
    timezone: TimeZone,
    calendar: CalendarRef,
    periodicity: Periodicity,
    fill: FillPolicy,
    adjustment: AdjustmentPolicy,
}

struct SeriesRequest {
    range: Interval<EventTime>,
    vintage: VintageSelection,       // exact assertion, known-at, or resolved
    aggregation: Option<Aggregation>,
    downsample: Option<Downsample>,
}

struct SeriesSlice<V> {
    values: ColumnarSlice<V>,
    semantics: SeriesSemantics,
    basis: Basis,
    manifests: NonEmpty<Ref<ObservationManifest>>,
    proof: ProofRef,
}
```

`ObjectSet<T>` is a typed lazy plan, not an array loaded before authorization. The engine can push its filters and entitlement predicates into relational or columnar execution. A `SeriesHandle` is an ontology object reference into the observation plane; callers still receive the same `Basis` and `ProofRef`. A person with twelve measurements and a fund with twelve billion measurements use the same semantic type.

Provider field equivalence is a governed, revisioned assertion between `MeasureDefinition`s. Matching labels or mnemonics do not create equivalence. Every observation segment states identity level, dimensions, clocks, units, calendar, adjustment, source contract, mapping digest, and usage rights.

## Domain Actions and honest receipts

```rust
struct BoundAction<A> {                 // private constructor: discovery/open only
    action: Ref<ActionDefinition<A>>,
    target: ActionTarget<A>,
    basis: Basis,
    discover_policy: Ref<PolicyDecision>,
    expires_at: Instant,
}

struct ActionOffer<A> {
    action: BoundAction<A>,
    input_digest: Digest<A::Input>,
    consequences: A::Consequences,
    uncertainties: Vec<Uncertainty>,
    decision: DecisionRequirement<A::Choice>,
    commit_token: CommitToken<A>,
    proof: ProofRef,
}

enum DecisionRequirement<C> {
    None { authority: Ref<PolicyDecision> },
    Confirm { question: HumanQuestion },
    Choose { question: HumanQuestion, choices: NonEmpty<C> },
    MultiParty { rule: ApprovalRule, pending: NonEmpty<PrincipalRef> },
}

struct CommitToken<A> {                 // opaque, signed, release-bound
    offer: OfferId,
    release: Ref<WorldRelease>,
    intent: Digest<ActionIntent<A>>,
    read_set: Digest<ReadSet>,
    policy: Ref<PolicyDecision>,
    expires_at: Instant,
}

struct ActionReceipt<A> {
    action: Ref<ActionDefinition<A>>,
    operation: OperationKey<A>,
    decision: Ref<DecisionRecord<A::Choice>>,
    world_commit: Ref<WorldCommit>,
    semantic_result: A::CommittedResult,
    effects: Vec<EffectReceipt>,
    proof: ProofRef,
}

enum Settlement {
    Pending,
    Confirmed { external_receipt: ProtectedRef },
    Rejected { reason: SafeReason },
    Unknown { last_attempt: EffectAttemptId, reconciliation: ReconciliationPlan },
}
```

The Action definition owns preview, preconditions, semantic transition, decision rule, and effect intent construction. The offer's read-set digest names exactly the object versions, beliefs, series watermarks, release, and policy decisions used. Commit rechecks that set. A change returns a typed `StaleOffer` with a meaningful diff and a fresh offer; it never silently applies to a new world.

`OperationKey<A>` plus the action-intent digest is the idempotency identity. Repeating both returns the same receipt. Reusing the key with different intent is a conflict. One Action may atomically change multiple objects and links. Its external `EffectIntent`s enter the outbox in that same transaction, but settlement is a later truth. Restate runs only those effects, keyed by `EffectId`; it never owns conversation, belief, or World state.

## Watches and earned interruption

```rust
struct Watch<W> {
    id: WatchId<W>,
    owner: PrincipalRef,
    capability: Ref<WatchDefinition<W>>,
    subject: ResolvedSelector<W::Subject>,
    condition: W::Condition,
    rolling_basis: RollingBasis,
    evidence_requirement: EvidenceRequirement,
    attention: AttentionContract,
    state: WatchState,
    expires_at: Option<Instant>,
}

struct AttentionContract {
    minimum_novelty: Novelty,
    minimum_confidence: Confidence,
    urgency: UrgencyPolicy,
    cooldown: Duration,
    quiet_hours: LocalTimeWindow,
    interruption_budget: InterruptionBudget,
    escalation: EscalationPolicy,
}

struct AttentionCandidate {
    watch: WatchRef,
    change: SemanticDelta,
    why_now: ProofRef,
    urgency: Urgency,
    suggested_actions: Vec<BoundAction>,
    deduplication: AttentionKey,
    expires_at: Instant,
}
```

Ontology decides whether the World changed in a semantically relevant way. Eve decides whether and how that candidate deserves this person's attention now, using relationship context, quiet hours, fatigue, channel state, and pending conversations. This two-stage boundary prevents the model from inventing urgency and prevents Ontology from becoming a messaging product.

No-change evaluations update compact `WatchCheckpoint`s and watermarks; they do not produce one authority event per poll or observation. A candidate is durable and deduplicated. Eve's delivery result belongs to the interaction journal. If a domain Action explicitly sends a message outside the Eve relationship, it is an external `ZoenEffect` and follows settlement semantics.

## Interaction continuity without conversational authority

```rust
struct FocusCapsule {
    world: WorldId,
    release_policy: FocusReleasePolicy,
    subjects: NonEmpty<EntityRef>,
    view: CapabilityRef,
    valid_scope: ValidScope,
    last_basis: Option<Basis>,
    selected_evidence: Vec<ProofRef>,
    pending_offer: Option<OfferRef>,
    watches: Vec<WatchRef>,
    presentation_state: PresentationState,
}

enum TurnEvent {
    MessageReceived(Message),
    FocusChanged(FocusCapsule),
    FramePresented(FrameRef),
    OfferPresented(OfferRef),
    DecisionCaptured(DecisionRef),
    WorldReceiptObserved(ReceiptRef),
    AttentionDelivered(AttentionDelivery),
}
```

Eve's journal is event-sourced because interaction is inherently a sequence. The model is a stateless reasoning function over a deterministically assembled context. It may produce prose, a proposed focus change, read calls, or an Action offer request. It cannot produce an `ExecutionGrant`, `ResolvedEntity`, `BoundAction`, `CommitToken`, or `Receipt` because constructors are outside the model boundary.

Conversation and Living World render the same focus and released experience facets. Structured presentation is flattened into excellent text on WhatsApp and Telegram. The transcript references World receipts; it is never the portable source of World truth.

## Definition branches and operational scenarios cannot be confused

```rust
struct WorldDraft {                     // changes meaning
    id: DraftId,
    base: Ref<WorldRelease>,
    source: Ref<WorldSource>,
    authoring_history: Vec<WorldChangeSet>,
}

struct ReleaseCandidate<State> {
    draft: Ref<WorldDraft>,
    compiled: Ref<CompiledRelease>,
    semantic_diff: SemanticDiff,
    data_impact: DataImpact,
    surface_diff: SurfaceDiff,
    evaluation: State,
}

struct Verified { proofs: NonEmpty<Ref<JourneyProof>> }
struct Unverified { failures: NonEmpty<JourneyFailure> }

struct Scenario<S> {                    // changes hypothetical operational state
    id: ScenarioId<S>,
    base: Basis,
    overlays: Vec<HypotheticalTransition>,
    effect_capability: Never,
    expires_at: Instant,
}
```

Only `ReleaseCandidate<Verified>` is accepted by `publish`. A `WorldDraft` can change meaning, policies, mappings, capabilities, and experience facets but cannot transact against live operational state. A `Scenario` can evaluate hypothetical state against one basis but cannot change meaning or emit an external effect. Applying a scenario means asking live domain Actions to prepare again against current state; there is no cast from `Scenario` to `WorldDraft` or `CommitToken`.

# 4. Public interfaces and signatures

## Caller surface

Consumers normally see a release-generated domain client like the usage above. The generated objects expose domain names and return domain types. This client is an artifact of Ontology, not a fourth SDK product.

All surface projections reduce to one small runtime spine:

```rust
trait WorldSession {
    fn discover(
        &self,
        grant: &ExecutionGrant,
        need: CapabilityNeed,
    ) -> Result<AuthorizedAtlas, DiscoveryError>;

    fn open<V: ViewCapability>(
        &self,
        grant: &ExecutionGrant,
        call: ViewCall<V>,
        basis: BasisRequest,
    ) -> Result<Frame<V::Output>, OpenError>;

    fn prepare<A: ActionOrWatchCapability>(
        &self,
        grant: &ExecutionGrant,
        call: CapabilityCall<A>,
        basis: BasisRequest,
    ) -> Result<ActionOffer<A>, PrepareError>;

    fn commit<A: ActionOrWatchCapability>(
        &self,
        grant: &ExecutionGrant,
        token: CommitToken<A>,
        decision: Decision<A::Choice>,
        operation: OperationKey<A>,
    ) -> Result<ActionReceipt<A>, CommitError<A>>;

    fn explain(
        &self,
        grant: &ExecutionGrant,
        target: ProofRef,
        depth: ExplanationDepth,
    ) -> Result<Explanation, ExplainError>;
}
```

These five methods are protocol mechanics, not product vocabulary. Generated callers see `households.open`, `protectReserve`, `watchRunway`, and `why`. The interface is deep: behind it sit identity resolution, authorization-before-discovery, bitemporal cuts, belief selection, relational/columnar planning, stale-read detection, multi-object transactions, effect outboxes, idempotency, causal proof, and surface redaction. Callers coordinate only when the domain says a decision is required.

Identity resolution, object sets, series queries, functions, audit feeds, and receipt status are `ViewCapability`s. Creating/updating/canceling a Watch uses a release-defined `WatchCapability` through the same prepare/commit ceremony as an Action; Watch evaluation itself is internal event-driven behavior. There is no generic public mutation endpoint.

## Builder surface

```rust
trait WorldStudio {
    fn build(
        &self,
        grant: &BuilderGrant,
        base: Ref<WorldRelease>,
        source: WorldSource,
    ) -> Result<WorldDraft, BuildReport>;

    fn rebase(
        &self,
        grant: &BuilderGrant,
        draft: Ref<WorldDraft>,
        onto: Ref<WorldRelease>,
    ) -> Result<WorldDraft, SemanticConflicts>;

    fn evaluate(
        &self,
        grant: &BuilderGrant,
        draft: Ref<WorldDraft>,
        suite: Ref<JourneyContractSet>,
        corpus: Ref<EvidenceCorpus>,
    ) -> ReleaseCandidate<EvaluationState>;

    fn publish(
        &self,
        grant: &BuilderGrant,
        candidate: ReleaseCandidate<Verified>,
        decision: PublishDecision,
        operation: OperationKey<PublishRelease>,
    ) -> Result<Ref<WorldRelease>, PublishError>;
}
```

Studio is a builder profile of Ontology. `build` validates boundary syntax and compiles semantic invariants. `evaluate` runs semantic comparisons and real product journeys through the actual Door/Eve/Ontology deployment; captured evidence is production-format, content-addressed evidence, not a mock source. `publish` atomically advances the active release only after policy and migration checks. Old releases and their explanations remain addressable.

## Surface compilers

```rust
trait SurfaceCompiler<S: Surface> {
    fn project(
        &self,
        release: &WorldRelease,
        authorized: &AuthorizedAtlas,
        facet: Option<&ExperienceFacet<S>>,
    ) -> SurfacePackage<S>;

    fn semantic_fingerprint(&self, package: &SurfacePackage<S>)
        -> Digest<CapabilityAtlas>;
}
```

The semantic atlas is transport-neutral; each projection can be excellent in its own medium:

- CLI gets domain command grammar, helpful flags, previews, inline decisions, and text explanations.
- API gets stable domain endpoints/descriptors and generated client types.
- MCP gets a small discovery resource, intent-indexed progressive capability loading, compact tool schemas, and decision-safe tools.
- Eve gets intent examples, clarification language, consequence renderers, citations, and structured `PresentationTree`s for Living World.

Surface richness lives in separate `ExperienceFacet<S>` artifacts pinned by the same release. This prevents the semantic core becoming a lowest-common-denominator UI schema. A conformance journey verifies that every projected package has the same semantic fingerprint and cannot bypass policy, basis, idempotency, or decision requirements. A capability may intentionally be absent on a surface; absence is explicit release policy, not drift.

## External contracts

External sources and effect destinations implement narrow, source-specific contracts. They do not implement the World interface and do not receive generic write authority.

```rust
trait AcquisitionAdapter<C: SourceCapability> {
    fn acquire(
        &self,
        credential: &SourceCredential<C>,
        request: C::Request,
        checkpoint: Option<C::Checkpoint>,
    ) -> Result<CapturedArtifact<C>, AcquisitionError>;
}

trait EffectConnector<E: EffectKind> {
    fn dispatch(
        &self,
        credential: &DestinationCredential<E>,
        intent: ImmutableEffectIntent<E>,
    ) -> EffectAttempt<E>;

    fn reconcile(
        &self,
        credential: &DestinationCredential<E>,
        unknown: UnknownEffect<E>,
    ) -> ReconciliationResult<E>;
}
```

Only the acquisition boundary can mint an `ArtifactReceipt`; only source-bound mapping and policy can admit assertions or observation manifests. Only the agency transaction can mint an `ImmutableEffectIntent`. Connector responses are evidence of external state, not authority to rewrite the committed decision.

# 5. Runtime/module map

The implementation begins as a modular monolith with three product boundaries, one deployable system, and a handful of deep modules. A normal request crosses a surface, the `WorldSession` facade, one owning module, and its transaction. There are no controller/service/repository triplets and no pass-through domain layers.

```text
┌──────────────────────────────────────────────────────────────────────┐
│ Door — Better Auth                                                   │
│ account/session/device proof                                         │
└──────────────────────────────┬───────────────────────────────────────┘
                               │ AccountProof only
┌──────────────────────────────▼───────────────────────────────────────┐
│ Eve — relationship                                                   │
│ channels · conversation journal · focus · model loop                │
│ Living World · context assembly · attention arbiter                 │
└──────────────────────────────┬───────────────────────────────────────┘
                               │ short-lived ExecutionGrant + calls
┌──────────────────────────────▼───────────────────────────────────────┐
│ Ontology — World                                                     │
│                                                                      │
│  protocol       release        authority        identity             │
│  WorldSession   compiler       membership       resolution           │
│  projections    Studio         entitlements     typed membership     │
│                                                                      │
│  reality        agency         attention        provenance           │
│  evidence       Action offers  Watch runtime    proof graph          │
│  belief         transactions   checkpoints      explanations         │
│  object sets    receipts       candidates       audit views          │
│  series query   effect intents                                      │
│                                                                      │
│  ingress                         settlement                           │
│  source contracts + CAS          Restate ZoenEffect workflows        │
└──────────────────────────────────────────────────────────────────────┘
```

Module ownership is semantic, not temporal:

- **protocol** owns the five-method facade, domain bindings, and surface compilation. It does not decide policy or truth.
- **release** owns `WorldSource → WorldDraft → ReleaseCandidate → WorldRelease`, semantic diff, rebase, migration, and journey evidence.
- **authority** owns Account-to-World membership, delegation, purpose, entitlements, discovery filtering, `ReadPermit`, and policy decisions. Door cannot replace it.
- **identity** owns explicit type membership, external assignments, ambiguity, merge/split/supersession, and `ResolvedEntity<T>` construction.
- **reality** owns artifact admission, assertions, resolution profiles, `Basis`, object/set/series Frames, and authorized query planning. It does not execute Actions.
- **agency** owns Action definitions at runtime, offers, read sets, decisions, multi-object commit, operation idempotency, semantic receipts, and effect intent creation.
- **attention** owns Watch instances, change dependency indexes, evaluation checkpoints, semantic novelty, and durable `AttentionCandidate`s. It never chooses a messaging channel.
- **provenance** owns typed proof nodes and authorized explanation/audit projections. Other modules contribute proof edges transactionally through typed references; they do not build ad hoc narrative lineage.
- **ingress** owns acquisition keys, source credentials, immutable artifact capture, deterministic mapping, batch/segment validation, and source-bound admission.
- **settlement** is the only Ontology module that calls Restate. It turns committed effect intents into attempts and reconciliation evidence, never semantic commits.

Eve has its own small set of deep modules:

- **journal** durably appends interaction events and derives conversation projections.
- **focus** owns `FocusCapsule` transitions shared by conversation and Living World.
- **context** deterministically assembles authorized Frames, capability bindings, and relevant journal windows; the LLM does not search ambient state.
- **turn loop** treats the model as an untrusted planner, executes read/prepare steps through typed bindings, and renders results.
- **attention arbiter** consumes `AttentionCandidate`s, applies relationship budgets and channel state, and chooses silence, in-app presentation, or one channel delivery.
- **channel edges** authenticate inbound webhook provenance and flatten structured presentation to excellent text for WhatsApp/Telegram.

The hot paths are short:

```text
read:    surface → WorldSession.open → reality (using authority permit) → Frame
action:  surface → WorldSession.prepare/commit → agency → transaction/outbox → Receipt
watch:   WorldChanged → attention → AttentionCandidate → Eve arbiter → channel/journal
build:   Studio.build/evaluate/publish → release → atomic active-release pointer
effect:  committed outbox → settlement/Restate → connector → reconciliation receipt
```

Internally generated events connect modules after authority changes. No synchronous call chain is extended merely to notify projections, Watches, or Eve.

# 6. Storage and event model

## Durable planes

One deployment uses four storage planes with one semantic contract:

| Plane | Canonical contents | Physical shape |
|---|---|---|
| Authority | memberships, releases, objects/type membership, sparse assertions, identity resolutions, policy decisions, Action/Watch/decision/settlement receipts, World commits | temporal relational rows plus immutable receipts in PostgreSQL |
| Artifact | raw provider payloads, source schema captures, rule/function artifacts, release bundles, attachments | immutable content-addressed objects |
| Observation | dense time-series/tabular segments, corrections, tombstones, statistics, semantic column bindings | immutable Arrow/Parquet-style segments plus manifest DAGs |
| Interaction | Eve messages, focus changes, presented offers, observed receipts, delivery history | append-only interaction streams plus disposable projections |

Search indexes, vector indexes, caches, object-set accelerators, and Living World projections are derived and rebuildable. They are never authority. Process-local caches are allowed; Redis is absent because no correctness invariant depends on a distributed cache.

PostgreSQL may host Door, Eve, and Ontology in separate schemas, but ownership remains product-specific. Object storage contains immutable bytes. A small World and a large World differ in partitioning and worker allocation, not in domain types.

## Authority commit and knowledge cuts

Each World has a monotonically ordered `WorldCommit` stream. Dense ingress produces one commit per admitted segment or synchronization slice, not per point. This keeps the rate of authority decisions low enough that a total World order is valuable and tractable.

```rust
struct WorldCommit {
    world: WorldId,
    cut: KnowledgeCut,
    id: WorldCommitId,
    kind: CommitKind,
    expected_versions: NonEmpty<AggregateVersion>,
    transition_digest: Digest<TransitionSet>,
    actor: ActorStamp,
    basis: Option<Digest<Basis>>,
    operation: OperationIdentity,
    recorded_at: AuthorityInstant,
}
```

The same serializable PostgreSQL transaction:

1. verifies all expected aggregate versions and the Action read set;
2. appends temporal state changes and immutable receipts;
3. assigns the next `KnowledgeCut` for that World;
4. appends meaningful event envelopes;
5. appends effect/projection/attention outbox entries.

Locks are acquired by sorted aggregate key, not by request timing. Two actors writing disjoint aggregates do not share mutable in-process state; the database merges them at the commit boundary. A multi-object Action is one transaction. A conflict produces no partial transition.

The single per-World commit order is an intentional consistency primitive, not a stream for every byte. Worlds can be placed on different database partitions or clusters. Observation volume is outside this serialized path. If one institution eventually exceeds one authority stream, federation is performed through explicit linked Worlds and imported signed receipts, not by weakening cuts into an undocumented vector clock.

## Meaningful events, not universal event sourcing

```rust
struct EventEnvelope<E: DomainEvent> {
    event: EventId<E>,
    world: WorldId,
    release: Ref<WorldRelease>,
    commit: Ref<WorldCommit>,
    stream: StreamKey<E::Owner>,
    stream_sequence: u64,
    actor: ActorStamp,
    cause: Cause,
    occurred_at: Option<DomainInstant>,
    recorded_at: AuthorityInstant,
    payload: E,
    payload_digest: Digest<E>,
}

enum Cause {
    Root { request: RequestId, operation: OperationIdentity },
    CausedBy { parent: EventRef, root: EventRef, proof: Vec<ProofRef> },
}
```

Events record transitions worth reacting to: release published, evidence batch admitted, identity resolved, Action committed, Watch changed, Attention offered, effect attempted or reconciled. Scalar reads, LLM tokens, every observation, and unchanged Watch polls are not authority events.

Consumers are at-least-once and idempotent by `EventId`; exactly-once delivery is not promised. The transactionally written outbox is the source. A broker can be added later as delivery infrastructure without changing domain semantics. PostgreSQL notification may wake workers but is never the durable record.

Eve alone is event-sourced at interaction granularity because replaying a relationship sequence is its natural model. Eve's events reference immutable World IDs and receipts instead of duplicating their payloads as conversational authority.

## Artifact and observation admission

Acquisition is safe across retries and crashes:

```text
AcquisitionKey = hash(
  provider + capability + canonical request + window/cursor/checkpoint
  + adapter digest + source-contract revision
)
```

1. The source-specific workload acquires bytes and writes the raw immutable object.
2. It records headers, clocks, effective request policy, provider schema snapshot, adapter digest, terms, and byte digest.
3. A release-pinned mapper deterministically produces assertion candidates or columnar segments.
4. Identity, units, time semantics, constraints, quality, and admission policy are evaluated.
5. For sparse evidence, assertions are appended. For dense evidence, immutable segments are written first.
6. One authority transaction accepts the assertion batch or segment manifest and emits `EvidenceBatchAdmitted`.

Writing immutable bytes before the database transaction does not require a distributed transaction. Unreferenced objects are invisible and later garbage-collected after a safety horizon. A committed manifest never points to partially written data.

An observation manifest records source, series identities, schema/measure revisions, column bindings, min/max event time, sequence range, row count, raw and normalized digests, previous checkpoint, correction/tombstone overlays, usage rights, validation results, and accepted World cut. Corrections append; they never mutate raw observations. Compaction creates a new manifest from reachable segments and preserves proof equivalence. Full rebuild is a repair operation, not normal freshness.

A query at `KnowledgeCut(k)` may only see manifests admitted at or before `k`. A strong read can combine authority metadata with immutable segments immediately. Derived projections state their covered cut. Eventual results expose the older cut rather than pretending freshness.

## Evidence, belief, and proof graph

Assertions are immutable and bitemporal. Automated resolution is a pure, digest-pinned function of visible assertions, quality evidence, policy, and basis. Its result includes a `ResolutionReceipt`. Human adjudication is a domain Action whose receipt becomes an additional resolution input; it does not delete prior rivals.

Proof nodes form a typed DAG:

```rust
enum ProofNode {
    Artifact(Ref<ArtifactReceipt>),
    Assertion(AssertionRef),
    IdentityResolution(Ref<ResolutionReceipt>),
    BeliefResolution(Ref<ResolutionReceipt>),
    Computation(Ref<ComputationReceipt>),
    Policy(Ref<PolicyDecision>),
    WorldCommit(Ref<WorldCommit>),
    EffectAttempt(Ref<EffectAttempt>),
    Release(Ref<WorldRelease>),
}
```

`explain` traverses this DAG under the same authority rules as the original query. Restricted artifacts, losing candidates, counts, and policy details remain restricted. Operators can query an authorized activity projection; the proof graph remains the causal source of depth.

## Effects and external ambiguity

Action commit and external settlement are separate state machines:

```text
Action: prepared → decided → committed | stale/rejected
Effect: requested → attempting → confirmed | rejected | unknown → reconciled
```

The Action transaction atomically stores `EffectIntent` and outbox entry. Restate executes one workflow per `EffectId`. The effect idempotency key is derived from World commit plus effect ordinal and is passed to providers that support it. If a crash occurs after a provider may have acted but before confirmation, status becomes `Unknown`. Automatic retry is allowed only when the connector contract proves idempotency; otherwise reconciliation queries the provider or requests a human decision. No timeout is interpreted as failure or success.

Restate stores only durable effect orchestration state. It does not store conversation turns, World objects, Watches, or evidence.

## Deployment topology

The first production topology is intentionally boring:

```text
one Fly application
  ├─ edge process: Door + Eve HTTP/channel edges + Ontology API/MCP
  ├─ worker process: ingress + projections + Watch evaluation
  ├─ effect process: Restate handlers/connectors
  └─ CLI: local client of the same Ontology protocol

managed PostgreSQL
immutable object storage
Restate (effects only)
```

Logical process boundaries can run in one or several machines without becoming products. Scaling first partitions by World and worker responsibility. The observation scan engine can become an independently scaled native/columnar process behind `SeriesRequest` without changing callers. Kafka, a graph database, a workflow engine, and Redis are not prerequisites.

## Portability

A portable `WorldBundle` contains selected signed release closures, semantic commits/receipts, permitted assertions, observation manifests, and proof nodes. Raw artifacts and licensed observations are included only when usage rights allow; otherwise the bundle contains non-resolvable protected references plus clear gaps. Import never converts another World's receipt into local truth automatically: a governed source contract admits it as signed evidence.

# 7. Canonical journeys

These journeys drive real product surfaces and real stores. They do not use unit mocks, fake repositories, or alternate test-only APIs.

## Journey 1 — first-minute Personal Watch

A new person signs in through Door, tells Eve to watch household runway, encounters two “Reserve” account candidates, resolves the correct identity, and creates the Watch. Eve shows current runway, evidence freshness, interruption threshold, quiet hours, and expiry. The person closes the app.

The real bank/source sandbox publishes ordinary fluctuations; no message is delivered. Later a new obligation reduces runway below six months. Ontology incrementally reevaluates the affected Watch and emits one deduplicated `AttentionCandidate`. Eve waits until quiet hours end and sends one excellent text message. Opening it restores the exact focus and basis in Living World.

**Proves:** Account is not authority; ambiguous identity cannot collapse; source evidence and belief differ; Watch silence is default; Ontology significance and Eve interruption are distinct; channel text and Living World share focus.

## Journey 2 — disputed truth through time

Two providers report different daily closing prices for one explicitly resolved venue listing. Each response is captured as a raw artifact with effective request policy, currency, calendar, adjustment basis, observation/publication/retrieval clocks, source schema, and terms. A point-in-time Frame returns the selected value, visible rival, resolution policy, and proof. A provider later corrects the value.

The operator asks for the view as known before and after the correction and obtains both. Changing the default resolution profile creates a different accepted belief without rewriting either assertion. A denied principal cannot infer the second provider from capability discovery, counts, cursors, rivals, citations, or explanations.

**Proves:** Bloomberg-grade identity/time semantics; evidence is not belief; four clocks survive; resolution is purpose-specific; entitlements happen before discovery; historical results remain reproducible.

## Journey 3 — a consequential Action with an unknown external result

A household or fund opens a current Frame, prepares a multi-leg transfer/rebalance, sees consequences and uncertainty, and leaves the offer open. Market/account state changes. Commit returns `StaleOffer` and a semantic diff; nothing is written. A refreshed offer receives the required decision and commits all semantic changes plus effect intents atomically.

The external provider accepts a request but the connection fails before a response. The receipt says `world_commit = committed` and `settlement = unknown`. Replaying the operation key does not duplicate any leg. Restate follows the connector's reconciliation plan and later attaches the provider confirmation to the same receipt.

**Proves:** exact read-set concurrency; multi-object atomicity; idempotency; decision authority; commit is not settlement; crash-safe unknown handling; Restate owns effects only.

## Journey 4 — conversation and Living World are one focus

In chat, a person asks why February runway dipped. Eve opens a time-scoped Frame and cites two obligations. The person opens Living World, traverses from the household to one obligation, switches the interval, compares evidence, and starts a hypothetical “cancel subscription” scenario. Returning to chat, “what if I do that?” refers to the same subject, interval, basis, and scenario. The scenario shows consequences but cannot emit an effect. Applying it prepares the live domain Action again against current state.

**Proves:** no context loss across modes; focus is not truth; scenario and release branch differ; model does not carry ambient object state; explanations remain authorized.

## Journey 5 — teach and publish a World

A builder asks Eve/Studio to add a “Protected account” concept and a `Protect reserve` Action. Studio produces a `WorldDraft`; the builder sees semantic, data, authority, and surface diffs. A required journey catches that an MCP projection exposes the Action name before entitlement filtering and fails the candidate. After correction, real journeys run through CLI, API, MCP, and Eve against an isolated World with real stores and signed evidence artifacts. A second builder has changed the base release, so rebase reports a semantic policy conflict rather than a text conflict. A reviewed `ReleaseCandidate<Verified>` publishes atomically.

Old receipts still explain under the old release. A Watch configured to follow only compatible releases migrates; an incompatible Watch remains pinned and asks for attention.

**Proves:** conversational and code authoring converge on one source; generated surfaces cannot drift; release closure and typed verification; semantic rebase; atomic activation; historical explanation.

## Journey 6 — personal semantics at institutional volume

A fund ingests one year of OHLCV for 10,000 resolved listings from two providers. Each page/window is replay-safe. Raw artifacts and columnar segments are immutable; one authority commit admits each synchronization slice, not each cell. A range query, downsample, object-set aggregation, and 20-day volatility computation run under one basis. The derived metric cites exact manifests, interval, adjustment/calendar rules, component digest, and cut.

One principal may view but not export a licensed measure; another cannot discover it. A correction creates a new segment/manifest. Normal projection advances compose manifests without rewriting history; repair rebuilds from reachable manifests and collects only proven orphans.

**Proves:** no conceptual fork between household and fund; dense physical plane; native range semantics; source-bound ingress; derivation lineage; purpose/export entitlements; incremental repairable projections.

## Journey 7 — human and agent use the same Action

A human delegates a 24-hour lease to an agent to protect runway up to R$25,000, with no transaction export. The agent progressively discovers only permitted capabilities through MCP, opens the same Frame, prepares the same domain Action, and commits within bounds. An attempt above the limit returns a safe denial and reveals no hidden policy or account details. The human opens the receipt in Eve and sees the full delegation chain, decision basis, and settlement.

**Proves:** agent parity without agent privilege; bounded delegation; progressive MCP; identical semantic fingerprint across surfaces; complete receipts.

# 8. Build slices

Each slice is a vertical user outcome spanning the necessary portions of Door, Eve, and Ontology. No slice is “build the event bus,” “finish all schemas,” or “make the platform.”

## Slice 1 — one trustworthy answer

Ship one handcrafted Household Finance release with `Person`, `Household`, `Account`, and runway. A person signs in, obtains membership, tells Eve the relevant accounts, and receives one Frame with explicit valid time, knowledge cut, evidence, and “why.” Living World can open that exact Frame. Build only sparse evidence, native identity plus one external assignment flow, `Basis`, authorized `open`, proof, Eve journal/focus, and text/visual renderers.

**User value:** Eve can answer one important question without lying about source or freshness.

## Slice 2 — quiet Personal Watch

Add source-bound acquisition for account balances/obligations, the `Runway risk` Watch, event-driven dependency indexing, checkpoints, semantic novelty, Eve attention arbitration, and one authenticated channel. Exercise silence, threshold crossing, deduplication, quiet hours, and focus restoration.

**User value:** Zoen keeps watch without becoming another notification machine.

## Slice 3 — one honest external Action

Add `Protect reserve`, Action offers, exact read sets, decision requirements, operation idempotency, multi-object commit, effect outbox, one real provider sandbox, Restate dispatch, unknown result, and reconciliation. The same Action works in Eve, CLI, and API.

**User value:** Eve can help do something consequential and state precisely what happened.

## Slice 4 — release compiler and surface parity

Replace the handcrafted release with `WorldSource`, compiler, canonical release closure, generated CLI/API/MCP/Eve facets, progressive discovery, Studio build/evaluate/publish, semantic diff, and real cross-surface journey gate. No generic marketplace and no broad builder UI.

**User value:** a builder can teach Zoen one new domain capability once and publish it safely everywhere.

## Slice 5 — disagreement, identity, and time

Add plural provider assertions, full identity ambiguity/assignment lifecycle, typed links, resolution profiles/receipts, point-in-time views, policy-before-discovery, sealed audience-bound cursors, and authorized explanations. Prove the two-provider price correction journey.

**User value:** the World can say what it believes, why, and what would have been believed earlier without erasing disagreement.

## Slice 6 — scenarios and continuous Living World

Add typed object-set plans, relationship traversal, richer Living World experience facets, operational scenarios with `Never` effect authority, pending-decision continuity, and apply-by-reprepare. Keep the UI focused on object, situation, decision, evidence, and Watch—not configurable dashboard chrome.

**User value:** conversation becomes a doorway into a coherent explorable World without context loss.

## Slice 7 — dense observation and institutional entitlements

Add immutable columnar segments, manifests, series semantics, range/downsample/aggregate queries, source contracts, correction overlays, incremental projections, compaction/GC, field/series/purpose/export rights, and the fund-volume journey. Keep the same `Frame`, `Basis`, `ProofRef`, and domain Action surfaces.

**User value:** the same product can become Bloomberg-grade for a professional without forking its conceptual model.

## Slice 8 — portable Worlds and bounded agents

Add signed `WorldBundle` export/import, protected gaps for non-portable licensed evidence, attenuated agent delegation, MCP progressive capability loading, and human-readable delegation receipts. Prove import as evidence rather than ambient trust.

**User value:** the person's or institution's meaning, decisions, and explanations are not trapped in one transcript, vendor, or agent.

# 9. Rejected shapes

This greenfield design explicitly deletes attractive but structurally expensive ideas.

1. **A fixed list of universal public verbs.** `Discover/Query/Propose/Decide/Commit/Explain/Execute` is an implementation lifecycle, not the language of a household, clinic, or factory. The runtime needs a small internal protocol, but public surfaces expose released domain Actions. Otherwise every caller learns the engine and domain at once.

2. **Chat as the product database.** A transcript is relationship history, not identity, evidence, accepted belief, or authority. LLM memory cannot mint grants, object IDs, operation keys, facts, or receipts.

3. **A universal event-sourced World.** Decisions and interaction transitions deserve events; observations and current temporal state do not need to be reconstructed from billions of events. Temporal relational authority plus meaningful immutable receipts is simpler and safer.

4. **One scalar claim per observation.** It gives decision-ledger semantics to data cells, serializes ingestion unnecessarily, and destroys native range performance. Dense series get immutable segments governed by semantic manifests.

5. **Provider endpoints as ontology or MCP.** A provider adapter is an acquisition contract. Endpoint trees, `symbol: string`, open-ended extras, and first-credential fallback cannot define object identity, field meaning, belief, or entitlement.

6. **A graph database as the semantic core.** Typed links and traversals are valuable; a universal property graph does not supply bitemporal evidence, resolution policy, action atomicity, or rights. Relational and columnar plans can execute the released graph model without exposing a graph storage ideology.

7. **Palantir product breadth.** Workshop clones, pipeline designers, notebooks, ontology managers, monitoring suites, model catalogs, and marketplaces would create many shallow modules before the deep World protocol exists. Living World and Studio expose only what the central loop needs.

8. **Builder, data, agent, or SDK as additional products.** Studio is an Ontology profile; generated clients are Ontology artifacts; the observation plane is physical storage; agents are principals. Product count remains three.

9. **Definition branches reused as scenarios.** A draft changes meaning and requires release governance. A scenario changes hypothetical operational state and must be incapable of effects. The types make conversion impossible.

10. **Commit equals success.** Local authority can commit a decision while an external system is pending or unknowable. Any API that returns one boolean `success` across that boundary is rejected.

11. **Always-on agent autonomy.** Agents receive attenuated leases with purpose, bounds, release scope, delegation chain, and expiry. “The model decided” is never an authority source.

12. **Kafka, Redis, microservices, and workflow infrastructure as day-one architecture.** A transactional outbox, immutable objects, PostgreSQL, and Restate only for effects are enough. Delivery infrastructure can evolve behind event consumers without becoming semantic primitives.

13. **A generic plugin marketplace before one vertical works.** The extension boundary is the release compiler and source/effect contracts. A marketplace would optimize distribution before identity, truth, policy, Actions, and Watches are proven.

14. **Handwritten parity across CLI, API, MCP, and Eve.** Independent controllers inevitably drift in names, types, policy, and action semantics. Every surface is projected from the release and checked by one semantic fingerprint.

15. **Configurable dashboard chrome as depth.** Living World is an object/situation/decision/evidence surface driven by focus. Charts and layouts exist only when a released experience facet makes the current decision clearer.

# 10. Rationale

## Problem

Zoen must combine an intimate proactive relationship with a governed operational World that remains correct under ambiguous identity, rival evidence, multiple clocks, licensed data, concurrent decisions, agent delegation, dense observations, crashes, and external uncertainty. The non-obvious challenge is to preserve one comprehensible product from household scale to institutional scale without turning conversation into authority, providers into ontology, transports into separate semantics, or event-driven architecture into universal event sourcing. The only inherited constraints are the three-product boundary, Better Auth's narrow role, Eve's ownership of conversation, domain-native public Actions, Restate's effect-only role, no Redis, channel text quality, and journey-based verification.

## Usage

The usage above was the design input. A person states ongoing intent, receives one ambiguity question only when required, sees a current Frame with evidence and time, and later receives one earned interruption with a domain Action. An operator opens typed objects and invokes `protectReserve` or `applyRebalance`, never manipulates claims or lifecycle verbs. A builder authors one `WorldSource`, evaluates semantic and journey effects, and publishes one release that produces every surface. An agent progressively discovers the same capabilities under a bounded delegation. These four experiences force the types: `ResolvedEntity` prevents silent identity choice; `Basis` removes ambient truth; `ActionOffer` makes consequences precede authority; `Receipt` separates commit and settlement; `Watch` makes attention a governed object; `WorldRelease` prevents semantic drift.

## Shape

The recommended shape is a **compiled World protocol centered on Basis → Frame → domain Action/Watch → Receipt**.

`WorldRelease` is the immutable executable constitution. It closes over meaning, source contracts, resolvers, policies, rule artifacts, capabilities, experience facets, migrations, and journey proofs. This is the single source of truth for every semantic invariant and surface fingerprint, per foundational-thinking and encode-lessons-in-structure.

`Basis` is mandatory and complete. It pins release, valid scope, knowledge cut, belief profile, policy cut, principal, purpose, delegation, and audience. The system resolves friendly “now/latest” requests once at the boundary and trusts typed bases internally, per boundary-discipline. Frames, offers, cursors, scenarios, caches, proofs, and exports all retain it.

Identity, evidence, belief, and settlement remain different algebraic types. Only Identity can construct `ResolvedEntity`; only acquisition can construct `ArtifactReceipt`; only resolution can construct accepted `Belief`; only the agency transaction can construct a World commit and effect intent. This makes silent first-match identity, ambient provenance, and optimistic external success unrepresentable in ordinary code.

The public runtime has five deep operations: discover authorized capability, open Frame, prepare Action/Watch, commit a required decision, and explain proof. Generated domain clients hide those mechanics and expose domain language. The small interface hides policy pushdown, temporal selection, rival resolution, relational/columnar planning, concurrency, idempotency, effects, and lineage. This is high interface depth rather than a generic command bus: callers supply domain inputs and receive domain outputs, while transport and persistence never leak.

State ownership follows knowledge, not execution order, per minimize-reader-load. Release owns model evolution; Authority owns grants and entitlements; Identity owns resolution; Reality owns evidence/belief/query; Agency owns decisions and commits; Attention owns semantic Watches; Eve owns relationship and interruption. No module is merely “validate,” “process,” or “save.” A hot flow crosses at most surface → facade → owner.

Concurrent actors write per-aggregate state and merge only in an ordered World transaction, per separate-before-serializing-shared-state. Action offers carry exact read-set digests. World commits supply a simple total knowledge cut; dense cells never enter that stream individually. Operation, acquisition, attention, event-consumer, and effect identities are explicit and replay-safe, per make-operations-idempotent.

The storage split is semantic but the query surface is one. Sparse operational truth and receipts remain temporal relational data; raw bytes and releases are content-addressed; dense observations are immutable segments under semantic manifests; Eve interactions are an event stream. `SeriesHandle` and `Basis` bridge the observation plane into Objects, so physical scale does not create a conceptual fork.

Surface generation uses a semantic atlas plus release-pinned medium-specific facets. That allows an excellent CLI, typed API, context-efficient MCP, human Eve, and visual Living World without reducing all of them to the least expressive transport. Semantic fingerprints and real journeys prove parity.

The design deliberately does not create a general workflow engine, graph store, data catalog, dashboard builder, plugin marketplace, SDK product, or event bus. Those additions would increase public concepts without deepening the central loop, per subtract-before-you-add.

## Synthesis decision

Candidate A recommends the compiled World protocol as the base shape. Within its explored alternatives, it chose `Basis`, `Frame`, released domain Actions, `Watch`, and honest `Receipt` as the minimum concepts that make the desired human experience inevitable. It incorporated Palantir's object/action/security unity, Bloomberg's identity/field/time/entitlement rigor, and OpenBB's progressive capability projection while rejecting their platform breadth or endpoint-centricity. Its structurally distinctive choice is the two-stage attention boundary—Ontology judges semantic significance, Eve judges interruption—and the refusal to expose any fixed universal verb list as product language. Cross-candidate grafting remains the orchestrator's synthesis step.

## Tradeoffs accepted

- We accept one ordered commit stream per World in exchange for simple, reproducible knowledge cuts and atomic multi-object decisions; dense observations are batched outside the stream and Worlds can be placed independently.
- We accept two physical truth planes—relational semantic authority and columnar observations—in exchange for keeping one rigorous semantic surface from personal to institutional volume.
- We accept immutable artifacts, segments, and old release closures consuming storage in exchange for replay, correction history, portability, and honest point-in-time explanation.
- We accept release publication ceremony in exchange for eliminating drift among meaning, policy, code, mappings, and surfaces.
- We accept that capability discovery differs by principal and purpose in exchange for preventing entitlement leakage before names, counts, schemas, and cursors are exposed.
- We accept a modular monolith before independently scalable services in exchange for short call chains, atomic transactions, and one-engineer comprehensibility.
- We accept that a Watch can remain pinned or require migration after incompatible meaning changes in exchange for never silently changing an ongoing promise.
- We accept bounded agent autonomy in exchange for making every consequential act attributable, revocable, and explainable.
- We accept orphan immutable objects before database acceptance in exchange for avoiding distributed transactions; reachability GC handles them safely.
- We accept that some licensed Worlds cannot export complete raw evidence in exchange for honoring contractual rights; portable bundles expose explicit protected gaps rather than fabricating completeness.

## Alternatives considered

1. **Universal event-sourced actor mesh.** Each object, conversation, source, Watch, and effect would be an actor whose event stream reconstructs state. It hides distribution mechanics but exposes ordering, replay, snapshot, and cross-actor transaction complexity to every domain module. It lost to temporal authority plus meaningful events because the chosen interface hides more concurrency and avoids treating dense observations as decisions.

2. **Palantir-style object platform with separate data, workflow, app, model, and governance services.** It can hide enormous enterprise complexity after years of platform investment, but initially exposes a vast authoring and operating surface. It lost because World release compilation plus five runtime operations delivers the decision semantics with far greater interface depth per concept.

3. **Agent-first tool fabric with conversation memory and MCP servers as the integration layer.** It makes demos fast and implementation simple, but forces callers and prompts to coordinate identity, provider choice, provenance, authorization, retries, and tool lifecycle. It hides almost none of the hard problem and makes the model an ambient authority. It was rejected.

4. **Knowledge graph/triple store with generic CRUD and SPARQL-like query.** It provides flexible schema and traversal but exposes storage vocabulary, weakens typed identity/action invariants, and leaves belief, entitlement, decisions, and settlement to callers. Typed released objects and object-set plans hide more complexity behind a smaller surface.

5. **One normalized provider model plus generated endpoints.** It efficiently hides adapter differences but exposes provider selection, unresolved identifiers, missing clocks, least-common fields, and licensing assumptions. Source contracts feeding a governed World hide those complexities and preserve rival evidence.

6. **Seven generic lifecycle verbs shared by every surface.** It appears elegant because the verb count is small, but the interface is shallow: every caller must understand the engine lifecycle and assemble domain meaning around it. Five private protocol mechanics plus generated domain Actions keep the kernel smaller while making the caller surface deeper.

## Open questions and risks

- Is Household Runway the correct first World wedge, or is there another recurring concern with a stronger combination of personal intimacy, dense evidence, and a safe consequential Action?
- What is the largest operational boundary that should remain one totally ordered World before explicit World federation is preferable?
- Which Actions may use `DecisionRequirement::None` for a human, and what product rule prevents convenience from becoming silent authority?
- Which provider rights must be modeled in the first source contract—display, derivation, retention, export, redistribution, and model-training use—and which can wait without compromising the type shape?
- How should a person understand a belief profile change in plain language when two valid profiles choose different assertions?
- Which portions of a portable `WorldBundle` should be encrypted to the destination World, and how are revocation and licensed-reference expiry represented?
- What is the minimum release authoring language that remains approachable to an AGI-assisted non-programmer without becoming an untyped configuration language?
- At what measured observation volume should the embedded columnar scan engine become a separately scaled runtime while retaining identical manifests and `SeriesRequest` semantics?
- What relationship-level signals may Eve use for attention arbitration without turning private conversational context into World evidence?
- Which real provider sandboxes and signed evidence corpora can make release journeys deterministic enough for gating without introducing mock-only behavior?

## Next implementation step

Build Slice 1 as a walking skeleton: one hand-authored Household Finance `WorldRelease`, one Better Auth Account-to-membership exchange, one evidence-backed runway `Frame` with complete `Basis` and `ProofRef`, and one Eve/Living World focus journey through the real deployment.
