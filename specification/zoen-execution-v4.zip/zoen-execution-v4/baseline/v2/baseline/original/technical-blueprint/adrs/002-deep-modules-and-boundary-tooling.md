# ADR 002: Deep modules and one-way dependencies

Status: Accepted

## Context

A modular monolith is only coherent when each module hides a substantial policy and the import graph matches the authority graph. Directory names alone do not stop Eve from mutating Ontology, a connector from bypassing admission, or a validation library from becoming the domain model.

Zoen also needs two forms of validation. Fixed transport envelopes are code-owned. Release-defined fact and action schemas are data-owned and remain unknown until a release is loaded. Treating both as the same validation problem would either erase types or create a generated-code pipeline for every world.

## Decision

The top-level dependency direction is:

```text
composition root
  -> public interfaces and infrastructure adapters
  -> product application modules
  -> product domain modules
  -> foundation and release model
```

Imports never point upward. Product modules expose ports; adapters implement them. Interfaces translate protocols into application calls and contain no domain decisions.

The repository has three executable or visible roots in `apps/server`, `apps/conversation`, and `apps/cli`; durable authored inputs in `releases`; and top-level `journeys`, `operations`, and `architecture`. Workspaces under `packages` begin as `foundation`, `release-model`, `door`, `ontology-domain`, `ontology-application`, `ontology-protocol`, `eve`, `web`, `storage-postgres`, `storage-objects`, `dense-duckdb`, `authorization-cedar`, `effects-restate`, `channels`, `models`, and `observability`. A new workspace must earn either an enforceable dependency boundary or a distinct executable target.

The initial modules are:

- `foundation`: identifiers, digests, canonical bytes, clocks, results, pagination, and telemetry vocabulary.
- `release-model`: closed release IR, schema references, stable semantic identifiers, and release validation.
- `door`: identity proofs, sessions, step-up, delegated clients, and decision handles.
- `ontology/admission`: parse, validate, normalize, authorize, and prepare commands.
- `ontology/truth`: facts, evidence, temporal cuts, frames, and dense observation references.
- `ontology/agency`: Actions, Cases, approvals, effects, receipts, and settlement.
- `ontology/attention`: Questions, Packs, disclosures, and memberships.
- `ontology/evolution`: release preparation, proof verification, and activation.
- `ontology/external`: connector declarations, source cursors, and provider attestations.
- `ontology/commit`: locks, AuthorityCommit, ProgressCommit, outbox, and audit roots.
- `eve/relationship`, `eve/conversation`, `eve/attention`, and `eve/presentation`.
- adapters for PostgreSQL, object storage, DuckDB, Cedar, Better Auth, Restate, model providers, Kapso/Chat SDK, native Eve Telegram, Resend/Chat SDK, and clocks. A Zoen-owned implementation of Chat SDK's public `StateAdapter` uses explicit SQL in isolated `kapso` and `email` schemas of the dedicated `eve_channels` database; it never becomes Eve or Ontology truth.
- public interfaces for API, CLI protocol, MCP, and Eve channels.

Additional rules:

- Only the composition root may import concrete adapters.
- Cordis imports are forbidden everywhere. ADR 013 permits a future evaluation behind `EveScopePort` only after its quantitative reopen trigger is met.
- Eve sees only a narrow `EveWorldPort` for entering, inspecting, opening authorized references, proposing Actions, and submitting already proved decisions. It cannot publish releases, admit evidence, mutate Watch checkpoints, create Notices or receipts, or execute effects.
- Better Auth stays behind Door. Cedar stays behind `AuthorizationPort`. DuckDB stays behind `ObservationQueryPort`. Restate stays behind `ZoenEffectPort`.
- Zod 4 validates fixed code-owned boundary envelopes. Ajv 8 validates release-owned JSON Schema 2020-12. Neither library defines domain behavior.
- First-party persistence uses `pg` 8 with explicit SQL repositories and transaction objects. Better Auth may use its official Kysely-backed adapter internally; Ontology does not inherit that abstraction.
- TypeScript uses `strict`, `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noImplicitReturns`, `noFallthroughCasesInSwitch`, `noPropertyAccessFromIndexSignature`, `noUncheckedSideEffectImports`, `useUnknownInCatchVariables`, `verbatimModuleSyntax`, `isolatedDeclarations`, `erasableSyntaxOnly`, and project references. `any`, unchecked casts, non-null assertions, TypeScript enums, floating Promises, direct time or randomness, ambient environment access, and cross-module deep imports fail static checks.
- Dependency-cruiser 18 and ESLint 10 own import-graph locks. These locks are static architecture checks, not tests.
- Application ports use frozen values, private boundary constructors, branded IDs, exhaustive state unions, and closed `Result` unions. Exceptions are reserved for programmer or infrastructure faults and are translated once at an adapter boundary. Provider objects, SQL rows, and broad `Record<string, unknown>` values stop at decoded adapters. There is no `BaseRepository`, generic event bus, universal `Entity`, service locator, wildcard barrel, or catch-all `shared`, `common`, or `utils` package.
- `storage-postgres` has separate Door, Ontology, and Eve entry points and scoped pool factories. It exposes no root repository barrel and can never construct an all-schema runtime role.

## Consequences

- Domain policy can be read without framework, SQL, HTTP, or provider details.
- Dynamic world schemas remain data while core envelopes remain statically typed.
- Raw SQL increases repository code, but makes transactional boundaries and locks visible where correctness depends on them.
- Some values are checked twice: once at an untrusted boundary and once by database constraints. That duplication protects different failure boundaries.

## Reopen triggers

- A module has more than three independent reasons to change or routinely requires unrelated maintainers to coordinate; split that module behind a port.
- A port has only one trivial implementation and merely mirrors its adapter for two releases; inline it.
- First-party query code becomes a measured delivery bottleneck across at least three modules; evaluate a typed query builder against the AuthorityCommit journeys before adoption.
- Clean install plus build exceeds five minutes in ten consecutive standard CI runs and traces show redundant workspace work dominates; evaluate orchestration tooling before adding it.
- A boundary tool cannot support a required standard or produces repeated security incidents; replace it behind its existing port.
