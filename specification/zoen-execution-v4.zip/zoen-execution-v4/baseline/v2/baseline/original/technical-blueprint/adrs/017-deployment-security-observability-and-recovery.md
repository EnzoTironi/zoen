# ADR 017: Deployment, security, observability, and recovery

Status: Accepted

## Context

A compact application still needs production discipline. The highest-risk operational mistakes are deploying an image different from the proved image, running incompatible migrations beside an old process, sharing overly broad credentials, recording private payloads in telemetry, or restoring old outbox and effect rows into an environment that immediately repeats external work.

Recovery is part of authority correctness, not a database-provider checkbox.

## Decision

The initial production cell is one Fly application and one steady-state Machine in Sao Paulo, one always-active Neon PostgreSQL 18 project in Sao Paulo, private Tigris buckets, Restate Cloud, AWS KMS in `sa-east-1`, and Grafana Cloud through OTLP. One signed image runs the Zoen Hono edge/authority process and the supported Eve Nitro process under ADR 029. The deployed image is the exact registry digest named by ReleaseProof, runs both processes as non-root users with a read-only root filesystem, and uses no mutable tag as identity.

### Credentials and cryptography

- Fly secrets contain only bootstrap material and scoped runtime credentials. Door, Ontology commit, Ontology read, Eve Workflow, channel-ingress/operational state, effect execution, migrator, backup, evaluation, and support use distinct database roles or credentials. Eve Workflow receives a dedicated `eve_workflow` database and role because its upstream package does not expose schema isolation; it never falls back to Ontology's connection string. Chat SDK bridges can reach only Eve-owned operational storage, never Ontology authority.
- Tigris has separate private credentials and prefixes for production, evaluation, journeys, admission staging, published dense objects, and backups. Object writers have write-without-delete capability. Garbage collection uses a separate delete-only credential and a signed reachability plan. Short-lived signed reads require fresh Ontology authorization and never enter Eve history.
- All connector access goes through `CredentialVaultPort`. Tokens are versioned, scoped to realm, World, source or destination and purpose, and envelope-encrypted with per-record data keys and a dedicated symmetric AWS KMS key. Ciphertext and encrypted data keys live in PostgreSQL. Plaintext exists only for the adapter call and never enters Restate history, models, receipts, logs, or traces.
- ReleaseProof uses a separate AWS KMS asymmetric signing key behind `ReleaseSignerPort`. A versioned trust registry supports rotation and immediate revocation. CI image provenance uses keyless Sigstore/Cosign in addition to, not instead of, the release signer.
- Signing and encryption keys have separate administrators and audit trails. A new signing key is issued at least every 180 days; prior public keys remain verification-only for the full retention of their proofs unless explicitly revoked. Emergency revocation is immediate. Data-key rewrap is online and does not change semantic digests.
- Public, database, object, Restate, and provider traffic requires TLS. The public listener has request, body, decompression, header, rate, and deadline limits. Connector egress is allowlisted and rejects private, link-local, loopback, and metadata-network destinations after DNS resolution.

Credential access records a non-sensitive audit fact with service identity, credential reference and version, purpose, source lease or EffectIntent, and time. Per-principal, client, relationship, World, source, Action, model, dense query, export, and connector budgets return closed outcomes and never partially commit.

The Hono process necessarily holds several Door and Ontology credentials, so roles reduce accidental misuse but do not contain total compromise of that process. Eve is already a separate process and receives model, channel, and Eve-store credentials but no Ontology database, object-admission, release-signing, or Restate credentials. Same-Machine compromise is not claimed as a hard security boundary. A further Machine split is a security decision, not a language decision.

### Lifecycle and observability

Startup validates configuration, rejects credential/database aliasing, establishes safe clients, checks both Zoen and Eve-store migration versions, verifies active release, manifest, database, and authoritative object-storage digests, starts the loopback Eve capability endpoint and private Restate listener, starts the exact built Eve Nitro service on loopback, proves `/eve/v1/health`, starts the public Hono listener, and only then claims eligible worker leases. Global readiness remains false until those authority prerequisites and the Eve runtime handshake pass. Restate, model, channel, and other optional provider probes publish capability-specific health and disable only their dependent operations; their outage cannot make inspect-only Zoen claim that it is dead.

Shutdown first makes Hono unready, stops ingress and new lease claims, aborts dense queries, asks Eve to stop accepting sessions and drain Workflow steps and streams, lets AuthorityCommits finish within a bound, checkpoints operational progress, closes the Eve Workflow world, drains Restate and both HTTP runtimes, then closes clients. The supervisor forwards signals and exits the Machine if either runtime exits. Kill journeys cover every step without relying on graceful shutdown.

Pino 10 writes structured logs and OpenTelemetry emits traces and metrics. Correlation fields include realm kind, hashed World ID, request, interaction, operation, commit, Case, effect, release, manifest, and trace IDs. Payloads, evidence, prompts, model output, credentials, protected names, and signed URLs are forbidden in telemetry. High-cardinality references stay in traces and logs, never metric labels. Audit envelopes are never reconstructed from logs. Required metrics include head-lock wait, serialization aborts, commit duration, outbox age, effect attempts and `Unknown`, Watch silence and Notices, authorization denies, dense scan and cancellation, manifest verification, proof duration, recovery fence state, and credential errors.

### Deployment and migration

GitHub Actions runs the CI tiers and Docker BuildKit creates the multi-stage OCI image. CI builds the image once, emits SBOM and provenance, proves it, and deploys that digest. Before launch, development and test data are disposable. Incompatible schema changes use an explicit maintenance deployment: stop ingress and workers, drain commits, run the checked-in migration with the migrator role, deploy the proved image, run smoke journeys, and reopen. An old image never runs against an incompatible schema. After the first production commitment, this migration policy must be replaced by an explicit expand-and-contract compatibility window before rolling or zero-downtime deployment is allowed.

Image construction runs `pnpm install --frozen-lockfile` from the committed workspace and lock files. The workspace config enforces strict peers, `disallowWorkspaceCycles`, `minimumReleaseAge`, a root catalog, `workspace:` internal references, and `allowBuilds` containing only individually reviewed native packages. The Node base image is pinned by digest. The runtime image contains compiled Hono code, static assets, generated Eve Nitro output, and the exact runtime dependencies required by both processes, but no compiler, package manager, secret-bearing source map, migration credential, or runtime download mechanism. It has bounded writable temporary space for Parquet work. The default Eve file Workflow world is absent from the production path. CI rejects unknown licenses, unresolved critical advisories without an explicit risk decision, unreviewed lifecycle scripts, and runtime package downloads.

GitHub Actions are pinned by commit SHA. Renovate changes one dependency family per pull request and runs its affected journeys; dependency upgrades do not share a release with unrelated product changes. A critical exception records owner, reason, compensating control, and expiry.

Every deployment verifies image, proof, Zoen migration, Eve/Workflow version pair, and Eve-store migration compatibility; acquires a deployment fence; applies forward migrations; starts the proved image with claims disabled; verifies release, object, both database, Eve, and Restate identities; runs the proxy/export-manifest/startup-recovery probes; registers the signed effect endpoint revision; enables claims and dispatch; runs smoke journeys; then releases the fence. Referenced prior handlers remain available.

### Backup, restore, and recovery fence

- Neon PITR retains at least 30 days. Encrypted, transactionally consistent logical exports cover the entire Ontology/Door database and the separate Eve Workflow/channel-ingress database on the same recovery cadence; each is retained for 35 days and one month-end pair is retained for 12 months. A realm- or table-filtered application export is not a recoverable backup. Restore evidence binds the two database checkpoints without pretending they form one transaction.
- Private object versioning or immutable retention is at least 35 days and never shorter than any database, Frame, receipt, Case, proof, or legal-hold reference.
- Every release activation and at least every hour produces a signed `WorldCheckpoint` containing the full World head, latest commit digest, audit root, retained manifest roots, release digest, and backup epoch.
- Initial objectives are authority RPO at most five minutes and service RTO at most 60 minutes. Restore is rehearsed monthly and in every release proof until three consecutive drills meet both objectives, then at least quarterly.

A restore is first rehearsed in a sealed recovery realm. It verifies migration checksums plus every active and retained release, proof, manifest, segment, Frame, Case, Watch, interaction, effect, and audit reference before promotion. The promoted deployment starts with a new random `RecoveryEpochId` set in the deployment control plane before the restored database is attached. Runtime workers fail closed when that external epoch does not match a signed active database epoch, so a rewound database cannot forget the fence. Public reads may open only after digest verification; AuthorityCommit, outbox delivery, Restate dispatch, connector polling, Watches, and channel delivery remain disabled in `RecoveryFenced` mode. Recovery compares the restored database and objects with the last signed checkpoint, queries Restate and providers by deterministic intent IDs where possible, and marks every pending outbox item, effect, Watch, source cursor, and channel delivery as reconciled, already observed, cancelled, or `Unknown`. Nothing ambiguous is retried automatically. A signed recovery certificate and two-person production approval activate the new epoch; workers claim only rows authorized for that epoch. A post-recovery AuthorityCommit records any semantic reconciliation.

Retention and erasure are release-governed Actions. They perform a fresh disclosure and legal-hold check, remove live reachability, publish tombstones or a new dense generation, and produce a deletion receipt. Physical object and backup deletion waits for the declared recovery window and every legal hold. Scoped data keys are destroyed after that window where cryptographic erasure is required; if law requires immediate key destruction, the receipt and checkpoint record the intentional loss of recovery. Audit history retains non-disclosing digests and the fact of erasure, not erased content.

## Consequences

- The operating system remains small, but proof, secrets, backup, and recovery have explicit owners and evidence.
- Maintenance deployments are acceptable before launch and deliberately incompatible with an unannounced zero-downtime promise.
- Recovery may stay read-only while effects are reconciled. This is preferable to duplicating a transfer or message.
- AWS KMS introduces one additional cloud dependency. Its purpose is narrow and adapter-bound.

## Reopen triggers

- Fly-to-Neon p95 AuthorityCommit latency exceeds its budget for seven days, restore misses RTO, or connection and failover journeys fail twice; reevaluate provider or region.
- Fly Managed Postgres provides the required PostgreSQL major version, automated patching and upgrades, PITR and restore, HA and failover, evaluation isolation, and a material measured colocation advantage.
- Consequential production use begins. Set product-specific retention, availability, breach response, and expand-and-contract migration policy before accepting users or data.
- Recovery cannot reconcile a provider or Restate state by deterministic identity. Keep the affected effects `Unknown` and require governed human resolution.
- A threat model requires hard containment between the Eve Machine and Ontology credentials, rather than the present separate-process/least-credential boundary. Split Machines behind ADR 029's existing protocol before claiming that property.
- RPO, RTO, key rotation, or retention becomes contractually stricter. Update operational policy and prove restore and revocation before the contract starts.
