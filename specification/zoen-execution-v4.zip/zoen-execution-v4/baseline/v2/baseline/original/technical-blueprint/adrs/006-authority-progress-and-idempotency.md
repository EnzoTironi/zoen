# ADR 006: AuthorityCommit, ProgressCommit, and exact idempotency

Status: Accepted

## Context

Some writes change what the World means: facts, membership, Cases, approvals, release activation, visible dense evidence, or effects. Others only move a durable worker forward: leasing an outbox row, recording a delivery attempt, renewing a lease, or storing a provider observation. If both classes advance the semantic cut, worker retries create false history. If neither is constrained, operational code can smuggle semantic mutation around authority rules.

Retries also require a scope stronger than a caller-chosen key. The same key from another principal, operation, or World must not alias the original result.

## Decision

An `AuthorityCommit` is the only transaction allowed to change World meaning or `WorldHead`.

Public callers submit one member of a closed command algebra and receive a closed result. They never submit a mutation plan, lock list, SQL, event payload, cut, or target head. Only the private authority module constructs the transaction capability or obtains its checked-out PostgreSQL client.

Its idempotency coordinate is exactly:

```text
(realm, authorityScope, authorizationPrincipal, operationKind, operationKey)
```

- `realm` prevents environment replay.
- `authorityScope` is normally the `WorldId`. Before a World exists, it is the authorization principal's explicit bootstrap scope; it is never null or global.
- `authorizationPrincipal` is the principal whose authorization was evaluated, not merely the transport client.
- `operationKind` prevents key reuse across verbs.
- `operationKey` is the caller's high-entropy idempotency key or a deterministic internal operation ID.

The unique coordinate stores canonical intent digest, admission basis, authorization decision digest, final status, resulting full `WorldHead`, receipt ID, and response digest. Reuse with a different intent is `IdempotencyConflict`. Reuse with the same intent performs no work and returns the original result only after fresh authorization to disclose that result. Provider idempotency keys and Restate invocation IDs use derived, domain-separated namespaces; they are not caller operation keys.

The AuthorityCommit transaction order is:

1. Validate fixed and release-owned envelopes outside the transaction where safe.
2. Begin a PostgreSQL `SERIALIZABLE` transaction and set transaction-local realm, World, principal, purpose, request, and release context for RLS and audit.
3. Claim or read the exact idempotency coordinate.
4. Lock the World head and then affected aggregates in stable `(kind, id)` order; compare the caller's expected full head or head version.
5. Recheck DecisionHandle consumption, membership version, release, exact reads, authorization, invariants, and external attestations at the locked basis.
6. Allocate exactly one next cut.
7. Write all semantic rows, receipt, deterministic EffectIntents, immutable commit envelope, audit node, and transactional outbox rows.
8. Advance `cut`, `headVersion`, affected digests, and `auditRoot` exactly once; mark the idempotency record committed.
9. Commit, or retry the entire pure command under the same coordinate for PostgreSQL SQLSTATE `40001` or `40P01`, with bounded jitter and attempts. Individual statements are never retried in isolation.

No external network, object upload, model call, or provider side effect occurs inside this transaction. Such evidence is prepared first and referenced immutably, or becomes an effect afterward.

An Action has one canonical Case that binds its intent, exact read set and head, release and policy digests, visible and hidden consequence digests, decision rule, version, expiry, and current stage. Principal-specific Case views are freshly authorized projections over that protected record, never divergent audience copies. Each DecisionHandle and contribution records the view digest and consequence digest the principal was allowed to see. Contributions append against an explicit Case revision, exact read set, principal, and purpose. The deciding AuthorityCommit locks the Case and World, recomputes release-owned admissibility, materiality, quorum, contributions, and current policy, rejects stale inputs without silently refreshing prior consent, and creates at most one DecisionReceipt with deterministic EffectIntents and outbox siblings.

A `ProgressCommit` is a named, constrained transaction that may update only operational state explicitly registered for it: leases and attempts, consumer receipts, delivery observations, retry schedules, silent Watch scan checkpoints, source-upload staging, release-preparation progress, persisted Frame read artifacts, health checkpoints, and recovery-fence acknowledgements. It cannot write temporal domain tables, memberships, material Watch state or Notices, Cases, receipts, releases, source cursors, manifest roots, EffectIntents, Settlements, audit nodes, or `WorldHead`. A material Watch evaluation uses AuthorityCommit for checkpoint plus Notice plus envelope plus outbox. Database grants and static SQL ownership enforce this allowlist.

A silent Watch evaluation writes its scan checkpoint and transition-consumer receipt atomically in one ProgressCommit. Persisting a Frame envelope writes a read artifact only and creates no World event.

One AuthorityCommit owns exactly one World. Exchange between Worlds is independently admitted evidence; there is no distributed lock or cross-World atomic command.

## Consequences

- At-least-once delivery and client retries cannot duplicate semantic outcomes.
- Operational churn does not pollute the semantic timeline.
- Some workflows become two or more transactions: prepare external evidence, AuthorityCommit intent, then ProgressCommit observations or a later AuthorityCommit for governed settlement.
- Authorization is evaluated twice for consequential writes: at preparation for good UX and under the head lock for correctness.

## Reopen triggers

- A command must atomically mutate more than one World. Define an explicit multi-World protocol with deadlock order, recovery, and a signed multi-head receipt before implementation.
- Lock contention crosses the thresholds in ADR 005 after transaction work has been minimized.
- A ProgressCommit field begins affecting user-visible truth, permission, consequence, or replay. Move it into AuthorityCommit rather than expanding the operational allowlist.
- An external system offers a transaction primitive that is demonstrably required. Reopen the workflow; never place an unbounded remote call under the World lock.
- A new bootstrap operation lacks a World. Allocate a distinct authority scope; do not weaken the coordinate.
