# Journey and CI constitution

## The only tests are journeys

Zoen tests products through the boundaries a person, delegated client, operator, or external system actually uses. There are no unit-test files, mocks, fakes, stubs, in-memory repository substitutes, `vi.mock`, snapshot forests, or tests whose only claim is an import graph.

This does not mean “only a few browser tests.” A journey is an executable proof with a public entry, real infrastructure, controlled facts, observable consequences, and a diagnostic evidence bundle. Playwright is the orchestrator because it can drive browser, HTTP, downloads, and process-facing flows; CLI and MCP clients run as real subprocesses/clients, not imported functions.

Static analysis, schema checking, compilation, dependency rules, migration verification, and supply-chain checks are gates. They are not renamed tests.

## Seven journey families

Every released capability declares which families prove it. The suite has exactly seven top-level families so coverage remains legible.

### J1 — One meaning, every surface

Teach or install a release once, then discover, inspect, invoke, explain, and export through Eve, Living World, CLI, JSON API, and MCP. Assert semantic IDs, input/output schema digests, temporal basis, policy outcome, consequence digest, receipt identity, and canonical result digest. Presentation may differ; meaning may not.

### J2 — Door, World authority, and disclosure

Exercise browser session, OAuth device flow, MCP resource token, expiry, revocation, step-up, membership change, purpose binding, hidden fields, hidden consequences, and cross-channel reopening. Prove that channel presence is not human authority, Focus is authority-free, stale views cannot decide, and a forbidden value is never fetched into an unauthorized plan.

### J3 — Evidence, live time, Frames, and Parquet

Admit immutable raw evidence, retain rival claims, resolve by purpose, correct without overwrite, query valid-time/as-known-at combinations, subscribe to entitled provider-sequenced live observations, declare gaps/staleness/conflation, capture the exact live basis of a consequential Action, seal a dense Parquet segment and manifest, compact without mutating history, and replay an old Frame after head advancement. Assert complete `WorldHead`, exact semantic and optional live bases, rights snapshots, evidence proofs, manifest reachability, result digest, and governed absence. Prove that an ephemeral tick never advances authority and that only a sealed admitted segment enters history.

### J4 — Concurrency, idempotency, and realms

Race duplicate and conflicting commands, concurrent contributions, invitation acceptance, head changes, dense admission, activation, Watch evaluation, and outbox consumers. Inject serialization failures and deadlocks. Prove stable retry, one receipt, deterministic EffectIntent IDs, no cross-World transaction, and rejection of every forged production/evaluation realm mismatch at HTTP, SQL, object, dense-query, and effect boundaries.

### J5 — Action, Effect, and honest Settlement

Open a Case, render two differently authorized views, contribute through principal-bound handles, commit once, then kill the process before and after external calls. Exercise destination idempotency, timeout after possible acceptance, reconciliation, provider rejection, later observation, and connector upgrade. Assert that DecisionReceipt never becomes Settlement and only `Observed<released outcome>` or `Unknown` is recorded.

### J6 — Eve, Watch, and channels

Build exact-pinned `eve@0.52.0`, start its Nitro output on loopback, and drive both `/eve/` and `/.well-known/workflow/` through public Hono. Prove raw signed body, headers, cookies, supported reference-only attachment handling, SSE, backpressure, cancellation, status, and path parity. Drive verified webhook admission, accepted message, direct-provider AI SDK model attempt, generated Ontology tool call, crash before and after every Workflow step and provider acknowledgement, parked wait, hook, stream append, resume, fork, Notice arbitration, silence, merge, defer, web SSE reconnect, Kapso WhatsApp, native Eve Telegram, Resend email, and readable plain-text fallback. Assert one durable ingress identity, at most one settled assistant response per branch, no duplicate runnable Workflow job, Action, or delivery, fresh authorization on reopen, scoped capability disposal, fixed provider boundaries, excellent non-helpdesk wording, and parity of semantic references across rich and flattened renderers. `InteractionJournal` must reproduce the typed view of stable Eve event identities without becoming a second replay log. Process-local adapter dedupe must fail a control case; `ChannelIngress` plus outbox before acknowledgement and idempotent delivery into Eve must survive kill and replay.

Run the exact public `chat@4.39.0` `StateAdapter` conformance behavior against `ZoenChatStateAdapter`, then kill around lock, queue, dedupe, subscription, provider ACK, and redelivery operations. Prove the dedicated `eve_channels` database, isolated `kapso`/`email` schemas, DML-only runtime roles, zero runtime DDL, and migration/upgrade behavior. A negative-control process using the rejected memory adapter must lose state on restart.

Inspect the model-visible tool manifest and exercise denial: `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, `todo`, `glob`, `grep`, `Workflow`, `sleep`, `load_skill`, and `connection_search` are absent; `ask_question` and only release-generated `inspect_*`/`propose_*` tools are present; every authored tool reports an explicit approval policy. Submit hostile byte-backed file parts and prove rejection or authorized normalization happens before session creation, `/workspace/attachments` is never written, ordinary text/reference turns never request a sandbox, and an induced sandbox access reaches only the custom disabled backend and fails closed.

### J7 — Release, deployment, and recovery

Compile canonical JSON, reject malformed/ambiguous releases, build once, create isolated EvaluationWorld, run proof evidence, sign, prepare against a complete head, race activation, deploy the same OCI digest, restore Ontology PostgreSQL, isolated `eve_workflow` and `eve_channels` databases, and objects, rotate the dispatcher lease epoch, reconcile resurrected Eve runs, accepted ingress, intents, and deliveries, and garbage-collect only unreachable artifacts. Prove no live credentials enter evaluation, no outbound delivery or dispatch occurs before the recovery fence is lifted, and the exact Eve/Workflow package pair upgrades without losing or duplicating a runnable turn.

## Real environments

### Local and pull request

The harness starts real PostgreSQL 18 databases for Ontology, isolated `eve_workflow`, and dedicated `eve_channels`, MinIO with S3 semantics, Restate, the compiled Hono process, and the exact built Eve Nitro output in containers or subprocesses. It creates disposable real databases/schemas, buckets, credentials, releases, Worlds, and users. Toxiproxy and process signals create network loss, latency, half-open connections, and crashes; they do not impersonate dependency behavior.

Protected provider behavior is not fabricated. Pull requests run all deterministic, model-free and local-infrastructure journeys. Model provider, Kapso, Telegram, Resend email, OAuth-delivery, and cloud-runtime paths run against official sandbox/test environments in protected CI.

### Evaluation and release

Evaluation uses a separate Neon authority project, a separate Eve Workflow database/role, object-store credentials and prefix, Restate namespace, provider sandbox accounts, channel bindings, encryption material, and observability partition. It runs the exact candidate OCI digest. Production data restores are forbidden; fixtures are synthetic or explicitly admitted redacted artifacts. The local file Workflow world is allowed only for disposable developer/evaluation journeys that are not used as production-storage evidence.

Release smoke journeys are small but real: identity, one proxied Eve turn, one disclosed Frame, one denied disclosure, one idempotent Action, one safely reversible sandbox Effect, one Notice delivery, and one historical Parquet read.

## Journey anatomy

Every journey declares:

```text
persona and assurance
realm + World + release + purpose
public entry surface
preconditions admitted through product APIs or setup CLI
action timeline and injected fault
observable product outcome
canonical semantic assertions
negative assertions
evidence bundle paths
cleanup and retention class
```

Setup may use a privileged, shipped `zoen evaluation seed` command; it must call the same application use cases and produce receipts. Direct SQL fixtures are allowed only for database-corruption and restore drills, where bypass is the subject of the journey.

Assertions prefer stable references, closed result kinds, released semantic IDs, database constraints, canonical digests, trace correlations, and accessible user output. They do not freeze incidental prose, generated timestamps, CSS layout pixels, SQL plans, or provider wording.

On failure the harness preserves: browser trace and screenshot, CLI transcript, MCP frames, relevant HTTP envelopes, structured logs by correlation IDs, OpenTelemetry trace, database rows named by public refs, object/manifest digests, durable-runtime invocation history, and the exact fixture/release/image digests. Secrets and undisclosed values are redacted before artifact upload.

## Static gates: Ultracite pedantic

From commit zero, quality has no warning tier:

1. formatting check;
2. Ultracite's type-aware TypeScript/React rules with `--max-warnings 0`;
3. `tsc --build` under the strict project profile;
4. no `any`, unsafe assignment/call/member access/return, floating or misused Promise, non-null assertion, unvalidated cast, unhandled discriminant, console output, unused suppression, or implicit dependency;
5. dependency-cruiser product/import constitution and cycle check;
6. Knip unused file/export/dependency check, with generated and executable entrypoints declared explicitly;
7. canonical release/schema compilation and generated-surface drift check;
8. SQL migration apply-from-zero, schema dump diff, grants/RLS/constraint lint, and downgrade-not-promised notice;
9. lockfile integrity, exact Eve/Workflow/AI SDK pair validation, generated Eve public-export, route, tool, approval, sandbox, and channel-state manifest drift, install-script allowlist, minimum package age, license policy, SBOM and vulnerability policy;
10. source/lock graph denial for `@chat-adapter/state-pg`, Cordis, raw provider SDKs, Eve default/optional tool imports, `defaultBackend()`, `ctx.getSandbox()`, skills/connections, byte-backed Eve attachment construction, Redis, and undeclared runtime DDL;
11. secret scan and OCI configuration checks.

Rule suppressions are exceptional architecture records. An inline disable must identify a tracked reason and expiry; unused disables fail. Generated code is isolated and checked at its generator boundary rather than filled with ignores. Autofix may format and apply safe lint fixes; it may not add suppressions or dangerous semantic rewrites.

The resolved toolchain is TypeScript 6.0.3 with Ultracite's ESLint, Prettier, and Stylelint presets. This deliberately prefers complete type-aware rule coverage over TypeScript 7 plus the current 59-of-61 Oxlint type-aware set. CI also runs dependency-cruiser and Knip. TypeScript 7 and Ultracite's Oxlint/Oxfmt path replace this combination only when the compiler API and boundary tooling gates in the technology reference pass.

`pnpm install --frozen-lockfile` is the only CI/image install. The committed workspace config rejects cycles, undeclared workspace fallbacks, unexpected peer versions, newly published packages inside the cooling-off window, and unapproved lifecycle builds. Native packages such as DuckDB appear individually in `allowBuilds`; there is no blanket script exception.

## CI budgets

| Lane | Budget | Required evidence |
|---|---:|---|
| Local fast gate | 5 min | format, pedantic lint, types, dependency graph, release/schema compile |
| Pull request | 15 min | local fast gate plus affected deterministic journey shards on real local infrastructure |
| Merge | 40 min | full deterministic suite, migration from zero, build image, crash/network journeys |
| Nightly | 120 min | protected providers/channels/cloud, Eve parked-run/startup recovery, concurrency/load, restore, retention, version compatibility |
| Release | no shortcut | exact-image EvaluationWorld, complete required attestations, signed proof, deploy-same-digest, smoke |

Budgets control feedback, never permit skipping a mandatory invariant. If a lane exceeds budget, first improve fixture reuse, safe parallelism, diagnostics, and journey selection. Do not respond by replacing real boundaries with mocks.

## Performance evidence

Performance claims use representative public journeys and immutable fixture corpora. Record p50/p95/p99, first meaningful response/batch, CPU, peak RSS, allocations when available, database lock wait, bytes and object requests, cold/warm state, cancellation latency, and result digest.

The dense-engine bakeoff uses identical Parquet bytes, manifests, query plans, concurrency, machine class, warmup, and result digests. Runtime/library marketing benchmarks cannot select a Zoen architecture. Baseline and treatment artifacts must be retained; a claim without the comparison is `INCONCLUSIVE`.

## Definition of done

A product slice is done only when its public journey passes, negative authority path passes, fault recovery passes in proportion to risk, static gates are clean with zero warnings/suppressions added, observability identifies the outcome from public references, and the owning ADR/release contract still says the truth. Compilation alone is no evidence of a product.
