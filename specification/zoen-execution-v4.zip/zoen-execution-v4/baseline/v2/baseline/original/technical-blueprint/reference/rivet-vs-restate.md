# Rivet and Restate

## Status

- Decision date: 2026-09-04
- Evidence checked: 2026-09-04
- Decision: adopt Restate only for Ontology `ZoenEffect`
- Launch exclusions: Rivet Actors, Rivet Workflows, and Rivet Dynamic Apps runtime
- Revisit status: evidence-gated

## Decision

Zoen uses Restate only to recover and reconcile external effects. Postgres owns every canonical `EffectIntent`, `EffectAttempt`, and `EffectSettlement`. The Restate journal is not authority.

Eve owns conversation durability. Eve may use Cordis for in-process service composition and lifecycle cleanup. Rivet does not replace Cordis because the two libraries solve different problems.

Workshop and Living World mini-apps are an Ontology and Eve interaction form. They are not a fourth product. The launch implementation uses the released declarative app manifest and a static renderer. Rich artifacts target the stable MCP Apps delivery protocol, with Eve as the first-party host. Rivet Dynamic Apps remains a possible generator/build/runtime adapter after it passes the gate in this document; it does not define artifact identity or authority.

## Invariants

The runtime choice cannot change these rules:

1. An `AuthorityCommit` writes domain events, the `EffectIntent`, and its outbox record in one PostgreSQL transaction.
2. The runtime receives only a stable `EffectIntentId` and the bounded data needed to execute the effect.
3. PostgreSQL constraints govern attempt allocation and settlement transitions.
4. A provider call uses a stable provider idempotency key when the provider supports one.
5. A timeout after a provider call records uncertainty. It does not imply failure.
6. Only a settlement transaction changes the canonical effect result.
7. A workflow journal cannot authorize a World change.
8. Conversation state remains in Eve's canonical event history.
9. A mini-app can read projections and request domain Actions only through the same authorized HTTP, MCP, and domain APIs as every other client.
10. A rich mini-app remains exportable as an MCP Apps-compatible artifact and useful as structured/text output without Rivet or a UI-capable host.

## Runtime comparison

| Property | Rivet | Restate | Zoen decision |
|---|---|---|---|
| TypeScript support | `rivetkit` is TypeScript-first and requires Node 22 or later | The TypeScript SDK is established and current | Both satisfy the language requirement |
| Durable execution | Actors, durable state, queues, and replayable Workflows | Journaled steps, durable calls, timers, and invocation state | Restate has the older stable workflow contract |
| Concurrency | Actor actions run in parallel by default | Virtual object and workflow semantics serialize defined handlers | PostgreSQL still owns authority serialization |
| External exactly-once | Not provided | Not provided | Provider idempotency plus the PostgreSQL state machine is required |
| Failure rollback | Failed workflow attempts can retain state and variable mutations | Journal replay preserves completed operations | Neither journal is a database transaction |
| Versioning | `ctx.getVersion` records branch choices in workflow history | Immutable deployments pin an invocation to one deployment | Restate has the clearer operational boundary; both require upgrade journeys |
| Production topology | Worker, control plane, and storage | Restate server or Restate Cloud plus the Zoen handler | Both add infrastructure; Restate stays confined to one product boundary |
| Security | Application hooks, endpoint tokens, and privileged Inspector access | Signed service requests, API keys, and network isolation | Neither replaces Better Auth, Cedar, or PostgreSQL RLS |
| Observability | Actor Inspector, logs, and Prometheus metrics | Invocation journal, logs, Prometheus metrics, and OpenTelemetry | Restate provides the stronger current effect investigation path |
| License | Apache-2.0 | BSL 1.1 server, MIT TypeScript SDK | Restate's server terms permit Zoen's internal use; record the license in the dependency ledger |
| Current maturity | `rivetkit` is active; standalone Workflows 1.0 is days old | Server and TypeScript SDK have shipped since 2023 | Adopt Restate now; keep Rivet behind an evidence gate |

## Effect execution contract

The dispatcher follows this sequence:

1. `AuthorityCommit` inserts the domain event, `EffectIntent`, and outbox row.
2. The outbox invokes the Restate handler with `EffectIntentId` as its invocation idempotency key.
3. A journaled database step starts a serializable transaction. The transaction inserts or claims an `EffectAttempt` with a unique `(intent_id, attempt_no)` key and a stable provider idempotency key.
4. The handler calls the provider with the stable key.
5. If the provider returns a receipt, another journaled database step inserts the immutable `EffectSettlement`. A unique provider receipt or idempotency constraint prevents a second canonical settlement.
6. If the result is unknown, the handler records that state and reconciles it. The handler does not create a new logical effect.

Restate's completed invocation retention is not permanent business idempotency. PostgreSQL uniqueness and legal-transition constraints remain permanent.

## Restate limits

Restate does not make an arbitrary provider call exactly once. The provider may accept a call and lose the response before Restate records completion. The handler must therefore use the provider's idempotency facility or reconcile by provider receipt.

Restate also adds a stateful service or a managed dependency. The one Fly app contains Zoen's signed Restate handler, not the Restate control plane. Deployment journeys must prove endpoint signing, version draining, storage recovery, and the loss of the Restate service.

## Rivet findings

Rivet Actors is active and credible. Actor state is isolated, queues are durable, and the runtime supports long-lived stateful processes. These capabilities do not imply a serial authority boundary. Actor actions run in parallel by default, and actor state persistence does not share the `AuthorityCommit` transaction.

The current queue documentation contains a blocking contradiction. The queue page says that Rivet removes a message when the receiver gets it and does not redeliver after a processing failure. The production checklist says that a failure before `complete()` causes a retry. Zoen cannot assign effect delivery to that contract until Rivet resolves the discrepancy and a crash journey confirms the result.

Standalone Rivet Workflows reached version 1.0.0 on 2026-08-31. Older examples use `rivetkit/workflow`; the current quickstart uses `@rivet-dev/workflows`. The package may mature into a good adapter, but its present release age and documentation drift are too high for the effect constitution.

## Eve and Cordis

Cordis provides in-process service registration, dependency ordering, typed event dispatch, child contexts, and reversible lifecycle effects. It does not provide durable workflow history.

Rivet provides a distributed actor and workflow runtime. It does not replace Cordis service composition. Adding Rivet to Eve at launch would introduce another durable state owner and another control plane.

Revisit Rivet for Eve only as an `EveSessionRuntimePort` implementation. The adapter may manage wake, hibernation, connection fanout, and per-session locality. It must rebuild from Eve's canonical event history and cannot own a second canonical copy of a conversation.

## Mini-app constitution

A Workshop or Living World mini-app remains part of Ontology and Eve. The user may create it through conversation or the Workshop, then use it as a focused view over the same World.

Every mini-app has these properties:

- An immutable `WorldRelease` authors or references the canonical UI and app manifest.
- The manifest pins renderer version, generated artifact digest, dependencies, permissions, provenance, and model inputs.
- Generated executable code runs in a sandbox with no database connection, infrastructure credential, filesystem authority, or direct network authority.
- The sandbox receives narrow read capabilities and Action request capabilities.
- Every read applies the caller's disclosure policy. Every mutation enters the normal authorized domain Action path.
- A replay resolves the same release, manifest, renderer, and generated artifact digests.
- Export includes the manifest, generated source or bundle, provenance, and referenced release identity.
- A static declarative renderer can render the manifest when the executable runtime is unavailable or rejected.

Rivet Dynamic Apps is a candidate implementation of the executable adapter, not the product contract. Its current package is version 0.3.1 and its documentation labels it Preview. It therefore remains outside the launch runtime.

The portable contract is MCP Apps: a content-addressed `ui://` resource, declared app-visible tools, content-security metadata, host-mediated JSON-RPC and a structured/text fallback. Eve/Living World is the first-party host. The inspected `@modelcontextprotocol/ext-apps` package still peers on the legacy aggregate MCP SDK while Zoen selects the split v2 SDK. Zoen therefore targets the protocol without installing a second MCP core line; it adopts the package after v2 compatibility or uses a minimal conformance-proved adapter.

## Adopt, reject, and revisit

### Adopt

- Restate TypeScript SDK for Ontology `ZoenEffect` only.
- PostgreSQL as the canonical effect state machine.
- Stable provider idempotency keys and explicit uncertain outcomes.
- Cordis inside Eve when its scoped composition and cleanup reduce code.
- Released mini-app manifests with a static declarative renderer.

### Reject at launch

- Rivet Actors or Workflows as an authority store.
- Rivet queues as the effect delivery contract.
- Rivet as Eve's durability owner.
- Rivet as a Cordis replacement.
- Rivet Dynamic Apps as the required mini-app renderer.
- Any mini-app code with direct database, credential, network, or authority access.

### Revisit Rivet Workflows

Reconsider the `ZoenEffectRuntimePort` adapter only after one pinned, non-preview version passes all of these checks:

1. Rivet resolves the queue acknowledgement contradiction in published documentation.
2. Real-process fault injection covers intent commit, enqueue, attempt insert, provider acceptance with a lost response, settlement insert, and retry.
3. Duplicate calls produce one canonical settlement. Providers with idempotency support receive at most one accepted logical effect.
4. Replay works across a code upgrade, `getVersion` branch, removed history entry, and rollback.
5. Backup, restore, control-plane loss, worker loss, secret rotation, and region failure pass on the proposed Fly topology.
6. Inspector and metrics endpoints reject unauthenticated access.
7. A 30-day soak passes with a pinned package and a documented upgrade policy.

### Revisit Rivet for Eve

Reconsider `EveSessionRuntimePort` only after multi-device reconnect, duplicate delivery, ordering, hibernation, backpressure, and rebuild journeys prove that Eve's event history remains the only canonical conversation state.

### Revisit Rivet Dynamic Apps

Run a bounded adapter spike only after the declarative renderer ships. The spike passes only if it proves:

1. The immutable release manifest fully determines the generated artifact and its permissions.
2. The sandbox has no ambient authority and cannot reach PostgreSQL, secrets, metadata services, or arbitrary network endpoints.
3. All data access and Actions traverse Zoen's authorized public contracts.
4. Provenance, dependency pins, content digests, replay, and export survive runtime upgrades.
5. Resource limits stop CPU, memory, storage, and request abuse.
6. The static renderer produces a useful result when Rivet is absent or the generated artifact fails.
7. The identical artifact runs through Eve and an independent MCP Apps host, exposes only the declared capability set, and retains useful structured/text fallback when UI rendering is unavailable.

## Contradictions and unknowns

- Rivet queue redelivery differs between the queue guide and the production checklist.
- Rivet Workflows examples span the old `rivetkit/workflow` API and the standalone `@rivet-dev/workflows` package.
- Rivet Inspector documentation says that its checked-in OpenAPI description does not cover every documented endpoint.
- Public documentation does not yet establish the required failover, backup, restore, queue deduplication, or cloud durability guarantees for Zoen.
- Restate deployment pinning makes long-running workflow upgrades operationally heavier.
- Neither product removes the provider lost-response window.

## Source ledger

All pages and package metadata were checked on 2026-09-04.

### Rivet

- [Rivet Actors repository](https://github.com/rivet-dev/actors). Latest inspected GitHub release: [v2.3.13](https://github.com/rivet-dev/actors/releases/tag/v2.3.13), published 2026-09-03.
- [`rivetkit` package](https://www.npmjs.com/package/rivetkit). Inspected version: 2.3.14, modified 2026-09-04, Node 22 or later.
- [Actor actions](https://rivet.dev/actors/docs/actions/).
- [Actor state](https://rivet.dev/actors/docs/state/).
- [Actor queues](https://rivet.dev/actors/docs/queues/).
- [Production checklist](https://rivet.dev/actors/docs/general/production-checklist/).
- [Workflow documentation](https://rivet.dev/workflows/docs/).
- [Workflow steps](https://rivet.dev/workflows/docs/steps/).
- [Workflow reference](https://rivet.dev/workflows/docs/reference/).
- [Workflow failure and recovery](https://rivet.dev/workflows/docs/failure-and-recovery/).
- [Workflow versioning](https://rivet.dev/workflows/docs/versioning/).
- [`@rivet-dev/workflows` package](https://www.npmjs.com/package/@rivet-dev/workflows). Inspected version: 1.0.0, published 2026-08-31.
- [Rivet Workflows repository and v1.0.0 release](https://github.com/rivet-dev/workflows/releases/tag/v1.0.0), published 2026-08-31.
- [Original Workflows announcement](https://rivet.dev/changelog/2026-02-24-introducing-rivet-workflows/), published 2026-02-24.
- [Runtime modes](https://rivet.dev/actors/docs/general/runtime-modes/).
- [Self-hosting architecture](https://rivet.dev/actors/self-host/).
- [Authentication](https://rivet.dev/actors/docs/authentication/).
- [Endpoints and tokens](https://rivet.dev/actors/docs/general/endpoints/).
- [Actor Inspector](https://rivet.dev/actors/docs/debugging/).
- [Prometheus metrics](https://rivet.dev/actors/self-host/workers/prometheus-metrics/).
- [Dynamic Apps quickstart](https://rivet.dev/dynamic-apps/docs/quickstart/).
- [`@rivet-dev/dynamic-apps` package](https://www.npmjs.com/package/@rivet-dev/dynamic-apps). Inspected version: 0.3.1.
- [MCP Apps extension and stable specification](https://github.com/modelcontextprotocol/ext-apps). Inspected `@modelcontextprotocol/ext-apps` version: 1.7.5.

### Restate

- [Restate server repository](https://github.com/restatedev/restate). Latest inspected release: [v1.7.8](https://github.com/restatedev/restate/releases/tag/v1.7.8), published 2026-08-27.
- [`@restatedev/restate-sdk` package](https://www.npmjs.com/package/@restatedev/restate-sdk). Inspected version: 1.17.0, modified 2026-09-03.
- [Durable steps](https://docs.restate.dev/develop/ts/durable-steps).
- [Database integration and idempotency](https://docs.restate.dev/guides/databases).
- [Service communication](https://docs.restate.dev/develop/ts/service-communication).
- [TypeScript invocation clients](https://docs.restate.dev/services/invocation/clients/typescript-sdk).
- [Service versioning](https://docs.restate.dev/services/versioning).
- [Service security](https://docs.restate.dev/services/security).
- [Metrics](https://docs.restate.dev/server/monitoring/metrics).
- [Tracing](https://docs.restate.dev/server/monitoring/tracing).
- [Logging](https://docs.restate.dev/server/monitoring/logging).
- [Server architecture](https://docs.restate.dev/server/overview).
- [Docker deployment](https://docs.restate.dev/server/deploy/docker).
- [Restate server license](https://github.com/restatedev/restate/blob/main/LICENSE).

### Cordis

- [Cordis primer](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-primer.md).
- [`@deepseek-ai/cordis` package](https://www.npmjs.com/package/@deepseek-ai/cordis). Inspected version: 4.0.2, modified 2026-08-30.
