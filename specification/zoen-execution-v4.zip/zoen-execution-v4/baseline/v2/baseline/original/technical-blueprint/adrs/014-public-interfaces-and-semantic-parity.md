# ADR 014: Native public interfaces over one semantic catalog

Status: Accepted

## Context

Ontology is simultaneously useful to a person, a browser, a CLI, an agent over MCP, and Eve. A lowest-common-denominator `invoke` endpoint would be easy to generate but would expose infrastructure rather than product verbs. Independent implementations, however, would let authorization, error behavior, receipts, and temporal meaning drift between interfaces.

The product needs semantic parity without presentation uniformity.

## Decision

The canonical application catalog contains released operations identified by `SemanticOperationId`. Each entry declares input and result schemas, authorization action, consequence and explanation metadata, idempotency policy, temporal behavior, stable errors, and presentation facets.

The release compiler emits one immutable `SurfaceManifest` from that catalog. `zoen.surface.v1` stores every name explicitly rather than deriving one interface from another. API and CLI slugs use lowercase ASCII kebab case, start with a letter, and contain at most 63 characters. MCP names use lowercase ASCII dot-separated segments, start with a letter, and contain at most 128 characters. Human labels are localized facets and never identity. It maps every approved name, slug, route descriptor, CLI descriptor, MCP tool or resource, browser form, and Eve tool to one opaque semantic ID and manifest digest. A collision within an interface, unmapped capability, hand-coded adapter name, or adapter-only domain verb fails release compilation.

The interfaces are native projections:

- The JSON API uses Hono 4, OpenAPI 3.1 descriptors, explicit resources and released verbs under `/ontology/v1/*`, ordinary HTTP semantics, and canonical JSON envelopes.
- The CLI is a thin Node 24 client using `util.parseArgs`, Door OAuth, the JSON API or MCP, stable exit codes, and explicit World, purpose, operation key, and temporal basis. `--json` emits the canonical API envelope.
- MCP uses the official v2 `@modelcontextprotocol/server`, `client`, and thin `hono` packages under `/ontology/mcp`, with Streamable HTTP and a local stdio bridge. It publishes specific released tools and resources, never a generic SQL, policy, or `invoke` tool.
- Eve calls a narrow `EveWorldPort` in process and renders only currently authorized operations. It cannot access privileged release, evidence-admission, or effect-management verbs unless the release explicitly exposes an appropriate human ceremony.
- The Living World in `apps/conversation` uses React 19, Vite 8, React Router 8, TanStack Query 5, React Aria Components 1, and native CSS tokens. It is an Eve experience over the same catalog, with accessible membership, evidence, Case, Watch, Notice, and release facets rather than a generic dashboard shell.
- Dense workbench experiences use TanStack Table 9 and Virtual 3 for keyboard-first bounded rendering, React Hook Form 7 for Action-form interaction, and ECharts 6 for Canvas or SVG data marks. Releases describe semantic table, form, and chart documents; they never contain TanStack or ECharts configuration. Server schemas and authorization remain decisive, and a hidden field is never sent merely to be hidden with CSS.

A released Workshop or focused mini-app remains a Living World facet, not a fourth product. Its immutable `MiniAppManifest` pins release, semantic capabilities, renderer version and digest, permissions, provenance, dependencies, and model inputs. V1 uses a first-party static declarative renderer. The long-term contract may compile rich content-addressed React presentation, routes, local interaction state, tables, charts, and composition into a `MiniAppArtifact`; drafts run only in EvaluationWorld, and publication pins source, dependency graph, capability requests, build evidence, and artifact digest. Every form reads authorized projections and requests Actions only through the same public catalog. It has no database credential, provider secret, ambient network, arbitrary HTML or script, `javascript:` URL, remote React component, or release-supplied module in the main origin. A future executable `MiniAppRuntimePort` stays optional and sandboxed so the declarative rendering remains useful when it is absent or fails. Portable delivery targets the stable MCP Apps contract: a content-addressed `ui://` resource, explicit content-security policy, an app-visible capability allowlist, host-mediated JSON-RPC calls, and a useful structured/text fallback. Eve/Living World is the first-party host, while the artifact remains renderable by independent conforming MCP hosts.

Every interface returns the same stable Frame, Case, receipt, Notice, release, and error references. It agrees on full head basis, authorized semantic result digest, evidence, gaps, uncertainty, and explanation root. Presentation remains idiomatic: API and CLI JSON are canonical, CLI human output is concise, MCP combines structured content with concise text, browser facets are interactive, and messaging is readable flattened prose.

Capability discovery is freshly authorized before names, descriptions, schemas, consequences, or existence cross the boundary. An unavailable capability is omitted rather than described and denied later. Listing and invoking are separately authorized.

JSON is UTF-8 with explicit versioned media and envelope types. Public mutation requests require `Idempotency-Key` and an expected head or Case version where the verb is concurrency-sensitive. Every result identifies full World head, result digest, and trace. Errors use RFC 9457 `application/problem+json` with stable Zoen codes, correlation ID, and no protected existence disclosure. Pagination cursors are opaque, signed, expiring values bound to realm, World, principal, purpose, view, release, disclosure, sort, query digest, and captured head. Server-Sent Events stream presentation updates; durable resumption comes from stable references and committed sequence, not an in-memory stream.

An export is an immutable artifact bound to audience, purpose, full head, release, manifest, disclosure decision, expiry, and content digest. Download authorization is current; an old signed URL is never authority.

The Restate listener is infrastructure-only and never appears in OpenAPI or public routing. No interface exposes raw SQL, object keys, provider payloads, Cedar evaluation, generic CRUD, or internal acquire/map/admit stages.

## Consequences

- A capability is taught once and appears as a first-class verb in every applicable interface.
- Generated descriptors reduce drift while each interface keeps the interaction style its user expects.
- Dynamic World capabilities make fully static client SDKs incomplete; the fixed envelopes are typed and release facets remain runtime schemas with stable semantic IDs.
- Cross-interface comparison can use semantic digests instead of screenshots or exact wording.

## Reopen triggers

- An external consumer requires a release-specific static SDK. Generate it from a pinned SurfaceManifest without creating separate domain logic.
- After the declarative renderer ships, Rivet Dynamic Apps may be evaluated only behind `MiniAppRuntimePort` when a pinned non-preview version passes no-ambient-authority, resource, provenance, replay, export, authorized bridge, and failure-fallback journeys.
- A genuine client-to-server streaming capability cannot be represented by commands plus SSE. Evaluate WebSocket for that capability only.
- MCP or HTTP standards change incompatibly. Version the transport adapter while preserving semantic IDs and canonical results.
- The first semantic digest mismatch between interfaces blocks release and reopens the generator or adapter design.
- A capability has no humane conversational rendering. It may remain unavailable through Eve with an explicit manifest reason; it must still retain API, CLI, and MCP semantic parity where published.
