# ADR 022: Released semantic computation, subscriptions, and data flows

Status: Accepted target contract. Implementation spans S1, S4, S6, and S7.

## Context

An operational ontology needs more than object schemas and Actions. Builders need polymorphic interfaces, object-set queries, reusable functions, change subscriptions, transformation pipelines, quality, and lineage. Without first-class contracts, each app, model, connector, or data engineer would invent private SQL, code, and change semantics. That would cap Workshop and data-platform breadth and create mutation paths outside the release.

The alternative cannot be an unbounded query or function language inside authority. General code, data engines, and model planners need explicit computation and proposal boundaries.

## Decision

`WorldRelease` gains five closed semantic contracts.

### InterfaceDefinition

`InterfaceDefinition` defines stable required properties, links, functions, and Actions that multiple object types implement. It supports exact and covariant-read compatibility. The release compiler proves each implementation. An interface is structural meaning in the Ontology. It is not a TypeScript inheritance tree, storage superclass, or generic `Entity` table.

### ObjectSetPlan

`ObjectSetPlan` is a bounded recursive algebra over released object types and interfaces: source, filter, link traversal, union, intersection, stable order, and bounded page. Predicates and order keys are closed IR. Ontology compiles a plan only after capability discovery, authorization, source-rights evaluation, and scan-budget selection. Callers never submit SQL, index expressions, object keys, or Cedar policy.

The result pins `KnowledgeBasis`, release, plan digest, sort, cursor, disclosure, rights decision and usage receipt, generic `ExactReadSet` including admitted captures, and canonical result digest. Pagination cursors bind those coordinates and expire. A plan cannot obtain hidden candidates and remove them after ranking.

### FunctionDefinition

`FunctionDefinition` pins input/output schemas, declared reads, budget, effect class, and one implementation form:

- a pure closed release expression.
- a deterministic or declared image-pinned trusted handler.
- an isolated executor that can return only a derived artifact or proposal.

The effect class is `pure`, `read-only`, or `proposal-only`. There is no released function that performs arbitrary I/O or writes authority. An operation that changes a World is an Action. An operation that contacts an external system creates an `EffectIntent` from an accepted Action.

### ActionPlannerArtifact

`ActionPlannerArtifact` is a verified, kind-indexed isolated artifact that may select one of its declared released Actions and propose typed inputs, exact reads, evidence, and an explanation. It receives a short read capability, not an authority port. It cannot define consequences, validation, quorum, mutations, Effects, or Settlement.

Ontology decodes the `ActionPlanCandidate`, reruns the released Action planner, and opens the ordinary `ActionCase`. Any mismatch, stale read, undeclared action, or invalid input rejects the candidate. Model generation and optimization can therefore help with complex plans without becoming sovereign.

### ChangeSubscription

`ChangeSubscription` binds a principal, purpose, World, release, ObjectSetPlan, fields, enter/update/leave change kinds, delivery facet, cursor, disclosure, rights proof, and expiry. It consumes admitted `AuthorityCommitEnvelope` records, not database replication or live ticks. It reauthorizes before each batch.

When visibility is revoked, the subscription emits a redaction boundary or closes according to its released contract. It does not reveal the protected object's identity through a synthetic delete. SSE, Watches, data-flow triggers, and federation projections may use the same change semantics.

## DataFlowDefinition and DatasetVersion

`DataFlowDefinition` is a released acyclic typed graph. Its nodes may acquire a released source, read an ObjectSetPlan, run an ObservationPlan, apply a FunctionDefinition, invoke a declared ExecutorArtifact, evaluate quality, and propose a dataset. Named edges bind schemas. The definition pins trigger, incremental key, rights program, quality policy, budgets, and output schema.

Ontology runtime storage owns `DataFlowAttempt`, lease, checkpoint, and wake state. A scheduler or future Rivet adapter can wake and execute an attempt but cannot own its identity or publish state. Each attempt pins one `DataFlowExecutionBasis`: complete `KnowledgeBasis`, generic exact read set, dense slices, admitted input DatasetVersions, code and kind-indexed connector artifacts, rights decisions, entitlement snapshots, and engine attestation.

A successful attempt produces an immutable proposed `DatasetVersion`. Its payload binds dataset and schema identity, materialization digest, the complete execution basis, every input, field-level lineage, transformation digests, tri-state quality results, non-widening `DataUsageContract`, release, and producing attempt. `passed`, `failed`, and `unknown` are distinct quality results. The release decides which results block admission and which permit a visibly degraded version.

Publishing a DatasetVersion uses one `AuthorityCommit`. The transaction revalidates the full execution basis, definition, exact inputs, entitlement snapshots, bounded rights meet, obligations, and required quality. It writes a separate `DatasetAdmission` naming version, commit, cut, resulting complete head, quality decision, rights decision, and usage receipt; admits the materialization; emits one ordered semantic change batch; and advances the complete World head. `DataFlowAttempt` has no `admitted` variant. Checkpoints, scheduler acknowledgements, engine state, and proposed versions remain `ProgressCommit` state or immutable staged artifacts and cannot notify downstream consumers as truth.

Batch, schedule, and change-driven data flows share this contract. An incremental run may reuse a physical checkpoint only when the input identities and released incremental contract match. High-rate input may be microbatched. A future stream or distributed engine remains an adapter behind `DataFlowRuntimePort`. Its checkpoint cannot replace PostgreSQL run state, DatasetVersion identity, Parquet history, or release semantics.

## Consequences

- The same semantic objects, functions, and subscriptions serve Living World, API, CLI, MCP, agents, data flows, and generated SDKs.
- Palantir-class application and pipeline breadth does not require public SQL or a second authority API.
- General compute stays useful through proposal and artifact contracts.
- Field-level lineage, rights, and quality make derived data inspectable but add metadata and release-authoring work.
- Change subscriptions describe admitted semantic changes, while live observations retain their separate latency contract.

## Required journeys

1. Two object types implement one interface and preserve field, link, Action, authorization, and generated-SDK parity.
2. Object-set union, intersection, traversal, stable pagination, stale cursor, hidden candidate, and scan-budget denial.
3. Pure, trusted-handler, and executor functions produce schema-valid results with declared read and resource evidence.
4. A malicious Action planner proposes an undeclared Action, hidden read, stale value, false consequence, and forged evidence. Every case is rejected.
5. Change subscription enter/update/leave, duplicate envelope, reconnect, release change, rights expiry, and non-leaking revocation.
6. Data-flow crash and replay, incremental checkpoint mismatch, concurrent publication, malformed executor result, and deterministic DatasetVersion identity.
7. Field lineage through source, join, function, model, and aggregate. Bounded rights meet never widens or drops clauses when normalization exceeds budget. Obligations and usage receipts survive publication. Failed and unknown quality follow release policy.

## Reopen triggers

- Three unrelated plans need the same missing safe operator. Add a typed IR node and replay corpus. Do not admit caller SQL.
- Closed functions cannot express a required pure computation. Evaluate the deterministic Wasm gate in ADR 010 before allowing release-supplied general code.
- A streaming engine materially improves a required flow. Adopt it behind the run port after kill, replay, rights, lineage, and result-equivalence journeys.
- No trigger permits a function, planner, subscription, or data-flow engine to write authority outside the released Action or DatasetVersion admission path.
