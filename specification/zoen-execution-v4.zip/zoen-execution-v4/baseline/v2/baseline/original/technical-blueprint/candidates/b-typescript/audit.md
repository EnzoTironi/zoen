# Hostile self-audit — Candidate B

Evidence cutoff: 2026-09-04. Scope: Candidate B only; no compatibility with the current repository is assumed.

## Verdict

The TypeScript modular-monolith bet survives. Its strongest parts are still one authority transaction, sparse PostgreSQL plus immutable Parquet manifests, Eve-owned conversation durability, and Restate restricted to `ZoenEffect`.

The document is **not yet a technical constitution**. Four claims are currently false or materially incomplete:

1. Zod cannot be the runtime truth for arbitrary declarative release schemas.
2. “API/MCP credentials” is not an authentication design; hosted MCP and the CLI need explicit OAuth flows.
3. a single process holding live credentials cannot prove hostile evaluation isolation;
4. a rolling Fly hostname is not, by itself, Restate's immutable deployment topology.

Two omissions also lower the design below the stated ambition: it reinvents a security-critical authorization evaluator instead of using Cedar, and it ignores Cordis even where Cordis is an unusually good fit—Eve's replaceable conversational runtime.

Severity means:

- **P0:** correct before accepting the constitution;
- **P1:** settle before S0/S1 implementation;
- **P2:** precision or simplification that can land with the baseline.

## Replacement decision spine

| Concern | Corrected decision |
|---|---|
| Runtime | Node `24.20.0` LTS, bundled npm `11.19.0`; exact image digest. |
| Compiler | TypeScript `7.0.2` is the canonical `tsc`; `typescript: npm:@typescript/typescript6@6.0.2` exists only for tools needing the old compiler API. Remove the sidecar after TS 7.1 ecosystem parity. |
| HTTP | Hono `4.13.5` on `@hono/node-server` `2.1.1`; one Fetch-shaped public boundary. |
| Schemas | canonical JSON Schema 2020-12 in `WorldRelease`; Ajv `8.20.0` is the runtime validator. Zod is an adapter for code-authored boundaries only, never release authority. |
| SQL | raw `pg` `8.23.0` for Ontology authority; Kysely remains an implementation detail inside Better Auth only. |
| Door | Better Auth `1.7.2` browser sessions plus its MCP/CIMD/JWT/OAuth-device plugins; no invented PAT scheme in S0. |
| MCP | `@modelcontextprotocol/server`, `core`, and `hono` `2.0.0`; MCP profile `2026-07-28`, stateless HTTP, legacy rejected. |
| Eve composition | `@deepseek-ai/cordis` `4.0.2`, confined to Eve's replaceable providers, channels, context, tools, and telemetry. |
| Authorization | `@cedar-policy/cedar-wasm/nodejs` `4.12.0` behind `AuthorizationPort`; Cedar schema and policies are release artifacts. |
| PostgreSQL provider | Amazon RDS PostgreSQL `18.6`, Multi-AZ in `sa-east-1`, direct TLS connections from Fly `gru`; no transaction pooler or RDS Proxy on authority paths. |
| Restate | raw Restate listener on `:9080`, exposed separately with identity verification and immutable, image-digest-addressed deployment URLs. |
| Evaluation | strong logical/correctness isolation for trusted application code; explicitly **not** malicious in-process code isolation. |

## Findings and exact corrections

### P0 — released schema authority is internally contradictory

Candidate B says release source is canonical JSON data, but also says Zod is the single truth and stores `z.ZodType<Row>` in `ObservationPlan`. That cannot work generically. Zod can emit JSON Schema, but several Zod constructs are unrepresentable and its JSON-Schema-to-Zod direction is experimental. A published release cannot contain a live Zod object or TypeScript generic. [Zod documents both limitations](https://zod.dev/json-schema).

**Correction:**

- Make JSON Schema 2020-12 the only released wire/data schema representation. Every schema has `SchemaId`, canonical bytes, and `SchemaDigest` in `WorldRelease`.
- Add `SchemaRegistry.compile(release, schema): Result<CompiledValidator, SchemaIssue[]>` backed by Ajv 8.20.0 in strict 2020-12 mode. Cache solely by schema digest.
- Replace `rowSchema: z.ZodType<Row>` with `rowSchema: ReleasedSchemaRef<Row>`. `Row` is compile-time help for generated/trusted callers; the referenced Ajv validator is runtime authority.
- Use the same registry for release inputs/outputs, database row boundaries, dense batches, HTTP payloads after release resolution, and generated-client conformance.
- Use MCP v2 `fromJsonSchema(document, validator)`; the SDK officially supports existing JSON Schema and Ajv on Node. Do not round-trip through Zod. [MCP schema-library guidance](https://ts.sdk.modelcontextprotocol.io/v2/advanced/schema-libraries).
- Keep Zod only where a code-owned integration exposes it naturally. Ban transforms, custom types, and refinements from anything exported into a release. Never use experimental `z.fromJSONSchema()` in authority code.
- Do not install per-World schemas as framework route schemas. A fixed route first resolves World/release, then invokes the digest-pinned validator. This supports many simultaneously active releases.
- Ajv/Fastify-style compilation treats schemas as code generation. Accept release schemas only after meta-schema validation, size/depth/regex limits, total-IR validation, and publisher authorization. Under the one-process rule, hostile schema-publisher DoS remains an admitted risk, not a sandbox claim.

### P0 — Door, hosted MCP, and CLI authentication are underspecified

The phrase “API/MCP credentials are hashed at rest” invents a token system and misses MCP 2026-07-28 authorization. Better Auth now has a first-party MCP provider, CIMD support, JWT signing/JWKS, route protection, and OAuth Device Authorization. Its MCP plugin is itself the OAuth Provider and must not be combined with a second `oauthProvider()` instance. [Better Auth MCP](https://better-auth.com/docs/plugins/mcp), [device authorization](https://better-auth.com/docs/plugins/device-authorization).

**Correction:** define exactly three Door ingress paths:

1. **Web/Eve/Living World:** secure Better Auth cookie session, CSRF/origin controls, fresh `IdentityProof` on each product boundary.
2. **Hosted MCP:** `jwt() + mcp({ resource, loginPage, consentPage }) + cimd({ metadataProfile: "mcp-2026-07-28" })`; authorization-code + PKCE for normal MCP clients; DCR disabled; `requireMcpAuth` wraps the route; `createMcpHandler(..., { legacy: "reject" })`; verified claims become MCP `AuthInfo`, then a Door proof.
3. **Zoen CLI:** one pre-registered public native client with `token_endpoint_auth_method: "none"`, `oauthDeviceAuthorization()`, device-code plus refresh-token grants, coarse Ontology scopes, and a resource-bound token. Store the refresh token only in the OS credential store. The CLI calls the hosted MCP surface and renders native commands; it does not receive a privileged local path.

Use one canonical resource identifier and pin it in discovery, issuer/audience validation, and challenges. OAuth scopes are coarse transport grants (`ontology:read`, `ontology:act`); World membership, purpose, disclosure, and quorum remain Ontology decisions.

Remove stdio from the initial hosted product. Reopen it only for a separately specified local-server threat model. Remove the claim that OAuth tokens are generically “hashed at rest”; state the actual Better Auth/JWT/refresh-token storage and rotation behavior.

Required journey: discovery → CIMD → PKCE → MCP call; insufficient scope; wrong audience; expired/revoked token; DPoP-bound request when enabled; CLI device approval/denial/expiry/refresh; every successful path produces the same Door proof shape.

### P0 — the custom policy evaluator should not be security authority

Candidate B admits the policy evaluator is security-critical, then proposes to invent it. That is neither subtractive nor ambitious. Cedar already provides fine-grained RBAC/ABAC, schema validation, deny semantics, independent auditability, and a maintained WASM interface for TypeScript. [Cedar project](https://github.com/cedar-policy/cedar), [Cedar security guidance](https://github.com/cedar-policy/cedar-docs/blob/main/docs/collections/_other/security.md).

**Correction:**

```ts
interface AuthorizationPort {
  decide<R extends Realm>(
    request: AuthorizationRequest<R>,
    release: AuthorizedPolicyBundle,
  ): Result<AuthorizationDecision, AuthorizationFailure>;
}

interface PolicyEvidence {
  release: ReleaseDigest;
  schemaDigest: Digest;
  policyDigest: Digest;
  entitiesDigest: Digest;
  requestDigest: Digest;
  decision: "allow" | "deny";
  diagnosticIds: readonly string[];
}
```

- `WorldRelease` contains canonical Cedar schema bytes, policy-set bytes, and digests.
- `ReleaseCompiler` validates policies against the schema and rejects every error before proof. Limit policy count, bytes, entity count, hierarchy depth, and evaluation time.
- At runtime, Ontology projects only the locked, relevant World facts into Cedar principal/action/resource/context plus an entity slice; `@cedar-policy/cedar-wasm/nodejs` evaluates it behind `AuthorizationPort`.
- Fail closed on malformed requests, entity/schema mismatch, engine failure, or diagnostics. Re-evaluate at final `AuthorityCommit` using the just-reread locked facts.
- Persist `PolicyEvidence` on Frames, authorized Case/Notice views, and commits.
- Cedar owns authorization and disclosure only. Quorum, mapping, computation, materiality, migration, and canonicalization remain Zoen release IR. Cedar's schema validates policies at publication; runtime request/entity construction must still be validated by Zoen.

This is still a TypeScript application. Cedar WASM is a pinned native engine dependency, like DuckDB, not a second source language in the repository.

### P0 — evaluation isolation and secrets are overclaimed

Fly Secrets are decrypted into environment variables on **every Machine in the app**, and application code can read them. Worker threads share the process and environment. A single Node process that can perform live work cannot prove that arbitrary code in the same process cannot access live credentials or egress. [Fly Secrets](https://fly.io/docs/apps/secrets/).

**Correction:** write the threat model into the constitution:

- no user-provided JavaScript, native plugin, `vm`, or eval executes; releases are bounded declarative data interpreted by trusted code;
- realm brands, separate DB roles/pools, composite keys, RLS, object namespaces, channel sinks, and connector leases protect against product defects and confused-deputy paths;
- they do not contain a compromised process or malicious dependency.

Fly env secrets should contain only bootstrap material: app DB role credentials, Better Auth signing/rotation material, Tigris bootstrap, and a credential-encryption/broker key. Provider, source, channel, and sandbox credentials become encrypted credential records selected through one `CredentialBroker`; adapters receive a realm-bound operation capability, never the raw secret.

Ban imports of `process.env`, global `fetch`, S3/model/channel SDKs, and raw credential decryption outside configuration and egress adapter packages with ESLint/dependency-cruiser. This is a correctness control, not process security.

Replace “evaluation cannot reach live” acceptance language with:

> Every public evaluation capability rejects live refs, prefixes, destinations, and credential leases; no raw credential leaves the broker; the journey observes zero production-destination calls.

If the threat model later includes malicious release authors, hostile dependencies, or contractual separation of live credentials, the required move is a separate Fly app/process boundary with distinct secrets and egress—not another TypeScript brand and not a worker thread.

Also remove the migration credential from Fly app secrets. Run checked SQL migrations from the deploy controller using short-lived CI/OIDC authority; the running image never receives owner/migrator credentials.

### P1 — Cordis is omitted at exactly the useful boundary

DeepSeek Harness uses Cordis for service injection, typed event modes, owned plugin lifecycles, and reversible registrations. Candidate B recreates enough of that machinery in Eve that omission is a real design loss. [DeepSeek's Cordis primer](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-primer.md).

**Correction:** depend on the stable `@deepseek-ai/cordis@4.0.2`, but confine it to `products/eve/runtime`:

- fixed services: `EveSessionStore`, `EveOntologyPort`, `CredentialBroker`;
- replaceable plugins: model providers, channels, prompt/context contributors, tool presenters, telemetry, and transient stream renderers;
- every registration owns a disposer; every event declares dispatch mode; production loads one committed profile/bundle;
- evaluation may mount a child context, but never receives an Ontology commit/store capability.

Do **not** make Ontology authority, PostgreSQL transactions, release activation, Watches, or domain `ZoenEffect`s Cordis plugins/events. Cordis effects are lifecycle disposers; `ZoenEffect` is durable external intent. Do not adopt the developer-preview DSH package family wholesale. This preserves the best Harness idea without making the kernel dynamically rewritable.

Required journey: replace/reload an Eve model or channel plugin, interrupt during streaming, restart, and prove one settled message and no duplicate listener/delivery. Authority semantics must be byte-identical with Cordis absent from the call graph below `EveOntologyPort`.

### P1 — choose Hono, not Fastify

Fastify is a strong server, but it is the less coherent choice here. Better Auth and MCP v2 are Fetch-native. Better Auth mounts directly in Hono, while its official Fastify recipe reconstructs Web `Request`/`Response`; MCP's Fastify recipe adds another Node adapter. Once dynamic release schemas move to application-level Ajv, Fastify's schema compiler is no longer the deciding benefit. [Better Auth Hono integration](https://better-auth.com/docs/integrations/hono), [MCP Hono adapter](https://ts.sdk.modelcontextprotocol.io/v2/api/%40modelcontextprotocol/hono/), [Hono Node adapter](https://hono.dev/docs/getting-started/nodejs).

**Correction:** use `hono@4.13.5`, `@hono/node-server@2.1.1`, and `@modelcontextprotocol/hono@2.0.0`. Mount Better Auth by passing `c.req.raw`; mount the protected MCP Fetch handler directly; use Hono streaming for SSE; use Pino as explicit request middleware. Keep `node:http` access at the server adapter only.

Do not add `@hono/zod-validator`. Static envelopes and released payloads use the same Ajv-backed schema registry. This removes Fastify, its schema/serializer lifecycle, `@modelcontextprotocol/fastify`, and `@modelcontextprotocol/node` from the app dependency graph.

### P1 — MCP v2 package names and behavior need correction

The packages exist at 2.0.0, but Candidate B's “core, server, and node” line is not the correct Hono server dependency set. MCP v2 is the stable line for the 2026-07-28 spec; framework adapters are separate packages. [MCP v2](https://ts.sdk.modelcontextprotocol.io/v2/), [v2 migration/package map](https://ts.sdk.modelcontextprotocol.io/v2/migration/upgrade-to-v2).

**Correction:** direct dependencies are:

```json
{
  "@modelcontextprotocol/server": "2.0.0",
  "@modelcontextprotocol/core": "2.0.0",
  "@modelcontextprotocol/hono": "2.0.0"
}
```

`core` is direct only where Zoen imports the public protocol Zod constants; otherwise let `server` own it transitively. Never import unpublished `core-internal`. The MCP handler is request-scoped/stateless, `legacy: "reject"`, and receives only verified `AuthInfo`. `createMcpHandler` does not authenticate by itself; Better Auth's `requireMcpAuth` must be outside it.

### P1 — Restate topology violates immutable deployment semantics as written

Restate says each deployment is immutable; a new code version is registered at a new endpoint so old invocations continue on the old deployment. A rolling Fly app at one unchanged URL does not satisfy that contract merely because connector IDs are versioned. [Restate services/deployments](https://docs.restate.dev/foundations/services), [TypeScript serving](https://docs.restate.dev/develop/ts/serving).

**Correction:**

- keep Hono/public HTTP on `:8080` and a raw `createEndpointHandler` HTTP/2 listener on `:9080`;
- expose the latter as a second Fly service, e.g. TLS external `:9443` → internal `:9080`, ALPN `h2`, plus Restate identity keys; Fly supports multiple service-to-internal-port mappings;
- assign every registered Restate deployment an immutable URL keyed by image/handler digest, for example `/deployments/<handlerDigest>` behind the Restate listener's small router;
- a new binary must continue serving every handler digest with unfinished invocations; register the new endpoint only after all Machines report it ready;
- remove an old handler path only when Restate reports the deployment drained **and** PostgreSQL has no unsettled intent referencing its connector/handler digest.

The single exposed service remains `zoenEffectDispatcher`, keyed by `EffectIntentId`. Identity is verified before reading an intent. The journey must start an Effect, roll the Fly image, resume the old deployment, and prove one Settlement.

### P1 — “managed PostgreSQL 18” is not deployable enough

Fly Managed Postgres currently provisions major 16 or 17, not 18, and Fly's own docs still list version/security-patch upgrades as incomplete. Neon documentation still labels PostgreSQL 18 preview. Amazon RDS officially supports PostgreSQL 18.6 as of 2026-08-25. [Fly MPG create](https://fly.io/docs/flyctl/mpg-create/), [Fly MPG limitations](https://fly.io/docs/mpg/), [RDS release calendar](https://docs.aws.amazon.com/AmazonRDS/latest/PostgreSQLReleaseNotes/postgresql-release-calendar.html).

**Correction:** baseline production on RDS PostgreSQL 18.6 Multi-AZ in `sa-east-1`, with Fly Machines in `gru`, app-scoped static egress IPs allowlisted by the RDS security group, TLS certificate verification, automated backups/PITR, deletion protection, and restore evidence. [Fly static egress](https://fly.io/docs/networking/egress-ips/).

Use direct connections:

- one bounded `pg.Pool` per least-privilege app role;
- one dedicated reconnecting `pg.Client` for `LISTEN`, with polling as truth;
- a separate direct deploy connection for migrations;
- no PgBouncer transaction mode or RDS Proxy on paths using transaction-local settings, advisory migration locks, prepared statements, or `LISTEN`.

Provisioning fails unless a public journey proves exact server version, `pgcrypto`, `btree_gist`, RLS/FORCE RLS, temporal constraints, `uuidv7`, SERIALIZABLE retries, backup, and restore. Reopen the provider when Fly MPG supports the required major, upgrades, roles, and restore SLO, or when private-network/compliance economics favor a dedicated database cluster.

### P2 — retain raw `pg`; reject Kysely for the kernel for the right reason

This decision is sound. `pg` exposes the exact transaction, lock, constraint, SQLSTATE, and CAS protocol; node-postgres explicitly requires one checked-out client for a transaction. [node-postgres transactions](https://node-postgres.com/features/transactions). Kysely would improve query expression typing but would not prove the runtime schema, lock order, RLS, or cross-row invariants.

**Correction:** make the exception precise. Better Auth's PostgreSQL adapter uses Kysely internally; that is permitted only inside Door's private `auth` schema. Ontology imports neither Kysely nor Better Auth database types.

All kernel SQL lives in named, parameterized query modules. Every row is decoded by the digest-pinned runtime schema, and PostgreSQL `int8`/numeric/time values remain strings until domain constructors parse them. Ban global `pg.types` mutations, `pool.query` in transactional modules, interpolated identifiers, and transaction callbacks that can perform network/model/object-store work.

### P2 — npm is the more subtractive choice, but it must be pinned

pnpm's strict dependency layout is attractive, and DeepSeek Harness uses it, but this design starts with four physical workspace packages and already enforces exports/imports through TypeScript, ESLint, and dependency-cruiser. Adding a second bootstrap tool does not yet buy a product invariant.

**Correction:** retain npm workspaces and pin `packageManager: "npm@11.19.0"` plus npm `devEngines` for Node 24.20.0/npm 11.19.0. CI and Docker run only `npm ci`; package-lock integrity is the source of exact dependency truth. Reopen pnpm only when install/storage time materially hurts CI or npm permits a demonstrated phantom dependency that the constitution gates did not catch.

### P2 — version table has factual and precision defects

Registry verification on 2026-09-04 found the following:

| Candidate claim | Finding | Correction |
|---|---|---|
| Node 24.20.0 | valid latest LTS; includes npm 11.19.0 | add exact npm version |
| TS 6 alias | package exists, but its binary is `tsc6`; TS 7 can coexist officially | canonical TS 7.0.2 + TS6 tooling sidecar |
| MCP `core/server/node` 2.0.0 | packages exist; wrong adapter set for the recommended boundary | `server/core/hono` 2.0.0 |
| OTel “API/Node SDK/exporters 0.222.0” | false for API | `@opentelemetry/api@1.9.1`; SDK/exporters `0.222.0` |
| DuckDB 1.5.5 + Node API 1.5.5-r.4 | Node API/bindings are correct; legacy `duckdb` npm package is 1.4.4 | depend only on Node API/bindings; label 1.5.5 as embedded engine |
| AWS S3 3.1126.0 | current registry is 3.1127.0 | take the version from the committed lock at baseline creation |
| Cordis/Cedar/Ajv absent | stable packages exist | Cordis 4.0.2; Cedar WASM 4.12.0; Ajv 8.20.0 |

The baseline generator should record package name, requested version, resolved version, integrity, engines/peers, official URL, and verification date from `package-lock.json`. The prose must not call a hand-entered number “current.”

## Required journey deltas

No unit tests, mocks, fakes, stubs, or internal-import tests are needed. Add only public journeys:

1. **Schema identity:** one published 2020-12 schema accepts/rejects identical payloads through API, MCP, CLI, dense query, and DB reload; all report the same schema digest.
2. **Door/OAuth:** browser session, MCP PKCE/CIMD, CLI device flow, audience/scope/expiry/revocation, and World authorization remain distinct layers.
3. **Cedar:** allow/forbid, withheld disclosure, purpose, revocation during an open Case, malformed entity denial, and persisted policy evidence.
4. **Cordis/Eve:** provider/channel replacement and interruption never duplicate a durable session event, tool authority call, or delivery.
5. **Restate deploy:** an in-flight Effect survives an image rollout through its original immutable deployment and settles exactly once.
6. **Evaluation honesty:** all evaluation capabilities reject live references and destinations; a separate assertion documents that malicious in-process code is out of scope.
7. **RDS constitution:** version/extensions/roles/RLS/serializable behavior, failover reconnect, PITR restore, and dedicated LISTEN catch-up.

## Final judgment

After these corrections, Candidate B is stronger—not less TypeScript. The elegant boundary is not “Zod everywhere” or “types make it safe.” It is one Fetch-shaped runtime, one canonical JSON-Schema release protocol, one Cedar authorization engine, one explicit SQL authority transaction, Cordis only where replaceability is the product, and a written admission that a modular monolith gives semantic unity but not hostile-process isolation.
