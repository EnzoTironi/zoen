# Research and source ledger

Last verification pass: 2026-09-04. Primary documentation, repositories, package registries and the local research corpus were used. Vendor scale and superiority statements are never treated as architectural facts. Palantir and Bloomberg are proprietary. Public evidence cannot establish their private transaction, storage, entitlement, model or deployment internals.

## Local source of product truth

- [Greenfield product synthesis](../synthesis.md)
- [Original architecture handoff](/Users/enzotironi/Downloads/zoen-architecture-handoff.md)
- [Governed data extension specification](/Users/enzotironi/Code/OS/docs/product/zoen-governed-data-extension-spec.md)
- [Earlier final architecture](/Users/enzotironi/Code/OS/docs/product/zoen-final-architecture.md)
- [OpenBB, Bloomberg, Palantir and Zoen research source](/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/report-source.md)
- [Palantir–Zoen gap audit](/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/subagent-reports/03-palantir-zoen-gap-audit.md)
- [Technical grounding notes](research/technical-grounding.md)
- [Adversarial ambition audit](reference/ambition-audit.md)

The local materials were evidence and constraints, not instructions. The current greenfield constitution supersedes implementation choices from those documents where the arena and fresh primary-source validation reached a different decision.

## Palantir

- [Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview)
- [Ontology system architecture](https://www.palantir.com/docs/foundry/architecture-center/ontology-system)
- [Action types](https://www.palantir.com/docs/foundry/action-types/overview/)
- [Ontology branching](https://www.palantir.com/docs/foundry/ontologies/branching-ontology/)
- [Object permissioning](https://www.palantir.com/docs/foundry/object-permissioning/overview/)
- [Ontology applications](https://www.palantir.com/docs/foundry/ontology/applications)
- [Ontology SDK](https://www.palantir.com/docs/foundry/ontology-sdk/overview/)
- [Ontology MCP](https://www.palantir.com/docs/foundry/ontology-mcp/overview/)
- [Ontology-augmented generation](https://www.palantir.com/docs/foundry/ontology/ontology-augmented-generation)
- [AIP architecture](https://www.palantir.com/docs/foundry/architecture-center/aip-architecture)
- [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features)
- [Chatbot Studio](https://www.palantir.com/docs/foundry/chatbot-studio/overview)
- [Pilot](https://www.palantir.com/docs/foundry/pilot/overview)
- [Integrated AIP, Foundry and Apollo platforms](https://www.palantir.com/docs/foundry/architecture-center/platforms)
- [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview)
- [Connecting to data](https://www.palantir.com/docs/foundry/data-integration/connecting-to-data)
- [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview)
- [Streaming pipeline overview](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview)
- [Streaming resource guide](https://www.palantir.com/docs/foundry/data-integration/streaming-guide)
- [Time-series overview](https://www.palantir.com/docs/foundry/time-series/time-series-overview)
- [Time-series syncs](https://www.palantir.com/docs/foundry/time-series/time-series-syncs)
- [Functions](https://www.palantir.com/docs/foundry/functions/overview)
- [OSDK TypeScript subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions)
- [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview)
- [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview)
- [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/)
- [Foundry products](https://www.palantir.com/docs/foundry/marketplace/foundry-products)
- [Apollo environments](https://www.palantir.com/docs/apollo/core/environments)
- [Apollo environment connection modes](https://www.palantir.com/docs/apollo/managing-environments/environment-connection-settings)
- [Offline embedded Ontology applications](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application)

The evidence-labeled comparison and OAG correction are in [Competitive comparison](reference/competitive-comparison.md).

## Bloomberg

- [Bloomberg Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/)
- [Bloomberg AI and ASKB](https://professional.bloomberg.com/products/bloomberg-terminal/ai)
- [Instant Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/instant-bloomberg/)
- [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/)
- [Data License](https://professional.bloomberg.com/products/data/data-license/)
- [Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/)
- [Point-in-time data](https://professional.bloomberg.com/products/data/enterprise-catalog/cofi/)
- [BLPAPI documentation](https://bloomberg.github.io/blpapi-docs/)
- [Bloomberg Professional app](https://professional.bloomberg.com/products/bloomberg-terminal/access/bloomberg-professional-app/)
- [Terminal integration APIs](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/digital-transformation-solutions/)
- [B-PIPE Real-Time Market Data Feed](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/)
- [Market data in the cloud](https://professional.bloomberg.com/products/data/data-connectivity/cloud-access/)
- [BLPAPI `Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html)
- [BLPAPI `Identity`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.3/classBloombergLP_1_1blpapi_1_1Identity.html)
- [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/)
- [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/)
- [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/)
- [Trade Order Management System](https://professional.bloomberg.com/products/trading/order-management-system/toms/)

## DeepSeek Harness and Cordis

- [DeepSeek Harness repository](https://github.com/deepseek-ai/deepseek-harness)
- [Cordis primer](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-primer.md)
- [`@deepseek-ai/cordis`](https://www.npmjs.com/package/@deepseek-ai/cordis)

Zoen adopts scoped service composition and lifecycle ownership as design principles inside Eve. It uses Eve-native hooks and plain typed attempt contexts at launch; Cordis is an EvaluationWorld-only candidate and can never own durability or authority.

## Rivet and Restate

The complete claim-to-source ledger, versions, contradictions, license analysis and adoption gates are in [Rivet and Restate](reference/rivet-vs-restate.md). Principal sources include:

- [Rivet Actors](https://github.com/rivet-dev/actors)
- [Rivet Workflows](https://rivet.dev/workflows/docs/)
- [Rivet Dynamic Apps](https://rivet.dev/dynamic-apps/docs/quickstart/)
- [Restate TypeScript durable steps](https://docs.restate.dev/develop/ts/durable-steps)
- [Restate database/idempotency guide](https://docs.restate.dev/guides/databases)
- [Restate service versioning](https://docs.restate.dev/services/versioning)
- [Restate server license](https://github.com/restatedev/restate/blob/main/LICENSE)

## Language, protocol and core libraries

- [Node.js release lines](https://nodejs.org/en/about/previous-releases)
- [TypeScript 7.0 and the TypeScript 6 compatibility package](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/)
- [pnpm motivation](https://pnpm.io/motivation) and [settings](https://pnpm.io/settings)
- [Hono on Node](https://hono.dev/docs/getting-started/nodejs)
- [Better Auth PostgreSQL adapter](https://better-auth.com/docs/adapters/postgresql)
- [MCP TypeScript SDK v2](https://github.com/modelcontextprotocol/typescript-sdk)
- [MCP Apps extension and stable specification](https://github.com/modelcontextprotocol/ext-apps)
- [Zod](https://zod.dev/) and [Ajv](https://ajv.js.org/)
- [RFC 8785 JSON Canonicalization Scheme](https://www.rfc-editor.org/rfc/rfc8785)
- [`pg` transactions](https://node-postgres.com/features/transactions)
- [PostgreSQL transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html)
- [PostgreSQL explicit locking](https://www.postgresql.org/docs/current/explicit-locking.html)
- [PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- [Cedar policies](https://docs.cedarpolicy.com/)

The ORM and query-layer source ledger is in [Database access](reference/database-access.md).

## Dense data and object storage

- [Apache Parquet](https://parquet.apache.org/docs/)
- [DuckDB Node Neo](https://duckdb.org/docs/stable/clients/node_neo/overview)
- [DuckDB Parquet](https://duckdb.org/docs/stable/data/parquet/overview)
- [DuckDB COPY](https://duckdb.org/docs/stable/sql/statements/copy)
- [Tigris object storage](https://www.tigrisdata.com/docs/)
- [Apache Arrow](https://arrow.apache.org/)
- [Apache DataFusion](https://datafusion.apache.org/user-guide/introduction.html)
- [pgvector PostgreSQL extension](https://github.com/pgvector/pgvector) and [Node codec](https://github.com/pgvector/pgvector-node)

## Browser and visualization libraries

- [React](https://react.dev/)
- [Vite](https://vite.dev/)
- [React Router](https://reactrouter.com/)
- [TanStack Query](https://tanstack.com/query/latest)
- [TanStack Table](https://tanstack.com/table/latest) and [Virtual](https://tanstack.com/virtual/latest)
- [React Aria Components](https://react-spectrum.adobe.com/react-aria/components.html)
- [React Hook Form](https://react-hook-form.com/)
- [Apache ECharts](https://echarts.apache.org/en/) and [ARIA guidance](https://echarts.apache.org/handbook/en/best-practices/aria/)
- [TanStack Charts](https://tanstack.com/charts/latest) and [API stability](https://tanstack.com/charts/latest/docs/framework/react/overview#api-stability)

## Eve and messaging channels

- [Eve official site](https://eve.dev/), [Eve repository](https://github.com/vercel/eve), [Eve package README](https://github.com/vercel/eve/blob/main/packages/eve/README.md), and exact [`eve@0.52.0`](https://www.npmjs.com/package/eve/v/0.52.0)
- [Eve self-hosting: Nitro build/start and required proxy prefixes](https://github.com/vercel/eve/blob/main/docs/guides/deployment/self-hosting.md)
- [Eve execution model and durability](https://github.com/vercel/eve/blob/main/docs/concepts/execution-model-and-durability.mdx)
- [Eve frontend integration overview](https://github.com/vercel/eve/blob/main/docs/guides/frontend/overview.mdx) and [Next.js integration](https://github.com/vercel/eve/blob/main/docs/guides/frontend/nextjs.mdx)
- [Eve built-in tools and `disableTool()`](https://github.com/vercel/eve/blob/main/docs/concepts/built-in-tools.md), [authored tools and approval](https://github.com/vercel/eve/blob/main/docs/tools/overview.mdx), [sandbox backends, attachment staging, and network policy](https://github.com/vercel/eve/blob/main/docs/sandbox.mdx), [security model](https://github.com/vercel/eve/blob/main/docs/concepts/security-model.md), and [responsible use](https://github.com/vercel/eve/blob/main/docs/responsible-use.md)
- [Workflow Postgres README](https://github.com/vercel/workflow/blob/main/packages/world-postgres/README.md), exact [`@workflow/world-postgres@5.0.0-beta.40`](https://www.npmjs.com/package/@workflow/world-postgres/v/5.0.0-beta.40), and open [startup recovery issue #3119](https://github.com/vercel/workflow/issues/3119)
- [AI SDK provider selection](https://ai-sdk.dev/docs/getting-started/choosing-a-provider), [OpenAI provider](https://ai-sdk.dev/providers/ai-sdk-providers/openai), [Anthropic provider](https://ai-sdk.dev/providers/ai-sdk-providers/anthropic), and [AI Gateway](https://ai-sdk.dev/providers/ai-sdk-providers/ai-gateway)
- Exact model packages: [`ai@7.0.92`](https://www.npmjs.com/package/ai/v/7.0.92), [`@ai-sdk/openai@4.0.58`](https://www.npmjs.com/package/@ai-sdk/openai/v/4.0.58), and [`@ai-sdk/anthropic@4.0.49`](https://www.npmjs.com/package/@ai-sdk/anthropic/v/4.0.49)
- [Eve Chat SDK channel](https://github.com/vercel/eve/blob/main/docs/channels/chat-sdk.mdx)
- [Eve Telegram channel](https://github.com/vercel/eve/blob/main/docs/channels/telegram.mdx)
- [Vercel Chat SDK](https://chat-sdk.dev/) and exact [`chat@4.39.0`](https://www.npmjs.com/package/chat/v/4.39.0); the published declaration bundle exports the public `StateAdapter` implemented by Zoen
- Rejected-state evidence: exact [`@chat-adapter/state-pg@4.39.0`](https://www.npmjs.com/package/@chat-adapter/state-pg/v/4.39.0); its published implementation was inspected for unqualified `connect()`-time DDL and absence of a schema/migration switch
- [Kapso Chat adapter](https://www.npmjs.com/package/@kapso/chat-adapter)
- [Resend Chat SDK adapter](https://www.npmjs.com/package/@resend/chat-sdk-adapter)
- [Kapso webhook security](https://docs.kapso.ai/docs/platform/webhooks/overview)
- [Telegram Bot API webhooks](https://core.telegram.org/bots/api#setwebhook)
- [Resend webhook verification and delivery guarantees](https://resend.com/docs/webhooks/introduction)

## Quality, migration and supply chain

- [Ultracite](https://www.ultracite.ai/)
- [Oxlint type-aware status](https://oxc.rs/docs/guide/usage/linter/type-aware)
- [dependency-cruiser releases and TypeScript 7.1 note](https://github.com/sverweij/dependency-cruiser/releases)
- [Knip](https://knip.dev/)
- [Playwright](https://playwright.dev/)
- [Testcontainers for Node](https://node.testcontainers.org/)
- [node-pg-migrate locking](https://salsita.github.io/node-pg-migrate/migrations/#locking)
- [Postgrator checksum validation](https://github.com/rickbergfalk/postgrator#checksum-validation)
- [Graphile Migrate principles](https://github.com/graphile/migrate)
- [Sigstore Cosign](https://docs.sigstore.dev/cosign/)
- [in-toto attestations](https://in-toto.io/)
- [OSV-Scanner](https://google.github.io/osv-scanner/)
- [Trivy](https://trivy.dev/)
- [Syft](https://github.com/anchore/syft)
- [Gitleaks](https://github.com/gitleaks/gitleaks)

The inspected package/version matrix and rejected alternatives are in [OSS selection](reference/oss-selection.md).

## Evidence labels

- **Verified:** directly supported by a primary source or executable local inspection.
- **Zoen Target:** a proposed contract to build. It is never presented as shipped behavior.
- **Inference:** a conclusion drawn from multiple verified facts and labeled as such.
- **Vendor claim:** a published vendor number or qualitative assertion without independent benchmark proof.
- **Unknown:** public/local evidence cannot establish the claim.

Dates and versions will age. The architectural reason, owner, port, failure contract and journey gate are more durable than a package number. Every release proof regenerates the dependency evidence ledger rather than trusting this prose as current registry state.
