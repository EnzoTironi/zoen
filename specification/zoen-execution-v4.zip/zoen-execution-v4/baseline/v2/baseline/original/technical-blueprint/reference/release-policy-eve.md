# Release language, policy, and Eve

## Meaning is a released artifact

A WorldRelease is immutable, content-addressed executable meaning. It closes over:

- semantic object, property, link, evidence, function, Action, Watch, and presentation identities;
- source contracts and deterministic mappings;
- identity and belief programs;
- horizontal admission and disclosure policy;
- domain Action reads, consequences, decision rules, changes, and Effect descriptions;
- Watch detectors, materiality, and compatibility tracks;
- JSON Schemas and idiomatic surface facets;
- trusted connector/handler IDs and minimum versions;
- the journey-suite digest that defines expected behavior.

It is compiled once. Runtime policy filters discovery and data; Zoen never emits a principal-specific ontology artifact.

## Source language

The first release language is canonical JSON plus a small typed, total declarative IR. It contains no uploaded JavaScript, TypeScript, SQL, arbitrary URL, filesystem path, environment lookup, network operation, model call, or runtime package.

The IR supports:

- typed literals and tagged decimal, money, instant, duration, and identifier values;
- total boolean, numeric, temporal, set, relationship, and aggregation expressions;
- explicit sparse and dense reads whose dependencies can be recorded;
- identity matching and belief selection;
- Action preconditions, disclosed consequences, decision/quorum rules, transition plans, and Effect intent plans;
- Watch checkpoint and materiality logic;
- presentation documents and explanation nodes.

Every expression has a statically known input/output type, declared cost, finite traversal bound, and deterministic result. Recursion, ambient state, implicit coercion, floating-point authority calculations, and hidden reads are rejected.

Trusted native handlers may be referenced by stable ID only for capabilities the IR cannot reasonably express. Their binary/version digest becomes part of the release. The registry is compiled into the application; a release cannot name an uninstalled handler.

Wasm is deliberately absent at first. Reopen a pure WebAssembly Component boundary only after three unrelated real capabilities require the same missing deterministic abstraction and extending the IR would be worse. Any future Wasm receives no WASI, I/O, secrets, clock, randomness, database, model, or Effect access; host reads are typed and become exact Frame dependencies; memory and fuel are bounded.

## Canonicalization and identity

The compiler:

1. parses UTF-8 JSON while rejecting duplicate keys, invalid Unicode, unknown fields, and ambiguous unions;
2. rejects domain decimals, money, timestamps, durations, and 64-bit values represented as binary JSON numbers;
3. validates static source schemas and every dynamic JSON Schema 2020-12 document;
4. validates semantic references, cycles, totality, complexity, slug collisions, and trusted handler IDs;
5. validates Cedar schema and policies;
6. derives the authorized capability catalog and surface manifests;
7. serializes the I-JSON artifact with RFC 8785 JCS;
8. computes a domain-separated SHA-256 digest over the exact bytes;
9. stores the bytes immutably before proof.

The canonical codec is one audited adapter around a pinned JCS implementation and lexical parser, exercised through the public `zoen doctor canonical` journey and the RFC fixture corpus. PostgreSQL `jsonb` is useful for indexing but is never signing input.

Stable semantic IDs are opaque UUID-based identities. Human labels and approved CLI/API/MCP slugs are facets. Published semantic IDs are never aliased to mean something else.

## Two policy languages, one clean boundary

Cedar answers horizontal authorization questions:

```text
principal + released action + resource/facet + purpose + entity slice
    -> permit | deny + determining policy IDs
```

Each release contains one Cedar schema and validated policy set. Default is deny; a matching forbid wins. Ontology uses Cedar for:

- World entry and capability discovery;
- admission to a released inspect/Action/Watch capability;
- disclosure of object, field, evidence, consequence, Notice, and explanation facets;
- whether a principal may contribute to a Case or request an Effect.

Cedar never resolves identity, selects beliefs, computes consequences, evaluates quorum, plans a mutation, detects materiality, performs an Effect, or records Settlement. Those are domain semantics in the released Zoen IR.

This separation prevents an access-control engine from becoming the ontology and prevents domain code from accreting ad hoc permissions. A `PolicyProof` records release, request digest, principal/entity-slice digests, purpose, decision, and determining policy IDs. Policy is evaluated before discovery and pushed into both sparse and dense plans; Zoen does not fetch forbidden fields and redact them afterward.

The first adapter is `@cedar-policy/cedar-wasm`, isolated behind `AuthorizationPort`. A second implementation must produce the same decision/proof corpus before replacement.

## Proof is not activation

Release evolution has four separate immutable facts:

1. `WorldRelease` says what the meaning is.
2. `ReleaseProof` says that exact release and image passed declared evaluation evidence.
3. `PreparedActivation` says one live World is ready through one exact head and cut.
4. `ReleaseActivationReceipt` says an authorized compare-and-swap changed that World head.

An EvaluationWorld is a disposable, active World in an evaluation realm. It uses the normal Door, Eve, API, CLI, MCP, storage, Watch, and Effect paths. It has separate database credentials and data, Tigris prefix credentials, relationship/channel bindings, Restate namespace, source leases, provider sandboxes, Effect leases, egress allowlist, expiry, and cleanup receipt. The runner receives no live credential. There is no `useInactiveRelease` escape hatch.

ReleaseProof is an in-toto-style statement wrapped in DSSE. It binds release digest, OCI image digest, environment, compiler/tool versions, journey digest, replay and policy results, provider/channel/effect sandbox attestations, and explicitly missing evidence. The platform release signer is a managed asymmetric key behind `ReleaseSignerPort`; CI image provenance is additionally signed keylessly with Sigstore/Cosign. Live activation rejects any capability whose released policy requires a missing attestation.

The proof order is fixed: run static gates; canonicalize and store the release; build the OCI image exactly once; record its digest and SBOM; create an ephemeral EvaluationWorld that runs that exact image with no live credential loaded; execute journey, replay, policy, channel, and sandbox evidence; sign the ReleaseProof; deploy the same image digest; then run smoke journeys. Rebuilding after evaluation invalidates the proof.

Preparation compares the complete current `WorldHead` with the target and internally chooses:

- reuse when meaning and representation remain compatible;
- reprojection when evidence remains valid but derived state changes;
- deterministic migration when authoritative representation changes;
- a governed Case when human judgment is required.

It builds a non-authoritative generation and catches up only from committed `AuthorityCommitEnvelope` records. The `PreparedActivation` binds the complete expected head `{world, headVersion, cut, release, generation, observationManifest, auditRoot}`, target release, target data generation, target observation manifest, ready-through cut, migration/reprojection receipts, open Case and Watch disposition, invariant results, and any World-specific attestation.

Activation joins valid proof, exact preparation, and approval in one serializable compare-and-swap over the complete `WorldHead` tuple. Any tuple mismatch returns `preparation-stale` and requires rebase. A busy World may use an explicit short write fence to finish catch-up. There is no dual read, dual write, partially active release, mutable candidate, or blind rollback. Rollback is another proved and prepared transition.

## Eve uses the Harness lesson narrowly

Eve adopts the strongest DeepSeek Harness and Cordis ideas—scoped capability composition, explicit lifecycle ownership, immutable child contexts, and declared event modes—without installing Cordis at launch. Eve already owns the durable turn, hooks, dynamic capabilities, state, cancellation, tools, and subagents. Plain TypeScript composition keeps one replay and lifecycle model.

The root Eve composition builds a curated, compile-time `EveServices` allowlist such as:

- `world`: the narrow `EveWorldPort`;
- `models`: provider-neutral model attempts;
- `channels`: verified ingress and delivery;
- `journal`: typed materialized reads over Eve Workflow history;
- `present`: released document rendering;
- `attention`: relationship interruption policy;
- `telemetry`: non-authoritative operational signals.

Eve creates each durable turn context. Each model/tool attempt derives an immutable `EveAttemptContext` with relationship, principal, World, release, Focus, channel, purpose, turn, attempt, budgets, and abort signal. Model/provider/tool capabilities may be isolated beneath that value without mutating its parent. Every acquired provider resource returns an explicit disposer owned and awaited by the attempt. This prevents cross-turn capability and listener leakage.

Attempt services are provider composition, not authority. A service cannot receive a database client, standing World grant, connector secret, or generic shell. World tools are generated from a freshly authorized catalog and call the narrow Ontology client with explicit operation keys.

Runtime-loaded packages, World-supplied plugins, arbitrary service names, global mutable contexts, and access to Ontology internals are forbidden. Cordis remains an evaluation candidate only if three unrelated needs prove that Eve-native hooks and the plain context repeat substantial lifecycle machinery; ADR 013 owns that gate.

Eve's own capability surface is allowlisted just as strictly. Launch disables the default `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `todo`, and root `agent` tools, does not add `glob`, `grep`, the model-facing `Workflow` tool, or `sleep`, and declares no skills or connections. `ask_question` remains as a durable, non-executing conversational pause. Only release-derived `inspect_*` and `propose_*` tools execute, every authored tool declares approval explicitly, and Ontology reauthorizes every call. Eve approval is interaction policy, never World authority.

Every Eve agent has a sandbox definition upstream, so Zoen makes non-use explicit: a custom `DisabledEveSandboxBackend` implements the required two phases with an idempotent empty `prewarm()` and an always-failing `create()`, and prevents `defaultBackend()` from falling through to a permissive local implementation. Launch code cannot call `ctx.getSandbox()`, and byte-backed attachments cannot start an Eve session. Media first crosses scanner, rights, evidence admission, and disclosure, then reaches Eve as an immutable authorized reference. A future sandbox is a released product capability with a named backend and proved isolation, egress, credential, retention, and deletion contract.

## Eve event and model protocol

In-process callbacks are ephemeral coordination. Eve's Workflow event history is the durable conversation execution truth; the typed `InteractionJournal` is its Eve-owned materialization rather than a parallel resumption log. A model attempt records:

- provider, model identity/revision, deployment profile, and parameters;
- exact settled interaction cut and Focus;
- authorized Frame/reference inputs and their digests;
- release and tool-catalog digest;
- prompt/context digest and attributable source references;
- started, settled, abandoned, or failed status;
- tool requests and recorded tool results;
- output digest, usage, cost, and latency.

Zoen never stores or asks providers to expose hidden chain-of-thought. It stores visible explanation, source attribution, tool evidence, and the model output actually shown.

The `ModelPort` is a Zoen-owned protocol over the `LanguageModel` contract required by Eve and AI SDK. The launch graph exact-pins `ai@7.0.92`, `@ai-sdk/openai@4.0.58`, and `@ai-sdk/anthropic@4.0.49`; provider packages create direct model objects and their types stop inside the adapter. Raw OpenAI and Anthropic SDKs are not duplicate launch dependencies. Vercel AI Gateway string IDs are a separately selected deployment profile with their own data-use, availability, attribution, and cost evidence. A second adapter must pass the same Eve journeys without changing conversation domain code.

The context compiler is deterministic for a settled journal cut. It budgets interaction, authorized Frames, Notices, tools, and presentation instructions explicitly. An unbounded transcript is never the source of model context.

## Attention and channel rendering

Ontology decides whether a World transition is materially worthy of a Notice. Eve decides whether and how the relationship is interrupted. It may suppress, merge, defer, schedule, phrase, and select a channel, but it keeps only a Notice reference while deferred and reopens current disclosure twice: during arbitration and immediately before composition.

Web presentation uses the full released `RenderDocument`. Messaging renders the same semantics into concise, excellent text. It does not serialize web chrome as fake buttons or invent URLs. WhatsApp uses Kapso at `/eve/v1/kapso` through one Chat SDK bridge, Telegram is native Eve at `/eve/v1/telegram`, and email uses a separate Resend Chat SDK bridge at `/eve/v1/email`. Kapso and email share only the public Chat SDK `StateAdapter` contract: Zoen implements it over raw `pg`, explicit migrations, and separate `kapso`/`email` schemas and roles in the dedicated `eve_channels` database. The upstream state-pg package is not a launch dependency because it performs unqualified DDL during runtime connection. This remains operational coordination state; Eve's Workflow event history is the conversation execution truth. Every provider route must commit a verified ingress and outbox command before `2xx`, then admit that stable identity into Eve durably, so an admission hook or gateway is a production gate rather than an implementation detail.

Delivery has `accepted`, `rejected`, and `unknown` observations. Channel/provider IDs are deduplicated. A timeout is not silently treated as delivery, and a provider without safe idempotency is reconciled before retry.

## Living World rendering

Living World renders released presentation facets around the current Focus. The initial renderer vocabulary is small and semantic: prose, value, uncertainty, evidence, relationship, timeline, comparison, table, chart, Case, receipt, Watch, Notice, and Scenario.

Use accessible DOM and SVG first, React Aria primitives, design tokens, and custom renderers. Do not start with a generic graph canvas, dashboard kit, or user-authored React. Add a WebGL renderer behind the same presentation boundary only after a real view exceeds roughly 5,000 simultaneously visible elements or DOM/SVG misses its interaction SLO.

The small initial renderer is the safety floor, not the capability ceiling. Workshop can compile a released `MiniAppManifest` into a rich content-addressed `MiniAppArtifact` when the experience needs custom TypeScript/React interaction. Its portable delivery target is MCP Apps: a `ui://` resource with declared app-visible capabilities, strict content-security metadata, host-mediated calls and a structured/text fallback. Eve/Living World is the first-party host, but the artifact is not host-owned. It runs on a separate origin or sandboxed frame, receives only short-lived public capability tokens, and can read Frames or request released Actions through the same currently authorized `SurfaceManifest`. It never receives a database client, internal Ontology port, provider secret, arbitrary egress, or authority to infer success from a UI event.

Rivet Dynamic Apps is the first `MiniAppRuntimePort` generation/build/runtime spike, not the product contract. Its output must preserve MCP Apps portability. Drafts run in EvaluationWorld; publication pins source, dependency, builder, permission, SBOM, artifact and proof digests; the first-party declarative renderer remains available on runtime failure. Server-side notebooks and analytics use a distinct `ExecutorArtifact` and isolated `DataGrant`, never the browser artifact's token. The complete target boundary is ADR 019.
