# ADR 028: Semantic charts and asymmetric renderers

Status: Accepted

## Context

Charts in Zoen must span a personal Living World, Workshop mini-apps, dense market workstations, static exports and text-only channels. Free-form renderer configuration would make presentation libraries part of released meaning, permit hidden client computation, and couple every surface to one implementation. Choosing only the newest library would also make an Alpha API constitutional; choosing one mature renderer forever would preserve unnecessary bundle, React and accessibility constraints.

## Decision

Zoen owns a closed, renderer-independent `ChartDocument`. It describes the question, released data slots, semantic fields and units, temporal basis, allowed interactions, annotations, accessibility contract, export contract and required capabilities. A runtime `ChartInstance` binds it to an authorized `WorldFrame` or immutable `AnalysisRun`, result and representation digests, exact cut, rights decision and `RepresentationProof`. A disposable `ChartRenderPlan` is the only renderer-shaped value.

No released chart contains ECharts options, TanStack marks, callbacks, formatter code, raw HTML, CSS selectors, URLs, arbitrary expressions or vendor escape hatches. Analytics such as returns, indicators, forecasts and scenario deltas are released plans with immutable outputs; the browser computes layout and pixels, not new business truth. Every chart has an accessible narrative and exact-value table. Renderer events become closed `ChartEvent` values and may select or propose, but never perform a domain Action.

The renderer strategy is asymmetric:

1. Launch with exact-pinned Apache ECharts 6.1.0, imported modularly through `echarts/core` and hosted by a small Zoen-owned React component. It supplies mature Canvas/SVG, progressive rendering and specialist financial, graph and matrix capability.
2. Keep exact-pinned `@tanstack/charts` 0.16.0 in EvaluationWorld only. It is the preferred future ordinary-chart renderer because its SVG-first, React-native, compositional model better fits Living World, Workshop, SSR and accessible interaction, but its official Alpha status prevents production adoption today.
3. After promotion, TanStack Charts is the default for ordinary semantic charts; ECharts remains available only for named capability profiles such as dense prepared marks, streaming append, candlestick/depth, matrix, chord and interactive force graphs. A page loads both only when the released composition genuinely requires both and the bundle journey passes.
4. GPU, tiled GIS or other specialized renderers may enter through `ChartRendererPort`; neither current renderer is described as WebGL.

Channels never run chart JavaScript. Email receives an immutable static `ChartArtifact` plus accessible text/table; WhatsApp and Telegram receive readable text and optionally an authorized image or file.

## Required evidence

- Canonical corpus: every supported `ChartDocument` compiles to semantically equivalent accessible output and refuses unsupported capability requirements.
- Representation honesty: viewport, aggregate, envelope, sample and density strategies record source, represented and omitted meaning; visual rendering never claims more observations than the authorized result.
- Accessibility: keyboard-only, screen-reader, focus, tooltip dismissal, reduced-motion, contrast and table/narrative parity journeys pass without relying on ECharts ARIA as the whole solution.
- Export and channel parity: static SVG/PNG binds document, result, representation, renderer, theme, locale and rights digests; flattened output preserves the useful meaning.
- Performance and bundle: modular imports meet recorded budgets on representative ordinary, dense, financial and network fixtures; cancellation and disposal release resources.
- Lifecycle: exact pins, license evidence, dependency graph and adapter upgrade corpus are part of release proof. A breaking renderer change cannot change the `ChartDocument` digest.

TanStack promotion additionally requires two consecutive accepted upgrades, the full corpus, production-grade accessibility/SSR/export behavior, no unsupported required profile, and a smaller or materially better ordinary-chart experience than the ECharts implementation. Promotion changes the adapter registry, not released domain meaning.

## Consequences

- The durable product object is the evidence-bearing question and representation, not a chart-library option tree.
- Zoen ships one proven renderer rather than two overlapping launch dependencies while retaining a credible path to a cleaner ordinary-chart experience.
- Terminal-grade views may use a larger specialist renderer without imposing it on every conversational or personal surface.
- Some ECharts interactions require first-party accessible controls; that work is a product obligation, not an optional polish item.

## Reopen triggers

- TanStack Charts satisfies every promotion gate. Promote it for ordinary profiles and retain ECharts only where capability evidence requires it.
- A named journey requires GPU-scale marks, vector tiles, terrain, spatial editing or globe-scale level of detail. Add a separate renderer/profile ADR; do not smuggle a plugin payload through `ChartDocument`.
- ECharts cannot meet accessibility, lifecycle or bundle gates for a required specialist journey. Replace that profile behind the port.
- A renderer cannot express a released chart without vendor configuration. Extend the semantic document only if the concept is meaningful across surfaces; otherwise reject the chart.

No trigger permits a rendering engine to become authority, analytics truth, authorization policy or the released schema.
