# ADR 021: Signed isolated connector artifacts

Status: Accepted target contract. Built-in launch adapters use the same protocol.

## Context

Palantir- and Bloomberg-class breadth requires many data sources, destinations, brokers, channels, devices, and enterprise systems. Compiling every integration directly into the authority application would tie ecosystem growth to Zoen deployments and retain every old dependency in the main process. Loading third-party packages as trusted plugins would give unreviewed code access to database clients, provider secrets, internal ports, and process memory.

An integration must be independently buildable and revocable without becoming a new authority system.

## Decision

Every independently supplied integration begins as `WireArtifact` and must decode into a nominally sealed, kind-indexed `VerifiedArtifactRef`. `ArtifactPayload<K>` pins kind, format, source, build, dependency lock, SBOM, protocol version, and body digest. Its domain-separated canonical digest is artifact identity and does not contain itself. `ArtifactSignature<K>`, `ArtifactEvaluation<K>`, and `ArtifactTrustBundle<K>` are separate records bound to that digest. Trust, revocation, expiry, or a new evaluation can change without changing artifact bytes; none can be smuggled into content identity. Mutable tags and package names are not identity.

`ConnectorArtifact`, `ConnectorLease`, `ConnectorRun`, and connector output preserve the same closed discriminant end to end:

- a source connector accepts a released acquisition request and returns immutable raw capture, cursor proposal, rights metadata, and `EvidenceAdmissionProposal`. It may also produce basis-bearing live observations.
- an effect connector receives an immutable `EffectIntent` reference and returns provider observations or `unknown` evidence for Ontology reconciliation.
- a channel connector returns verified ingress or delivery observations to Eve.

A source lease binds realm, World, actor, purpose, acquisition request, content-addressed object-write lease, credential, egress, recovery epoch, and expiry. An effect lease binds an existing `EffectIntent`, operation, destination, credential, egress, and epoch. A channel lease is Eve-owned and binds channel account and ingress or delivery direction; it need not invent a World or principal before identity resolution. A source lease cannot start an effect run, and channel output cannot decode as settlement.

One isolated `ConnectorRun` starts under its matching short lease. The runner validates artifact payload digest, kind, current local trust epoch, signatures, evaluations, revocation, protocol, lease, budget, and runtime before execution. It starts with a read-only root, no inherited environment, no runtime dependency installation, and no route to authority storage.

Secrets are either used by a brokered request or supplied as a short-lived operation-specific lease. A source connector streams raw output to a write-only object broker that returns its content digest. It cannot list, read, replace, or delete objects. The artifact never receives a master database or object-store credential, a membership service, a grant constructor, release activation, or a generic internal network. The runner records canonical input, artifact, lease, attempt, network transcript, resource use, output, and fault digests.

A connector output is a kind-specific verified value, evidence, or proposal:

- a source proposal becomes World truth only after release mapping, identity, evidence, rights, quality, and object verification in `AuthorityCommit`.
- an effect observation becomes an `EffectSettlement` revision only after reconciliation in `AuthorityCommit`.
- a channel decoder may construct `VerifiedChannelIngress`, never settled interaction.

Channel durability crosses processes explicitly. One local transaction inserts `AdmittedChannelIngress` and a deterministic Eve-delivery outbox row; only then may the provider receive 2xx. An idempotent dispatcher submits the stable ingress identity to Eve. Eve starts model work only after its Workflow history durably accepts the event. `InteractionJournal` is a rebuildable typed materialization of Eve Workflow history, so no cross-database atomic journal append is claimed.

Kapso and email bridge state uses Zoen's raw-`pg` `ZoenChatStateAdapter` against explicit migrator-owned `eve_channels.kapso` and `eve_channels.email` schemas. The generic Chat SDK contract is retained, but `@chat-adapter/state-pg` is not a launch dependency because its connection-time unqualified DDL cannot satisfy ownership or migration discipline.

The connector cannot write a World head, Case, receipt, manifest admission, `EffectSettlement`, admitted channel ingress, Eve Workflow history, `InteractionJournal`, or provider success state directly.

Restate remains restricted to `ZoenEffect`. It may durably invoke an effect-profile connector for an existing intent, but its journal and the connector run are execution evidence. PostgreSQL retains canonical `EffectIntent`, `EffectAttempt`, provider observation, and `EffectSettlement` records. Source and channel connectors do not run as Restate services.

Launch connectors may be image-pinned TypeScript modules, but they still receive the same typed request, lease, and result contracts. Third-party artifacts always run outside the authority process. TypeScript/Node is the first runner profile. An isolated OCI profile may support vendor libraries later without changing Zoen's TypeScript-owned authority and application implementation.

Artifacts enter a release through a `PackArtifact` or direct `ReleaseProposal`. EvaluationWorld proof covers provider sandboxes, schema fixtures, denial, replay, data usage, idempotency, reconciliation, supply chain, resource behavior, and process death. A signature identifies a publisher. Only a current sealed trust bundle can authorize execution, and it still does not grant credentials, installation, activation, or network access.

## Consequences

- Integrations can evolve and be revoked independently of the authority application.
- The credential broker and runner add an explicit process and operations boundary.
- Old artifact bytes and protocol runtimes must remain available while retained releases, Cases, intents, data, or replay evidence reference them.
- Built-in and ecosystem connectors produce comparable evidence and journey results.
- A provider's SDK language does not become Zoen's domain language.

## Required journeys

1. Signature, trust-root rotation, expiry, revocation, digest mismatch, and dependency-confusion denial.
2. Filesystem, metadata service, authority network, environment, secret-class, DNS, port, and arbitrary-egress denial.
3. CPU, memory, output, time, process-tree, and cost enforcement across runner death.
4. Source replay, cursor race, malformed output, rights mismatch, duplicate capture, and staged-object orphan collection.
5. Effect provider idempotency, lost acknowledgement, reconcile-before-retry, callback reorder, and recovery-epoch fence.
6. Channel spoofing, duplicate ingress, crash before/after admission, 2xx-before-commit denial, idempotent Eve delivery, delivery ambiguity, and inability to construct a principal or settled message.
7. Upgrade and rollback while retained runs and releases still name the prior artifact.

## Reopen triggers

- A connector requires a native or vendor runtime unavailable in the Node profile. Add a constrained OCI runner with the same lease and result protocol.
- Runner throughput causes sustained isolation overhead. Pool only artifacts with the same trust, credential, egress, and revocation domain. Do not colocate them with authority.
- A provider supplies a managed connector service. Treat the service as another destination behind the same evidence, rights, identity, and reconciliation contract.
- No trigger permits installation to grant ambient authority or a connector response to define Settlement without Ontology reconciliation.
