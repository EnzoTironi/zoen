# Candidate C — Rust-first Zoen technical constitution

Status: candidate, not a language decision. Baseline date: 2026-09-04.

## 0. Verdict and burden of proof

This is the strongest coherent case for a Rust-first Zoen: one Rust server owns Ontology, Eve, channels, API, MCP, CLI protocol, dense query execution, and the Restate effect endpoint. TypeScript exists only in the Better Auth compatibility process and the React build.

Rust does **not** make authorization, serializability, idempotency, release safety, or honest settlement true. Those are protocol and Postgres properties. Strict TypeScript plus Postgres and DuckDB can implement every product invariant in this document.

Rust earns its cost only if an S0 comparison proves both of these:

1. The safe Rust domain model removes a material class of realm, state-machine, and concurrent-worker defects without expanding the public interface.
2. The Arrow/DataFusion dense path materially outperforms the TypeScript/DuckDB alternative on Zoen's real as-of and entitlement workloads.

Fail either gate and keep this constitution, schemas, protocols, and release format while implementing the server in strict TypeScript. No product concept depends on Rust.

**Current verdict:** the available evidence does not yet pay Rust's ecosystem and two-process tax. If a language must be chosen before S0, choose 100% strict TypeScript for the application server plus the unavoidable native DuckDB engine. Candidate C becomes the recommendation only after it clears the measured gate; architecture preference is not evidence.

Planning estimates, to be replaced by S0 measurements:

| Cost or property | Rust-first estimate | Strict TS + Postgres + DuckDB estimate |
|---|---:|---:|
| S1–S3 elapsed time, Rust-fluent team | 1.25–1.45× | 1.0× |
| S1–S3 elapsed time, TS team learning Rust | 1.6–2.2× | 1.0× |
| First provider/channel adapter | 1.4–2.0× | 1.0× |
| Subsequent provider adapters | 1.2–1.5× | 1.0× |
| Typical cold CI build with DataFusion | 6–15 min | 0.5–2 min |
| Production runtimes to supervise | Rust + narrow Node Door | Node only |
| Database migration toolchains | SQLx + Better Auth | one TS stack can own both |

These are engineering estimates, not benchmark claims. The S0 acceptance thresholds are: at least 2× throughput **or** 30% lower peak memory on the dense reference workload, no more than 1.35× implementation time for the honest-Frame slice with a Rust-fluent pair, and demonstrably fewer runtime state/realm assertions. Otherwise TypeScript wins.

### 0.1 Parquet is decided; Rust/DataFusion is not

Parquet, immutable manifest DAGs, content-addressed object storage, and Postgres admission are firm product-scale decisions. They are language-neutral and receive **zero credit** in the Rust business case. A strict TypeScript server can keep Better Auth, Eve, Ontology, channels, MCP, and orchestration in one Node process while embedding the primary DuckDB Node Neo client to scan the same Parquet in Tigris.

The comparison is only the incremental value of `Rust + DataFusion` versus `TypeScript + DuckDB`:

| Already obtained in both designs | Possible DataFusion-specific increment |
|---|---|
| Parquet compression and column pruning | direct Arrow `RecordBatch` ownership without JS/native value conversion |
| immutable manifests and point-in-time roots | a Zoen-owned `TableProvider` that centralizes which files/columns can enter a plan |
| predicate and row-group pushdown | custom logical/physical optimizer rules for rights and semantic fields |
| vectorized native execution | one Rust type system from semantic plan through physical plan |
| streaming result reads | tighter memory accounting inside the server runtime |

DuckDB already supplies a native vectorized engine, Parquet pushdown, rich decimals/timestamps, and a primary Promise-based Node client. A strict TS adapter can also authorize the manifest and pass DuckDB only permitted object URLs, columns, and predicates. There is currently no known policy guarantee unique to DataFusion. Therefore “native speed,” “columnar,” “Parquet support,” and “entitlement pushdown” are not Rust arguments without evidence. DataFusion must win on **measured end-to-end** entitled/as-of workloads or on a newly demonstrated guarantee that cannot be expressed safely through DuckDB's boundary.

Rust-first permanently costs one extra supervised process because Better Auth remains Node, two language toolchains, two dependency graphs, and a cross-process session proof. The S0 dense threshold is deliberately high enough to pay for that: 2× throughput or 30% peak-memory reduction at equivalent result correctness and p95 latency. A smaller win does not justify losing the one-language/one-process TypeScript shape. Even a dense win is insufficient if S1 implementation exceeds 1.35× or provider integration exceeds 1.5× on the reference adapter.

### 0.2 Evidence, separated from inference

Verified primary-source facts at the baseline date:

- DuckDB 1.5.5 classifies Node Neo and Rust as equal **primary** clients. Node Neo has native Promises, lossless support for DuckDB values, and streaming row/column reads. Its direct Arrow APIs remain on the roadmap.
- DataFusion 55 is a Rust-native Arrow engine with Parquet/object-store reads and extension points for `TableProvider`, logical plans, optimizer rules, and memory accounting.
- Better Auth 1.7.2 is a TypeScript/Node library with direct PostgreSQL, OAuth 2.1, device authorization, client credentials, and MCP composition. A Rust-first server therefore still needs a Node compatibility boundary.
- The official Rust MCP SDK 3.0.1 is stable and reports full dated-suite conformance; MCP no longer forces TypeScript.
- The official Restate Rust SDK 0.11.0 exposes an embeddable endpoint API; Effects no longer force TypeScript either.
- Parquet, manifest DAGs, SHA-256 addressing, serializable Postgres, and outboxes are independent of application language.

The inference is deliberately narrow: Rust may improve the implementation of realm/state invariants and dense execution, but no source proves that it improves **Zoen's** workload enough. Only S0 can supply that missing evidence. By contrast, Better Auth plus the model/channel ecosystem creates an immediate, known integration advantage for TypeScript.

## 1. Caller's usage is the specification

### 1.1 A person: conversation and Living World

The browser sees one origin. Better Auth routes, Eve, Living World, and Ontology do not look like separate products stitched together.

```text
POST /api/auth/sign-in/...
POST /eve/v1/turns
{
  "relationship": "rel_...",
  "message": "Can I take three months off next year?",
  "focus": { "ref": "focus_..." }
}

202 Accepted
{
  "turn": "turn_...",
  "stream": "/eve/v1/turns/turn_.../stream"
}
```

The settled answer contains prose plus stable, opaque references. It can say that the runway is provisional, open the exact Frame in Living World, or propose a released domain Action.

```text
"You have about 8–10 months on the evidence I can currently see.
 The missing pension statement is the largest uncertainty."

[Open the evidence] [Model three months off] [Protect six months of reserve]
```

Opening Living World sends only the authority-free Focus or a Frame reference. The server gets a fresh Door proof and a fresh `Understand` grant. It either reopens the pinned historical Frame or labels a newly computed Frame as newer.

Answering a decision never sends an ambient `approve=true`:

```text
POST /ontology/v1/worlds/w_.../cases/case_.../answers
Authorization: current browser session
X-Zoen-CSRF: ...
Idempotency-Key: 01J...
{
  "handle": "dh_...",
  "answer": { "choice": "protect-six-months" }
}
```

The `handle` proves which disclosed consequences the person saw. Fresh identity, membership, delegation, eligibility, Case version, and exact read dependencies are still checked on submission.

### 1.2 An operator: native CLI vocabulary

```bash
zoen auth login
zoen --world home runway --as-of 2026-09-04
zoen --world home protect-reserve --months 6 --operation-key 01J...
zoen case open case_...
zoen case answer case_... --handle dh_... --choice protect-six-months --operation-key 01J...
zoen --world home watch cash-runway --below 9months --materiality 1month --operation-key 01J...
zoen explain frame_...
```

`runway`, `protect-reserve`, and `cash-runway` come from the authorized release catalog. Static CLI commands are limited to identity, selecting a World, opening a kernel object, explaining it, and release operations. There is no public generic CRUD or `invoke-action` command.

The CLI uses Better Auth OAuth 2.1 device authorization or authorization-code + loopback PKCE, stores the refresh credential in the operating-system keychain, and sends a short-lived resource-bound token. Door proves the account; Ontology still computes World authority.

### 1.3 A builder: teach once, prove, then activate

```bash
zoen release compile ./family-finance
# sha256:7b...

zoen harness run sha256:7b... --realm new
# release-proof:sha256:c1...

zoen release prepare sha256:7b... --world home
# prepared-activation:sha256:ae...

zoen release activate \
  --proof sha256:c1... \
  --prepared sha256:ae... \
  --approval approval_...
# activation-receipt:receipt_...
```

The compiled release never changes between candidate, evaluation, and active states. Evaluation installs that exact release as an active head in a disposable `EvaluationWorld`; normal Eve, API, CLI, MCP, and Living World paths drive it. Preparation is per live World and cut-exact. Activation is one compare-and-swap, not a rollout mode.

### 1.4 An agent: native MCP tools, filtered before discovery

An authenticated MCP client connects to:

```text
POST /mcp/worlds/w_...
Authorization: Bearer <Better Auth resource token>
```

`tools/list` returns only capabilities visible for this principal, World, and MCP purpose. A finance release can expose:

```text
finance.inspect_runway
finance.protect_reserve
finance.watch_cash_runway
zoen.open_case
zoen.answer_case
zoen.explain
```

Tool names, JSON Schemas, descriptions, consequence facets, and semantic IDs come from the same release catalog as the CLI and API. The MCP adapter never exposes query plans, provider schemas, SQL, grants, or internal lifecycle stages.

### 1.5 Eve inside the server

```rust
let turn = eve.accept(InboundTurn {
    relationship,
    message,
    focus,
    ingress: Ingress::Web { door },
    operation_key,
}).await?;

// Eve's model loop, not the transport caller:
let session = ontology.enter(
    turn.presence(),
    turn.focus(),
    Purpose::ConversationTurn { turn: turn.id() },
).await?;

let frame = session.inspect(runway, input).await?;
let reply = eve.compose(turn, frame.presentation()).await?;
```

The caller asks for a human outcome. Eve hides prompt assembly, model retries, tool routing, transcript recovery, channel rendering, and delivery ambiguity. Ontology hides policy, evidence, time, storage, and commit mechanics.

## 2. Runtime and library baseline

All dependency versions are exact in committed lockfiles. These are the deliberate version families at the baseline date; patch updates are automated but never float at deploy time.

### 2.1 Rust runtime

| Concern | Choice | Baseline |
|---|---|---:|
| Language | Rust, edition 2024 | 1.98.1 |
| Async runtime | `tokio` | 1.x |
| HTTP/router | `axum`, `tower`, `tower-http`, `hyper` | 0.8.9 / 0.5 / 0.6 / 1.x |
| Postgres | `sqlx`, Postgres + Tokio + rustls features | 0.9.0 |
| MCP | official `rmcp`, server + macros + schemars + Streamable HTTP | 3.0.1 |
| Durable Effects | official `restate-sdk` | 0.11.0 |
| HTTP clients | `reqwest` with rustls; `eventsource-stream` only for private provider SSE parsing | 0.13.x |
| Serialization | `serde`, `serde_json`, `schemars`, `jsonschema` | 1.x / 1.x / 1.x / pinned |
| Dense execution | Apache DataFusion | 55.0.0 |
| Columnar memory/files | Arrow + Parquet | 59.2.0 |
| Object access | Apache `object_store`, S3/rustls features | 0.14.1 |
| IDs/time/decimal | `uuid` v7, `time`, `rust_decimal` | 1.x / 0.3.x / 1.x |
| Digests/signatures | `sha2`, `hmac`, `ed25519-dalek`, `secrecy` | 0.10 / 0.12 / 2.x / 0.10 |
| CLI | `clap`, `miette`, OS keyring adapter | 4.x / 7.x / pinned |
| Errors | typed domain enums + `thiserror`; `anyhow` only in binary startup | 2.x / 1.x |
| Telemetry | `tracing`, OpenTelemetry OTLP, Prometheus exporter | pinned together |

`unsafe` is forbidden in Zoen crates. Transitive native engines are isolated behind adapters. `clippy::unwrap_used` is denied; there are no local lint exemptions.

DataFusion is not exposed as a product query language. It is a private physical engine behind the released semantic planner. SQL text never crosses the public boundary.

### 2.2 The narrow TypeScript runtime

| Concern | Choice | Baseline |
|---|---|---:|
| Runtime | Node.js Krypton LTS | 24.20.0 |
| Type checker | TypeScript, strict ESM | 6.0.x |
| Package manager | pnpm with frozen lockfile | pinned |
| Door | `better-auth`, PostgreSQL adapter | 1.7.2 |
| OAuth/MCP auth | `@better-auth/oauth-provider` and Better Auth MCP composition | matching 1.7.x |
| Door HTTP shell | Hono using Web `Request`/`Response` | 4.x |
| Door database driver | `pg` | 8.x |
| UI | React / React DOM | 19.2.7 |
| Build | Vite / official React plugin | 8.2.x / 6.x |

TypeScript 7.0 is not selected yet because its first stable release has no programmatic compiler API; reconsider at 7.1. The web app contains presentation state only. It cannot implement policy, derive belief, complete a Case, evaluate a Watch, or form an EffectIntent.

### 2.3 Infrastructure

- PostgreSQL 18 is the only transactional authority.
- Tigris is the production S3-compatible object store for immutable raw evidence, release artifacts, and Parquet segments.
- Restate runtime 1.6.x executes only `Ontology.ZoenEffect` handlers.
- One Fly application deploys one image. There is no Redis, Kafka, workflow engine for Eve, graph database, or separate vector database.
- Evaluation harnesses run the same image with evaluation-only credentials against real Postgres, Tigris namespaces, Restate, and provider sandboxes.

## 3. One deploy, two operating-system processes

```text
Fly app / one image
┌─────────────────────────────────────────────────────────────────┐
│ zoend (Rust, PID 1, public :8080, metrics :9091)                │
│                                                                 │
│  Axum ingress                                                   │
│   ├─ /api/auth/* ───────────────┐                               │
│   ├─ /eve/v1/*                  │                               │
│   ├─ /ontology/v1/*             │                               │
│   ├─ /mcp/worlds/*              │                               │
│   ├─ /restate/*                 │                               │
│   └─ /studio/* + Living World   │                               │
│                                 ▼                               │
│  supervised Node Door ── Unix socket /run/zoen/door.sock        │
│  Better Auth only       ── Postgres role/schema `door`          │
│                                                                 │
│  Ontology kernel ───────── Postgres role/schema `ontology`      │
│  Eve runtime ───────────── Postgres role/schema `eve`           │
│  workers ──────────────── outbox/watch/eve/acquisition/reconcile│
│  dense engine ─────────── DataFusion → Tigris Parquet           │
└─────────────────────────────────────────────────────────────────┘
                 │                         │
                 ▼                         ▼
          PostgreSQL 18              Restate runtime
                                      ZoenEffect only
```

`zoend` starts and supervises the Node Door child, creates the Unix socket with owner-only permissions, and becomes unready if Door exits. Rust proxies Better Auth's public responses byte-for-byte, including multiple `Set-Cookie` headers. Rust never parses Better Auth cookies or reads Better Auth tables.

For protected requests, Rust sends the original auth headers plus a nonce and requested resource to Door's private `prove` endpoint. Door calls `auth.api.getSession` or OAuth token introspection and returns a short-lived closed `DoorAttestation`. It contains identity and assurance, never World membership or permission. It expires in at most 30 seconds and is not cached across requests.

The Restate Rust SDK endpoint is mounted under `/restate/*` through its `Endpoint::handle` adapter. If an SDK release makes the body integration unsafe or lossy, a second Tokio listener in the same `zoend` process is acceptable; a second application or business service is not.

Horizontal Fly Machines run the same image. Postgres leases distribute background work. No machine owns durable process memory. The app begins in one write region; multi-region writes require an explicit architecture decision.

## 4. Code ownership and dependency direction

```text
zoen-domain       pure IDs, value types, release IR, result algebras
    ↑             no sqlx, axum, rmcp, Restate, provider, or UI types
    │
zoen-ontology     admission, truth, agency, attention, release, settlement
    ↑             depends only on domain + narrow ports
    │
zoen-eve          relationship, conversation, model loop, attention delivery
    ↑             depends on domain + public Ontology facade, never internals
    │
zoen-adapters     Postgres, Tigris/DataFusion, models, channels, Restate, Door
    ↑
zoend             composition root + Axum/API/MCP/static surface adapters

zoen-cli          generated/native HTTP client + dynamic released commands
zoen-harness      black-box journey runner against deployed public surfaces
```

The six conceptual Ontology engines are modules, not crates or services:

```text
ontology/
  admission.rs    Door proof → one purpose-bound WorldSession
  truth.rs        evidence, identity, belief, Frame, explain
  agency.rs       ActionCase, contributions, DecisionReceipt
  attention.rs    Watch, checkpoint, Notice
  release.rs      compile, prove, prepare, activate
  external.rs     EffectIntent, reconciliation, Settlement
  commit.rs       the one serializable AuthorityCommit implementation
```

Modules are organized by knowledge ownership, not `load/validate/save` execution order. A public operation crosses at most surface → deep product module → adapter. Transport DTOs are parsed at the surface and do not enter `zoen-domain`.

Eve has four deep modules:

```text
eve/
  relationship.rs  relationship, Focus continuity, channel binding
  conversation.rs  durable turns, forks, attempts, tool loop
  attention.rs     Notice arbitration, merge/defer, wording, delivery
  presentation.rs  RenderDocument → web/channel-specific rendering
```

## 5. Core types: make illegal authority states unrepresentable

### 5.1 Realm and identity

```rust
mod realm {
    pub trait Realm: private::Sealed + Send + Sync + 'static {
        const KIND: RealmKind;
    }
    pub enum Live {}
    pub enum Evaluation {}
}

pub struct WorldRef<R: Realm> {
    realm_id: RealmId,
    id: WorldId,
    _realm: PhantomData<R>,
}

pub struct Ref<R: Realm, T> {
    world: WorldRef<R>,
    id: TypedId<T>,
}

pub type RelationshipRef<R> = Ref<R, Relationship>;
pub type FrameRef<R> = Ref<R, WorldFrame>;
pub type CaseRef<R> = Ref<R, ActionCase>;
pub type WatchRef<R> = Ref<R, Watch>;
pub type NoticeRef<R> = Ref<R, Notice>;
pub type EffectRef<R> = Ref<R, EffectIntent>;
pub type EvidenceRef<R> = Ref<R, EvidenceRecord>;
pub type ReceiptRef<R> = Ref<R, Receipt>;
pub type TurnRef<R> = Ref<R, Turn>;
pub type WakeupRef<R> = Ref<R, Wakeup>;
pub type ExplanationRef<R> = Ref<R, Explanation>;
pub type WorldTransitionRef<R> = Ref<R, WorldTransition>;
pub type SubjectRef<R> = Ref<R, Subject>;
```

`Live` and `Evaluation` are sealed zero-sized brands. There is no cast. Every operational reference also carries its World, so two live Worlds are not interchangeable merely because their realm brand matches. A boundary parses an untrusted wire ID into `UnresolvedRef`, selects one credential-isolated realm context and World, and produces the typed reference only after lookup. Runtime realm/World tags remain in persisted keys so database constraints backstop the compiler.

Domain identity is separate from login identity:

```rust
pub struct AccountId(Uuid);       // Better Auth human subject
pub struct DoorClientId(Uuid);    // Better Auth OAuth client subject
pub struct PrincipalId(Uuid);     // Ontology actor: human or agent
pub struct IdentityHypothesis<R: Realm> {
    subject: SubjectRef<R>,
    rivals: NonEmpty<SubjectRef<R>>,
    evidence: NonEmpty<EvidenceRef<R>>,
    status: IdentityStatus,
}
```

Door cannot create or merge `SubjectRef` values.

### 5.2 Presence, grant, purpose, and Focus

```rust
pub struct HumanDoorAttestation {
    account: AccountId,
    session: DoorSessionId,
    assurance: Assurance,
    authenticated_at: Timestamp,
    expires_at: Timestamp,
    transport: DoorTransport,
    request_nonce: Nonce,
}

pub struct ClientDoorAttestation {
    client: DoorClientId,
    token: DoorTokenId,
    assurance: ClientAssurance,
    issued_at: Timestamp,
    expires_at: Timestamp,
    resource: ResourceId,
    request_nonce: Nonce,
}

pub enum DoorAttestation {
    Human(HumanDoorAttestation),
    Client(ClientDoorAttestation),
}

pub enum Presence<R: Realm> {
    Human(HumanDoorAttestation),
    DelegatedAgent {
        client: ClientDoorAttestation,
        relationship: RelationshipRef<R>,
        channel_presence: Option<ChannelPresence>,
    },
}

pub enum Purpose<R: Realm> {
    Understand,
    ConversationTurn { turn: TurnRef<R> },
    DomainAction { action: SemanticId },
    OpenCase { case: CaseRef<R> },
    AnswerCase { case: CaseRef<R> },
    WatchEvaluation { watch: WatchRef<R> },
    NoticeArbitration { notice: NoticeRef<R> },
    NoticeComposition { notice: NoticeRef<R> },
    EvaluateRelease { release: ReleaseDigest },
}

pub struct Focus<R: Realm> {
    world: WorldRef<R>,
    subject_or_lens: FocusIntent,
    basis: BasisIntent,
    last_frame: Option<FrameRef<R>>,
    pending_case: Option<CaseRef<R>>,
    pending_watch: Option<WatchRef<R>>,
}

pub struct WorldSession<R: Realm> {
    world: WorldRef<R>,
    purpose: Purpose<R>,
    // private: grant, principal, audience, membership revision,
    // delegation chain, release constraint, expiry
}

pub struct ReleasedValue {
    release: ReleaseDigest,
    schema: SemanticId,
    canonical_bytes: Arc<[u8]>,
    digest: CanonicalDigest,
}

pub struct AuthorizedCapability<R: Realm, K> {
    world: WorldRef<R>,
    release: ReleaseDigest,
    semantic_id: SemanticId,
    authorization: AuthorizationDigest,
    _kind: PhantomData<K>,
}

pub type InspectCapability<R> = AuthorizedCapability<R, InspectKind>;
pub type ActionCapability<R> = AuthorizedCapability<R, ActionKind>;
pub type WatchCapability<R> = AuthorizedCapability<R, WatchKind>;
```

Focus contains no grant, token, membership, evidence selection, disclosed view, or DecisionHandle. A stolen Focus is a bookmark. A `WorldSession` has exactly one purpose and is never serialized.

`ReleasedValue` is not `serde_json::Value`. Only the active release runtime can construct it after schema validation and canonicalization. Authorized capability handles come only from that session's filtered catalog and cannot be moved to another World or release.

Inbound WhatsApp or Telegram is not falsely recorded as a fresh Better Auth human session. Eve verifies the channel event, resolves an enrolled relationship, and enters Ontology as a Better Auth client-credential agent under an explicit delegation. Policy can permit low-risk inspection at that assurance. A human DecisionContribution requiring presence triggers a Better Auth step-up link; it is never attributed to the person merely because a channel ID matched.

### 5.3 Time, truth, and Frame

```rust
pub struct Basis {
    valid: ValidTime,             // instant or interval in domain reality
    recorded: KnowledgeCut,       // what Zoen had admitted
}

pub struct KnowledgeCut {
    world: WorldId,
    cut: CutSeq,
    recorded_at: Timestamp,
    release: ReleaseDigest,
    data_generation: DataGenerationId,
    observation_manifest: ManifestDigest,
}

pub enum TruthRecord {
    Evidence(EvidenceRecord),
    Claim(ClaimRecord),
    Belief(BeliefRecord),
    Dispute(DisputeRecord),
    Unknown(UnknownRecord),
}

pub struct WorldFrame<R: Realm> {
    id: FrameRef<R>,
    basis: Basis,
    purpose: PurposeDigest,
    authorized_audience: AudienceDigest,
    belief_policy: SemanticId,
    evidence_rights: RightsDigest,
    result: ReleasedValue,
    gaps: Vec<Gap>,
    uncertainty: Uncertainty,
    explanation: ExplanationRef<R>,
    read_set: ExactReadSet,
}

pub struct ExactReadSet {
    sparse: Vec<RecordRevision>,
    beliefs: Vec<BeliefDigest>,
    policies: Vec<PolicyRevision>,
    dense_slices: Vec<ManifestSliceDigest>,
    digest: ReadSetDigest,
}
```

Reads first pin an immutable `KnowledgeCut`, then query temporal Postgres records at `recorded_cut <= cut` and immutable dense objects under the pinned manifest root. The grant is checked before discovery and again before a sensitive response leaves the process. If membership or delegation changed during computation, the computed result is discarded.

### 5.4 Agency

```rust
pub enum Invocation<R: Realm> {
    Committed(DecisionReceipt<R>),
    Impossible(ReleasedImpossibility),
    Deliberation {
        case: CaseRef<R>,
        view: AuthorizedCaseView<R>,
        handle: Option<DecisionHandle<R>>,
    },
}

pub struct ActionCase<R: Realm> {
    id: CaseRef<R>,
    world: WorldRef<R>,
    release: ReleaseDigest,
    action: SemanticId,
    canonical_intent: CanonicalDigest,
    read_set: ExactReadSet,
    decision_rule: SemanticId,
    version: CaseVersion,
    expires_at: Timestamp,
}

pub struct AuthorizedCaseView<R: Realm> {
    case: CaseRef<R>,
    principal: PrincipalId,
    audience: AudienceDigest,
    case_version: CaseVersion,
    disclosure: DisclosureDigest,
    consequences: ReleasedValue,
    progress: AuthorizedProgress,
    view_digest: ViewDigest,
}

pub struct DecisionHandle<R: Realm> {
    case: CaseRef<R>,
    case_version: CaseVersion,
    view_digest: ViewDigest,
    principal: PrincipalId,
    expires_at: Timestamp,
    mac: SecretMac,
}

pub struct DecisionContribution<R: Realm> {
    case: CaseRef<R>,
    principal: PrincipalId,
    authorization: AuthorizationDigest,
    case_version: CaseVersion,
    answer_digest: AnswerDigest,
    view_digest: ViewDigest,
    recorded_at: Timestamp,
}

pub struct OpenedCase<R: Realm> {
    view: AuthorizedCaseView<R>,
    handle: Option<DecisionHandle<R>>,
}

pub enum AnswerOutcome<R: Realm> {
    Progress { receipt: AnswerReceipt<R>, view: AuthorizedProgress },
    Decided { receipt: AnswerReceipt<R>, decision: DecisionReceipt<R> },
    Stale { receipt: AnswerReceipt<R>, changed: NonEmpty<DependencyChange> },
    Expired { receipt: AnswerReceipt<R> },
}

pub struct DecisionReceipt<R: Realm> {
    receipt: ReceiptRef<R>,
    case: Option<CaseRef<R>>,
    transition: WorldTransitionRef<R>,
    changes: ChangeSetDigest,
    effects: Vec<EffectRef<R>>,
    committed_cut: KnowledgeCut,
}
```

A `DecisionHandle` is a short-lived HMAC-bound continuation, not sole authority. Answering always requires fresh presence and policy. An eligible view yields a handle only if all decision-relevant consequences are disclosed. The server stores the view audit, not the handle secret.

One Action invocation has one canonical Case. Concurrent identical invocations converge through `OperationKey + intent digest`. A Case never silently refreshes after consent; changed dependencies return `Stale` and require a new live invocation.

### 5.5 Attention and interaction

```rust
pub enum WatchState {
    Active,
    Paused(PauseReason),
    Cancelled { at: Timestamp },
}

pub enum WatchRevision {
    ReplaceIntent { intent: ReleasedValue },
    Pause { reason: UserReason },
    Resume,
    Cancel,
}

pub struct Watch<R: Realm> {
    id: WatchRef<R>,
    owner: PrincipalId,
    capability: SemanticId,
    intent_digest: CanonicalDigest,
    release_track: ReleaseTrack,
    detector_version: SemanticId,
    checkpoint: WatchCheckpoint,
    state: WatchState,
}

pub struct Notice<R: Realm> {
    id: NoticeRef<R>,
    watch: WatchRef<R>,
    cause: WorldTransitionRef<R>,
    materiality: ReleasedValue,
    basis: KnowledgeCut,
}

pub enum OpenNotice<R: Realm> {
    Authorized(AuthorizedNoticeView<R>),
    Redacted(RedactedNotice),
    Suppressed(SuppressionReason),
}

pub enum InteractionEvent<R: Realm> {
    UserMessageAccepted(UserMessage),
    ModelAttemptStarted(ModelAttempt),
    ToolRequested(ToolRequest),
    ToolCompleted(ToolResult),
    AssistantMessageSettled(AssistantMessage),
    NoticeArbitrated(NoticeArbitration),
    DeliveryObserved(DeliveryObservation),
    Forked(ConversationFork),
    WakeupScheduled(Wakeup),
    WakeupFired(WakeupRef<R>),
}
```

Ontology owns deterministic materiality through Notice creation. Eve owns silence, merge, deferral, timing, wording, channel, and delivery. Ontology's outbox gives Eve only a Notice reference. Eve calls `open_notice` for arbitration and calls it again immediately before composition. Deferred state stores only Notice references.

### 5.6 Scenarios, Effects, and settlement

```rust
pub struct ScenarioWorld<R: Realm> {
    base: FrameRef<R>,
    overlay: ScenarioOverlay,
}

impl<R: Realm> ScenarioWorld<R> {
    pub async fn inspect(&self, capability: InspectCapability<R>, input: ReleasedValue)
        -> Result<ScenarioFrame<R>, ScenarioError>;
    pub async fn consider(&self, action: ActionCapability<R>, intent: ReleasedValue)
        -> Result<ScenarioConsequences<R>, ScenarioError>;
    pub fn prepare_live_case(self) -> FreshLiveIntent;
}

pub struct EffectIntent<R: Realm> {
    id: EffectRef<R>,
    connector: CompiledConnectorId,
    operation: SemanticId,
    payload_digest: CanonicalDigest,
    retry_safety: RetrySafety,
    sandbox_lease: Option<SandboxEffectLease<R>>,
}

pub enum RetrySafety {
    DestinationIdempotent { destination_key: DestinationKey },
    ReconcileBeforeRetry { reconciliation: SemanticId },
}

pub enum SettlementOutcome {
    Observed(ReleasedDomainOutcome),
    Unknown { reason: UnknownReason },
}

pub struct Settlement<R: Realm> {
    effect: EffectRef<R>,
    outcome: SettlementOutcome,
    evidence: NonEmpty<EvidenceRef<R>>,
    observed_at: Timestamp,
    admitted_cut: KnowledgeCut,
}
```

`ScenarioWorld` has no commit, decision, acquisition, publication, or Effect API. `prepare_live_case` discards scenario authority and yields only intent for a fresh live invocation.

Restate receives an Effect reference, not arbitrary connector payload from a caller. The handler reloads the immutable EffectIntent, validates realm and lease, executes the compiled connector, and records evidence. A timeout is `Unknown`. A DecisionReceipt never changes into a Settlement.

### 5.7 Release types

```rust
pub struct WorldRelease {
    digest: ReleaseDigest,
    manifest: ReleaseManifest,
    canonical_bytes: Arc<[u8]>,
}

pub struct ReleaseProof {
    release: ReleaseDigest,
    image: OciImageDigest,
    environment: EnvironmentDigest,
    journeys: JourneySuiteDigest,
    attestations: Vec<Attestation>,
    missing_sandboxes: Vec<CapabilityId>,
    signature: AttestationSignature,
}

pub struct PreparedActivation<R: Realm> {
    world: WorldRef<R>,
    expected_head: WorldHeadDigest,
    target_release: ReleaseDigest,
    target_generation: DataGenerationId,
    ready_through: CutSeq,
    migration_receipts: Vec<MigrationReceipt>,
    reprojection_receipts: Vec<ReprojectionReceipt>,
    open_case_disposition: Vec<CaseDisposition>,
    watch_disposition: Vec<WatchDisposition>,
    invariants: InvariantResultsDigest,
    world_attestation: Option<AttestationDigest>,
    digest: PreparedActivationDigest,
}

pub enum ActivationResult<R: Realm> {
    Activated(ReleaseActivationReceipt<R>),
    HeadChanged { current: WorldHeadDigest },
    PreparationStale { prepared: CutSeq, current: CutSeq },
    Blocked(NonEmpty<PreparationBlocker>),
}
```

Release-wide proof and per-World preparation are different artifacts. Neither can substitute for the other.

## 6. Deep public interfaces

```rust
pub trait Ontology: Send + Sync {
    async fn create_personal_world(
        &self,
        presence: HumanDoorAttestation,
        plant: AttestedPlantRef,
        key: OperationKey,
    ) -> Result<WorldGenesis, BootstrapError>;

    async fn accept_invitation(
        &self,
        presence: HumanDoorAttestation,
        invitation: InvitationSecret,
        key: OperationKey,
    ) -> Result<InvitationAcceptance, BootstrapError>;

    async fn enter<R: Realm>(
        &self,
        presence: Presence<R>,
        focus: Focus<R>,
        purpose: Purpose<R>,
    ) -> Result<WorldSession<R>, EnterError>;
}

impl<R: Realm> WorldSession<R> {
    pub async fn discover(&self) -> Result<AuthorizedCatalog<R>, DiscoverError>;

    pub async fn open_frame(
        &self,
        frame: FrameRef<R>,
    ) -> Result<WorldFrame<R>, OpenFrameError>;

    pub async fn inspect(
        &self,
        capability: InspectCapability<R>,
        input: ReleasedValue,
    ) -> Result<WorldFrame<R>, InspectError>;

    pub async fn invoke(
        &self,
        action: ActionCapability<R>,
        intent: ReleasedValue,
        key: OperationKey,
    ) -> Result<Invocation<R>, InvokeError>;

    pub async fn open_case(
        &self,
        case: CaseRef<R>,
    ) -> Result<OpenedCase<R>, OpenCaseError>;

    pub async fn answer(
        &self,
        handle: DecisionHandle<R>,
        answer: ReleasedValue,
        key: OperationKey,
    ) -> Result<AnswerOutcome<R>, AnswerError>;

    pub async fn watch(
        &self,
        capability: WatchCapability<R>,
        intent: ReleasedValue,
        key: OperationKey,
    ) -> Result<Watch<R>, WatchError>;

    pub async fn revise_watch(
        &self,
        watch: WatchRef<R>,
        expected: WatchRevisionNo,
        revision: WatchRevision,
        key: OperationKey,
    ) -> Result<Watch<R>, WatchError>;

    pub async fn open_notice(
        &self,
        notice: NoticeRef<R>,
    ) -> Result<OpenNotice<R>, OpenNoticeError>;

    pub async fn scenario(
        &self,
        frame: FrameRef<R>,
    ) -> Result<ScenarioWorld<R>, ScenarioError>;

    pub async fn explain(
        &self,
        subject: ExplainableRef<R>,
    ) -> Result<Explanation<R>, ExplainError>;
}
```

The interface is intentionally richer than CRUD and smaller than the implementation. It hides storage selection, temporal joins, DataFusion planning, policy, identity resolution, transaction retries, outbox emission, release compatibility, and presentation projection.

```rust
pub trait ReleaseEvolution: Send + Sync {
    async fn compile(&self, source: ReleaseSource)
        -> Result<WorldRelease, CompileError>;

    async fn create_evaluation(
        &self,
        release: ReleaseDigest,
        lease: EvaluationLease,
    ) -> Result<EvaluationWorld, EvaluationError>;

    async fn prove(
        &self,
        world: EvaluationWorld,
        suite: JourneySuiteDigest,
    ) -> Result<ReleaseProof, ProofError>;

    async fn prepare(
        &self,
        world: WorldRef<realm::Live>,
        target: ReleaseDigest,
        proof: ReleaseProofRef,
    ) -> Result<Preparation, PreparationError>;

    async fn activate(
        &self,
        proof: ReleaseProofRef,
        prepared: PreparedActivationRef<realm::Live>,
        approval: ActivationApproval,
    ) -> Result<ActivationResult<realm::Live>, ActivationError>;
}
```

`prepare` performs reuse, reprojection, or migration internally. Callers do not orchestrate stages.

```rust
pub trait Eve: Send + Sync {
    async fn accept<R: Realm>(&self, inbound: InboundTurn<R>)
        -> Result<TurnRef<R>, EveError>;
    async fn ingest_notice<R: Realm>(&self, notice: NoticeRef<R>)
        -> Result<(), EveError>;
    async fn attention<R: Realm>(&self, relationship: RelationshipRef<R>)
        -> Result<AttentionView<R>, EveError>;
}

trait ModelPort: Send + Sync {
    async fn stream(
        &self,
        request: ModelRequest,
        sink: &mut dyn ModelEventSink,
    ) -> Result<ModelCompletion, ModelFailure>;
}

trait ChannelPort: Send + Sync {
    async fn verify(&self, request: RawChannelRequest)
        -> Result<VerifiedChannelEvent, ChannelIngressError>;
    async fn deliver(&self, delivery: ChannelDelivery)
        -> Result<DeliveryObservation, ChannelDeliveryError>;
}
```

Provider SDK types never escape adapters. `ModelRequest`, tool calls, and channel documents are Zoen-owned closed types.

## 7. Protocols and concurrency

### 7.1 Authorization admission

1. Surface validates size, syntax, media type, CSRF/origin where relevant, and parses closed DTOs.
2. Door validates cookie or OAuth token and returns a short-lived DoorAttestation.
3. Admission resolves the World without disclosing its existence on failure.
4. Admission reads current membership, delegation, relationship, release, and audience.
5. Policy evaluates one explicit purpose.
6. Admission returns an in-process `WorldSession<R>`.
7. Discovery and data enumeration occur only after step 5.

For sensitive reads and all writes, the membership/delegation revision captured in the grant is revalidated at the final authority boundary. Failures that would leak existence collapse to `not-found-or-not-disclosable`.

### 7.2 Operation idempotency

The idempotency coordinate is:

```text
(realm, world, authorization principal, operation kind, OperationKey)
```

World creation has no World yet, so its bootstrap coordinate is `(realm, principal, CreatePersonalWorld, OperationKey)` and is protected by a unique constraint before the initial head is inserted. Invitation acceptance uses the invited World coordinate.

The transaction stores `intent_digest` and `result_ref` under that key.

- Same key + same canonical intent: replay the original result.
- Same key + different canonical intent: `IdempotencyConflict`.
- Crash before commit: no result exists, so a retry may execute.
- Crash after commit but before response: retry returns the committed result.

Provider idempotency keys are distinct from Zoen OperationKeys and are derived only when the connector declares a destination idempotency contract.

### 7.3 The one AuthorityCommit

Every Ontology mutation follows one internal protocol:

```text
BEGIN ISOLATION LEVEL SERIALIZABLE
  lock world_head FOR UPDATE
  lock affected aggregates in ascending typed-ID order
  revalidate grant + expected release + exact dependencies
  resolve OperationKey replay/conflict
  compute next CutSeq
  write semantic records
  write receipt / contribution / Notice / Settlement as applicable
  write deterministic EffectIntents as applicable
  write one WorldTransition batch with one or more stream changes
  write sibling outbox records
  advance world_head {cut, audit_root, release, generation, manifest_root}
COMMIT
```

Serialization failures are retried with the same command and OperationKey using bounded jitter. Exhaustion returns a retryable busy result, never a partial success. Multi-object Actions lock in stable order. Cross-World atomic Actions are forbidden; exchange between Worlds is admitted evidence with independent receipts.

Creation and invitation acceptance are separate commands with disjoint writes:

- `CreatePersonalWorld` verifies the planted `zoen` release and atomically creates World, initial head, owner membership, and `WorldGenesisReceipt`.
- `AcceptInvitation` consumes an invitation and creates only membership plus `InvitationAcceptanceReceipt`; it cannot write the existing head.

### 7.4 Frames and exact reads

Frame construction does not hold a database transaction open across object-store IO:

1. Pin current head and authorized cut.
2. Read temporal sparse rows as of that immutable cut.
3. Read immutable Parquet objects reachable from the pinned manifest root.
4. Execute released belief/query programs.
5. record exact sparse revisions, belief/policy digests, and dense manifest slices.
6. Revalidate disclosure before returning.
7. Persist the immutable Frame envelope and explanation root as a read artifact without advancing the World cut.

Because admitted records and manifest nodes are immutable by cut, steps 2–5 remain reproducible after the head advances.

Every returned Frame has a `FrameRef`. Its audience-protected result and explanation are therefore durable for the release retention policy and reopen only under fresh authorization. Persisting the read receipt is not a World truth mutation and emits no WorldTransition.

### 7.5 Eve recovery without Restate

An Eve turn has one `TurnId`, one monotonically revised interaction stream, zero or more model attempts, and at most one settled assistant message per turn branch.

1. Ingress deduplicates the provider event and atomically appends `UserMessageAccepted` plus work availability.
2. A Postgres lease claims the turn.
3. Eve appends `ModelAttemptStarted` before calling a model.
4. Tool requests and completed tool results are appended before they are fed back to the model.
5. Live token chunks stream to the client but are not durable.
6. The final message is atomically appended as `AssistantMessageSettled` with a delivery outbox item.
7. If the process dies during a model call, the attempt becomes abandoned after its lease. Recovery starts a new attempt. It may spend model tokens twice but can settle only once.

Eve timers and wakeups are due rows leased with `FOR UPDATE SKIP LOCKED`. Restate is not used for conversation, Notice arbitration, delivery, or wakeups.

### 7.6 Channels

- WhatsApp ingress is exactly `/eve/v1/kapso`; Kapso signature and event semantics are private to that adapter.
- Telegram ingress is exactly `/eve/v1/telegram`; the adapter verifies `X-Telegram-Bot-Api-Secret-Token` and deduplicates Telegram update IDs.
- Channel ingress persists the raw verified envelope before acknowledging.
- Structured presentation becomes one excellent readable text document; unsupported web chrome is not serialized as pseudo-buttons.
- Delivery has `Accepted`, `Rejected`, and `Unknown` observations. An unsafe timeout is not blindly retried if the provider lacks a destination idempotency key.
- Relationship/channel binding is Eve state. It is not domain identity and does not silently confer human decision authority.

### 7.7 Watch and Notice

Watches consume only committed, cut-bound WorldTransitions from the Ontology outbox. No table trigger, raw observation point, Parquet upload, or projection wakes a Watch directly.

Each evaluation reauthorizes the owner/delegation, confirms release-track compatibility, advances a deterministic checkpoint, and either remains silent or atomically commits Notice + checkpoint + event + outbox. Incompatible releases pause or create a governed migration Case.

Eve may merge or defer Notices, but stores references only. Revocation suppresses; disclosure change redacts. Notice content is never cached into a future message.

### 7.8 Effect and Settlement

1. An AuthorityCommit creates deterministic EffectIntents as siblings of the DecisionReceipt.
2. The Ontology outbox invokes Restate with `EffectRef` and a Restate idempotency key derived from it.
3. `zoen-effect-dispatcher` reloads the EffectIntent and realm-specific credential lease.
4. It checks the connector's retry contract before network IO.
5. Provider bytes are captured as evidence.
6. A separate AuthorityCommit admits evidence and records `Observed<domain outcome>` or `Unknown` Settlement plus event/outbox.

Restate durability does not turn an HTTP 202, timeout, or local handler completion into external truth.

## 8. Data and event model

### 8.1 Postgres schemas and roles

```text
door         Better Auth only; Node `door_role`
ontology     Worlds, meaning, authority, truth, agency, attention, effects
eve          relationships, interaction streams, attempts, wakeups, delivery
projection   disposable read indexes
```

Live and evaluation use distinct databases or schema sets, credentials, and connection pools. Evaluation credentials have no grants on live schemas. The runtime chooses a pool before producing a realm brand. `SET ROLE` is not used.

Core Ontology tables:

```text
worlds, world_heads, memberships, delegations
world_releases, release_proofs, data_generations, prepared_activations
semantic_records, identity_hypotheses
raw_captures, evidence, claims, beliefs, disputes
frames, explanations
action_cases, authorized_case_views, decision_contributions, decisions
watches, watch_checkpoints, notices
effect_intents, settlement_evidence, settlements
operation_results, world_transitions, ontology_outbox, consumer_receipts
dense_segments, dense_manifests, dense_rights, source_watermarks
```

Core Eve tables:

```text
relationships, channel_bindings, focuses
interaction_streams, interaction_events, conversation_snapshots
turns, model_attempts, eve_work, wakeups
notice_inbox, attention_preferences, deferred_notices
delivery_attempts, eve_outbox, eve_consumer_receipts
```

Temporal authority rows carry valid-time bounds and admitted cut bounds. Corrections append; they do not overwrite history. Current projections are derived and disposable.

### 8.2 WorldTransition envelope

```rust
pub struct WorldTransitionEnvelope<R: Realm> {
    transition: WorldTransitionRef<R>,
    world: WorldRef<R>,
    cut: CutSeq,
    actor: PrincipalId,
    purpose: PurposeDigest,
    release: ReleaseDigest,
    root_cause: CauseRef,
    parent: Option<WorldTransitionRef<R>>,
    changes: NonEmpty<StreamTransition>,
    recorded_at: Timestamp,
    prior_audit_root: AuditDigest,
    audit_root: AuditDigest,
}

pub struct StreamTransition {
    stream: StreamId,
    revision: StreamRevision,
    kind: TransitionKind,
    payload_digest: CanonicalDigest,
}
```

One AuthorityCommit creates one batch and one World cut; a multi-object Action contributes multiple deterministically ordered stream changes to that batch. `audit_root = SHA-256(domain-separator || prior_audit_root || canonical envelope without audit_root)`. The head stores the latest root. This makes exported histories tamper-evident without pretending the application key can prevent a database administrator from deleting both history and head.

Delivery is at least once. Each consumer commits its state change and `(consumer_id, event_id)` receipt atomically. The outbox row is a sibling of the source transition. Outbox deletion is retention, not correctness; receipts and events remain.

A data point is not an event. One admitted dense manifest or meaningful watermark transition can be.

### 8.3 Dense plane

Raw provider payloads and Parquet segments are uploaded to Tigris under their SHA-256 digest before admission. PostgreSQL remains authoritative about reachability, rights, schema, and which manifest belongs to a World cut.

```text
raw/{sha256}
release/{release_digest}/{artifact_digest}
dense/{world}/{data_generation}/{segment_digest}.parquet
manifest/{manifest_digest}.json
evaluation/{evaluation_id}/...
```

An immutable manifest DAG node contains child digests, semantic field IDs, valid-time bounds, provider clocks, rights digest, row counts, statistics, writer version, and segment digests. Manifest changes are copy-on-write. Orphan objects are safe and later collected after a reachability grace period.

DataFusion receives a Zoen-built logical plan, never caller SQL. An `EntitledTableProvider` exposes only segments and columns authorized by `DenseRights`, and pushes semantic time, subject, field, and entitlement predicates into Parquet scans. Result batches are converted into released values plus exact manifest-slice digests.

Personal and institutional Worlds use the same `inspect` capability. The physical planner selects temporal SQL, DataFusion, or a joined plan. That choice is absent from release surface schemas and explanations describe sources and transformations, not engine internals.

## 9. Evidence admission

Provider endpoints are compiled connectors, not ontology types. A release may reference a connector capability ID but may never provide an arbitrary URL, SQL fragment, credential name, or executable script.

```rust
pub async fn contribute<R: Realm>(
    source: &SourceCapability,
    lease: SourceLease<R>,
    request: ReleasedValue,
) -> Result<AdmissionReceipt<R>, ContributionError>;
```

The deep contribution operation hides these internal stages:

1. Validate canonical request and current rights.
2. Derive acquisition identity from provider, capability, request, window, checkpoint, adapter version, and source-contract ID.
3. Capture immutable raw bytes.
4. Deterministically map under the active release.
5. Preserve identity rivals and validate evidence.
6. Produce an immutable sparse or dense proposal.
7. AuthorityCommit accepts the proposal, advances cut, writes receipt/event/outbox, and updates the manifest root if dense.

A crash before step 7 can leave an orphan object but cannot leave half-admitted truth.

## 10. Canonical JSON Publish and release execution

### 10.1 Source and executable IR

A release source is a directory of authored canonical JSON documents plus journey definitions. The compiler parses every document into closed Rust types with unknown-field denial. LLM-generated builder output is merely source input.

The initial executable language is a small typed, total Zoen IR:

- semantic object/link/field declarations;
- identity match and resolution rules;
- evidence mappings and belief programs;
- temporal/relational/dense query expressions;
- policy predicates and decision rules;
- domain Action read/consequence/change/effect descriptions;
- Watch detectors and materiality expressions;
- presentation facets and explanation labels.

There is no arbitrary JavaScript, Rust plugin, SQL, network IO, or WASM in a release. Connector and effect implementations are compiled into the server and referenced by stable IDs. If the IR cannot express three independently demanded real capabilities, a pure WASM Component boundary may be proposed later; it is not preinstalled complexity.

### 10.2 Canonicalization

The compiler is the sole canonicalizer:

1. Decode UTF-8 JSON while rejecting duplicate object keys.
2. Validate NFC strings; reject rather than silently normalize identifiers.
3. Parse into closed typed ASTs; reject unknown fields and ambiguous unions.
4. Reject binary floating-point numbers. Decimals are canonical strings carrying scale/unit rules; integers are range-checked.
5. Normalize timestamps to UTC with the release format's fixed precision.
6. Sort every set-valued collection by stable `SemanticId`; preserve only arrays declared semantically ordered.
7. Serialize RFC 8785 JSON Canonicalization Scheme bytes.
8. Digest `SHA-256("zoen.world-release.v1\0" || canonical_bytes)`.

Stable semantic IDs are opaque UUID-based IDs; human names and CLI/MCP slugs may change without changing identity. Slug collisions fail compilation.

The release manifest closes over all typed IR documents, compiled indexes, public schemas, surface facets, compiled connector IDs and minimum versions, and the journey-suite digest. Referenced binary artifacts are separately digested. The manifest digest is the `ReleaseDigest`.

### 10.3 Proof, preparation, activation

An EvaluationWorld has its own realm ID, WorldHead, Postgres role/database, Tigris namespace and credential, Eve relationship IDs, interaction store, outbox coordinates, Restate namespace, source leases, sandbox Effect leases, channel capture/sandbox bindings, expiry, and cleanup receipt.

The same image installs the candidate release as that world's active head. There is no `useInactiveRelease` flag.

`ReleaseProof` records exact image, Rust/Node/runtime/library versions, release and journey digests, schema/semantic/policy/replay results, provider sandbox attestations, and missing attestations. Its detached Ed25519 signature covers a domain-separated canonical digest. Activation policy fails closed when a capability requires a sandbox attestation that is absent.

`prepare` compares `{current release, generation, cut}` with the target and chooses internally:

- reuse when representation and meaning are compatible;
- reprojection when source evidence remains valid but derived state changes;
- migration when authoritative semantic records require a deterministic mapping;
- blocked governed Cases when mapping requires human judgment.

It stages a non-authoritative data generation, catches up only from committed WorldTransitions, and emits a content-addressed PreparedActivation. If writes outrun catch-up, a short per-World write fence is the explicit fallback.

Activation starts one serializable transaction, verifies release proof, approval, expected head, and `ready_through == current cut`, then atomically changes `{release, data_generation}`, writes activation receipt/event/outbox, and advances the head. Head mismatch rebases. Cut mismatch returns `PreparationStale`. Rollback is another proved and prepared release transition. Dual-read, dual-write, partial migration, and mutable release artifacts are forbidden.

## 11. Surface projection without lowest-common-denominator semantics

Every release capability has one stable semantic identity and optional surface facets:

```rust
pub struct CapabilityDescriptor {
    id: SemanticId,
    kind: CapabilityKind,
    input: ReleasedSchema,
    output: ReleasedSchema,
    consequences: Option<ReleasedSchema>,
    disclosure_policy: SemanticId,
    cli: Option<CliFacet>,
    api: Option<ApiFacet>,
    mcp: Option<McpFacet>,
    eve: Option<EveFacet>,
    living_world: Option<LivingWorldFacet>,
}
```

The descriptor does not contain transport request structs. Each adapter maps its idiom:

- CLI dynamically parses released subcommands and generates help/completions.
- API routes `.../actions/{released-slug}` and returns typed domain envelopes; authorized OpenAPI is generated per World/release/audience.
- MCP produces current protocol tool schemas with `rmcp`; list and call each perform fresh authorization.
- Eve gets internal tool descriptors optimized for model use, not an MCP round trip.
- Living World gets presentation facets and opaque action/case references, never policy logic.

Fixed Rust-to-web envelope types are generated into TypeScript by `cargo xtask bindings`. They are checked artifacts, not a second hand-authored domain model. Dynamic released schemas remain runtime data.

## 12. Security constitution

1. **No ambient authority.** Focus is authority-free; every entry creates one short-lived, single-purpose grant.
2. **Door is identity only.** Better Auth never stores World roles or domain identity. Rust never reads Door tables.
3. **Auth before discovery.** Capability and data existence are filtered before enumeration; unsafe distinctions collapse.
4. **Realm isolation.** Live/evaluation brands, database credentials, object credentials, Restate namespaces, relationship IDs, and egress allowlists are distinct.
5. **Browser mutation defense.** SameSite secure HTTP-only auth cookies, exact Origin checks, and an HMAC session-bound double-submit CSRF header are required on cookie-authenticated mutations.
6. **OAuth.** API/CLI/MCP use resource-bound OAuth 2.1 tokens with PKCE or device flow; opaque introspection is preferred where immediate revocation matters. Dynamic client registration is off unless MCP interoperability proves it necessary.
7. **Channel ingress.** Verify provider secrets/signatures before parsing business payloads; deduplicate provider IDs; retain raw evidence; rate limit by provider and binding.
8. **No caller URLs.** Connector endpoints and redirect policies are compiled allowlists. Releases cannot produce SSRF destinations.
9. **Prompt injection is not authority.** Evidence is labelled untrusted; models can propose only released tool calls. Every call is independently parsed, authorized, and validated by Ontology.
10. **Secret indirection.** Domain records carry `SecretRef`/lease IDs, never values. Adapters resolve them at the final boundary. Secrets and raw evidence are redacted from logs.
11. **Signed immutable releases.** Digests, signatures, exact image attestations, per-World preparation, and approval are all required.
12. **Database defense in depth.** Separate roles/schemas, least privilege, realm-qualified primary keys, foreign keys, check constraints, and RLS for World isolation. Transaction-local context is set before protected SQL.
13. **Bounded input.** Body, stream, recursion, collection, expression complexity, query cost, model tokens, and object-range requests all have released or server ceilings.
14. **Effect egress.** Restate identity is verified; an Effect can reach only its compiled connector and realm-specific credentials.
15. **Supply chain.** Locked Cargo/pnpm dependencies, provenance/SBOM, `cargo deny`, npm audit, signed image digest, and no runtime package installation.

## 13. Observability and audit

Every request, turn, World transition, Watch evaluation, Notice arbitration, model attempt, effect attempt, and release transition has an OpenTelemetry trace. Causality fields are stable across Postgres, Restate, providers, and Eve:

```text
trace_id, realm, opaque_world_id, release_digest, cut,
root_cause, parent_event, operation_key_digest, turn_id,
case_id/watch_id/notice_id/effect_id when applicable
```

Logs contain digests and opaque IDs, never message/evidence bodies by default. Privileged forensic access is an audited product operation.

Required metrics:

- Door proof latency/failure and assurance mix;
- admission denial by non-sensitive reason class;
- AuthorityCommit latency, lock wait, serialization retry, idempotent replay;
- World-head commits per second and hot-World contention;
- Frame sparse/dense planning, bytes scanned, row groups pruned, final reauth failures;
- outbox, Watch, Eve work, wakeup, and delivery lag;
- Notice material/suppressed/deferred/merged ratios;
- model latency, attempts per turn, abandoned attempts, tool-loop depth, token spend;
- Effect queued/attempted/Unknown/reconciled/settled ratios;
- release proof coverage, preparation lag, catch-up rate, activation conflicts;
- evaluation cleanup age and orphan object age.

Alerts protect semantic promises: stuck outbox, Watch falling behind its cut, duplicate settled turn, live credential used in Evaluation, unsafe Effect retry, Preparation claiming a stale cut, and audit-root discontinuity.

## 14. Deployment and operations

The multi-stage image:

1. pins Rust and builds `zoend`, `zoen`, and `zoen-harness`;
2. pins Node/pnpm, builds the Better Auth Door and React assets;
3. runs only the Rust binaries, Node LTS runtime, Door JavaScript, static assets, CA roots, and required native DataFusion dependencies;
4. emits SBOM and records the OCI digest used in ReleaseProof.

`zoend` is PID 1 and supervises Door. It handles SIGTERM by stopping ingress, abandoning no claimed lease without expiry, flushing telemetry, and exiting inside Fly's grace window.

Health:

- `/health/live`: event loop and supervisor alive.
- `/health/ready`: Door socket, Postgres schema version, required release artifacts, and worker lease subsystem usable.
- Restate/provider degradation does not make read-only inspection unready; it appears in capability health and blocks affected Effects honestly.

Migrations are explicit release commands, never concurrent startup side effects:

```bash
zoen admin migrate --component ontology
pnpm --dir door auth:migrate
zoen admin verify-schema
```

Postgres advisory locks serialize migration ownership. Better Auth owns only its `door` schema migration output. Pre-launch baselines can be replaced deliberately, but checked-in setup remains deterministic.

Backups require Postgres PITR and Tigris retention/lifecycle policy. Restore is proven by a journey that reopens a historical Frame and validates its manifest digests.

Evaluation runs outside the live process as `zoen-harness` in CI or an ephemeral runner, using the same image but only evaluation credentials. It is not a second product or long-lived Fly app.

## 15. Repository constitution

```text
/
  Cargo.toml
  Cargo.lock
  rust-toolchain.toml
  deny.toml
  crates/
    domain/src/
    ontology/src/
    eve/src/
    adapters/src/
  apps/
    zoend/src/
    zoen-cli/src/
    zoen-harness/src/
  door/
    package.json
    src/auth.ts
    src/server.ts
    migrations/
  web/
    package.json
    src/api/generated/
    src/conversation/
    src/living-world/
    src/studio/
  releases/
    planted-zoen/
    schema/
  journeys/
    first-frame/
    focus-continuity/
    quiet-watch/
    accountable-action/
    scenario/
    release-activation/
    dense-as-of/
  migrations/
    ontology/
    eve/
    projection/
  xtask/
  deploy/
    Dockerfile
    fly.toml
```

Crate import rules are enforced statically. `domain` imports no framework. `eve` cannot import Ontology internals or Restate. Only `adapters` imports provider SDK/wire modules. Only `zoend` composes concrete adapters. TypeScript cannot import or duplicate policy logic.

## 16. Journey-only verification and CI

There are no unit tests, mocks, fakes, stubs, snapshot substitutes, or `vi.mock`. Static analysis is not renamed as testing. Behavioral proof comes from user journeys through public surfaces and real persistence.

### 16.1 Canonical journeys

1. **First honest Frame.** Sign in; create a personal World or accept an invitation and prove their disjoint write sets; connect one real evaluation source; admit evidence; receive a provisional Frame with gaps; resolve an identity ambiguity through a Case and DecisionReceipt; reopen the Focus in Living World under fresh authority.
2. **Continuous Focus.** Ask in Eve, open the exact Frame in Living World, advance the World, reopen historical vs newer Frame explicitly, revoke membership mid-read, and prove no stale disclosed result leaves the server.
3. **Quiet Watch.** Create/edit/pause/resume/cancel idempotently; process ordinary changes silently; emit one material Notice atomically; defer only its ref; revoke before composition; observe Suppressed; restore with changed rights and observe Redacted.
4. **Accountable Action.** Form one shared quorum Case; open principal-specific views; refuse a hidden-consequence approver; record contributions; stale the read set concurrently; retry same/different intent keys; commit once; observe Effect timeout as Unknown; reconcile real sandbox evidence into Settlement.
5. **Unforgeable Scenario.** Fork a Frame; inspect and consider; attempt decision/acquisition/effect/publication through every surface and prove absence; prepare a fresh live Case and prove it re-reads current reality.
6. **Release evolution.** Compile deterministic bytes twice; install exact digest in EvaluationWorld; exercise API/CLI/MCP/Eve; prove sandbox attestations; prepare reprojection through cut; advance live cut during catch-up; observe PreparationStale; activate by exact-head CAS; prove old open Case/Watch disposition; roll back only as a new release transition.
7. **Dense as-of and entitlement.** Admit a real large Parquet fixture through the source contract, resolve comparable semantic fields, query two valid times and two recorded cuts, remove entitlement, prove row-group/column pruning and no leakage, trigger one watermark Watch transition rather than point events.

### 16.2 Real harness

`zoen-harness` launches the production image against PostgreSQL 18, a real Tigris evaluation bucket or isolated S3-compatible production-grade store, and a real Restate runtime. It drives HTTP, browser-visible API, CLI subprocess, MCP conformance/client, and channel endpoints. `CaptureChannel` is a first-class EvaluationWorld sink and attests rendering/persistence only; a capability claiming provider delivery requires that provider's verified sandbox.

Crash/retry journeys use real process termination, duplicate webhook delivery, database contention, and network interruption. They do not replace a provider with an in-memory implementation. Missing provider sandbox evidence is recorded as missing and can block activation.

### 16.3 CI gates

Static gates on every change:

```text
cargo fmt --check
cargo clippy --workspace --all-targets --all-features -- -D warnings -D clippy::unwrap_used
cargo deny check
cargo sqlx prepare --check
pnpm --frozen-lockfile typecheck
dependency/import graph checks
generated bindings and release schemas have no diff
canonical release compile is byte-identical
```

Journey gates:

- pull request: first Frame, Focus, Watch, Action core in an EvaluationWorld;
- merge: all seven journeys plus crash/retry/replay;
- release: exact OCI image, real provider sandboxes, MCP protocol conformance, restore journey, and signed ReleaseProof;
- scheduled: dense scale, contention, orphan collection, credential-realm isolation, and dependency update journeys.

`cargo test` is not the product verification harness. Compiler examples and invariants are exercised through the release journey.

## 17. Build sequence

### S0 — language trial, five focused engineering days

Implement the same thin slice twice: Better Auth entry, one purpose grant, one serializable mutation/outbox, one as-of Frame, and one 100-million-row entitled Parquet query. Rust uses SQLx/DataFusion; TypeScript uses a strict stack/Postgres/DuckDB Node Neo. Measure elapsed implementation time, changed lines, unsafe escapes (`as`/`any` versus runtime assertions), cold/incremental CI, p50/p95 latency, peak RSS, scanned bytes, and failure recovery. Apply the gate in section 0. Delete the losing spike completely.

### S1 — planted `zoen` and one honest Frame

Ship Door, create/join distinction, one WorldHead, admission, one source contribution, evidence/claim/belief separation, identity ambiguity Case, honest provisional Frame, explanation, API/CLI, and Living World reopening.

### S2 — Eve is a durable relationship

Ship Relationship, Focus, interaction event stream, model attempts, tool loop, one settled message, web streaming, crash recovery, and text-first presentation. Integrate one model through a direct `reqwest` adapter; no generic agent framework.

### S3 — one quiet Watch

Ship deterministic transition consumption, checkpoint, reauthorization, materiality, atomic Notice, Attention view, Eve arbitration/defer/merge, fresh open before composition, and Telegram plus Kapso ingress/delivery truth.

### S4 — one accountable Action and real Effect

Ship exact read sets, canonical Case, principal-specific views/handles, contributions/quorum, stale rejection, AuthorityCommit, DecisionReceipt, EffectIntent, Restate dispatcher, Unknown, reconciliation, and Settlement.

### S5 — release evolution

Ship canonical JSON compiler, typed IR, dynamic surface catalog, EvaluationWorld, seven journeys, ReleaseProof, data generations, preparation/catch-up, approval, atomic activation, and rollback-as-release.

### S6 — dense reality

Ship Parquet segments, manifest DAG, Tigris, DataFusion entitled provider, mixed sparse/dense Frame, comparable fields, watermarks, and dense Watch efficiency.

### S7 — institutional authority without a second product

Ship delegated/machine principals, partitions in policy rather than product types, larger quorums, portable release/evidence exports, audit verification, contention scaling, and multi-instance Fly operation.

Each slice ends in a human-visible outcome and its journey proof. Infrastructure that no journey needs is not built.

## 18. Architecture decisions (18)

### ADR-01 — Rust-first is provisional

Use Rust for the server only if S0 meets explicit safety/performance/velocity gates. Reason: language is a means; all semantic invariants are portable. Reopen: any gate fails or provider work dominates roadmap.

### ADR-02 — exactly three products

Door, Eve, and Ontology are product/authority boundaries. Studio is an Ontology profile; deployment/runtime pieces are not products.

### ADR-03 — one Fly app and one Rust server

Deploy one image and one public Rust process; supervise a minimal local Better Auth Node process. Reason: one operational unit without rewriting Better Auth.

### ADR-04 — Postgres is transactional authority

Use PostgreSQL 18 for every authoritative sparse record, receipt, event, outbox, and Eve stream. Reason: serializable transactions close the promises. Object storage and projections are not authority.

### ADR-05 — Better Auth is accessed, never reimplemented

Proxy public auth and exchange credentials through a private Unix socket. Never read its tables or validate its cookies in Rust. Reason: preserve session semantics and keep TS bounded.

### ADR-06 — realm isolation is typed and credentialed

Brand references with sealed `Live`/`Evaluation` types and use distinct database/object/Restate/channel credentials. Reason: neither types nor infrastructure isolation is sufficient alone.

### ADR-07 — one purpose per grant

Focus has no authority. Each operation obtains a short-lived grant for one explicit purpose and revalidates at authority/disclosure boundaries.

### ADR-08 — one AuthorityCommit protocol

All Ontology mutations use serializable transactions, stable lock order, exact preconditions, idempotency ledger, receipt/event/outbox siblings, and one World cut.

### ADR-09 — event-oriented, not universal event sourcing

Persist meaningful transitions and Eve interaction events. Keep dense points and current projections in suitable data forms. Reason: causality without replaying every byte.

### ADR-10 — Eve durability stays in Eve/Postgres

Use Eve streams, work leases, and outbox for turns/delivery. Restate cannot become a conversation engine.

### ADR-11 — Restate only executes ZoenEffect

Effect creation remains an Ontology commit; Restate performs durable attempts; Settlement remains separate evidence-bound truth.

### ADR-12 — canonical JSON is the release source of truth

Compile closed typed JSON through RFC 8785 and SHA-256. Candidate and active bytes are identical. Reason: portable, reviewable, language-neutral meaning.

### ADR-13 — the first release language is a total declarative IR

No arbitrary extension code, SQL, URL, or WASM. Reason: deterministic proof, lineage, safety, and a small compiler. Reopen only after three real expressiveness failures.

### ADR-14 — sparse Postgres, dense Parquet/DataFusion

Use temporal relational authority plus immutable columnar objects/manifests. Reason: one semantic model without forcing dense series through row storage.

### ADR-15 — surfaces project one authorized catalog

CLI/API/MCP/Eve/Living World share semantic IDs and schemas but own idiomatic facets. Discovery is policy-filtered; no transport type enters the kernel.

### ADR-16 — World writes serialize at the head

Allocate one monotonic CutSeq by locking a WorldHead; batch dense points into manifest admissions. Reason: the simplest globally ordered causal stream. Reopen at sustained >500 commits/s or p95 lock wait >25 ms for one World.

### ADR-17 — no cross-World atomic transaction

A command has one authority World. Cross-World facts arrive as evidence with independent receipts. Reason: avoid distributed authority and hidden coupling.

### ADR-18 — journeys are the only behavioral proof

Drive real surfaces, storage, Restate, and sandboxes in EvaluationWorld. No unit tests, mocks, fakes, or stubs. Static compiler/lint/schema checks remain static gates.

## 19. Alternatives and rejected shapes

### Strict TypeScript + Postgres + DuckDB

This is the leading rival, not a discredited fallback. It can attain every semantic property here. TypeScript discriminated unions, runtime schema validation, branded IDs, serializable SQL, outboxes, and DuckDB Node Neo are sufficient. It wins Better Auth, MCP, LLM, channel, hiring, iteration, and one-runtime simplicity. Rust wins only provisionally on sealed realm/state types and a native customizable Arrow/DataFusion path; S0 decides. Do not cite “correctness” without measured defect reduction.

### Rust kernel plus TypeScript Eve

Rejected for this candidate because it duplicates transport and domain envelopes across the hottest product boundary and turns every model tool call into RPC. It may become the compromise if Rust proves valuable only for dense/authority work.

### TypeScript server plus Rust dense sidecar

Rejected initially because a second service/protocol is premature. Reopen if TypeScript wins product velocity while a measured dense bottleneck justifies a native library or sidecar.

### DuckDB embedded in the Rust server

Rejected in favor of DataFusion because Zoen needs a custom entitlement-aware `TableProvider` and direct Arrow plans more than ad hoc SQL ergonomics. Reopen if DataFusion API churn or compile cost exceeds its policy/pushdown advantage.

### Microservices for the seven authorities

Rejected. Authorities are truth ownership partitions, not network boundaries. Distributed commits would weaken the core promises.

### Graph database as the World

Rejected. Graph is a semantic view; temporal evidence, decisions, policy, receipts, and dense series require richer lifecycles. Postgres plus manifests is the authority.

### Kafka, Redis, or a universal workflow engine

Rejected. Transactional outboxes, Postgres leases, and Restate Effects cover the required durability with fewer truths.

### Restate for Eve, Watches, and release preparation

Rejected by ownership. Eve owns conversation durability; Watches follow committed World transitions; preparation has explicit data-generation state. Restate is only Effects.

### Arbitrary code or WASM in releases on day one

Rejected. It makes determinism, lineage, policy review, sandboxing, and canonical proof much harder before an expressiveness ceiling is observed.

### Public generic CRUD, query plans, or provider APIs

Rejected. Domain Actions and released capabilities are the language. Acquisition and physical planning remain deep internals.

### Per-principal release compilation

Rejected. Meaning is compiled once; authority filters discovery and data at runtime. Otherwise identity and review fragment.

### Universal event sourcing

Rejected. Meaningful transitions and settled interactions are events; raw bytes, dense points, and projections are not forced into one log.

### Commit equals success

Rejected. DecisionReceipt proves local agency; Settlement records observed external reality; Unknown is first-class.

## 20. Risks and reopen triggers

| Risk | Mitigation now | Reopen trigger |
|---|---|---|
| Rust slows product learning | S0 kill gate; direct adapters; few crates | >1.35× slice time or roadmap becomes mostly channels/models |
| No semantic invariant actually needs Rust | Say so; keep constitution language-neutral | TS spike matches dense target and defect surface |
| DataFusion compile/API weight | pin v55; isolate one adapter; benchmark | cold CI >15 min, binary/RSS unacceptable, or two costly upgrades |
| DuckDB closes dense gap | benchmark Node Neo 1.5.5; do not assume FFI is slow | TS meets latency/memory target within 20% |
| Better Auth forces a second runtime | UDS, separate DB role, tiny code surface | stable Rust/OIDC boundary removes need, or UDS causes repeated incidents |
| Better Auth/MCP plugin churn | pin 1.7.x; conformance journey | two breaking auth migrations in six months |
| LLM providers change wire formats rapidly | direct private adapters, Zoen-owned model events | adapter maintenance exceeds 20% of engineering capacity |
| Channel SDKs are TS-first | HTTP adapters, raw evidence, narrow types | a required provider cannot be integrated safely in Rust on schedule |
| Inbound channel is weak human proof | agent delegation + step-up for human decisions | provider gains strong device-bound identity or product accepts a new assurance policy |
| One WorldHead becomes hot | dense batching, stable lock, metrics | >500 commits/s sustained or p95 head-lock wait >25 ms |
| One region limits institutional latency | causal primary reads and honest cut | regulated residency or p95 regional latency breaks product SLO |
| Evaluation process could see live secrets | separate runner credentials/databases/buckets | any credential-isolation journey fails; block all activation |
| Provider lacks sandbox | explicit missing attestation | capability is required for activation; obtain sandbox or do not ship it |
| Declarative IR is too weak | total typed core; builder proposes only valid source | three unrelated released capabilities require the same missing abstraction |
| Declarative IR becomes a language project | cap constructs; surface real examples first | compiler exceeds 20% of code or simple Actions need deep AST ceremony |
| Dynamic surface schemas hurt client ergonomics | stable kernel envelopes + generated facets | external API consumers demand compile-time release-specific SDKs |
| No unit tests lengthen feedback | small journeys, parallel realms, static gates | PR journey median >10 min; optimize harness, do not add mocked contracts |
| Tigris/object reads vary by region | immutable digests, range reads, telemetry | p95 dense scan dominated by object latency; add governed caching/projection |
| Release signing key becomes sole trust root | signer registry, rotation, approval separation | external portability/compliance requires KMS, Sigstore, or multi-signature |
| Node and Rust migration ownership drifts | schema roles, separate dirs, verify-schema gate | one component needs cross-schema writes; redesign rather than grant access |

## 21. Rationale

### Problem

Zoen must feel like one intimate relationship while behaving like a governed decision system. The non-obvious part is not HTTP or storage; it is keeping identity, meaning, truth, agency, attention, interaction, and external reality from impersonating one another while supporting personal and institutional scale. A Rust-first implementation adds a second runtime for Better Auth and pays an ecosystem tax, so it must prove that its type-state and native dense path create more leverage than they consume.

### Usage

A person speaks to Eve, opens the exact evidence in Living World, consents only to disclosed consequences, receives a DecisionReceipt, and later sees a separate honest Settlement. An operator uses released domain verbs in CLI. An agent discovers only authorized MCP capabilities. A builder compiles canonical meaning once, proves the exact bytes through real journeys, prepares one live World through its current cut, and activates atomically.

### Shape

The shape is one Rust process around two deep products—Ontology and Eve—with Better Auth isolated behind a private local Door boundary. Postgres closes every authority promise; Tigris and DataFusion specialize dense reality; Restate executes only Effects. Sealed realm references, closed result algebras, purpose-bound sessions, exact read sets, and capability-shaped interfaces make misuse harder. Canonical JSON keeps releases portable if Rust loses the implementation trial.

The public interface is deep: nine intention-shaped Ontology operations and three Eve operations hide policy, temporal truth, storage, retries, models, channels, and release evolution. Complexity remains exposed only where the person must decide: basis, gaps, uncertainty, consequence, stale state, external ambiguity, and release approval.

### Tradeoffs accepted

- We accept a supervised Node process in exchange for using Better Auth without reimplementing or reading through it.
- We accept slower Rust iteration in exchange for a measurable chance at stronger realm/state guarantees and a native dense engine; S0 prevents faith-based adoption.
- We accept one serialized commit point per World in exchange for a simple causal cut and atomic semantic transitions.
- We accept orphan immutable objects in exchange for never making object storage part of the authority transaction.
- We accept duplicate model spend after a crash in exchange for Eve-owned durability without abusing Restate.
- We accept a smaller declarative release language in exchange for deterministic proof, lineage, and security.
- We accept dynamic released CLI/API/MCP schemas in exchange for compiling meaning once rather than per audience.

### Alternatives

Strict TypeScript is fully viable and currently has the velocity/ecosystem advantage; it loses only if S0 demonstrates that Rust's sealed types and DataFusion path create material leverage. A split Rust kernel/TS Eve has attractive ecosystem alignment but leaks the central conversation-to-World loop across RPC. A TS server/Rust dense sidecar has good eventual economics but adds an unnecessary service before dense workloads prove the need.

### Open questions

- Does the actual team meet the “Rust-fluent” assumption behind the 1.35× S0 velocity ceiling?
- Which first provider offers a real sandbox with enough semantics to prove Unknown and reconciliation?
- Which human decisions, if any, may accept enrolled channel presence without Better Auth step-up?
- Can the first three real domains fit the total declarative IR without turning it into a general-purpose language?
- What single-World commit rate and dense query shape should define the institutional reference workload?
- Should ReleaseProof signatures remain deployment-local Ed25519, or must portable Worlds begin with an external trust root?

### Next implementation step

Run S0 against one frozen journey and publish the measurements before creating the production workspace; then delete the losing language spike and build S1 in the winner.

## 22. Official primary references checked at this baseline

- [Rust 1.98.0/1.98.1 releases](https://blog.rust-lang.org/releases/)
- [Axum 0.8](https://github.com/tokio-rs/axum)
- [SQLx 0.9 announcement and repository](https://github.com/transact-rs/sqlx/discussions/4271)
- [PostgreSQL 18 serializable transactions](https://www.postgresql.org/docs/18/sql-set-transaction.html)
- [Official MCP Rust SDK](https://rust.sdk.modelcontextprotocol.io/)
- [MCP Rust SDK releases](https://github.com/modelcontextprotocol/rust-sdk/releases)
- [Restate Rust SDK endpoint](https://docs.rs/restate-sdk/0.11.0/restate_sdk/endpoint/)
- [Apache DataFusion 55](https://datafusion.apache.org/download)
- [Apache Arrow Rust Parquet](https://arrow.apache.org/rust/parquet/)
- [Apache object_store](https://docs.rs/object_store/latest/object_store/)
- [DuckDB primary clients and Node Neo status](https://duckdb.org/docs/stable/clients/overview)
- [Better Auth PostgreSQL](https://better-auth.com/docs/adapters/postgresql)
- [Better Auth OAuth 2.1 provider](https://better-auth.com/docs/plugins/oauth-provider)
- [Better Auth MCP composition](https://better-auth.com/docs/plugins/mcp)
- [Node 24 LTS archive](https://nodejs.org/en/download/archive/v24)
- [React 19.2 releases](https://react.dev/versions)
- [Vite 8 releases](https://vite.dev/releases)
- [Tigris on Fly](https://www.fly.io/docs/tigris/)
- [Telegram webhook secret contract](https://core.telegram.org/bots/api#setwebhook)
- [Kapso webhook overview](https://docs.kapso.ai/docs/platform/webhooks/overview)
