# ADR 020: Live observation plane and exact Action capture

Status: Accepted target contract. Implementation deferred to S7.

## Context

Terminal-grade market, sensor, health, logistics, and operational feeds may deliver thousands or millions of updates between meaningful World changes. Creating one serializable `AuthorityCommit` per tick would make the per-World cut a throughput bottleneck, flood Watches and audit history, and still fail to describe provider gaps or conflation honestly.

Microbatching alone does not solve the product problem. A user needs to see new values before the next Parquet publication, while an Action needs an immutable and reviewable basis. Treating a transient stream as ordinary Frame truth would let a stale browser value, a lost sequence, or a revoked entitlement influence authority.

## Decision

Zoen adds a non-authoritative live observation plane behind `LiveObservationPort`.

`LiveFeedDefinition` is part of `WorldRelease`. It pins the semantic feed, signed connector artifact, selector and field schemas, normalization digest, provider ordering or conflation behavior, clocks, staleness policy, source-rights program, and periodic seal policy.

`LiveSubscription` is a short server-created lease. It binds realm, World, principal, purpose, release, selector, fields, entitlement revision, rights proof, and expiry. The gateway checks these inputs before subscribing and continuously while streaming. It narrows or closes a stream when any input changes. Provider credentials never cross the gateway.

Each `LiveObservationEnvelope` carries values plus `LiveObservationBasis`: connector and provider-session digests, sequence or gap state, provider and receipt clocks, entitlement revision, rights proof, freshness, and the last sealed `{cut, generation, manifest}`. Strict-sequence, partitioned-sequence, and latest-value feeds are different released contracts. Zoen does not claim an unconflated history for a latest-value source.

`WorldFrame.liveBasis` is always explicit:

- `sealed-only` means that the body is derived only from the authoritative `KnowledgeBasis` and exact read set.
- `live-overlay` means that the presentation includes transient observations whose bases remain separate from the sealed result.

Live observations do not alter the Frame's `KnowledgeBasis`, exact read set, sealed result digest, or explanation evidence. They are presentation-only. They cannot wake a Watch, enter model or retrieval context, create a Notice, become an export, feed a data flow, cross federation, open a Case, or create an authority envelope. There is no released exception that promotes raw live bytes; every durable or consequential consumer uses the admission path below.

The connector periodically seals a bounded sequence range:

1. Write an immutable raw transcript and normalization receipt.
2. Produce deterministic typed rows and immutable Parquet `SegmentPayload` values whose content identity excludes admission metadata.
3. Build a canonical manifest payload with sequence, gap, data-usage, schema, and quality evidence; its digest excludes the future commit and cut.
4. Verify every object and descriptor.
5. Use one `AuthorityCommit` to create separate `ManifestAdmission` and advance the complete `WorldHead`.

There is no AuthorityCommit per tick. Late, revised, or gap-filling updates create later immutable segments and manifests with provider revision evidence. Reconnect begins at an admitted manifest and then opens a new live subscription. An in-memory tick buffer is never replayed as truth.

An Action that uses a live value follows the capture path:

1. The gateway captures the exact provider observation, writes content-addressed raw and normalized bytes, and records an immutable local object-verification receipt.
2. Only the gateway decoder can construct sealed `StagedObservationCapture`, bound to that receipt, live basis, schema, and short expiry. It is not evidence authority and cannot satisfy an exact read.
3. A dedicated Ontology AuthorityCommit verifies only local immutable receipts and locked state: connector and release, sequence, market or device state, current sealed entitlement snapshot, data-usage decision and obligations, and released staleness. It performs no object-store, provider, or entitlement-service I/O.
4. That commit constructs `AdmittedObservationRef` and advances the complete head.
5. The Case opens against the resulting head and includes that admitted reference in `ExactReadSet`; the later Action revalidates it. Admission and consumption of a staged value are never collapsed into one Action commit.

An echoed client value, missing object, sequence gap, stale capture, changed entitlement, or unknown market state cannot authorize the Action.

## Consequences

- Zoen can deliver low-latency interfaces without weakening the per-World semantic clock.
- Parquet remains the durable dense history and engine-independent replay contract.
- Users see freshness, gap, and basis state instead of a falsely seamless stream.
- Actions incur a capture and admission boundary for live-dependent decisions.
- The live gateway becomes a latency-sensitive entitled system and needs separate capacity, provider-session, and denial journeys.

## Required journeys

1. Unconflated sequence, out-of-order update, duplicate, gap, and late repair.
2. Latest-value provider and Zoen conflation with no false history claim.
3. Entitlement, purpose, field, geography, relationship, and release revocation during an open stream.
4. Gateway crash and reconnect from the last admitted manifest.
5. Seal publication, concurrent compaction, old-cut replay, and exact logical-result equivalence.
6. Action capture before and after the staleness boundary, entitlement change, market halt, and sequence gap.
7. Browser or model value tampering cannot change the capture digest or admitted Action basis; staged, expired, and raw-live values fail every non-presentation boundary.

## Reopen triggers

- A required provider protocol cannot meet its latency or ordering objective through the current gateway. Add a replaceable adapter or live-feed cell behind `LiveObservationPort`. Do not move tick truth into PostgreSQL authority.
- The seal cadence misses historical availability objectives. Tune batch, object, and publication bounds while preserving immutable manifests.
- A product requires disconnected live operation. Run a separate edge World and later federate its evidence. Do not create a second writer for the same World.
- No trigger permits a transient observation to become an authoritative Action dependency without immutable capture and admission.
