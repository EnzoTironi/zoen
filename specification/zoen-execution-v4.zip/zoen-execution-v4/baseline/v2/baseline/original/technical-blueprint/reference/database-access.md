# Database access

## Status

- Decision date: 2026-09-04
- Evidence checked: 2026-09-04
- Decision: use raw `pg` for authority transactions
- Identity decision: use Better Auth's official PostgreSQL adapter in isolated `door` schema and role
- Eve decision: allow the Workflow Postgres package's internal Drizzle/Graphile implementation only in a separate `eve_workflow` database and role
- Revisit status: Kysely may enter later for read models only

## Decision

Ontology uses `pg` directly at every authority write boundary. Handwritten SQL migrations define the database. Runtime schemas validate returned rows before domain code receives them.

Better Auth uses its official PostgreSQL adapter and a dedicated `pg.Pool`. Better Auth owns only the `door` schema. A Session Door maps the authenticated Better Auth subject to a Zoen `PrincipalId`; Better Auth roles never authorize a World Action.

Eve's exact-pinned `@workflow/world-postgres` implementation uses Drizzle and Graphile Worker internally. That is accepted third-party operational machinery only inside the separate `eve_workflow` database. Eve receives no Ontology database role and reaches released semantic operations through the authenticated loopback client in ADR 029. Neither third-party adapter becomes a schema model for Ontology.

Zoen does not use an ORM or query builder inside `AuthorityCommit`. Kysely may support read-only projections after evidence shows that it removes repeated mapping defects without hiding authorization or transaction behavior.

## Why the database owns authority

TypeScript types constrain one process and one compilation. They cannot stop two requests, two Machines, a maintenance client, or a failed retry from violating a shared invariant.

PostgreSQL enforces the shared rules with:

- serializable transactions;
- foreign keys, checks, unique constraints, exclusion constraints, and deferred constraints;
- row locks and transaction-level advisory locks;
- compare-and-set updates on the expected World revision;
- row-level security with default denial;
- immutable event and settlement rows;
- one transaction for the World change, domain events, effect intents, and outbox records.

TypeScript remains useful. Opaque IDs, closed unions, and a capability-scoped transaction API make invalid code harder to write. The database rejects invalid concurrent outcomes.

## `AuthorityCommit` contract

Only the authority module constructs an `AuthorityTx`. Callers submit an intention and receive a closed result. They do not receive a `PoolClient`.

```ts
declare const authorityTxBrand: unique symbol;

export interface AuthorityContext {
	readonly requestId: RequestId;
	readonly principalId: PrincipalId;
	readonly worldId: WorldId;
	readonly expectedHead: WorldHeadId;
}

export interface AuthorityTx {
	readonly [authorityTxBrand]: true;
}

export type AuthorityCommitResult<T> =
	| { readonly kind: "committed"; readonly value: T; readonly head: WorldHeadId }
	| { readonly kind: "head-conflict"; readonly current: WorldHeadId }
	| { readonly kind: "denied"; readonly reason: DenialCode }
	| { readonly kind: "rejected"; readonly errors: readonly DomainError[] }
	| { readonly kind: "unavailable"; readonly retryable: boolean };

export function authorityCommit<T>(
	context: AuthorityContext,
	command: AuthorityCommand<T>,
): Promise<AuthorityCommitResult<T>>;
```

The implementation performs one bounded sequence:

1. Check out one `PoolClient`.
2. Start `BEGIN ISOLATION LEVEL SERIALIZABLE READ WRITE`.
3. Set transaction-local principal, World, request, and release values used by RLS and audit functions.
4. Lock the current World head row. Acquire a transaction-level advisory lock only when one invariant spans rows that have no safe lock row.
5. Compare the current head with `expectedHead`.
6. Evaluate disclosure, authority, quorum, domain preconditions, and the released schema.
7. Insert immutable domain records, event records, `EffectIntent` rows, and outbox rows.
8. Advance the World head with an expected-revision condition.
9. Commit.
10. Roll back and release the same client on every error path.

The transaction wrapper retries SQLSTATE `40001` and `40P01` a bounded number of times with jitter. The wrapper retries the complete command, not individual statements. Code inside the transaction cannot call an external provider. External work starts from the committed outbox.

The TypeScript brand prevents accidental construction through ordinary typed code. It does not create a security boundary. Package exports, dependency rules, code review, and database privileges prevent adapters from reaching the raw client.

## Connection and role boundaries

Each duty uses a distinct role and pool:

| Role | Access | Forbidden access |
|---|---|---|
| `zoen_ontology` | Ontology tables through RLS and approved functions | Better Auth internals, DDL, `BYPASSRLS` |
| `zoen_door` | Better Auth `door` schema | Ontology tables, Parquet manifests, effect settlement tables |
| `zoen_eve_workflow` | Workflow tables, Graphile queue, hooks and streams in dedicated `eve_workflow` database | every Ontology and Better Auth table |
| `zoen_eve_ingress` | Eve-owned channel ingress, delivery outbox and adapter coordination namespaces | Workflow migrations, Ontology tables and Better Auth internals |
| `zoen_effect` | Effect attempts, settlements, and required intent reads | World mutation outside the settlement contract |
| `zoen_migrate` | Ordered DDL during deployment | Runtime login |

Application roles do not own their tables and do not receive `BYPASSRLS`. Tables with principal or World disclosure rules use `ENABLE ROW LEVEL SECURITY` and `FORCE ROW LEVEL SECURITY`. Policies fail closed when required transaction-local context is absent.

Use direct TLS connections for migrations, serializable commits, advisory locks, and `LISTEN`. Do not route them through transaction pooling. A read-only pool may use a pooled endpoint only after session-context and failover journeys pass.

## Better Auth isolation

Better Auth receives a dedicated `pg.Pool` whose role can access only the `door` schema. Set its `search_path` explicitly. Better Auth migration generation cannot change Ontology or Eve tables.

The Session Door performs this boundary:

1. Better Auth validates the browser session, OAuth token, or device session.
2. The Door reads the stable Better Auth subject.
3. The Door resolves the subject to a Zoen `PrincipalId` through an explicit mapping.
4. Ontology opens its own transaction with the principal context.
5. PostgreSQL RLS and domain authority decide access.

Better Auth's adapter uses Kysely internally. That implementation detail does not require Zoen to use Kysely.

The Eve Workflow package's Drizzle schema and Graphile Worker migrations run only with an Eve-store bootstrap role against the dedicated database. Runtime startup rejects a Workflow URL that resolves to the Ontology database or role. Its internal ORM does not relax the explicit-SQL requirement for any authority or Zoen-owned operational schema.

## SQL and row validation

Use parameterized `pg` queries only. Do not concatenate identifiers or values from request data. A small set of audited helpers may quote static identifiers used by migrations or released projection builders.

Each query module owns:

- the SQL text;
- the parameter type;
- the runtime schema for each returned row;
- the mapping from the database row to a domain type;
- the expected cardinality;
- the allowed transaction capability.

A returned row is `unknown` until the runtime schema parses it. Type assertions do not replace parsing. Released dynamic data uses its released JSON Schema validator; fixed application rows use the fixed runtime validation library.

## Migration contract

Handwritten, forward-only SQL files are the source of truth. A small migration command records each filename, checksum, application time, and deployment identity in a migration table.

The migration command:

1. Connects with the migration role over a direct connection.
2. Acquires one transaction-level or session-level advisory migration lock, as required by the migration form.
3. Refuses a changed checksum for an applied migration.
4. Runs transactional DDL in one transaction.
5. Isolates PostgreSQL operations that cannot run inside a transaction.
6. records the migration only after the operation succeeds.

Development data is disposable, but the checked-in chain and setup command remain deterministic. Baseline consolidation is a coordinated change, not an incidental edit.

## Option assessment

| Option | Relevant support | Cost at the authority boundary | Decision |
|---|---|---|---|
| `pg` 8.23.0 | Explicit checked-out client, transactions, parameters, notices, and SQLSTATE | No generated row types or migration framework | Adopt for authority and migrations |
| Drizzle ORM 0.45.2 and Drizzle Kit 0.31.10 | Serializable transaction configuration, RLS declarations, raw SQL, and custom migrations | Functions, triggers, advisory locks, deferred constraints, and retry behavior still require SQL; the ORM becomes a second schema description | Reject at launch |
| Kysely 0.29.5 | Serializable transactions, parameterized raw SQL, typed query construction, and PostgreSQL migration locks | Does not model RLS policy meaning; query result types still need runtime validation | Revisit for read-only projections only |
| Prisma Client 7.10.0 | Interactive serializable transactions and raw SQL | RLS, deferred constraints, exclusion constraints, triggers, and procedures live outside the Prisma schema; the inspected CLI `latest` tag pointed to an 8.0.0 release candidate | Reject for authority |
| MikroORM 7.1.15 | Serializable transactions, row locks, raw SQL, and transactional migrations | Unit of Work, identity map, implicit flush, and nested savepoints obscure the ordered authority transaction; no official Better Auth adapter | Reject for authority |

No option statically proves PostgreSQL policy behavior, lock order, legal concurrent history, or crash recovery. Real PostgreSQL journey tests provide that evidence.

## Adopt, reject, and revisit

### Adopt

- `pg` for `AuthorityCommit`, migrations, and effect settlement transactions.
- Handwritten SQL constraints, RLS policies, functions, triggers, and indexes.
- A capability-scoped transaction API that hides `PoolClient` from callers.
- Runtime parsing of every returned row at the query boundary.
- Better Auth's official PostgreSQL adapter with an isolated schema, role, and pool.
- Bounded whole-command retries for serialization failures and deadlocks.

### Reject

- An ORM entity model as the authority definition.
- ORM-generated migrations as the only database specification.
- Better Auth roles as World authorization.
- A shared application role with `BYPASSRLS`.
- External calls inside `AuthorityCommit`.
- `pool.query` for multi-statement transactions.
- Query result casts without runtime validation.
- Transaction pooling for serializable commits, session locks, migrations, or listeners.

### Revisit Kysely

Add Kysely only to a read-model package after all of these conditions hold:

1. Journey or production evidence shows repeated defects in handwritten projection joins or row mapping.
2. The package uses a read-only database role.
3. RLS remains active and the caller cannot inject policy context.
4. Runtime schemas continue to validate query results.
5. `AuthorityCommit`, migrations, effect settlement, and authentication remain outside the Kysely package.
6. Dependency rules prevent authority modules from importing the read-model builder.

### Revisit Drizzle

Reconsider Drizzle only if maintaining SQL plus runtime row schemas causes measured delivery or correctness problems across several releases. A spike must prove that Drizzle removes those defects without duplicating schema authority or weakening the exact transaction and migration contract.

## Required journeys

- Two concurrent commands against the same head yield one legal head advance and one deterministic conflict or retry result.
- A serialization failure reruns the whole pure command and does not duplicate events or effect intents.
- A deadlock retry preserves lock order and idempotency.
- Missing principal or World transaction context causes RLS denial.
- The Better Auth role cannot read or write Ontology tables.
- The Ontology role cannot read Better Auth credential tables.
- The Eve Workflow and ingress roles cannot connect to the Ontology or Door databases; the Ontology runtime cannot migrate Eve Workflow tables.
- Startup rejects `WORKFLOW_POSTGRES_URL` fallback or aliasing to the Ontology connection.
- A migration lock prevents concurrent migration runners.
- A changed checksum for an applied migration fails deployment.
- A process crash after commit but before response leaves one canonical commit and one outbox record.
- A process crash before commit leaves no domain event, intent, or head advance.
- Direct and pooled connection routes preserve their declared session behavior.

## Source ledger

All pages and package metadata were checked on 2026-09-04.

### PostgreSQL and `pg`

- [`pg` transactions](https://node-postgres.com/features/transactions). Inspected package version: 8.23.0, modified 2026-08-08.
- [PostgreSQL transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html).
- [PostgreSQL concurrency control](https://www.postgresql.org/docs/current/mvcc.html).
- [PostgreSQL explicit and advisory locking](https://www.postgresql.org/docs/current/explicit-locking.html).
- [PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).
- [PostgreSQL constraint definitions](https://www.postgresql.org/docs/current/ddl-constraints.html).

### Better Auth

- [Better Auth PostgreSQL adapter](https://better-auth.com/docs/adapters/postgresql). Inspected Better Auth version: 1.7.2, modified 2026-08-26.
- [Better Auth database concepts](https://better-auth.com/docs/concepts/database).
- [Better Auth Drizzle adapter](https://better-auth.com/docs/adapters/drizzle).
- [Better Auth Prisma adapter](https://better-auth.com/docs/adapters/prisma).

### Drizzle

- [Drizzle transactions](https://orm.drizzle.team/docs/transactions).
- [Drizzle row-level security](https://orm.drizzle.team/docs/rls).
- [Drizzle custom migrations](https://orm.drizzle.team/docs/kit-custom-migrations).
- Package versions inspected: `drizzle-orm` 0.45.2 and `drizzle-kit` 0.31.10.

### Kysely

- [Kysely transaction builder](https://kysely-org.github.io/kysely-apidoc/classes/TransactionBuilder.html).
- [Kysely parameterized SQL](https://kysely-org.github.io/kysely-apidoc/interfaces/Sql.html).
- [Kysely PostgreSQL adapter](https://kysely-org.github.io/kysely-apidoc/classes/PostgresAdapter.html).
- Package version inspected: 0.29.5, modified 2026-08-10, Node 22 or later.

### Prisma

- [Prisma transactions](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
- [Prisma introspection and unsupported database features](https://www.prisma.io/docs/orm/prisma-schema/introspection).
- [Prisma Migrate unsupported database features](https://docs.prisma.io/docs/orm/prisma-migrate/workflows/unsupported-database-features).
- Package metadata inspected: Prisma Client 7.10.0; the Prisma CLI `latest` tag pointed to 8.0.0-rc.13.

### MikroORM

- [MikroORM transactions and locking](https://mikro-orm.io/docs/transactions).
- [MikroORM migrations](https://mikro-orm.io/docs/migrations).
- [MikroORM query builder](https://mikro-orm.io/docs/query-builder).
- Package version inspected: 7.1.15, modified 2026-09-04, Node 22.17 or later.
