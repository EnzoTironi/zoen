# ADR 029: Eve Nitro runtime and isolated workflow store

Status: Accepted, production activation gated

## Context

`eve@0.52.0` is not a generic request handler that Zoen can mount inside Hono. Its supported self-hosted contract is `eve build` followed by `eve start`, which runs a generated Nitro Node service. Eve also requires both `/eve/` and `/.well-known/workflow/` route families. Its public package exports framework integrations for Next.js, Nuxt, and SvelteKit, but no stable Hono or generic Fetch server adapter. Importing `eve/internal/*`, copying generated handlers, or relying on an undocumented Nitro bootstrap would make Zoen own a permanent private fork at the most important conversational boundary.

Eve's sessions and turns are durable Workflows. In self-hosted development, the default Workflow world persists under `.eve/.workflow-data`. Eve supports selecting an installed Workflow world through `experimental.workflow.world`; the compatible line for this release is Workflow `5.0.0-beta`. The Postgres implementation is still explicitly a reference implementation, depends on Drizzle and Graphile Worker internally, and has an open startup-recovery report in which parked runs can be re-enqueued and duplicate jobs can accumulate. None of those implementation tables may share Ontology authority credentials or become a second semantic truth.

## Decision

Zoen remains one TypeScript deployable, one signed OCI image, one Fly application, and initially one steady-state Machine. That Machine runs two supervised Node 24 processes:

1. the **Zoen edge/authority process** runs Hono on public port `:8080`, a loopback-only Eve capability endpoint on `127.0.0.1:8081`, and the signed private Restate endpoint on `:9080`;
2. the **Eve process** runs the supported pinned `eve start` Nitro output on `127.0.0.1:4274`.

The Hono process is also the minimal supervisor: it starts the exact pinned Eve command without a shell and with an explicit environment allowlist, publishes readiness only after Eve health and all authority prerequisites pass, stops admission if either runtime becomes unhealthy, forwards termination, waits for bounded drain, and exits if Eve exits. Fly restarts the whole Machine; the bootstrap does not hide repeated crashes with an in-process restart loop. Kill journeys, not graceful shutdown, remain the correctness proof. Process separation prevents accidental import and credential injection; it is not hostile-code containment inside one container.

Hono is the only public socket. It reverse-proxies the complete `/eve/` and `/.well-known/workflow/` prefixes to loopback without rewriting their paths. The proxy preserves method, raw bytes, headers required by the downstream verifier, cookies, streaming, backpressure, cancellation, and response status. It imposes public size, decompression, deadline, and rate limits before the hop and never parses a provider body and then pretends the reconstructed bytes still satisfy its signature. A proxy alone does not prove channel durability; every provider route remains gated by ADR 027's journal-before-acknowledgement protocol.

Browser requests cross Door at Hono. Hono exchanges a valid Better Auth session for a short-lived, audience- and request-bound `EveIngressProof`; Eve's custom authenticator validates that proof and never treats it as World authority. Provider channels validate their own raw signed requests and resolve a verified channel binding through Door. Workflow callbacks retain Eve's supported route and authentication contract.

Eve's process environment and import graph contain no Ontology database role, object-store write credential, KMS release key, Restate endpoint credential, or authority repository. An Eve tool calls a narrow generated `EveOntologyClient` over the loopback capability endpoint. Each request carries a boot-scoped `EveServiceProof`, principal evidence, purpose, expected release/head basis, operation ID, deadline, and body digest. The Hono-side adapter validates the proof, opens a fresh `WorldSession`, and calls the ordinary Ontology application port. It returns the same closed protocol result used by public surfaces. Eve can inspect and propose; it cannot send an `AuthorityCommitEnvelope`, fabricate a receipt, or retain a standing World capability through supported code paths. A same-container RCE remains capable of attacking the sibling runtime, so this topology never claims a hard credential boundary.

Eve's official defaults are too broad for this product boundary: they include shell and file tools backed by a per-session sandbox, an app-runtime URL fetcher, provider-managed search, durable todo state, and root self-delegation. Omitted authored-tool approval is permissive, the default sandbox egress is `allow-all`, and `defaultBackend()` can silently fall through to `just-bash`, which supplies no network isolation. Zoen therefore disables `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `todo`, and `agent`; does not opt into `glob`, `grep`, `Workflow`, or `sleep`; retains only the no-executor `ask_question`; and exposes generated released `inspect_*`/`propose_*` tools with explicit approval policies. Conditional skill and connection tools are absent because no such resource is declared. CI verifies the effective Eve manifest, not merely the authored files.

Because Eve defines one sandbox for every agent even when no model-facing sandbox tool is exposed, launch config selects an explicit Zoen `DisabledEveSandboxBackend`. The public interface requires both phases: `prewarm()` is an idempotent no-op that accepts no bootstrap or seed material and returns its stable disabled marker; `create()` always rejects with a typed `sandbox-disabled` error. It never selects `defaultBackend()`, carries no optional sandbox runtime, performs no package auto-install, and has no storage or egress. Authored callbacks are statically forbidden from calling `ctx.getSandbox()`. Raw attachments do not enter Eve as byte-backed AI SDK file parts: the edge/channel integration rejects them or admits them through the governed evidence pipeline and sends only an authorized reference. This is a deliberate launch boundary, not a claim that a non-isolating sandbox is safe. Enabling any sandbox path requires a successor decision with an exact supported backend, resource topology, network policy, credential broker, persistence, deletion, and recovery proof.

The first production storage candidate is exact-pinned `eve@0.52.0` with exact-pinned `@workflow/world-postgres@5.0.0-beta.40`, selected through Eve's public `experimental.workflow.world` contract. It receives a dedicated `eve_workflow` PostgreSQL database and role, not merely a shared schema. `WORKFLOW_POSTGRES_URL` never falls back to Ontology's `DATABASE_URL`; a startup assertion rejects equal hosts/database/roles. `WORKFLOW_POSTGRES_JOB_PREFIX` is unique to the deployment. Drizzle, Graphile Worker, Workflow tables, hooks, queues, steps, and streams are third-party Eve operational internals. Their presence does not weaken the raw-`pg`/explicit-SQL rule for Ontology authority.

Eve's durable session event history is the conversation execution truth. `InteractionJournal` is the Eve-owned typed view/materialization of those stable session, turn, step, message, and attempt identifiers; it is not an independent scheduler or a second resumption log. `ChannelIngress` is a durable accepted-input ledger and outbox used to close the provider acknowledgement gap. A successful provider acknowledgement means “accepted durably for Eve,” not “the turn completed.” Delivery into Eve is idempotent by stable ingress identity; settled presentation is derived from Eve's durable events.

The local file world is allowed only for local development and disposable `EvaluationWorld` journeys. No production conversation route is enabled until the Postgres world passes all gates below. If the pinned upstream package fails, Zoen contributes the fix upstream or waits for a compatible release; it does not silently move conversation into Restate, Rivet, Redis, a local volume, or an unreviewed private fork.

## Production gates

- build and start the exact Eve output, then prove Hono proxying for ordinary HTTP, SSE, uploads, cookies, cancellation, both required route prefixes, and shutdown;
- prove Better Auth exchange, `EveIngressProof`, `EveServiceProof`, replay rejection, audience binding, expiry, key rotation, and complete denial of direct Eve authority access;
- kill before and after every Workflow step, parked wait, hook delivery, stream append, channel admission, and settled response; observe one valid continuation and no fabricated completion;
- reproduce the `@workflow/world-postgres` parked-run/startup corpus, restart repeatedly, and prove no parked replay, duplicate outstanding job, lost runnable work, or cross-deployment claim;
- prove at-least-once step semantics for every non-idempotent tool and force all external consequence through the ordinary Action/Effect protocol;
- inspect the generated Eve tool manifest and prove the exact launch allowlist; use adversarial content to request shell, file reads/writes, arbitrary fetch/search, generic delegation, Workflow, skills, connections, hidden tool names, and direct authority, and observe a closed capability error without network, sandbox creation, or authority change;
- prove every authored tool declares approval explicitly, every generated inspect/propose call is reauthorized server-side, no tool package imports ambient environment access, and the Eve child process receives only the reviewed environment allowlist;
- submit byte-backed web and channel attachments and prove they are rejected before session creation or converted through scanner, evidence admission, disclosure, and immutable reference without `ctx.getSandbox()`; assert `DisabledEveSandboxBackend.create` is never reached in an accepted launch journey;
- restore the isolated Eve database and channel-ingress ledger together to a sealed realm, reconcile session aliases and accepted inputs, and keep outbound delivery disabled until ambiguity is resolved;
- prove queue backpressure, retention, hook expiry, connection exhaustion, graceful close, hard kill, migration compatibility, observability redaction, and an upgrade from the prior exact Eve/Workflow pair;
- compare generated route and public export manifests on every Eve upgrade; an internal import or unexpected route drift blocks the image.

## Consequences

- The architecture gains one narrow serialization seam but follows Eve's actual supported runtime instead of inventing a mounting API.
- Door/Ontology and Eve receive separate allowlisted credential sets while remaining one deployable TypeScript application and one product grammar; this reduces accidental reach but does not contain hostile code inside the Machine.
- Hono owns public policy and routing; Nitro owns Eve routes and workflow entrypoints. Neither framework impersonates the other.
- A single Machine still fails as a unit. That is an honest pre-launch availability tradeoff, not evidence that Eve and Ontology share memory or credentials.
- Eve and its Workflow world are preview/beta dependencies at a critical boundary. Exact pins and destructive recovery journeys are release blockers, not optional hardening.
- The launch has no shell/file sandbox, arbitrary URL fetch, open-web search, or generic agent/workflow capability. That is the smallest secure product grammar; each future capability must be released and proved independently.

## Reopen triggers

- Eve publishes a stable generic Fetch/Hono server adapter with route, schedule, Workflow, streaming, and shutdown parity. A one-process topology may be reconsidered only after the identical journey corpus passes without internal imports.
- A threat model requires an Eve compromise to be unable to attack Ontology memory, loopback, or credentials. Move Eve to a separately isolated Machine/process group behind the same signed protocol before making that claim.
- Eve's Postgres world cannot pass the recovery gates within the launch window. Production conversation remains blocked while Zoen evaluates an upstream-compatible world implementation through Eve's public contract; no other product acquires conversation durability.
- A released journey needs sandboxed computation or byte-backed attachments. Choose and pin an actual supported isolation backend and prove deny-by-default egress, secret brokering, persistence, deletion, crash recovery, and tenant separation before removing the disabled backend.
- Independent scaling, contractual credential isolation, or availability objectives require separate Machines. Preserve the same proxy and capability contracts; do not turn them into a second public API.
- Eve changes its route families, workflow protocol line, or storage contract. Upgrade the exact pair in an `EvaluationWorld`, regenerate evidence, and issue a successor ADR before production activation.
