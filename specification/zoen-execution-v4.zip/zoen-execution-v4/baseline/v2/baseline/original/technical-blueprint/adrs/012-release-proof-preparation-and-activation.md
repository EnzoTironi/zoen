# ADR 012: Release proof, preparation, and atomic activation

Status: Accepted

## Context

A valid release document is not yet safe to activate. The exact interpreter and trusted handlers must be built before evaluation; otherwise a proof can describe code that is not what production runs. Activation must also fail if the World changes between review and commit, including changes to dense evidence or the audit chain.

Proof, deployment provenance, human approval, and activation therefore need one digest-linked protocol.

## Decision

Four immutable artifacts and one local readiness set define release evolution:

1. `WorldRelease`: canonical bytes and `releaseDigest` from ADR 010.
2. `ZoenArtifact`: an `ArtifactPayload` whose kind-indexed digest pins OCI image, source revision, Node runtime, lockfile, interpreter, and trusted-handler registry. Signatures, evaluations, and trust are separate `ArtifactSignature`, `ArtifactEvaluation`, and `ArtifactTrustBundle` records; none changes artifact identity.
3. `ReleaseProof`: evaluation evidence for one release digest, one artifact digest, one database-schema digest, and one base `WorldHead`.
4. `PreparedActivation`: the exact compare-and-swap proposal that may be committed.
5. `ActivationReadinessSet`: local, immutable receipts proving every external prerequisite already completed.

The order is mandatory:

1. Pass static constitution gates, then normalize, validate, canonicalize, hash, and immutably store the release.
2. Build the OCI image exactly once from the committed source and lockfile. Resolve its registry digest and SBOM before evaluation.
3. Create an isolated EvaluationWorld and run the release with that exact artifact and trusted handler registry.
4. Produce canonical evidence: database-schema digest, compiler and evaluator versions, journey-suite and replay-corpus digests, seeded journey results, schema and policy validation, migration result, denial cases, resource budgets, deterministic replay results, model and connector transcripts where applicable, known limitations, present attestations, and explicitly missing sandboxes.
5. Create an in-toto-style attestation, sign its DSSE envelope with a managed non-exportable signer, and attach Cosign provenance linking source, lockfile, image, release, evaluator, and evidence digests.
6. Store proof bytes immutably. An unsigned report is not a `ReleaseProof`.
7. Deploy the same image digest and run deployment smoke journeys. Rebuilding invalidates the proof.
8. Mirror required trust roots and revocation epochs locally; verify proof signatures, artifact and release bytes, registry availability, manifest objects, migrations/reprojections, invariant results, and required attestations outside the activation transaction. Store digest-bound, expiring readiness receipts.
9. Create `PreparedActivation` against a live World's current head, obtain its separate human or governed `Approval`, and activate.

`PreparedActivation` contains realm, World, digest and complete value of the expected `WorldHead` including its audit root and observation manifest, source release and generation digests, target release digest, target data-generation digest, target observation-manifest digest, `readyThroughCut`, proof digest, artifact payload digest, trust-bundle digest and epoch, readiness-set digest, migration or reprojection digest, invariant-results digest, optional World-evaluation attestation, preparer, expiry, and its own canonical preparation digest. Even when dense data is unchanged, the target manifest is present and equals the expected manifest. Preparation stages non-authoritative output and catches up only from committed AuthorityCommit envelopes. If writes outrun catch-up, a short explicit per-World write fence is the fallback; human ambiguity creates a governed Case and leaves preparation blocked.

The activation `Approval` binds World, proof digest, preparation digest, purpose, approver, Ontology-issued `DecisionContinuation` where required, and expiry.

An agent or Eve may author, critique, evaluate, and prepare a release. It cannot mint Approval, consume another principal's `DecisionContinuation`, or call activation with channel presence alone.

Activation is one AuthorityCommit. Under the World lock it:

- compares the complete current head with the complete expected head;
- locks and verifies unexpired local readiness receipts, local trust/revocation epoch, proof, scope, artifact and release digests, target manifest, generation, invariant results, and required attestations;
- requires `readyThroughCut` to equal the locked pre-activation cut;
- re-evaluates activation authorization and consumes the bound `DecisionContinuation`;
- applies only the proved closed-IR migration;
- writes the release change, proof and artifact references, commit envelope, and outbox;
- advances the complete `WorldHead` and audit root once.

The activation transaction performs no registry lookup, signature-service call, object-store read, provider call, model call, or other network I/O. It trusts only locked, digest-bound local receipts whose epochs and expiries still match local mirrors. Any mismatch rejects activation. The operator must refresh readiness, prepare and prove again, or explicitly prepare against the new head. Production runs the same OCI digest named by the proof. There are no feature flags that silently change World meaning. Returning to an older release is a new prepared and proved activation, not an in-place rollback.

## Consequences

- The build that was evaluated is the build that may execute the release.
- Review cannot race a changed release, manifest, sparse generation, or audit history.
- Release delivery is slower and stores more evidence, but every activation has a complete chain of custody.
- Emergency evolution still needs a signed proof. Its evidence plan may be smaller only if an explicit trust policy defines and records that limitation.

## Reopen triggers

- Proof production misses its service objective for twenty releases. Reuse content-addressed evidence whose full input digests match; do not change proof order.
- A signer or registry trust root rotates or is compromised. Version the trust policy, revoke affected proofs, and re-attest before activation.
- A release depends on a provider behavior that cannot be reproduced in evaluation. Mark that behavior unproved and require a bounded post-activation canary with an explicit stop rule.
- Multi-cell deployment needs several artifact digests. Define a signed artifact set and compatibility proof before allowing activation.
- No trigger permits evaluating source and building a different production image afterward.
