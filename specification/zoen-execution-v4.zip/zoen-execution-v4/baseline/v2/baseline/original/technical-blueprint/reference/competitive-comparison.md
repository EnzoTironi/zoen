# Competitive comparison

## Scope and evidence labels

This reference compares the proposed Zoen constitution with the public product contracts of Palantir Ontology, Palantir AIP, and Bloomberg Professional Services. It does not compare private implementations.

The Zoen column describes a target unless a source says otherwise. The governed-data specification records major implementation gaps as of 2026-09-02. The greenfield synthesis is newer and proposes a product model. Neither document proves shipped behavior.

The comparison uses four labels:

- **Verified** means that a first-party public source or a local normative document supports the statement.
- **Zoen Target** means that the Zoen constitution requires the capability, but the comparison does not claim that it exists in the product.
- **Inference** means that the conclusion follows from verified facts but is not a published product contract.
- **Unknown** means that public sources do not expose enough detail to make the claim.

Vendor scale counts and outcome claims are self-reported. They show product intent and commercial scope, not independent benchmark results.

Delivery status uses a separate four-part classification:

- **Shipped foundation** requires running code and a named end-to-end journey against the release candidate. This comparison assigns no competitive category to that class.
- **Target protocol** names the contract Zoen must build. It is not a delivery claim.
- **Unproven product** means that product quality, operations, latency, reliability, scale, or adoption lacks evidence.
- **Moat** means data rights, content, counterparties, a professional network, support, or accumulated deployment knowledge that software types cannot supply.

[Ambition audit](ambition-audit.md) contains the adversarial capability audit behind this comparison.

## Executive comparison

Zoen combines two established product models. Palantir provides the closest public reference for an operational ontology that joins data, logic, Actions, security, applications, data integration, compute, and agents. Bloomberg provides the closest reference for finance identity, licensed data, live feeds, analytics, execution, and professional collaboration.

Zoen does not match either product today. The constitution targets typed modeling, governed Actions, permission-scoped interfaces, dense-series separation, temporal evidence, and causal explanation. Palantir remains far ahead in application builders, agent operations, branching, deployment, and production evidence. Bloomberg remains far ahead in data, news, analytics, execution connectivity, and its professional network.

Zoen's target differs in how it divides authority. Conversation, meaning, identity resolution, belief, agency, attention, live observations, and external settlement cannot impersonate one another. That division is more specific than a claim to have an ontology or an AI assistant. It becomes valuable only when product journeys prove it.

After adding target protocols for live observations and installable connectors, the audit found no known constitutional blocker to the public categories below. That is the strongest supported claim. It is not shipped parity, and a new workload can still falsify it.

## Capability matrix

| Capability | Palantir | Bloomberg | Zoen target | Delivery truth |
|---|---|---|---|---|
| Ontology, interfaces, object sets, functions, and subscriptions | **Verified.** Ontology models objects, properties, links, interfaces, Actions, functions, object sets, security, and applications. OSDK exposes real-time object-set subscriptions. [Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview), [Functions](https://www.palantir.com/docs/foundry/functions/overview), [OSDK subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions) | **Verified.** Data License Plus publishes a managed model across entities, securities, markets, and prices. BLPAPI services publish operation and message schemas. [Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/), [BLPAPI](https://bloomberg.github.io/blpapi-docs/) **Unknown.** Public sources do not expose Bloomberg's full internal model. | **Zoen Target.** `WorldRelease`, temporal identity and links, released interfaces, `ObjectSetPlan`, typed `FunctionDefinition`, and basis-bound subscriptions. | **Target protocol. Unproven product.** Zoen has no modeling workbench, mature set algebra, function fleet, index, or subscription service. |
| Actions and governance | **Verified.** Actions can change several objects, properties, and links in one transaction and can run across applications. Branches, proposals, review, rebase, conflict resolution, and merge checks govern ontology change. [Actions](https://www.palantir.com/docs/foundry/action-types/overview/), [branching](https://www.palantir.com/docs/foundry/ontologies/branching-ontology/) | **Verified.** Bloomberg connects trading, order management, automation, audit, and post-trade work. **Unknown.** Public sources do not describe a generic customer-authored action ontology. [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/), [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/) | **Zoen Target.** `ActionCase`, authorized Case views, contributions, one `DecisionReceipt`, `EffectIntent`, and a separate `Settlement`. | **Target protocol. Unproven product.** The design is more explicit about deliberation and external uncertainty. No evidence shows that it is complete or better. |
| Data connection and pipelines | **Verified.** Data Connection handles batch, incremental, CDC, media, streaming, and virtual sources. Pipeline Builder adds typed transforms, schema and output checks, version control, Spark, Flink, DataFusion, and external compute. [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview), [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview) | **Verified.** Data License supports REST, SFTP, and cloud delivery. B-PIPE and event feeds provide streaming inputs. [Data License](https://professional.bloomberg.com/products/data/data-license/), [B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/), [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/) | **Zoen Target.** `ConnectorArtifact`, `DatasetVersion`, `DataFlowDefinition`, `DataFlowRun`, `QualityGateResult`, and `LineageEdge`. | **Target protocol. Unproven product.** A provider adapter and Parquet writer are not a data-integration platform. |
| Provenance, temporality, and rights | **Verified.** Foundry documents lineage, edit and Action history, audit controls, dataset transactions, branches, and separate resource and object-data permissions. [Object permissioning](https://www.palantir.com/docs/foundry/object-permissioning/overview/), [connecting to data](https://www.palantir.com/docs/foundry/data-integration/connecting-to-data) **Unknown.** Public documents do not define one rival-evidence or bitemporal contract for every value. | **Verified.** Data License Plus traces records to source files. BLPAPI binds authorized identities to service entitlements. Bloomberg sells point-in-time data. [Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/), [BLPAPI `Identity`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.3/classBloombergLP_1_1blpapi_1_1Identity.html), [point-in-time data](https://professional.bloomberg.com/products/data/enterprise-catalog/cofi/) | **Zoen Target.** Raw artifacts, several clocks, rival evidence, `KnowledgeBasisDefinition`, direct and derived rights decisions, obligations, and receipts. | **Target protocol. Unproven product.** The structure differs from the public vendor contracts. Zoen remains behind both vendors' delivered controls and data operations. Contractual rights are a **Moat**. |
| Time series and live market data | **Verified.** Palantir stores time-series metadata on objects and indexes values in separate dataset-backed or stream-backed syncs. Streaming pipelines run continuously. [Time series](https://www.palantir.com/docs/foundry/time-series/time-series-overview), [streaming pipelines](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview) | **Verified.** B-PIPE provides normalized, unconflated real-time data, market depth, cloud and installed delivery, and centralized entitlements. BLPAPI exposes identity-bound subscriptions and asynchronous events. [B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/), [BLPAPI `Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html) | **Zoen Target.** `LiveFeedDefinition`, `LiveSubscription`, `LiveObservationEnvelope`, `LiveObservationBasis`, and `CapturedObservationRef` handle the live plane. Immutable Parquet manifests hold sealed history. | **Target protocol. Unproven product.** The earlier microbatch-only plan was a real ceiling. Feed content, exchange rights, latency, and operations remain Bloomberg **Moats**. |
| Compute, analytics, and notebooks | **Verified.** Foundry has object analytics, SQL, time series, notebooks, models, batch and stream compute, Compute Modules, and code workspaces. [Ontology applications](https://www.palantir.com/docs/foundry/ontology/applications), [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview), [developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview) | **Verified.** BQuant provides entitled data, notebooks, managed compute, scheduled jobs, and published Launchpad applications. [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/) | **Zoen Target.** `AnalyticsPlan`, `NotebookArtifact`, `ExecutorArtifact`, `DatasetGrant`, and `AnalysisRun` keep compute outside authority and bind exact inputs and rights. | **Target protocol. Unproven product.** DuckDB and Parquet are useful foundation choices, not counterparts to Foundry analytics or BQuant. |
| Models, retrieval, and headless agents | **Verified.** AIP provides model access, agents, logic, evals, Automate, Ontology tools, and both builder and consumer MCP routes. [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features), [developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview) | **Verified.** ASKB coordinates cited research over Bloomberg data, news, research, documents, and analytics. It can expose BQL used for analysis. [AI on Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/ai) | **Zoen Target.** `ModelProfile`, `RetrievalPlan`, `AgentDefinition`, `AgentRun`, `EvalSuite`, and one generated API, CLI, and MCP catalog. Eve is one client, not the only agent runtime. | **Target protocol. Unproven product.** Zoen has no managed model service, agent builder, retrieval operations, or eval program at vendor breadth. |
| Workspace, charts, and dynamic applications | **Verified.** Workshop, Slate, Quiver, Object Explorer, OSDK applications, and Pilot cover no-code, low-code, generated, and code-based work. [Ontology applications](https://www.palantir.com/docs/foundry/ontology/applications), [Workshop](https://www.palantir.com/docs/foundry/workshop/overview), [Pilot](https://www.palantir.com/docs/foundry/pilot/overview) | **Verified.** Terminal joins dense commands, Launchpad, charts, alerts, Excel, analysis, news, and execution. BQuant can publish interactive applications. [Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/), [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/) | **Zoen Target.** `WorkspaceDocument`, `ChartDocument`, `RepresentationProof`, the standard renderer, and `MiniAppArtifact` through MCP Apps. Rivet may generate or run an app but does not own its protocol. | **Target protocol. Unproven product.** Zoen has no full builder, dense professional workspace, or demonstrated chart grammar. |
| Governed conversation and channels | **Verified.** Chatbot Studio and AIP Threads use Ontology data, documents, tools, and governed Actions. [Chatbot Studio](https://www.palantir.com/docs/foundry/chatbot-studio/overview), [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features) | **Verified.** Instant Bloomberg has persistent rooms, structured security links, surveillance, chatbots, and workflow integration. ASKB adds cited research. [Instant Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/instant-bloomberg/), [AI on Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/ai) | **Zoen Target.** Eve owns continuity, attention, wording, current disclosure, and delivery. Launch channels are web, WhatsApp through Kapso, native Eve Telegram, and email. | **Target protocol. Unproven product.** Zoen has no delivered conversational parity or professional network. |
| Developer platform | **Verified.** Palantir combines multi-language OSDK, APIs, IDEs, MCP, custom endpoints, code workspaces, Compute Modules, and application deployment. [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview) | **Verified.** BLPAPI supports several languages and publishes service schemas, requests, messages, subscriptions, correlation, and events. Bloomberg also exposes data and workflow APIs. [BLPAPI](https://bloomberg.github.io/blpapi-docs/), [Terminal integration APIs](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/digital-transformation-solutions/) | **Zoen Target.** `SurfaceManifest`, generated clients, OAuth audiences, local test realms, trace inspection, conformance journeys, signed artifacts, and connector tooling. | **Target protocol. Unproven product.** One TypeScript implementation and a generated SDK do not equal either vendor's developer platform. |
| Marketplace and packaging | **Verified.** Foundry Marketplace packages versioned products with inputs, outputs, installation, upgrades, and recall. Foundry products add cross-enrollment portability and Apollo management. [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/), [Foundry products](https://www.palantir.com/docs/foundry/marketplace/foundry-products) | Bloomberg distributes data, analytics, integrations, and workflows through commercial products, but the sources reviewed do not publish an equivalent customer-authored resource marketplace. | **Zoen Target.** `PackArtifact`, `PackDependency`, `PackInstallationPlan`, and `PackInstallationReceipt` package released semantics and optional data, workflow, agent, connector, executor, or mini-app artifacts. | **Target protocol. Unproven product.** A package format is not a marketplace. Trust, distribution, commercial terms, builders, and adoption are product work. |
| Deployment, cells, offline use, and federation | **Verified.** Apollo manages products across cloud, on-premises, air-gapped, edge, connected, intermittent, and disconnected environments. Palantir also documents offline embedded Ontology applications. [Apollo environments](https://www.palantir.com/docs/apollo/core/environments), [offline embedded Ontology](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application) | Bloomberg documents installed, zero-footprint, cloud, and API delivery for market data. Public sources do not expose a general deployment platform comparable to Apollo. [Market data in the cloud](https://professional.bloomberg.com/products/data/data-connectivity/cloud-access/) | **Zoen Target.** Deployment profiles, cell bundles and attestations, epoch-bound authority leases, disconnected-operation policy, federation agreements, and basis-explicit `FederatedFrame`. | **Target protocol. Unproven product.** One Fly application is not fleet, edge, offline, or federation proof. Palantir's deployment history is a **Moat**. |
| OMS and EMS | Palantir Actions and operational applications can model order workflows, but the reviewed public Foundry sources do not establish Bloomberg-class liquidity, market connectivity, or an OMS product. | **Verified.** Bloomberg EMS, AIM, and TOMS span multi-asset execution, broker and venue connectivity, automation, inventory, risk, allocations, compliance, middle-office, and post-trade work. [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/), [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/), [TOMS](https://professional.bloomberg.com/products/trading/order-management-system/toms/) | **Zoen Target.** Released order and portfolio semantics, order Cases and Actions, exact live snapshots, connector reconciliation, execution events, allocations, workflows, and honest Settlements. | **Target protocol. Unproven product.** A generic Action and Effect are insufficient. Liquidity, venue access, certification, latency, support, and counterparties are Bloomberg **Moats**. |
| Audience and user experience | **Verified.** Palantir serves builders, developers, analysts, compliance teams, operators, and frontline users through different applications. [Ontology applications](https://www.palantir.com/docs/foundry/ontology/applications) | **Verified.** Bloomberg focuses on financial professionals across Terminal, mobile, chat, data, research, risk, and execution. [Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/), [Professional app](https://professional.bloomberg.com/products/bloomberg-terminal/access/bloomberg-professional-app/) | **Zoen Target.** The same authority grammar is intended for a person, family, clinic, fund, or factory, with interfaces that disclose only what each person can use. | **Unproven product.** Zoen is behind both vendors in tested interfaces, training, support, accessibility evidence, and repeated use. |
| Defensibility | **Inference.** Palantir's accumulated customer models, integration library, deployment knowledge, regulated operations, support, and builder familiarity reinforce its product. | **Inference.** Bloomberg's licensed content, field and identifier systems, newsroom, liquidity, connectivity, support, and professional network reinforce its product. | **Inference from Zoen Target.** Longitudinal Eve relationships, reusable packs, preserved evidence, governed decisions, and honest outcomes might accumulate value. | **Moat, not protocol.** Zoen has a design, not a defense. The assets and repeated use must be earned. |

## OAG correction

Palantir's first-party documentation uses the phrase "Ontology-augmented generation." The page describes retrieval methods over Ontology objects and functions. It covers chunk objects, embeddings, keyword search, HyDE, query augmentation, and hybrid search. The page says that no single method is best. It recommends starting without search when the full context fits in the model input. [Ontology-augmented generation](https://www.palantir.com/docs/foundry/ontology/ontology-augmented-generation)

The source supports these statements:

- **Verified.** Ontology-augmented generation is a documented Palantir retrieval approach.
- **Verified.** AIP agents can use Ontology data, functions, tools, and Actions under platform permissions.
- **Inference.** The important advantage is the shared object and Action contract, not the acronym.
- **Unknown.** Public sources do not define OAG as a separate engine, protocol, accuracy guarantee, or private reasoning architecture.

Zoen's nearest target is broader than retrieval. An authorized `WorldFrame` pins evidence, rights, time, release, and exact dependencies. A consequential continuation leaves conversation and enters a governed `ActionCase`. That is a design difference, not a measured quality result.

## Honest gaps

### Zoen is a proposal

The 2026-09-02 implementation snapshot says that `WorldRelease` was not integrated into the kernel. It also records missing type assignments, target-type link validation, pre-scan authorization, native series queries, inbound Ontology MCP, `KnowledgeBasisDefinition`, `ObjectSetPlan`, `ObjectView`, and field-level data entitlements. [Implementation gaps](/Users/enzotironi/Code/OS/docs/product/zoen-governed-data-extension-spec.md:1427)

The greenfield synthesis expands the target with `Focus`, `WorldFrame`, `ActionCase`, `Watch`, `Notice`, `Settlement`, `EvaluationWorld`, release proof, and per-World preparation. None of those additions is a delivery claim.

The ambition audit adds live observations, isolated connectors, governed data flows, a complete rights algebra, cells, federation, workspace and chart documents, headless agents, a developer platform, OMS and EMS semantics, and pack installation. Those are target protocols, not corrections to the implementation snapshot.

### Palantir has the broadest comparable product

Zoen has no delivered counterpart to Palantir's data connections, Pipeline Builder, lineage and quality operations, time-series and streaming systems, functions, Compute Modules, code workspaces, ontology management, branching, object applications, Workshop, Slate, Quiver, AIP Logic, Chatbot Studio, Evals, Automate, Pilot, OSDK, MCP, Marketplace, or Apollo deployment.

Palantir's breadth does not prove every internal guarantee that Zoen specifies. Public sources do not expose Palantir's exact transaction isolation, universal temporal model, external Settlement semantics, or private runtime architecture.

### Bloomberg owns the finance gap

Zoen has no comparable B-PIPE feed, BLPAPI certification, entitlement operation, event feed, licensed data catalog, news operation, professional network, exchange and broker connectivity, EMS, OMS, portfolio and risk suite, research distribution, or execution footprint. A finance pack can model parts of these products. It cannot replace their data rights, history, counterparties, latency, support, or operations.

Bloomberg's public material does not expose a customer-authored operational ontology like Palantir's. It also does not establish a universal cell-level evidence model. Those unknowns do not reduce Bloomberg's practical lead in finance.

### Product proof matters more than architecture prose

Zoen must prove denial behavior, derived rights, live-feed gaps and resync, stale snapshots, rival evidence, connector isolation and revocation, failed quality gates, realm isolation, split-brain cell denial, federated partial failure, effect uncertainty, order reconciliation, release preparation, and cross-interface identity through real journeys. Until then, the constitution describes intended behavior.

### The audit found no known constitutional blocker

The microbatch-only observation design and image-compiled connector design were blockers. The live observation and `ConnectorArtifact` target protocols remove those blockers on paper.

After adding the remaining target protocols, the audit found no public Palantir or Bloomberg category that requires hidden authority, mutable evidence, false settlement, or an unbounded cross-cell transaction. That is a conditional architecture result. It is not evidence that the protocols work, that the product matches either vendor, or that Zoen can reproduce vendor Moats.

## Five structural differentiators

### 1. Evidence remains separate from belief

Zoen keeps supporting and rival evidence. A named knowledge basis selects a view without deleting alternatives. The resulting `ResolutionDecision` remains a derived record unless a governed Action commits a reference to it.

### 2. Continuity carries no authority

`Focus` remembers the subject, lens, time intent, and opaque references. It contains no membership grant, token, delegation, visible evidence selection, or other authority. Each use requires a fresh Door proof and purpose-bound World grant.

### 3. Deliberation is an authority object

One `ActionCase` owns the exact intent, dependencies, policy, consequences, rule, and expiry. Each principal receives a different authorized view. A `DecisionHandle` exists only when that view reveals enough information for the decision. Each contribution records what the principal saw.

### 4. Material change and interruption have different owners

Ontology decides whether a semantic change deserves a `Notice`. Eve decides whether to stay silent, merge, defer, choose a channel, or interrupt the person. Eve stores a reference and reopens disclosure before composition, so delayed attention cannot outlive permission.

### 5. Local commitment cannot claim external success

A `DecisionReceipt` proves a local World change. An external system owns its outcome. Zoen records only `Observed<ReleasedDomainOutcome>` or `Unknown` in a separate `Settlement`. A timeout does not become success or failure. A non-idempotent effect must reconcile before another attempt.

## Primary sources

### Zoen

- [Greenfield product synthesis](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/synthesis.md:1)
- [Governed-data specification](/Users/enzotironi/Code/OS/docs/product/zoen-governed-data-extension-spec.md:1)
- [Earlier final architecture](/Users/enzotironi/Code/OS/docs/product/zoen-final-architecture.md:1)
- [OpenBB, Bloomberg, Palantir, and Zoen research source](/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/report-source.md:1)
- [Palantir and Zoen gap audit](/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/subagent-reports/03-palantir-zoen-gap-audit.md:1)
- [Ambition audit](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/ambition-audit.md:1)

### Palantir

- [The Ontology system](https://www.palantir.com/docs/foundry/architecture-center/ontology-system)
- [Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview)
- [Action types](https://www.palantir.com/docs/foundry/action-types/overview/)
- [Ontology branching](https://www.palantir.com/docs/foundry/ontologies/branching-ontology/)
- [Object permissioning](https://www.palantir.com/docs/foundry/object-permissioning/overview/)
- [Ontology-aware applications](https://www.palantir.com/docs/foundry/ontology/applications)
- [AIP architecture](https://www.palantir.com/docs/foundry/architecture-center/aip-architecture)
- [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features)
- [AIP Chatbot Studio](https://www.palantir.com/docs/foundry/chatbot-studio/overview)
- [Ontology-augmented generation](https://www.palantir.com/docs/foundry/ontology/ontology-augmented-generation)
- [Ontology SDK](https://www.palantir.com/docs/foundry/ontology-sdk/overview/)
- [Ontology MCP](https://www.palantir.com/docs/foundry/ontology-mcp/overview/)
- [Pilot](https://www.palantir.com/docs/foundry/pilot/overview)
- [Integrated AIP, Foundry, and Apollo platforms](https://www.palantir.com/docs/foundry/architecture-center/platforms)
- [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview)
- [Connecting to data](https://www.palantir.com/docs/foundry/data-integration/connecting-to-data)
- [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview)
- [Streaming pipelines](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview)
- [Time series](https://www.palantir.com/docs/foundry/time-series/time-series-overview)
- [Functions](https://www.palantir.com/docs/foundry/functions/overview)
- [OSDK subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions)
- [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview)
- [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview)
- [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/)
- [Foundry products](https://www.palantir.com/docs/foundry/marketplace/foundry-products)
- [Apollo environments](https://www.palantir.com/docs/apollo/core/environments)
- [Offline embedded Ontology](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application)

### Bloomberg

- [Bloomberg Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/)
- [Bloomberg AI and ASKB](https://professional.bloomberg.com/products/bloomberg-terminal/ai)
- [Instant Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/instant-bloomberg/)
- [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/)
- [Bloomberg Data License](https://professional.bloomberg.com/products/data/data-license/)
- [Bloomberg Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/)
- [Bloomberg point-in-time data](https://professional.bloomberg.com/products/data/enterprise-catalog/cofi/)
- [BLPAPI documentation](https://bloomberg.github.io/blpapi-docs/)
- [Bloomberg Professional app](https://professional.bloomberg.com/products/bloomberg-terminal/access/bloomberg-professional-app/)
- [B-PIPE Real-Time Market Data Feed](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/)
- [Market data in the cloud](https://professional.bloomberg.com/products/data/data-connectivity/cloud-access/)
- [BLPAPI `Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html)
- [BLPAPI `Identity`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.3/classBloombergLP_1_1blpapi_1_1Identity.html)
- [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/)
- [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/)
- [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/)
- [TOMS](https://professional.bloomberg.com/products/trading/order-management-system/toms/)

## Research boundary

Palantir and Bloomberg are proprietary. This reference compares their documented product contracts, published SDK behavior, and self-reported scale. It does not infer private storage, model, transaction, entitlement, or deployment internals. The local research records the same limitation. [Research limitations](/Users/enzotironi/Code/OS/docs/research/2026-09-02-openbb-ontology/report-source.md:551)
