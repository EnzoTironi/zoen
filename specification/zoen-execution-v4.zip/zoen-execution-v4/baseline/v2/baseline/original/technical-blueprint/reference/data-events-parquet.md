# Data, events, and Parquet

## Decision

Zoen has two durable physical data planes, one transient live-observation plane, and one semantic model:

- PostgreSQL is the authority for sparse governed state, temporal truth, identity, policy, agency, attention, receipts, external settlement, channel admission, Eve Workflow history, and the reachability of dense data.
- Immutable Parquet segments in private S3-compatible object storage are the durable form of dense observations.
- A content-addressed manifest DAG joins the two: PostgreSQL admits one manifest root at a World cut, and every Frame pins that root.
- Entitled live feeds deliver short-lived overlays between admitted cuts. They are neither PostgreSQL authority nor an alternative history store. Periodic sealing turns verified feed ranges into immutable evidence and Parquet.

Parquet is not being abandoned. It is deliberately insulated from the first query engine. DuckDB Node Neo is the initial executor; `ObservationQueryPort` allows DataFusion or another engine to read the same Parquet and manifests later without a semantic or data migration.

Arrow is optional transient interchange. It is not durable authority and is not part of a release identity unless an exported artifact explicitly says so.

## PostgreSQL schemas and roles

```text
door                  Better Auth tables only; Door role only
ontology              Worlds, releases, truth, policy, agency, Cases, DecisionContinuations,
                      Effects, Settlements, receipts, commits, rights and entitlement snapshots
ontology_dense        immutable segment/manifest payloads, admission records and lineage
ontology_runtime      Ontology idempotency, outbox, leases, connector/effect/data-flow attempts,
                      object staging and projection checkpoints
eve                   relationship-facing typed materializations, Focus and attention
eve_channels.admission verified/admitted ingress, Eve-delivery outbox, delivery evidence
eve_channels.kapso    ZoenChatStateAdapter state for the Kapso bridge
eve_channels.email    ZoenChatStateAdapter state for the email bridge
eve_workflow database Eve Nitro Workflow history and execution state; separate role and database
```

There is no shared writable `ops` schema. Every table and migration has exactly one product owner. `DecisionContinuation` hashes belong to Ontology; Door proves identity and assurance but never owns decisional authority. Eve Workflow owns conversation execution truth. `InteractionJournal` is its typed, rebuildable materialization, not a second scheduler or independently authored event history. Channel admission is durable before the provider acknowledgement but is not itself a settled conversation turn.

Kapso and email Chat SDK state uses a Zoen-owned `ZoenChatStateAdapter` over raw `pg`, explicit migrator-owned DDL, and separate schema-scoped DML roles. `@chat-adapter/state-pg` is a rejected reference rather than a dependency because connection-time unqualified DDL cannot satisfy these ownership guarantees.

DDL is owned by a non-runtime migrator role. Runtime roles are not table owners, superusers, or `BYPASSRLS`. Hono-side adapters open only Door, Ontology, and channel-owner pools. Eve Nitro alone opens its Workflow database and Eve-owned materialization pool; Hono has no Eve authority pool. Only an owning PostgreSQL adapter imports `pg`; the isolated Eve Workflow store follows ADR 029.

Authoritative keys include `(realm_kind, realm_id, world_id)`. Composite foreign keys make live/evaluation, cross-realm, and cross-World references fail physically. `FORCE ROW LEVEL SECURITY` adds a row-local backstop using transaction-local realm and World context. RLS does not query mutable membership; Ontology evaluates membership, delegation, purpose, and Cedar policy inside the serializable transaction and locks the relevant revisions.

## Sparse temporal truth

Raw evidence, claims, beliefs, identity hypotheses, Cases, receipts, Notices, and Settlements are different records. They cannot substitute for one another.

Temporal records carry:

- domain valid time as a half-open `tstzrange` or released interval;
- provider observation time when supplied;
- immutable capture time;
- admission World cut;
- source, evidence, rights, release, and mapping digests;
- a semantic stream and stream revision.

Corrections append a new record that supersedes an earlier record. They do not overwrite history. Current projections may update because they are disposable indexes; as-of queries select authoritative versions by cut and valid time.

PostgreSQL constraints enforce realm/World locality, uniqueness, legal discriminants, immutable identities, non-overlap where a released single-value policy requires it, and the one-receipt/one-contribution invariants. SQL never implements released belief, consequence, quorum, or materiality policy.

## AuthorityCommit

Every write that changes semantic authority uses one internal protocol. An `AuthorityCommit` must advance the World cut and must create exactly one immutable `AuthorityCommitEnvelope`; a write that cannot do both is not an authority write.

```text
BEGIN ISOLATION LEVEL SERIALIZABLE
  establish realm/World/principal/purpose transaction context
  open idempotency coordinate and compare canonical intent digest
  lock and validate the AuthorityFence row and sealed cell lease
  lock WorldHead and affected aggregates in stable typed-ID order
  lock and revalidate membership, delegation, release and exact reads
  evaluate the deterministic released rule
  construct the canonical payload with complete before head and next non-audit coordinates
  allocate exactly headVersion + 1 and cut + 1
  insert semantic records, including AdmittedObservationRef, DatasetAdmission or ManifestAdmission
  insert contribution, receipt, Notice, EffectSettlement or mandate reservation
  insert deterministic EffectIntents when applicable
  canonicalize one non-empty, deterministically ordered StreamTransition batch
  hash the payload without the resulting audit root
  derive auditRoot = H(domain, before.auditRoot, payloadDigest)
  insert exactly one AuthorityCommitEnvelope and complete after WorldHead
  insert sibling outbox records that reference the envelope
  record the idempotent result
  compare-and-swap the complete six-coordinate-plus-audit-root WorldHead tuple
COMMIT
```

The transaction performs no model call, provider call, object upload, Restate invocation, or other network I/O. Slow planning happens before the transaction and is accepted only after its exact read set is revalidated inside it.

SQLSTATE `40001` and `40P01` retry the complete deterministic operation with bounded jitter and the same operation key. Retry exhaustion returns a typed busy result. A suffix of a transaction is never retried.

The idempotency coordinate is `(realm, authority scope, authorization principal, operation kind, operation key)`, where authority scope is either an existing World or the bootstrap principal that is allowed to create it. The row stores the canonical intent digest and result reference. A replay still performs fresh Door and Ontology authorization before returning the old result:

- same key and digest returns the original result;
- same key and different digest returns `idempotency-conflict`;
- crash before commit leaves nothing to replay;
- crash after commit returns the committed result.

`CreatePersonalWorld` and `AcceptInvitation` are distinct commit variants. The former creates World, genesis head, owner membership, and genesis receipt. The latter consumes one invitation, inserts membership and its acceptance receipt, and advances `headVersion`, cut, and audit root exactly once while release, generation, and manifest remain unchanged. Membership is semantic authority; no constraint or shortcut may hide it from the World history.

## ProgressCommit

Operational progress is explicit and weaker. A `ProgressCommit` may write only an allowlisted operational row: leases and attempts, connector and data-flow run checkpoints, consumer receipts, unchanged-Watch checkpoints, live-subscription leases, staging uploads, release-preparation progress, delivery observations, and persisted Frame read artifacts. It may never change semantic records, membership, Case state, a DecisionReceipt, Notice truth, an EffectIntent, Settlement, admitted DatasetVersion, manifest head, release activation, audit root, or World cut.

The allowlist is encoded in repository methods and database grants rather than an open `kind` string. If a proposed progress write acquires semantic meaning, it is promoted to a full `AuthorityCommit`; the system never silently turns an authority change into background bookkeeping.

## Meaningful events

Zoen is event-oriented, not universally event-sourced. Four event classes must not blur:

1. `AuthorityCommitEnvelope` is the single durable causal record for one semantic World cut. Its ordered `StreamTransition` values describe what changed; they are not independent envelopes.
2. Eve Workflow history is conversation execution truth; `InteractionJournal` is its typed, rebuildable materialization.
3. `RuntimeSignal` is an ephemeral process-local notification with no launch dependency on a composition framework.
4. OpenTelemetry is non-authoritative operational telemetry.

An authority envelope contains:

```ts
interface AuthorityCommitPayload<R extends Realm> {
  readonly ref: AuthorityCommitRef<R>;
  readonly operation: SemanticId;
  readonly operationKey: OperationKey;
  readonly intent: IntentDigest;
  readonly actor: PrincipalOrSystem;
  readonly purpose: PurposeDigest;
  readonly authorization: Digest<"AuthorizationDecision">;
  readonly rootCause: CauseRef;
  readonly fence: Digest<"AuthorityFence">;
  readonly before: WorldHead<R>;
  readonly advance: WorldHeadCoordinates<R>;
  readonly changes: NonEmpty<StreamTransition>;
  readonly recordedAt: string;
}

interface AuthorityCommitEnvelope<R extends Realm> {
  readonly payload: AuthorityCommitPayload<R>;
  readonly payloadDigest: Digest<"AuthorityCommitPayload">;
  readonly after: WorldHead<R>;
}
```

Changes are sorted deterministically. `payloadDigest` hashes canonical payload bytes and therefore excludes the resulting audit root; `after.auditRoot` hashes the domain, `before.auditRoot`, and `payloadDigest`. `after` must equal `advance` plus that root. This avoids a self-referential digest while still committing the complete head. Periodic signed checkpoints make exported history tamper-evident. Telemetry does not replace this record.

Raw provider points, live ticks, staged captures, unchanged polls, projection rows, caches, and token chunks are not authority commits. `ManifestAdmission`, `AdmittedObservationRef`, `DatasetAdmission`, or a semantically meaningful watermark is one. A raw live value has no alternate authority path.

## Outbox and work

Outbox rows are transaction siblings of their source records and reference the source `AuthorityCommitEnvelope` rather than copying domain truth. Destinations are a closed code union such as `WatchEvaluator`, `EveNoticeInbox`, `EffectDispatcher`, `ProjectionBuilder`, `DataFlowScheduler`, `ChangeSubscriptionProjector`, and `AuditCheckpoint`; there is no public `publish` or wildcard subscriber.

Workers claim ordered batches with `FOR UPDATE SKIP LOCKED`, a bounded lease, and an attempt record. Delivery is at least once. A consumer records its semantic change and `(consumer, event)` receipt atomically. `LISTEN/NOTIFY` wakes a poller but never supplies truth, and bounded polling closes missed notifications.

Redis and BullMQ are forbidden in every role under the current constitution, including caches, locks, queues, rate limits, sessions, and ephemeral coordination. Kafka or NATS may be evaluated only as an external transport after a demonstrated consumer and explicit delivery gate; neither can become the local commit boundary or a second event vocabulary. Eve's scoped Workflow runtime is conversation execution, and Restate's scoped `ZoenEffect` is external-effect recovery; neither is a general Ontology workflow engine.

## Eve interaction durability

A verified channel callback first enters one local admission transaction that inserts `AdmittedChannelIngress` plus a deterministic Eve-delivery outbox row. The provider receives 2xx only after that commit. An idempotent dispatcher submits the stable ingress identity to Eve, and model work begins only after Eve durably accepts it into Workflow history. No transaction is claimed across the gateway and Eve Nitro processes.

Eve Workflow history is execution truth for accepted messages, turn claims, model attempts, tool requests/results, assistant messages, Focus changes, Notice arbitration, forks, wakeups, channel rendering, and delivery observations. Each relationship branch has an ordered sequence and prior identity. `InteractionJournal` is a typed materialization derived from that history for inspection and product reads; it can be rebuilt and never drives recovery independently.

A turn has at most one settled assistant message per branch. A crashed model call may spend tokens twice; the abandoned attempt remains visible and a new attempt starts. Tool operation keys derive from `(turn_id, model_tool_call_id, canonical intent digest)`, so recovery cannot duplicate World authority or Effects.

Live model token chunks are transient SSE presentation. Reconnection resumes from Eve's durable Workflow boundary and may read its typed `InteractionJournal` materialization; the materialization is not a second durable scheduler.

## Evidence admission

Provider schemas are acquisition contracts, not ontology types. One deep contribution operation hides the pipeline:

```text
realm-scoped SourceLease
  -> signed ConnectorArtifact and isolated ConnectorRun
  -> canonical request and rights check
  -> acquisition identity
  -> immutable raw capture
  -> deterministic release mapping
  -> identity and evidence validation
  -> sparse or dense admission proposal
  -> AuthorityCommit
```

The acquisition identity closes over provider, capability, canonical request, time window, checkpoint, adapter version, and source-contract digest. The raw bytes are uploaded before the database admits them. A crash may leave an unreachable object, which a delayed collector can delete; it cannot leave half-admitted World truth. Source cursors advance only inside the admission commit.

The connector never calls an admission repository. It returns a content-addressed raw capture, cursor proposal, network-transcript digest, rights metadata, and typed `EvidenceAdmissionProposal`. The application validates that output against the released source contract. A source run is operational evidence until an `AuthorityCommit` admits its capture or manifest.

Effect and channel profiles use the same payload/trust pattern but different kind-indexed artifacts, leases, runs, outputs, and owners. An effect run receives only an immutable `EffectIntent` reference and a short credential lease; its observation reaches Ontology's reconciler. A channel run returns `VerifiedChannelIngress` or delivery evidence to Eve's admission boundary. No connector variant can construct a principal, grant, `WorldSession`, `DecisionReceipt`, authority envelope, admitted ingress, or `EffectSettlement`.

## Live observations between World cuts

Bloomberg-class market and operational feeds cannot create one serializable World cut per tick. The live plane therefore has a different promise from a Frame: low-latency entitled presentation with an explicit basis, followed by periodic immutable admission.

`LiveFeedDefinition` is released meaning. It binds a semantic feed to a signed connector, selector and field schemas, normalization digest, provider ordering or conflation behavior, supported clocks, staleness policy, source-rights program, and seal policy. A change to any of those values creates a new release or artifact digest.

`LiveSubscription` is a server-created lease bound to realm, World, principal, purpose, release, selector, fields, entitlement revision, rights proof, and expiry. The gateway checks rights before opening the provider subscription and continuously while it is open. A field, entitlement, purpose, relationship, geography, or release change terminates or narrows the feed immediately. Provider credentials never reach a browser, model, mini-app, or executor.

Each transient `LiveObservationEnvelope` carries a `LiveObservationBasis` with provider session, connector digest, sequence state, provider and receipt clocks, entitlement revision, rights proof, freshness, and the last admitted `{cut, generation, manifest}`. Strict feeds surface missing sequence ranges. Latest-value feeds declare provider or Zoen conflation. A stream never implies a contiguous history when its contract supplies only a current value.

A disclosed `WorldFrame` retains its authoritative `KnowledgeBasis` and exact read set. Its separate `liveBasis` is either `sealed-only` or a presentation-only live overlay. Live values cannot enter the sealed result digest, Case exact reads, explanation evidence, exported artifact, model context, notification, data flow, or federation. There is no contract-level opt-out. Any such use requires a prior `AdmittedObservationRef`. A reconnect starts from the latest admitted manifest and then obtains a new live lease. Zoen does not replay an in-memory tick buffer as truth.

The sealing path is:

```text
bounded provider sequence range
  -> immutable raw transcript and normalization receipt
  -> deterministic typed rows
  -> immutable Parquet segments and canonical manifest proposal
  -> sequence/gap, rights, schema, quality and object verification
  -> one AuthorityCommit that admits the manifest and advances WorldHead
```

The seal interval follows product latency, provider terms, and object-size bounds. It does not follow the World commit rate. Late, revised, or gap-filling values publish a later segment and manifest with their provider revisions. Compaction preserves the logical row-set digest.

If an Action, model, Notice, export, data flow, or federation operation needs a live quote, book, sensor state, or availability value, the gateway first constructs a nominally sealed `StagedObservationCapture` from content-addressed raw and normalized bytes plus a local object-verification receipt. A dedicated Ontology AuthorityCommit then rechecks connector, sequence, release, market or device state, locally stored current entitlement snapshot, rights decision, and staleness and creates `AdmittedObservationRef`. The consumer starts against the resulting head and pins that admitted reference in `ExactReadSet`. No transaction performs object-store or provider I/O, and no Action simultaneously admits and consumes a staged capture.

## Durable dense contract

Dense observations use release-defined typed schemas rather than one universal value column. A typical time-series schema includes canonical subject/series identity, valid time, provider revision or observation time, typed value columns, unit/currency, quality status, source evidence digest, and rights marking. Schema and field identities come from the WorldRelease.

Initial writer defaults are operational profiles, not semantic identity:

- Parquet with Zstd compression;
- stable sort by semantic series identity, valid time, and provider revision;
- target row groups around 128 MiB uncompressed and objects around 256–512 MiB, bounded by latency and source cadence;
- exact writer/version metadata recorded;
- decimals use Parquet DECIMAL, timestamps use UTC microseconds, identifiers use fixed or canonical binary/text representations declared by the released schema;
- compaction creates new segments and a new manifest; it never mutates admitted objects.

A segment digest is SHA-256 over its exact bytes. Byte identity across different writer versions is not assumed; reproducible semantic queries are checked by canonical result digest. Segment and manifest payload identities never contain the commit or cut that will later admit them.

```ts
interface SegmentPayload<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly object: Digest<"ParquetObjectBytes">;
  readonly byteLength: bigint;
  readonly schema: DenseSchemaDigest;
  readonly footer: Digest<"ParquetFooter">;
  readonly logicalRange: Digest<"DenseLogicalRange">;
  readonly providerClocks: Digest<"ProviderClockBounds">;
  readonly rowCount: bigint;
  readonly writer: Digest<"ParquetWriter">;
  readonly layout: Digest<"ParquetLayout">;
  readonly statistics: Digest<"DenseStatistics">;
  readonly sourceEvidence: NonEmpty<EvidenceRef>;
  readonly usage: DataUsageContract;
  readonly encryptionContext: Digest<"ObjectEncryptionContext">;
}

interface SegmentDescriptor<R extends Realm> {
  readonly digest: Digest<"SegmentDescriptor">;
  readonly payload: SegmentPayload<R>;
}

interface SegmentVerification<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly segment: Digest<"SegmentDescriptor">;
  readonly objectVerification: Digest<"ObjectVerificationReceipt">;
  readonly verifiedAt: string;
}

interface DenseManifestPayload<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly generation: DataGenerationDigest;
  readonly schema: DenseSchemaDigest;
  readonly previousSnapshot:
    | Readonly<{ kind: "genesis" }>
    | Readonly<{ kind: "manifest"; digest: ManifestDigest }>;
  readonly merkleParents: readonly ManifestDigest[];
  readonly segments: readonly Digest<"SegmentDescriptor">[];
  readonly logicalRowSet: Digest<"LogicalRowSet">;
  readonly validRange: Readonly<{ from: string; through: string }>;
  readonly rowCount: bigint;
  readonly sourceEvidence: readonly EvidenceRef[];
  readonly usage: DataUsageContract;
}

interface DenseManifest<R extends Realm> {
  readonly digest: ManifestDigest;
  readonly payload: DenseManifestPayload<R>;
}

interface ManifestAdmission<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly manifest: ManifestDigest;
  readonly generation: DataGenerationDigest;
  readonly commit: AuthorityCommitRef<R>;
  readonly cut: WorldCut;
  readonly resultingHead: WorldHead<R>;
  readonly sourceCursorAdvances: readonly Digest<"SourceCursorAdvance">[];
  readonly admittedAt: string;
}
```

`SegmentPayload`, `SegmentDescriptor`, and `DenseManifestPayload` are immutable staged content. A descriptor or manifest digest is the domain-separated hash of its payload and is not itself a field inside that payload. `SegmentVerification` is also separate because verification time is not content identity. Their canonical digests exclude `AuthorityCommitRef`, admission cut, resulting head, and admission time. `ManifestAdmission` is a separate relational authority record. The commit payload names the already computed manifest digest; after the audit root is derived, the admission row can name the commit and resulting head without creating a hash cycle.

`previousSnapshot` orders payload history. `merkleParents` names structural content dependencies. They are different relations and never share a generic `parent` field. A manifest records source-rights provenance, not a frozen audience. Every query reevaluates current admission, usage rights, and disclosure before selecting columns or objects.

Source rights use the released positive-grant algebra in the protocol reference. Combining datasets computes the canonical meet of every contributing restriction. The result can only become more restrictive. A derivation carries field-level lineage, attribution, retention, training, redistribution, geography, purpose, output-class, and entitlement constraints. Cedar authorization and source rights are both required; neither evaluator can widen the other. An unavailable entitlement decision is `unknown` or denial, never an implicit grant.

PostgreSQL stores canonical segment and manifest payload bytes, both edge kinds, usage provenance, statistics, source watermarks, generation heads, and separate `ManifestAdmission` rows. Runtime roles can insert immutable payload nodes but cannot update or delete them. A separate collector credential deletes only objects proven unreachable after a grace period.

### Publication

1. A writer builds a segment, computes its digest, and uploads it under a realm/World/generation/content-addressed key.
2. The staging ledger records upload, length, checksum, schema, writer, evidence, and retention deadline.
3. `AuthorityCommit` locks the authority fence and complete World head; verifies local object and payload receipts; inserts one `ManifestAdmission`; advances the source cursor; and compare-and-swaps `{world, headVersion, cut, release, generation, observationManifest, auditRoot}`. The manifest digest exists before the commit and excludes its admission coordinate. Manifest admission is semantic and therefore always receives a new cut and audit envelope; staging and compaction preparation remain ProgressCommits.
4. A failed commit leaves a harmless staged orphan. A successful commit makes reachability authoritative.

Queries pin one manifest digest for their entire lifetime. Garbage collection follows reachability from active World heads, historical Frames, open Cases, Watches, release preparations, retention holds, and exports.

## Data flows and DatasetVersions

`DataFlowDefinition` is a released, acyclic, typed graph. Its closed nodes can acquire a released source, read an authorized `ObjectSetPlan`, run an `ObservationPlan`, apply a `FunctionDefinition`, invoke a declared `ExecutorArtifact`, check quality, and propose a dataset publication. Edges bind named output and input schemas. The definition also pins its trigger, incremental-key policy, rights program, quality policy, budgets, and output schema.

Ontology runtime storage owns `DataFlowAttempt`, its lease, and checkpoint records. A scheduler may wake an attempt, but it owns no semantic state. Every attempt pins a `DataFlowExecutionBasis`: complete `KnowledgeBasis`, exact sparse/capture reads, dense slices, admitted input DatasetVersions, code and connector artifacts, rights decisions, entitlement snapshots, and engine attestation. Incremental execution may reuse a prior physical checkpoint only when those inputs and the released incremental contract match. A scheduler, Rivet workflow, connector cursor, or engine checkpoint can never stand in for a DatasetVersion.

A successful run first produces an immutable proposed `DatasetVersion`. The version binds:

- dataset identity, schema, release, and materialization digest;
- every sparse read set, dense manifest, raw capture, and prior DatasetVersion;
- field-level lineage through each mapping, join, function, model, and executor;
- the canonical meet of input rights and output restrictions;
- quality-rule results, observed statistics, failures, unknowns, and score;
- run, engine, code, connector, and environment digests.

Quality has three results: `passed`, `failed`, and `unknown`. A release states which results block admission, which create a governed quality Notice, and which permit a visibly degraded dataset. A data flow never converts missing evidence into a pass. The model or executor that estimated a quality value remains in lineage.

Publishing the DatasetVersion is one `AuthorityCommit`. The commit revalidates the full execution basis, current inputs, rights, entitlement revisions, definition, and required quality results; creates a separate `DatasetAdmission` naming the commit, cut, resulting full head, quality decision, and usage receipt; emits one semantic change batch; and advances the full head. `DataFlowAttempt` has no admitted state. A failed attempt, proposed version, or scheduler checkpoint is only operational state. Downstream `ChangeSubscription` and Watches observe only `DatasetAdmission` changes.

Batch, change-driven, and scheduled flows share this contract. High-rate inputs may be microbatched before publication. An external streaming engine may later implement a run adapter, but PostgreSQL still owns run identity and admitted DatasetVersions, Parquet still owns dense history, and the release still owns semantics.

## ObservationQueryPort

```ts
interface ObservationPlan<R extends Realm, Row> {
  readonly world: WorldRef<R>;
  readonly basis: KnowledgeBasis<R>;
  readonly generation: DataGenerationDigest;
  readonly manifest: ManifestDigest;
  readonly schema: DenseSchemaDigest;
  readonly projection: readonly SemanticId[];
  readonly predicate: ReleasedPredicateIr;
  readonly aggregation?: ReleasedAggregationIr;
  readonly timeRange: Readonly<{ from: string; through: string }>;
  readonly usageRequest: Digest<"UsageRequest">;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly resultSchema: RuntimeSchema<Row>;
  readonly budget: Readonly<{
    maxObjectRequests: number;
    maxBytesScanned: bigint;
    maxRowsReturned: bigint;
    deadlineMs: number;
  }>;
}

interface ObservationQueryPort {
  execute<R extends Realm, Row>(
    plan: ObservationPlan<R, Row>,
    signal: AbortSignal,
  ): Promise<Result<ObservationResult<Row>, ObservationQueryError>>;
}
```

Ontology creates the plan only after authorization. Callers never submit SQL, object keys, S3 URLs, DuckDB expressions, or entitlement predicates. The adapter receives only segments reachable from the pinned authorized manifest and only permitted columns. It compiles an allowlisted parameterized query, applies budgets and cancellation, validates result batches, and returns query, manifest, schema, engine, and result digests.

DuckDB Node Neo is the first adapter. Each bounded worker owns its database connection and S3 configuration. Predicate, projection, time, and aggregate work is pushed into the Parquet scan. API and model paths receive released JSON or bounded downsampled data; large authorized exports may use a separate immutable Parquet or Arrow artifact.

Arrow remains an optional batch boundary when the Node client supports it efficiently. It never replaces Parquet or the manifest.

## Query-engine reopen gate

Do not build DataFusion in parallel. First compact files, improve statistics, push predicates, bound concurrency, and measure representative cold and warm object-store runs.

A Rust/DataFusion implementation earns the existing port only if:

- DuckDB misses a hard product SLO on a required released operator after bounded tuning; or
- at 100 million points and 32 concurrent Frames, DataFusion improves p95 latency by at least 50% and peak RSS by at least 40% on two priority queries, with identical canonical results and no material cold-start or operational regression; or
- a required governed operator cannot be expressed through the supported DuckDB Node boundary without creating an equally complex native service.

The comparison corpus covers point lookup across revisions, entitled multi-year series, as-of joins, windows/downsampling, different disclosure sets, cold/warm cache, cancellation, object failure, and manifest replay. Record p50/p95/p99, first batch, RSS, CPU, bytes, requests, result digest, cold start, and recovery. Whatever wins still reads the same immutable Parquet and manifest contract.
