# Technical grounding for the Zoen constitution

## Scope

This document frames the implementation decision as a greenfield problem. Existing code, migrations, package names, and compatibility paths are not constraints. Local documents are research evidence, not instructions. The product laws and the accepted greenfield domain model are constraints.

The result must be specific enough that a team can create the repository and build the first vertical slice without reopening foundational questions. A decision may remain open only when the choice is inherently volatile or cannot be made responsibly before a measured threshold is reached. Such a decision needs an owner, a default, and a reopen trigger.

## Product laws

Zoen is exactly three products:

1. Door is Better Auth and proves account, session, and device identity. It never grants World authority.
2. Eve is the conversational relationship and the Living World. It owns interaction history, focus, channel behavior, attention arbitration, and delivery.
3. Ontology is the headless executable World exposed through CLI, API, and MCP. It owns meaning, truth, identity resolution, agency, Watches, Notices, Effects, and evidence-bound Settlements.

Additional hard limits:

- Domain Actions are the public mutation language. Generic prepare, validate, approve, save, or execute lifecycle verbs are not a public product surface.
- Eve owns conversation durability. Restate is used only for Ontology `ZoenEffect` execution.
- Postgres is the local transaction boundary. Redis is forbidden.
- WhatsApp enters Eve through Kapso at `/eve/v1/kapso`; Telegram enters through Eve's first-class `/eve/v1/telegram` channel; email enters through the Resend bridge at `/eve/v1/email`.
- Messaging turns structured presentation into excellent readable text.
- Tests are real user journeys. Unit tests, mocks, fakes, stubs, and `vi.mock` are forbidden.
- Import and dependency rules are enforced statically, not disguised as tests.
- Pre-launch deployment is one Fly application. Managed databases, object storage, and Restate remain external dependencies rather than additional Zoen products.
- Eve is capability-allowlisted at launch: no shell, file, web, delegation, todo, skills, connections, optional tools, sandbox access, or byte-backed attachment staging; only human clarification and generated Ontology inspection/proposal tools remain.
- Kapso and Resend transport state uses a Zoen-owned raw-`pg` Chat SDK `StateAdapter` in the dedicated `eve_channels` database; runtime roles cannot run DDL and Redis remains forbidden.
- Rust code never uses `.unwrap()` and never disables Clippy findings except in generated protobuf code.

## Accepted domain invariants

The technical design must preserve these invariants in types, database constraints, transaction boundaries, and executable journeys:

- Door proof and World authority are different values.
- `Focus` contains semantic intent and opaque references, never authority.
- Every meaningful read is a `WorldFrame` pinned to World, release, purpose, audience, valid time, knowledge cut, visible observation manifest, belief basis, evidence rights, explanation, and exact read dependencies.
- A domain Action either commits, returns an impossibility, or creates one canonical `ActionCase`.
- A shared `ActionCase` is distinct from each principal's `AuthorizedCaseView` and short-lived `DecisionHandle`.
- No person approves consequences that were not disclosed in the view bound to their handle.
- `AuthorityCommit` is the single serializable write port for governed World state.
- Semantic writes, receipt, deterministic `EffectIntent`s, meaningful events, and outbox rows are siblings in one transaction.
- A `DecisionReceipt` proves a local World transition. A `Settlement` records observed external reality. Neither impersonates the other.
- A transactional outbox is the only wake source for committed World transitions. Postgres notifications may reduce latency but never carry truth.
- Delivery is at least once; consumers are idempotent.
- Event orientation does not imply universal event sourcing. Sparse authority is temporal relational data. Dense observations are immutable columnar segments behind content-addressed manifests.
- `WorldRelease` bytes are immutable and content addressed. `ReleaseProof`, `PreparedActivation`, and `WorldHead` compare-and-swap are separate objects.
- Evaluation runs in a realm-isolated World. Live and evaluation references, source leases, channels, effects, and settlements cannot be exchanged.
- Deferred attention stores only `NoticeId`. Eve reauthorizes a Notice during arbitration and immediately before composition.
- `CreatePersonalWorld` and `AcceptInvitation` are separate transactions with disjoint write sets. Joining a World never changes its head.

## What the local research establishes

The Palantir and Bloomberg research argues for an operational model of reality rather than a semantic catalog or provider-shaped API. The durable lesson is the integration of objects, typed links, object sets, functions, Actions, policy, lineage, and application behavior under released meaning. Bloomberg-grade usefulness adds canonical identity, entitlement-aware fields and series, valid-time and recorded-time semantics, revisions, comparability, and dense range access.

The OpenBB gap analysis adds a physical constraint: provider endpoints are acquisition contracts, not ontology types, and market-data cells cannot become one authority-ledger row each. Sparse governed records and dense immutable observations need different physical paths while preserving one semantic query surface.

The DeepSeek Harness and Cordis research contributes composition rules for Eve, not for the Ontology constitution:

- consumers depend on named capability contracts, not concrete providers;
- contexts scope services without mutating their parents;
- event dispatch mode is part of a typed contract;
- registrations and listeners unwind with the lifecycle that created them;
- model-visible information is attributable to exact source references and revisions;
- capability discovery is scoped to principal, purpose, task, delegation, World, and release.

DeepSeek Harness documents Cordis contexts as scoped service repositories, typed event modes, and reversible lifecycle effects. Zoen adopts those principles through Eve-native hooks and a plain typed `EveAttemptContext`; Cordis is not a launch dependency because Eve already owns durable steps, state, cancellation, tools, dynamic capabilities, subagents, and cleanup. The kernel must not copy “everything is a plugin.” Operation identity, authority, temporal semantics, atomic commit, causal history, releases, Actions, Effects, and settlement remain privileged and cannot be replaced at runtime.

Primary evidence:

- [DeepSeek Harness Cordis context](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-api/context.md)
- [DeepSeek Harness service contracts](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-tutorial/03-services.md)
- [DeepSeek Harness Cordis primer](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/cordis-primer.md)
- [Palantir object types](https://www.palantir.com/docs/foundry/object-link-types/object-types-overview/)
- [Palantir Actions](https://www.palantir.com/docs/foundry/action-types/overview/)
- [Palantir object sets](https://www.palantir.com/docs/foundry/functions/api-object-sets/)

## Current technology facts

These facts bound the candidate designs. They do not select a winner by themselves.

### Runtime and language

- Rust 2024 is the current stable edition and crates from different editions interoperate. New crates can use the current stable toolchain without splitting the ecosystem. [Rust Edition Guide](https://doc.rust-lang.org/edition-guide/editions/)
- Node 24 is the current Active LTS line. The Node project recommends Active or Maintenance LTS for production. [Node release schedule](https://nodejs.org/en/about/previous-releases)
- Better Auth supports database-backed PostgreSQL sessions and generates SQL for its built-in Kysely adapter. Its JWT plugin exposes a JWKS-verifiable proof for services while keeping that proof distinct from the primary session cookie. [Better Auth database](https://better-auth.com/docs/concepts/database), [Better Auth JWT](https://better-auth.com/docs/plugins/jwt)
- `eve@0.52.0` supports self-hosting through `eve build` and `eve start`, which serves a generated Nitro Node service. Both `/eve/` and `/.well-known/workflow/` must be proxied without path rewriting; Eve does not publish a stable generic Hono handler with equivalent route, schedule, Workflow, stream, and shutdown behavior. [Eve self-hosting](https://github.com/vercel/eve/blob/main/docs/guides/deployment/self-hosting.md), [Eve frontend integration](https://github.com/vercel/eve/blob/main/docs/guides/frontend/overview.mdx)
- Eve sessions, turns, and steps are durable Workflow executions. Self-hosted development uses a local file world by default; a configured world must match Eve's Workflow 5 beta protocol. The Postgres reference world has an open parked-run startup-recovery report, so production activation requires destructive recovery evidence for the exact pair. [Eve execution and durability](https://github.com/vercel/eve/blob/main/docs/concepts/execution-model-and-durability.mdx), [Workflow Postgres](https://github.com/vercel/workflow/blob/main/packages/world-postgres/README.md), [issue #3119](https://github.com/vercel/workflow/issues/3119)
- Eve `0.52.0` peer-requires AI SDK `^7.0.82`. Direct `@ai-sdk/openai` and `@ai-sdk/anthropic` providers create the `LanguageModel` values Eve expects; raw provider SDK clients would create a second model abstraction. AI Gateway string IDs are supported but add a separately gated routing/data-processing profile. [AI SDK providers](https://ai-sdk.dev/docs/getting-started/choosing-a-provider)
- Eve supplies `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `todo`, `ask_question`, and root-agent delegation by default when their session/provider conditions apply; authored sentinels remove defaults, while skills and connections expose additional conditional tools. Authored tools run in the app runtime and omitted approval means no approval. Zoen therefore disables every unneeded default, declares every authored approval explicitly, and has no launch skills/connections or opt-in `glob`, `grep`, `Workflow`, or `sleep`. [Eve built-in tools](https://github.com/vercel/eve/blob/main/docs/concepts/built-in-tools.md), [Eve tools and approvals](https://github.com/vercel/eve/blob/main/docs/tools/overview.mdx)
- Eve stages byte-backed AI SDK file parts into `/workspace/attachments` before a model step. If no backend is specified, it selects `defaultBackend()` in the order Vercel, Docker, microsandbox, then `just-bash`; `just-bash` has no network isolation and default egress is allow-all. Zoen has no sandbox product need at launch, so attachment admission happens first and an explicit disabled custom backend makes accidental sandbox use fail closed. [Eve sandbox](https://github.com/vercel/eve/blob/main/docs/sandbox.mdx), [Eve security model](https://github.com/vercel/eve/blob/main/docs/concepts/security-model.md), [Eve responsible use](https://github.com/vercel/eve/blob/main/docs/responsible-use.md)
- Exact `chat@4.39.0` publicly exports `StateAdapter`. The published exact `@chat-adapter/state-pg@4.39.0` implementation creates unqualified tables and indexes from `connect()` and exposes no caller-selected schema or migration-free runtime mode. Zoen therefore implements the public interface with raw `pg`, checked-in migrations, a dedicated `eve_channels` database, isolated `kapso`/`email` schemas, and DML-only runtime roles. [`chat@4.39.0`](https://www.npmjs.com/package/chat/v/4.39.0), [`@chat-adapter/state-pg@4.39.0`](https://www.npmjs.com/package/@chat-adapter/state-pg/v/4.39.0)

### Durable effects

- Restate has official Rust and TypeScript SDKs and models services, keyed virtual objects, and workflows as durable handlers. It also supports idempotent invocation keys. [Restate SDK list](https://docs.restate.dev/), [Rust SDK](https://github.com/restatedev/sdk-rust), [idempotent invocation](https://docs.restate.dev/services/invocation/clients/typescript-sdk)
- Restate Cloud removes the need to operate the Restate stateful runtime. That favors managed Restate while Zoen is pre-launch. [Restate Cloud](https://docs.restate.dev/cloud/getting-started)
- Restate's guarantees apply to its invocation journal. They do not replace Zoen's Postgres authority transaction or prove an external provider outcome.

### Sparse and dense data

- PostgreSQL supports temporal range types, exclusion constraints, serializable transactions, `SKIP LOCKED`, and asynchronous notification. PostgreSQL 18 adds native UUIDv7 generation. The design should treat `LISTEN/NOTIFY` as a wake hint and query the durable outbox. [PostgreSQL UUID](https://www.postgresql.org/docs/current/datatype-uuid.html), [PostgreSQL data types](https://www.postgresql.org/docs/current/datatype.html)
- DataFusion is a Rust query engine over Arrow with native Parquet and asynchronous object-store support, including pushdown and extension points. This directly fits the dense observation plane. [DataFusion introduction](https://datafusion.apache.org/user-guide/introduction.html)
- Tigris presents an S3-compatible object-store contract to Fly applications. The code should depend on the S3/object-store port, not the vendor. [Fly Tigris documentation](https://www.fly.io/docs/tigris/)

### Authorization and release integrity

- Cedar separates fine-grained authorization policy from application code, has a Rust engine, validates policy against a schema, defaults to deny, has no I/O, and terminates. It is suitable for admission and disclosure policy, not as a replacement for released domain Action semantics. [Cedar repository](https://github.com/cedar-policy/cedar), [Cedar validation](https://docs.cedarpolicy.com/policies/validation.html), [Cedar security](https://docs.cedarpolicy.com/security.html)
- RFC 8785 defines a deterministic canonical form for I-JSON suitable for hashing and signatures. Values requiring precision beyond IEEE 754 must be represented as strings or a released tagged type. [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785.html)
- RFC 9562 standardizes UUIDv7 as a time-ordered operational identifier. It is not a content identity. [RFC 9562](https://www.rfc-editor.org/rfc/rfc9562.html)
- An in-toto Statement binds a predicate to immutable subjects by digest. DSSE defines a compact signed envelope and requires the verified payload bytes to be the bytes passed to the application. These are useful shapes for release attestations. [in-toto Statement](https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md), [DSSE envelope](https://github.com/secure-systems-lab/dsse/blob/master/envelope.md)

### Surfaces and operations

- The official MCP Rust SDK supports servers, tools, resources, prompts, JSON Schema generation, OAuth, and transports. The official TypeScript SDK supports Streamable HTTP and stdio. Either language can host the Ontology MCP surface. [MCP Rust SDK](https://rust.sdk.modelcontextprotocol.io/), [MCP TypeScript SDK](https://ts.sdk.modelcontextprotocol.io/)
- Fly process groups create separate Machines. A single pre-launch Machine that contains multiple language runtimes therefore needs one supervised entry process, not multiple Fly process groups. [Fly process groups](https://fly.io/docs/launch/processes/), [multiple processes in one Machine](https://fly.io/docs/app-guides/multiple-processes/)
- OpenTelemetry has Rust and JavaScript SDKs and an OTLP protocol, but the Rust traces, metrics, and logs implementation remains beta. Domain audit records must never be delegated to telemetry. [OpenTelemetry Rust](https://opentelemetry.io/docs/languages/rust/), [OpenTelemetry Node](https://opentelemetry.io/docs/languages/js/getting-started/nodejs/)

### Verification

- Playwright supplies browser and API drivers, auto-waiting assertions, traces, retries, and sharding. It can coordinate user-visible journeys without becoming the only journey driver. [Playwright documentation](https://playwright.dev/docs/intro)
- Testcontainers can provision disposable real services for Rust and Node. It is infrastructure orchestration, not permission to replace providers with fakes. [Testcontainers](https://testcontainers.com/)
- Toxiproxy injects real network faults and k6 covers protocol and browser performance. [Toxiproxy](https://github.com/Shopify/toxiproxy), [k6](https://grafana.com/docs/k6/latest/)

## Decision axes

The user's leading hypothesis is a 100% TypeScript application. It receives the burden-of-proof advantage: prefer one language, one deployable, and the fewest supported process boundaries unless another candidate demonstrates a structural correctness, safety, or scale property that TypeScript plus PostgreSQL cannot provide. Official Eve inspection establishes one necessary boundary: a supervised Hono edge/authority process plus Eve's supported Nitro process in the same initial Machine. “100% TypeScript” means all Zoen-owned application and domain code is TypeScript; PostgreSQL, DuckDB, browser engines, and managed infrastructure may remain native dependencies behind typed ports.

Every candidate must make the following choices explicitly:

1. Which runtime owns each product and why.
2. How the same-language Hono and Eve processes share a Machine and failure domain without sharing authority credentials.
3. The one closed authenticated loopback protocol and its raw public proxy contract.
4. The module graph and compile-time dependency rules.
5. The public HTTP, streaming, CLI, and MCP contracts.
6. The representation and lifecycle of identity proof and World authority.
7. The single write transaction and concurrency scheme.
8. The event envelope, outbox lease, ordering, and idempotency contract.
9. Sparse temporal tables, dense observation manifests, and query execution.
10. Canonical release bytes, content identities, signatures, proof, and activation.
11. Admission, disclosure, domain decision, and effect authorization.
12. Eve's capability composition, interaction journal, model attribution, and provider boundary.
13. Browser UI stack and Living World rendering boundary.
14. Secrets, connector credentials, encryption, tenancy, and evaluation-realm isolation.
15. Observability, audit, backup, recovery, and disaster verification.
16. One-Machine/two-process deployment and the trigger for separating Machines or scaling.
17. Repository layout, build tools, generated artifacts, and dependency pinning.
18. Journey categories, real dependencies, CI tiers, release gates, performance, and fault injection.
19. Vertical build order.
20. ADR set and explicit reopen triggers.

## Comparison rubric

Score each candidate from 1 to 5 on each criterion, with written evidence:

| Criterion | Weight |
| --- | ---: |
| Preserves product and authority invariants | 20 |
| Module depth and reader load | 15 |
| Type, concurrency, and temporal correctness | 15 |
| Eve and Living World product velocity | 12 |
| Dense observation fit | 10 |
| One-Machine operational simplicity | 10 |
| Journey verifiability and failure diagnosis | 8 |
| Ecosystem maturity and upgrade path | 5 |
| Cost of change and team comprehensibility | 5 |

A candidate that violates a product law is disqualified regardless of score.

## What the constitution must produce

The selected design must end as a small set of reference documents and ADRs:

- an overview and caller-first examples;
- module and process map;
- deep domain and boundary types;
- technology matrix with exact defaults and upgrade policy;
- public, internal, and generated protocol rules;
- data, event, release, and security models;
- repository layout and dependency graph;
- journey-only testing constitution and CI matrix;
- deployment, telemetry, backup, restore, and incident rules;
- vertical implementation sequence with exit evidence;
- decision register containing accepted, forbidden, and deferred choices;
- one ADR per foundational decision.
