# Charting selection: semantic contract, ECharts 6, and TanStack Charts

## Decision

Zoen adopts an **asymmetric dual-renderer architecture with one launch renderer**:

1. **Ship Apache ECharts 6.1.0 as the only production renderer at launch.** Import it modularly from `echarts/core`; write a small Zoen-owned React host; do not adopt `echarts-for-react`.
2. **Keep `@tanstack/charts` 0.16.0 in an exact-pinned EvaluationWorld lane.** It does not enter the production bundle or released schema yet. It is the preferred future renderer for ordinary semantic charts if it passes the promotion gates below.
3. **Own one released `ChartDocument` and one runtime `ChartInstance`.** Neither contains ECharts options, TanStack mark objects, JavaScript callbacks, arbitrary HTML, renderer names, or renderer-specific escape hatches.
4. **After promotion, use TanStack Charts by default and ECharts only for named specialist capability profiles.** ECharts remains the dense/progressive, financial, graph, matrix, and broad-chart engine. TanStack becomes the SVG-first, React-native, accessible, compositional engine for most Living World and Workshop views. A page does not load both unless its released composition genuinely contains both profiles and its bundle gate passes.
5. **Reserve GPU rendering as a future `ChartRendererPort`.** Neither core library is WebGL. Do not adopt `echarts-gl` now.

This is not indecision and it is not a lowest-common-denominator abstraction. `ChartDocument` is the product language; renderer adapters are replaceable compilers. The initial implementation remains small—one backend—while preserving the Bloomberg/Palantir horizon without making a young alpha library constitutional.

The decision was researched on 2026-09-04 against the tagged source, official documentation, GitHub repository metadata, and npm registry metadata. The inspected source commits were TanStack Charts `258ed39382b09843f98e6f48a2e9d4d0bd3f1d41` (`v0.16.0`) and ECharts `c5a48f5f97d23e5379720870b8444cd05b50ffb4` (`6.1.0`). Exact package versions and integrity hashes still belong in `pnpm-lock.yaml`, the SBOM, and the dependency evidence ledger.

## Why this is the elegant choice

Choosing only TanStack Charts today would optimize the local API while accepting explicit 0.x churn, a five-week-old public project, no unbounded-data renderer, and weaker terminal-grade chart controllers. Choosing only ECharts forever would make a mature implementation detail the permanent authoring model, despite a larger baseline bundle, a less natural React/SSR model, and incomplete keyboard interaction semantics.

The stable thing should instead be the question the chart answers:

- which released measures, dimensions, units, temporal basis, and knowledge cut it uses;
- which representation of the underlying rows it shows and what was omitted or aggregated;
- which evidence and objects each mark can reopen;
- which semantic interactions are allowed;
- which accessible and export forms must remain available;
- which capabilities a renderer must prove rather than silently approximate.

This is also the important competitive lesson. Palantir and Bloomberg are not excellent because they selected a JavaScript chart package. Their advantage comes from entitled data, reusable semantics and analytics, linked workflows, saved workspaces, collaboration, evidence, and action. Zoen should make those durable and let a rendering engine remain an engine.

## Inspected baseline

| Candidate | Inspected version | License | Stability and maturity evidence | Production posture |
|---|---:|---|---|---|
| TanStack Charts | `@tanstack/charts` 0.16.0, tag `v0.16.0`, 2026-08-26 | MIT | The official stability policy labels the package Alpha, publishes it on `latest`, and allows breaking changes in minor releases. The repository was created on 2026-07-28. Exact pins are required. | Evaluation only; preferred future ordinary-chart renderer after gates |
| Apache ECharts | `echarts` 6.1.0, tag `6.1.0`, 2026-05-19 | Apache-2.0 | Public project since 2013, version 6 line, extensive official chart/component catalog, compatibility-oriented upgrade guide, and a much larger installed ecosystem. Major/default changes still exist across versions. | Adopt now, exact-pinned, behind Zoen's port |
| React wrapper for ECharts | `echarts-for-react` 3.0.6 | MIT | Third-party wrapper, separate lifecycle and dependency choices, not the Apache ECharts React contract. | Reject; the required host is small and authority-sensitive |
| ECharts GL | `echarts-gl` 2.1.0 | BSD-3-Clause in tagged source; npm metadata reports MIT | The release declares ECharts 6 support, but a 2026 official issue reports failing ESM deep imports with ECharts/zrender 6. The license metadata disagreement also requires resolution. | Reject now; reconsider through a separate GPU adapter |

The npm registry reported unpacked package sizes of approximately 2.82 MB for `@tanstack/charts@0.16.0` and 60.30 MB for `echarts@6.1.0`. Those numbers include source, declarations, maps, and distributions; they are **not browser bundle sizes**. In the TanStack team's own reproducible twelve-consumer comparison at the 0.16.0 baseline, TanStack ranged from 38.96–44.98 KiB gzip and modular ECharts from 153.10–173.18 KiB gzip. That is useful vendor-controlled evidence, not an independent Zoen benchmark. The bundle journey below must rerun equivalent Zoen imports.

Repository and download counts are maturity signals, not quality scores. On the inspection date, the official repository APIs reported roughly 707 GitHub stars and 125,070 npm downloads in the 2026-08-23 to 2026-08-29 week for TanStack Charts, versus roughly 67,242 stars and 5,133,947 weekly downloads for ECharts. Both repositories were active during the inspection period.

## Capability comparison

| Dimension | TanStack Charts 0.16.0 | Apache ECharts 6.1.0 | Zoen consequence |
|---|---|---|---|
| API model | Typed, framework-neutral grammar of marks, channels, scales, views, and compiled scenes. Renderer-neutral scene output makes it close to a headless chart compiler. | Imperative instance plus a broad, series/component-oriented option tree and action/event API. It is renderer-independent, but not a headless semantic scene grammar. | `ChartDocument` resembles neither API. Adapters compile from Zoen semantics into either model. |
| API stability | Officially Alpha. Minor versions may break; patch versions should not intentionally break. | Mature major version with a compatibility orientation, although v6 changes themes, layout, rich text, and defaults. | Exact-pin both. TanStack cannot be a released dependency until upgrade journeys prove the adapter boundary. |
| React | First-party React 19 adapter at `@tanstack/charts/react`, with controlled inputs and documented SVG SSR/hydration adoption. | No first-party React adapter in core. ECharts owns an imperative instance that must be created, resized, updated, and disposed around React. | TanStack has the cleaner application fit. For ECharts, own one small component and one adapter module rather than accepting a wrapper dependency. |
| Composition | Layers, grids, insets, shared axes, linked views, and mixed marks are structural parts of the grammar. | Rich grids, coordinate systems, datasets, components, linked instances, and graphic/custom series; composition is powerful but expressed through option orchestration. | TanStack is the better future authoring target for application-native views; ECharts is the stronger specialist implementation. |
| Accessibility | Requires an accessible label; documents SVG semantics, keyboard/pointer parity, focus, native interactive legends, brush sliders, keyboard zoom, reduced motion, and polite tooltip behavior. | ARIA is opt-in and can generate descriptions and decals. Tagged 6.1 source sets the chart role to `img`, but the inspected core does not establish a general keyboard navigation contract for marks, legend, zoom, brush, or tooltip dismissal. | Every chart also gets first-party semantic HTML controls, narrative, and an exact-value table. ECharts cannot pass accessibility merely by enabling `aria`. |
| SVG and Canvas | Accessible SVG default. Canvas may be selected for the whole chart or individual marks, enabling mixed SVG/Canvas scenes. | Canvas default and SVG renderer optional through zrender. Renderer is selected explicitly in modular builds. | Both satisfy ordinary rendering. Mixed accessible presentation is more direct in TanStack. |
| WebGL/GPU | No core WebGL renderer. | No core WebGL renderer. ECharts GL is separate and currently blocked. | Keep a renderer capability seam; do not pretend Canvas is GPU. |
| Large data | Canvas still creates one scene node per datum. Official guidance assigns aggregation, windowing, spatial indexing, and representation to the application. Nearest-point lookup is linear by default unless an index is supplied. No general progressive renderer. | Incremental/progressive pipeline, series `large` modes, typed-array paths, `appendData`, `dataZoom`, and sampling including LTTB. Official marketing demonstrates very large datasets, but vendor scale claims are not acceptance evidence. | Zoen prepares honest bounded representations in both cases. ECharts wins when many prepared marks still require progressive painting or stream append. Neither is a substitute for query planning. |
| Virtualization | No row virtualization; bounded representation is the model. | No row virtualization in the table sense; zoom/windowing and progressive painting bound the visible work. | Use TanStack Virtual for tables. For charts, use viewport queries, aggregation, envelopes, density, and level-of-detail. |
| Time series | `scaleTime`/`scaleUtc`, line/area/interval marks, controlled zoom/brush, linked views, and compositional annotations. | Native time axes, data zoom, sampling, append, axis pointer, linked panels, mark components, and broad streaming patterns. | Both cover ordinary time series. ECharts is the initial engine for dense or continuously appended series. |
| Financial primitives | Candlesticks/OHLC are composed explicitly from link and rect marks. This is elegant grammar but not a terminal controller. | Native candlestick series with large/progressive paths. ECharts 6 demonstrates multi-pane stock, volume, MACD, order book/depth, and matrix layouts. | Use an ECharts specialist profile for market workbenches. Indicators remain governed `AnalyticsPlan` outputs, never opaque client formatter logic. |
| Graph and hierarchy | Tree, treemap, sunburst, Sankey, Delaunay/Voronoi, and a force transform. A live draggable/reheated simulation controller remains application-owned. | Native graph with force/circular layouts, roam and draggable nodes; native tree, treemap, sunburst, Sankey, and v6 chord. | ECharts wins for interactive operational networks. TanStack remains suitable for authored/static explanatory networks after proof. |
| Maps and spatial | GeoJSON through d3-geo projections, routes, contours, density, hexbin, and vector marks. It bundles no atlas or tiled GIS runtime. | Geo/map/lines series with GeoJSON or SVG base maps, visual maps, roam, and effect lines. It is not a full vector-tile operational GIS engine. | Use either for bounded thematic/vector maps. Add a dedicated map port only when a named journey requires tiles, terrain, spatial editing, or globe-scale LOD. |
| Annotations | Rules, bands/rectangles, text, arrows, and prepared semantic annotation rows; HTML overlays are application-owned. | `markPoint`, `markLine`, `markArea`, `graphic`, and custom series. | Annotations are released semantic objects bound to evidence/events; vendor graphic primitives never enter the release. |
| Interaction | Controlled cursor, crosshair, select, brush, handles, zoom, linked views, and semantic signal state. | Extensive pointer events, actions, `dispatchAction`, tooltip, axis pointer, data zoom, brush, timeline, toolbox, and connected charts. | Normalize both into closed `ChartEvent` values. Renderer events never execute domain Actions. |
| SSR and hydration | Full SVG can be rendered on the server and adopted on hydration. Canvas SSR emits an accessible shell and paints after mount; mixed mode preserves server SVG then adds Canvas. | Zero-dependency SVG string SSR; Canvas SSR through node-canvas. The documented lightweight hydration runtime is small but server-round-trip oriented and does not provide the full tooltip/high-frequency client runtime. | TanStack has the superior React SSR path. Launch ECharts pages serve semantic HTML plus static SVG, then replace/enhance with a client instance; do not call this DOM hydration. |
| Export | SVG string/serialization and browser raster export for SVG, Canvas, or mixed output. Server Canvas pixels are not available without a browser. | Server `renderToSVGString`; Canvas/image export through server canvas or browser `getDataURL`/connected export. | `renderStatic` is a required port method. Exports pin document, data, renderer, theme, locale, and representation digests. |
| Theming | `currentColor`, CSS variables, partial themes, gradients, clipping, light/dark inheritance; Canvas resolves the CSS environment. | Registered themes and v6 dynamic theme switching/dark-mode support; application observes system preference. | Zoen tokens compile to either renderer. A theme name is not released meaning. |
| Bundle | Smaller in the vendor-controlled equivalent-feature comparison, with granular D3 dependencies. | Modular tree-shakeable imports exist, but the equivalent baseline is materially larger. Full `import * as echarts` is avoidable. | Common charts get an explicit 60 KiB gzip future budget; ECharts is code-split behind specialist profiles and capped separately. |
| Ecosystem | Fast-moving TanStack ecosystem and unusually good TypeScript/AI-authoring ergonomics, but the chart project itself is new. | Long-lived Apache project, wide examples/integrations, more production history, broad chart catalog, and much larger adoption. | Maturity decides launch; semantic fit creates the TanStack promotion lane. |

## The product contract: a chart is an evidence-bearing view

A chart does not own facts, analytics, authorization, or action. It renders an authorized, cut-pinned representation of a `WorldFrame` or immutable analysis result. The visual may help a person inspect, compare, select, or form an intent. It cannot turn a hover, click, brush, annotation, or optimistic client state into authority.

The released template and runtime binding are deliberately separate:

- `ChartDocument` is released meaning: the question, semantic fields, units, views, accessible contract, allowed interaction, annotations, and required capabilities.
- `ChartInstance` is an authorized occurrence: exact World/release/cut/as-of basis, query or analysis result, visible manifest, representation proof, current controlled viewport, and data digest.
- `ChartRenderPlan` is disposable compilation output: chosen adapter/version, target, layout, prepared payload, warnings, and capability proof.
- `ChartArtifact` is an immutable export: SVG/PNG/PDF-ready image plus the exact accessible/table representation and all relevant digests.

The same document may therefore appear as interactive SVG in Living World, progressive Canvas in a dense Workshop app, static SVG in email, an image plus readable text in WhatsApp or Telegram, or a table/narrative in a host that cannot render charts. Channel flattening is a product feature, not a degradation accident.

### TypeScript shape

The following sketches the closed contract. Names may move during implementation; ownership and separation may not.

```ts
type ChartCapability =
  | "mark.line"
  | "mark.area"
  | "mark.bar"
  | "mark.point"
  | "mark.interval"
  | "mark.candlestick"
  | "mark.boxplot"
  | "mark.heatmap"
  | "mark.sankey"
  | "mark.chord"
  | "mark.tree"
  | "mark.treemap"
  | "mark.network.force"
  | "coordinate.cartesian"
  | "coordinate.polar"
  | "coordinate.geo.vector"
  | "coordinate.calendar"
  | "coordinate.matrix"
  | "interaction.inspect"
  | "interaction.select"
  | "interaction.brush"
  | "interaction.zoom"
  | "interaction.pan"
  | "interaction.linkedViews"
  | "render.svg"
  | "render.canvas"
  | "render.mixed"
  | "render.progressive"
  | "output.staticSvg"
  | "output.raster";

interface ChartDocumentV1 {
  readonly schemaVersion: "zoen.chart/1";
  readonly chartId: string;
  readonly question: string;
  readonly title: ReleasedText;
  readonly subtitle?: ReleasedText;
  readonly dataSlots: readonly ChartDataSlot[];
  readonly views: readonly ChartView[];
  readonly links: readonly LinkedViewRule[];
  readonly annotations: readonly SemanticAnnotation[];
  readonly interaction: ChartInteractionPolicy;
  readonly accessibility: ChartAccessibilityContract;
  readonly export: ChartExportPolicy;
  readonly requires: readonly ChartCapability[];
}

interface ChartDataSlot {
  readonly slotId: string;
  readonly source: ReleasedQueryRef | AnalyticsPlanRef;
  readonly fields: readonly {
    readonly fieldId: string;
    readonly meaning: ReleasedFieldRef;
    readonly role: "dimension" | "measure" | "time" | "identifier" | "evidence";
    readonly valueType: "decimal" | "integer" | "instant" | "date" | "duration" | "category" | "boolean";
    readonly unit?: ReleasedUnitRef;
    readonly nullMeaning: "absent" | "unknown" | "notApplicable" | "withheld";
  }[];
  readonly expectedGrain: readonly ReleasedFieldRef[];
}

interface ChartInstance {
  readonly documentDigest: Digest;
  readonly frameRef: WorldFrameRef;
  readonly worldReleaseDigest: Digest;
  readonly knowledgeCut: KnowledgeCutRef;
  readonly validTime: TimeBasis;
  readonly result: AuthorizedResultRef;
  readonly resultSchemaDigest: Digest;
  readonly resultDataDigest: Digest;
  readonly representation: RepresentationProof;
  readonly state: ChartControlledState;
}

interface RepresentationProof {
  readonly strategy: "raw" | "viewport" | "aggregate" | "envelope" | "sample" | "density";
  readonly algorithmId: ReleasedAlgorithmRef;
  readonly sourceRows: number;
  readonly representedRows: number;
  readonly preparedRows: number;
  readonly expectedMarks: number;
  readonly preserved: readonly ("count" | "sum" | "min" | "max" | "first" | "last" | "ordering")[];
  readonly omittedMeaning: ReleasedText;
  readonly proofDigest: Digest;
}
```

`ReleasedText`, identifiers, numeric formatting, units, locale behavior, null semantics, and algorithms are closed released values. A `ChartDocument` contains no function, formatter callback, expression string, CSS selector, raw URL, arbitrary markup, `option`, `series`, `mark`, or plugin payload. Domain-derived values such as returns, Bollinger bands, MACD, confidence intervals, forecasts, exposure, and scenario deltas are produced by released `AnalyticsPlan` nodes and recorded in the result artifact. The browser may calculate pixels and layout, not new business truth.

### Renderer port

```ts
interface ChartRendererPort {
  readonly id: "echarts-6" | "tanstack-charts" | (string & {});
  readonly version: string;

  capabilities(): RendererCapabilities;

  plan(input: {
    readonly document: ChartDocumentV1;
    readonly instance: ChartInstance;
    readonly target: ChartRenderTarget;
    readonly environment: ChartEnvironment;
  }): Result<ChartRenderPlan, ChartCompileError>;

  mount(input: {
    readonly element: HTMLElement;
    readonly plan: ChartRenderPlan;
    readonly emit: (event: ChartEvent) => void;
  }): Result<MountedChart, ChartMountError>;

  renderStatic(input: {
    readonly plan: ChartRenderPlan;
    readonly format: "svg" | "png";
  }): Promise<Result<ChartArtifact, ChartExportError>>;
}

interface ChartRenderPlan {
  readonly rendererId: string;
  readonly rendererVersion: string;
  readonly capabilityDigest: Digest;
  readonly documentDigest: Digest;
  readonly dataDigest: Digest;
  readonly representationProofDigest: Digest;
  readonly target: ChartRenderTarget;
  readonly expectedMarks: number;
  readonly accessibleDocument: AccessibleChartDocument;
  readonly warnings: readonly ChartWarning[];
  readonly adapterPayload: unknown; // private to the selected adapter package
}

type ChartCompileError =
  | { readonly kind: "unsupportedCapability"; readonly missing: readonly ChartCapability[] }
  | { readonly kind: "schemaMismatch"; readonly slotId: string; readonly detail: string }
  | { readonly kind: "representationBudgetExceeded"; readonly expectedMarks: number; readonly limit: number }
  | { readonly kind: "inaccessibleInteraction"; readonly interaction: string; readonly detail: string }
  | { readonly kind: "staticOutputUnavailable"; readonly format: string }
  | { readonly kind: "invalidSemanticCombination"; readonly detail: string };
```

An unsupported capability is a typed failure. The selector may choose another admitted renderer or a released table/narrative fallback; it may not silently turn a candlestick into a line, drop an annotation, remove keyboard access, change a UTC scale into local time, or sample undisclosed rows.

`ChartEvent` is also a closed semantic union: inspect a released object/evidence reference, change viewport, select a semantic key, brush a temporal interval, request exact values, open evidence, draft an annotation, drill through a released query, or **propose** a released Action. The host reopens the current Frame and policy for every consequential continuation. The renderer never receives an internal Ontology port or an Action executor.

## Adapter design

### Shared preparation pipeline

Both adapters consume exactly the same prepared columns and controlled state:

```text
authorized WorldFrame / immutable AnalysisRun
  -> validate slot schema, units, cut, rights, and null meanings
  -> choose viewport and representation under a named policy
  -> execute through the governed query/analytics port
  -> produce columnar PreparedChartData + RepresentationProof
  -> select an admitted renderer by required capabilities and target
  -> compile a private render plan
  -> render + semantic HTML controls/table/narrative
  -> emit closed ChartEvent values back to the host
```

The representation stage precedes renderer selection. A ten-million-row observation manifest should normally become a pixel-aware min/max envelope or density result with an explicit proof, not ten million browser marks. This keeps exports, accessibility, cross-renderer parity, and explanations honest. ECharts progressive rendering is still valuable when the prepared result is large, but it is a paint strategy, not permission to hide what the chart represents.

The selector is a pure policy over required capabilities, output target, admitted adapter versions, accessibility mode, and budgets. Renderer identity is recorded in telemetry and artifacts but is not part of a release. Selection changes therefore do not republish ontology meaning.

### ECharts 6 adapter

The adapter imports only admitted modules from `echarts/core`, the required chart/component/feature packages, and one renderer. It constructs a `ComposeOption` union from those exact imports. Full-package imports are rejected by dependency-cruiser or ESLint, not by a test file.

The initial profiles are code-split:

| Profile | ECharts modules | Intended use |
|---|---|---|
| `common` | line, bar, scatter, pie only if a released journey needs it; grid, dataset, tooltip, legend, axis pointer, data zoom; SVG and Canvas chosen by target | Launch charts and static exports |
| `market` | candlestick, line, bar, custom where unavoidable; multiple grids, matrix, axis pointer, brush/data zoom | OHLC, volume, studies, depth, synchronized market panels |
| `network` | graph, Sankey, chord, tree, treemap, visual map | Operational relationships and hierarchy |
| `spatial` | map, lines, scatter/effect scatter, geo, visual map | Bounded GeoJSON/SVG thematic views |

The React host owns one `div`, one `echarts.init`/dispose lifecycle, `ResizeObserver`, theme/locale changes, and the semantic event bridge. It never accepts an options prop from a caller. Updates originate from a validated `ChartRenderPlan`; event listeners are removed on replacement; `clear`/`dispose` behavior is covered by the leak journey. The application keeps selection, viewport, and focus state outside the ECharts instance so that rerender, export, navigation, and renderer changes are reproducible.

Server output is an ECharts SVG string plus Zoen's accessible narrative/table and an immutable evidence footer. On a capable browser, React replaces or enhances the static graphic with a client instance while preserving the same controlled state. This is progressive enhancement, not claimed DOM hydration. Email and messaging use the static artifact plus text/table fallback; they never ship an interactive ECharts runtime.

ECharts tooltips and labels use plain text or narrowly generated rich-text tokens. HTML tooltip rendering, arbitrary formatter functions, untrusted SVG, arbitrary image URLs, and runtime plugin registration are rejected. `graphic` and `custom` series are allowed only inside audited adapter implementations for a named semantic capability; a release cannot request arbitrary drawing code.

### TanStack Charts adapter

The evaluation adapter uses exact subpath imports, especially `@tanstack/charts/react`, and compiles the same closed fields into marks, channels, scales, views, interactions, and semantic annotations. SVG is the default. Canvas or mixed marks are selected only when the plan declares the required rendering capability and still supplies the semantic SVG/HTML interaction layer.

React controls selection, cursor, brush, zoom, and linked-view state. Full SVG is the expected SSR path. The adapter uses TanStack's accessible legend/slider/focus mechanics but still supplies Zoen's narrative and exact-value table because a chart's visual semantics are not an adequate substitute for its underlying evidence.

No TanStack transform may become undeclared analytics. Layout-only transforms are adapter concerns; any aggregation, sample, density, financial study, or material derived value must match the shared prepared result and `RepresentationProof`. Live force-network interaction remains outside this adapter until the capability corpus proves a deterministic controller and keyboard equivalent.

### Future GPU adapter

A GPU engine enters only for a named workload that Canvas plus bounded representation cannot meet: millions of simultaneously meaningful marks, 3D/terrain, dense geospatial tiles, or a scientific volume. It must consume the same prepared-data contract, emit the same semantic events, provide a non-GPU accessible/static equivalent, survive device/context loss, and pass deterministic export and denial journeys. WebGL is not selected for visual prestige.

`echarts-gl@2.1.0` is not admitted because the tagged source license and npm license metadata disagree and the official tracker records an ECharts 6/zrender 6 ESM import failure. A future fixed release may compete with deck.gl, MapLibre, regl-based implementations, or another engine behind the port; no candidate is preselected.

## Accessibility is a host capability, not an option flag

Every interactive chart surface must provide:

- a concise label, purpose, temporal basis, units, knowledge cut, freshness, and representation disclosure;
- an exact-value table whose rows are the authorized prepared result, with virtualization only for rendering and no client-hidden forbidden fields;
- keyboard access to series, points or meaningful aggregates, legend visibility, zoom, pan/brush, annotation, reset, evidence, and action proposal;
- visible focus, screen-reader announcements for controlled changes, reduced-motion behavior, forced-colors legibility, touch targets, and Escape dismissal for transient content;
- an alternative narrative that communicates trend, extrema, gaps, uncertainty, and material annotations without claiming model-generated prose is the data;
- identical authorization in visual, table, narrative, tooltip, export, and channel-flattened forms.

For ECharts, Zoen owns a semantic control rail and synchronized DOM table. Pointer events from the canvas update controlled state; keyboard events on the control rail issue corresponding semantic commands through `dispatchAction` or a recompiled plan. The ECharts canvas/SVG is an image-like presentation, not the sole interactive accessibility tree. TanStack's stronger native interaction semantics reduce this layer but do not remove the table or narrative contract.

The admission target is WCAG 2.2 AA across the complete experience, not a vendor checklist.

## Evidence gates

All product verification is through journeys using the real compiled application, real browser, real PostgreSQL/Parquet/query path, and exact dependency lock. There are no mocked renderer instances or unit-test snapshots. Import restrictions live in dependency-cruiser/ESLint. Benchmarks and static source checks may supplement journeys but cannot replace them.

### G0 — dependency and license admission

- Exact version, tarball integrity, license text, provenance, lifecycle scripts, transitive dependencies, advisories, and SBOM are recorded.
- Production imports resolve only through `ChartRendererPort`; no application/release package imports ECharts or TanStack types.
- ECharts imports are modular and the production graph contains no `echarts-for-react`, `echarts-gl`, or full-package convenience barrel.
- A dependency update is one reviewed family at a time and reproduces every affected artifact.

### G1 — canonical semantic corpus

One immutable corpus is admitted through the real path and covers at least:

- line, area, bar, scatter, stacked and grouped comparison;
- UTC and zoned time, daylight-saving boundaries, gaps, null meanings, decimals, negative values, log-scale refusal, units, and uncertainty bands;
- synchronized multi-panel series, brush/zoom, linked selection, semantic annotations, evidence reopening, and static export;
- OHLC/candlestick, volume, two governed studies, depth/order book, and high-frequency viewport change;
- tree, Sankey, force network, chord, treemap, GeoJSON choropleth, routes, heatmap/density, calendar, and matrix layout where the adapter claims support;
- malicious labels, bidirectional text, very long text, withheld fields, revoked rights, stale Frames, no-data, partial-data, and renderer failure.

The journey asserts semantic values, scales/domains, unit labels, time basis, selection identities, annotation/evidence bindings, accessible output, and export metadata. Pixel identity is not required; semantic equivalence is.

### G2 — representation honesty

The query/preparation layer, not the renderer, proves source count, represented count, prepared count, expected marks, algorithm version, preserved invariants, and disclosure. At minimum:

- ten million ordered ticks become a viewport-bounded envelope of at most roughly two marks per horizontal pixel while preserving first, last, min, max, ordering, and exact visible count;
- one hundred thousand scatter observations become a declared density/hexbin result or bounded sample with exact aggregate accounting;
- one hundred thousand OHLC rows open into a bounded viewport of approximately two thousand candles, with zoom fetching a new authorized slice rather than preloading the universe;
- totals, extrema, temporal gaps, and null/withheld distinctions remain equal to the governed result;
- switching renderers cannot change the representation algorithm or its proof.

Any automatic renderer sampling is disabled unless its algorithm and result can satisfy the same recorded contract. ECharts progressive paint may schedule already prepared marks incrementally without changing their values.

### G3 — interaction and accessibility

Real Chromium, Firefox, and WebKit journeys use keyboard only, pointer, touch emulation, a screen-reader-oriented accessibility tree assertion, forced colors, 200% zoom, and reduced motion. They prove:

- every visual operation has a named keyboard/DOM equivalent;
- focus order and restoration survive updates, renderer replacement, and navigation;
- tooltips can be opened without hover and dismissed with Escape;
- legend filtering, brush/zoom, point inspection, reset, evidence opening, and Action proposal remain semantic controlled events;
- the exact-value table and narrative remain available with JavaScript disabled for static server output;
- withheld or newly revoked information appears nowhere, including labels, ARIA descriptions, tooltip caches, Canvas backing data, exports, and event payloads.

No renderer is promoted with a known critical keyboard or disclosure gap.

### G4 — SSR, export, and channel parity

- The server produces deterministic SVG for the corpus with no browser global.
- Client enhancement preserves document/data digests, visible viewport, selection, table, and narrative; there is no duplicate accessibility tree.
- SVG and PNG exports pin release, Frame, result, representation, adapter/version, theme, locale, timezone, dimensions, and digest.
- Email receives a static visual plus accessible text/table. WhatsApp and Telegram receive readable text and an optional authorized image/file; no interaction is implied.
- A renderer outage or unsupported target selects the released fallback without changing the answer.

### G5 — performance, bundle, and lifecycle

Reference hardware, browser, viewport, thermal state, dataset digests, production build flags, and measurement tooling are recorded with results. Initial budgets are deliberately demanding and may tighten after the first product corpus:

- a future ordinary TanStack renderer route adds no more than 60 KiB gzip excluding React and shared application code;
- each ECharts specialist route adds no more than 200 KiB gzip, and ordinary navigation does not preload it;
- no route downloads both engines by default;
- p95 pointer-to-visual-response is below 16.7 ms on the reference desktop and 33 ms on the reference mobile profile for the admitted mark budget;
- ordinary controlled updates finish below 50 ms p95 and do not create browser long tasks above 50 ms during sustained pan/zoom;
- first static meaning is available from server output before the interactive engine loads;
- one hundred mount/update/theme/resize/unmount cycles leave no event listeners, observers, canvases, workers, or retained prepared datasets, and post-GC retained heap remains within a documented 10% noise envelope;
- resize, hidden-tab return, device-pixel-ratio change, context loss where applicable, and cancellation preserve state and do not duplicate effects.

The ECharts home-page claim of ten-million-point realtime rendering and the TanStack bundle table are hypotheses for these journeys, not accepted outcomes.

### G6 — compiler refusal and security

Journeys submit unknown capabilities, incompatible scales, invalid units, formatter-like strings, markup, external URLs, oversized marks, malicious SVG/text, and unsupported static targets. They must produce typed errors or a named safe fallback. They must never pass untrusted values into HTML, dynamic code, `register*`, custom series code, or a renderer callback.

CSP remains restrictive. Exports escape labels. Representation algorithms are deterministic. Telemetry records renderer/version, capability profile, counts, timings, failures, and digests, but never upgrades a rendered result into evidence or authority.

### G7 — TanStack production promotion

TanStack may become the default ordinary renderer only when all previous gates pass and:

1. its exact-pinned adapter covers every ordinary-chart corpus item with no P0/P1 semantic, accessibility, SSR, export, or lifecycle gap;
2. two consecutive deliberate TanStack minor upgrades pass without changing `ChartDocument`, the prepared-data contract, or released artifacts;
3. the project publishes a stable API line, or Zoen explicitly accepts an internal long-lived version freeze with a measured maintenance budget;
4. large-data journeys demonstrate that server preparation plus its selected SVG/Canvas/mixed mode meets the ordinary product budgets;
5. the resulting user experience is materially better—accessibility, first meaning, composition, authoring, or bundle—not merely newer.

Promotion adds a second admitted production adapter; it does not rewrite charts or expose a renderer choice to users. ECharts remains the named specialist unless TanStack later proves the same profiles more simply.

## Selection policy after promotion

| Required profile | Default renderer | Reason |
|---|---|---|
| Ordinary line, bar, area, scatter, comparison, authored annotation, small hierarchy, generated mini-app chart | TanStack Charts, SVG first | Strong semantic grammar, React ownership, SSR, mixed rendering, accessibility, and smaller common bundle |
| Static server SVG for ordinary views | TanStack Charts | Direct deterministic SVG/React path |
| Dense prepared marks, incremental append, market multi-panel, candlestick/depth, matrix, rich data zoom | ECharts | Progressive pipeline, native financial/controller primitives, and mature Canvas implementation |
| Draggable/roaming force graph, chord, broad operational network | ECharts | Native interactive controller and chart breadth |
| Bounded thematic vector map | TanStack for ordinary authored map; ECharts for dense/effect/roaming profile | Capability and bundle decide; neither becomes the future tiled GIS engine |
| Email or messaging | Neither in the recipient runtime; use a server-rendered `ChartArtifact` plus text/table | Channels must carry meaning without JavaScript |
| GPU/tiles/3D | No admitted renderer initially | Open a new evidence-gated port decision |

The selector does not choose by row count alone. It receives prepared mark count, update rate, interaction profile, output target, accessibility requirements, and admitted capabilities. A dense source may produce a tiny honest representation; a small network may still require an ECharts controller.

## Palantir and Bloomberg horizon

### What Palantir makes clear

Palantir's public Workshop and Quiver material treats charts as parts of an analysis/action environment: object and time-series inputs, units, saved analyses, reusable derivations, multiple canvases, filtering, rolling/statistical/signal operations, embedding in Workshop, and connections from charts to Actions. The lesson is not to reproduce every widget inside `ChartDocument`. It is to connect released data, analysis, presentation, evidence, and Action through stable references.

Zoen's parity path is therefore:

- `ChartDocument` binds released object/field/unit meaning rather than raw column labels;
- `AnalyticsPlan` owns reusable transforms and studies, with exact inputs and output artifacts;
- `WorldFrame` pins rights, time, evidence, knowledge cut, and visible dense manifests;
- cross-filtering and drill-through emit semantic query/state events;
- a consequential selection can propose one released Action and open the ordinary `ActionCase`;
- Workshop composes charts, tables, forms, Cases, Watches, Scenarios, and navigation without acquiring ambient authority.

Chart-library breadth alone would not provide Quiver or Workshop parity. The analysis graph, saved state, explanation, permissions, collaboration, and Action loop are the product.

### What Bloomberg makes clear

Bloomberg's official charting and BQuant materials emphasize multi-instrument comparison, linked workspaces, real-time updates, templates and shortcuts, annotations, export/share, collaborative work, studies, backtesting/optimization, maps, and programmable applications over entitled market data. ECharts 6 is the more credible immediate substrate for the visible dense/financial portion, but it provides none of the decisive data, rights, news, identifiers, research, execution connectivity, or professional network.

Zoen preserves that horizon by making these separate capabilities:

- a finance pack defines instruments, calendars, corporate actions, currencies, units, market states, and released studies;
- immutable Parquet manifests and `WorldFrame` cuts make a displayed historical slice reproducible;
- streaming ingestion and Watches update material state without treating transient pixels as truth;
- market workspaces persist semantic layout, instruments, linked cursors, viewports, studies, annotations, and evidence—not ECharts option JSON;
- annotations are first-class drafts/releases with author, time, object/event/evidence bindings, and visibility;
- replay, comparison, scenario, backtest, and optimization are `AnalysisRun` artifacts with exact code/plan, data, environment, costs, and results;
- sharing reopens authorization for the recipient instead of sharing a screenshot as authority;
- a chart selection may form an order or other Action proposal, but execution and Settlement remain separate governed products.

This is maximum ambition with honest sequencing. Launching ECharts does not make Zoen Bloomberg. Owning the semantic and evidence contracts means future terminal-grade experiences do not require migrating released Worlds when the rendering frontier changes.

## Explicit non-decisions and rejected shortcuts

- **No public renderer choice.** Users choose an experience and perhaps an accessible/view style; implementation selection is internal.
- **No vendor configuration in releases.** An `echartsOption`, TanStack scene, Vega/Vega-Lite spec, Plotly figure, or arbitrary JSON escape hatch would make the renderer the ontology.
- **No client-side analytics as truth.** Renderer transforms and callbacks do not calculate material domain values.
- **No `echarts-for-react`.** Its convenience is smaller than the lifecycle, policy, and dependency surface it adds.
- **No `echarts-gl` yet.** Current compatibility and license evidence is insufficient.
- **No premature second production engine.** TanStack stays in EvaluationWorld until promotion evidence exists.
- **No fake large-data claim.** Every display records representation accounting; progressive painting is not row-level honesty.
- **No fake accessibility claim.** `role="img"`, an auto-generated description, or decals do not provide keyboard-equivalent analysis.
- **No fake GIS claim.** GeoJSON thematic charts are not tiled maps, spatial editing, routing, or terrain.
- **No chart-triggered writes.** Interaction forms an intent; only a released Action through the Door/World/Case path can commit.

## Primary-source ledger

### TanStack Charts

- [Official repository and tagged source](https://github.com/TanStack/charts)
- [0.x stability policy](https://github.com/TanStack/charts/blob/v0.16.0/docs/stability.md)
- [Overview and grammar](https://tanstack.com/charts/latest/docs/overview)
- [React adapter](https://tanstack.com/charts/latest/docs/framework/react/adapter)
- [Accessibility](https://tanstack.com/charts/latest/docs/guides/accessibility)
- [Large data](https://tanstack.com/charts/latest/docs/guides/large-data)
- [SSR and hydration](https://tanstack.com/charts/latest/docs/guides/ssr-and-hydration)
- [Rendering and export](https://tanstack.com/charts/latest/docs/reference/rendering-and-export)
- [Intervals and financial charts](https://tanstack.com/charts/latest/docs/examples/intervals-and-financial)
- [Networks and hierarchies](https://tanstack.com/charts/latest/docs/examples/networks-and-hierarchies)
- [Maps and spatial charts](https://tanstack.com/charts/latest/docs/examples/maps-and-spatial)
- [Annotations and overlays](https://tanstack.com/charts/latest/docs/examples/annotations-and-overlays)
- [Interactions and selections](https://tanstack.com/charts/latest/docs/guides/interactions-and-selections)
- [View composition](https://tanstack.com/charts/latest/docs/reference/view-composition)
- [Themes and styling](https://tanstack.com/charts/latest/docs/guides/themes-and-styling)
- [AI authoring](https://tanstack.com/charts/latest/docs/guides/ai-authoring)
- [Official controlled bundle comparison](https://github.com/TanStack/charts/blob/v0.16.0/docs/comparison.md)
- [npm registry metadata for `@tanstack/charts`](https://registry.npmjs.org/@tanstack%2Fcharts/latest)
- [GitHub repository metadata](https://api.github.com/repos/TanStack/charts)
- [npm download API, inspected week](https://api.npmjs.org/downloads/point/2026-08-23:2026-08-29/@tanstack%2Fcharts)

### Apache ECharts

- [Official site and feature overview](https://echarts.apache.org/en/)
- [Official repository](https://github.com/apache/echarts)
- [ECharts 6.1.0 release](https://github.com/apache/echarts/releases/tag/6.1.0)
- [Changelog](https://echarts.apache.org/en/changelog.html)
- [ECharts 6 features](https://echarts.apache.org/handbook/en/basics/release-note/v6-feature/)
- [ECharts 6 upgrade guide](https://echarts.apache.org/handbook/en/basics/release-note/v6-upgrade-guide/)
- [Modular import and tree shaking](https://echarts.apache.org/handbook/en/basics/import/)
- [Canvas versus SVG](https://echarts.apache.org/handbook/en/best-practices/canvas-vs-svg/)
- [ARIA guidance](https://echarts.apache.org/handbook/en/best-practices/aria/)
- [Server-side rendering](https://echarts.apache.org/handbook/en/how-to/cross-platform/server/)
- [Events and actions](https://echarts.apache.org/handbook/en/concepts/event/)
- [Dataset](https://echarts.apache.org/handbook/en/concepts/dataset/)
- [Data transforms](https://echarts.apache.org/handbook/en/concepts/data-transform/)
- [Axes](https://echarts.apache.org/handbook/en/concepts/axis/)
- [Custom series](https://echarts.apache.org/handbook/en/how-to/custom-series/)
- [Tagged core instance/source API](https://github.com/apache/echarts/blob/6.1.0/src/core/echarts.ts)
- [Tagged ARIA implementation](https://github.com/apache/echarts/blob/6.1.0/src/visual/aria.ts)
- [Tagged candlestick series](https://github.com/apache/echarts/blob/6.1.0/src/chart/candlestick/CandlestickSeries.ts)
- [Tagged graph series](https://github.com/apache/echarts/blob/6.1.0/src/chart/graph/GraphSeries.ts)
- [npm registry metadata for `echarts`](https://registry.npmjs.org/echarts/latest)
- [GitHub repository metadata](https://api.github.com/repos/apache/echarts)
- [npm download API, inspected week](https://api.npmjs.org/downloads/point/2026-08-23:2026-08-29/echarts)

### ECharts GL admission evidence

- [ECharts GL 2.1.0 release](https://github.com/ecomfe/echarts-gl/releases/tag/2.1.0)
- [Tagged license](https://raw.githubusercontent.com/ecomfe/echarts-gl/2.1.0/LICENSE)
- [Tagged package metadata](https://raw.githubusercontent.com/ecomfe/echarts-gl/2.1.0/package.json)
- [npm registry metadata for `echarts-gl`](https://registry.npmjs.org/echarts-gl/latest)
- [Official ECharts 6 ESM compatibility issue](https://github.com/ecomfe/echarts-gl/issues/574)

### Third-party wrapper metadata

- [npm registry metadata for `echarts-for-react`](https://registry.npmjs.org/echarts-for-react/latest)

### Product horizon

- [Palantir Workshop time-series analysis](https://www.palantir.com/docs/foundry/workshop/widget-time-series-analysis)
- [Palantir Quiver overview](https://www.palantir.com/docs/foundry/quiver/overview)
- [Palantir time-series visualization in Quiver](https://www.palantir.com/docs/foundry/quiver/timeseries-visualize)
- [Palantir Workshop widgets](https://www.palantir.com/docs/foundry/workshop/concepts-widgets)
- [Palantir chart-to-Action announcement](https://www.palantir.com/docs/foundry/announcements/2023-08)
- [Bloomberg charts](https://professional.bloomberg.com/products/bloomberg-terminal/charts/)
- [Bloomberg Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/)
- [Bloomberg BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/)
- [Bloomberg News](https://professional.bloomberg.com/products/bloomberg-terminal/news/)
- [W3C WCAG 2.2](https://www.w3.org/TR/WCAG22/)

## Revalidation rule

Re-run the registry/source inspection and every applicable gate when either renderer version changes, an adapter claims a new capability, a new output target is added, or a representative workload changes materially. A newer release, a larger star count, or a vendor demo never changes the architecture by itself. Promotion and replacement require recorded product evidence against the same semantic corpus.
