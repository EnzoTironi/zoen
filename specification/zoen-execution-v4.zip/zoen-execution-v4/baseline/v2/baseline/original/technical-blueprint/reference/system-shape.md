# System shape

## Decision

Zoen is a TypeScript modular monolith on Node.js, packaged as one signed image and initially deployed as one Fly Machine with two supervised processes. It contains exactly three products, one authority-commit protocol, one deliberately weaker progress-commit protocol, one public semantic catalog, and one deployable Fly application. Live feeds, connector runners, data flows, packs, cells, agents, and developer tools extend those products; none becomes a fourth product or a second authority. The products are ownership boundaries, not a mandate for one process each:

1. **Door** uses Better Auth to prove an account, session, client, and assurance level. It never grants World authority.
2. **Eve** owns the relationship: settled interaction, Focus, model attempts, attention arbitration, wording, channel behavior, and Living World presentation.
3. **Ontology** owns executable meaning, identity resolution, temporal truth, evidence, policy, domain Actions, Cases, Watches, Notices, receipts, Effects, and Settlements. CLI, API, and MCP are its native faces.

All Zoen-owned application and domain code is TypeScript. Native databases, WebAssembly libraries, DuckDB, browser engines, and managed services do not violate this rule; they are replaceable infrastructure behind Zoen-owned ports.

Rust is not installed speculatively. It may enter only as a measured implementation of an existing pure port. It cannot change the public grammar or acquire authority credentials merely because it is faster.

## Irreducible loop

```text
authority-free Focus
    -> fresh IdentityProof
    -> one purpose-bound WorldSession
    -> WorldFrame
         -> optional entitled LiveObservation overlay
              -> exact CapturedObservation -> admitted Action dependency
         -> answer + explanation
         -> domain Action -> ActionCase -> DecisionReceipt
                                            -> EffectIntent -> Settlement
         -> Watch -> Notice -> Eve arbitration -> delivery observation
         -> read-only Scenario -> fresh live ActionCase if applied
```

The same identifiers, release, temporal basis, evidence, and outcome algebra survive every surface. A renderer may change; authority and meaning may not.

## Runtime

Each Fly Machine runs one signed OCI image and two supervised Node 24 processes because Eve's supported self-hosted contract is a generated Nitro service:

```text
Fly Machine / one signed image
├── Hono edge + Ontology authority process
│   ├── public :8080
│   │   ├── /api/auth/*                   Better Auth Door
│   │   ├── /eve/*                        raw proxy -> 127.0.0.1:4274
│   │   ├── /.well-known/workflow/*       raw proxy -> 127.0.0.1:4274
│   │   ├── /ontology/v1/*                released JSON API
│   │   ├── /ontology/mcp                 MCP Streamable HTTP
│   │   └── web assets and SSE
│   ├── loopback 127.0.0.1:8081           authenticated Eve capability server
│   ├── signed Restate listener :9080     ZoenEffect only
│   ├── PostgreSQL lease coordinators     Ontology-owned work only
│   └── bounded worker threads            DuckDB and release replay
└── Eve Nitro process
    ├── eve start --host 127.0.0.1 --port 4274
    ├── durable sessions, turns, steps, hooks, streams and schedules
    ├── ask_question + generated inspect_*/propose_* tools only
    ├── explicit disabled SandboxBackend; no byte attachment staging
    ├── /eve/v1/kapso                     Kapso WhatsApp
    ├── /eve/v1/telegram                  native Eve Telegram
    ├── /eve/v1/email                     Resend bridge
    └── EveOntologyClient -> 127.0.0.1:8081

isolated operational databases
├── eve_workflow                         Eve Workflow 5 state only
└── eve_channels
    ├── kapso                            migrator-owned schema, DML-only runtime role
    └── email                            migrator-owned schema, DML-only runtime role

isolated capability runners
├── signed ConnectorArtifact runs with brokered credentials and egress
├── MiniAppArtifact build/runtime sandboxes
└── ExecutorArtifact, model, and ActionPlannerArtifact runs
```

The Hono process starts the exact pinned Eve command without a shell, gives it an explicit environment allowlist, publishes global readiness only after Eve health and authority prerequisites pass, stops admission when either runtime is unhealthy, forwards termination, waits for bounded drain, and exits if Eve exits. It does not hide repeated crashes with an in-process restart loop; Fly restarts the Machine.

Hono is the only public socket. Its proxy preserves methods, raw bytes, signature-relevant headers, cookies, status, streaming, backpressure, and cancellation and never parses then reconstructs a provider payload. The Restate SDK owns its separate protocol listener inside the Hono process. Fly exposes it only to Restate and the handler verifies request identity.

Eve uses exact-pinned `@workflow/world-postgres@5.0.0-beta.40` in a dedicated `eve_workflow` database and role. The default local file world is development/EvaluationWorld-only. No production conversation route is enabled until the pinned Eve/Workflow pair passes crash, parked-run, duplicate-job, backup/restore, and upgrade evidence. Eve's Workflow history is the conversation execution truth; `InteractionJournal` is an Eve-owned typed materialization of stable session, turn, step, message, and attempt identifiers, not an independent resumption log.

At launch, authored `disableTool()` sentinels remove `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, root `agent`, and `todo`. Zoen adds none of `glob`, `grep`, experimental `Workflow`, or `sleep`, and declares no skills or connections, so their conditional tools are absent. `ask_question` remains. The only authored capabilities are generated `inspect_*` and `propose_*` tools backed by `EveOntologyClient`; each declares an approval policy explicitly, but Door, disclosure, Case, and idempotency remain the authority. A custom fail-closed disabled `SandboxBackend` is configured directly, so Eve can never fall back through `defaultBackend()`.

Eve stages byte-backed AI SDK file parts in `/workspace/attachments` before its first model step. Zoen therefore never passes such a part into a session: ingress either rejects it or resolves it through a Hono-owned quarantine/evidence path and supplies only authorized text plus an opaque reference. Static gates forbid `ctx.getSandbox()` and the staging path; journeys prove an accidental sandbox request fails closed without affecting the ordinary text/reference path.

Chat SDK bridge state uses a Zoen-owned `ZoenChatStateAdapter` that implements the exact public `chat@4.39.0` `StateAdapter` over raw `pg`. A dedicated `eve_channels` database contains isolated `kapso` and `email` schemas. Only the migrator can run DDL; each runtime role receives DML only in its schema. `@chat-adapter/state-pg` is rejected at launch because its `connect()` performs unqualified runtime DDL and exposes no schema or migration switch. Telegram remains Eve-native and does not acquire either bridge schema merely for symmetry.

Eve receives no Ontology database, object-store write, release-signing, or Restate credential. `EveOntologyClient` sends a closed request to loopback `:8081` with boot-, request-, audience-, principal-, purpose-, operation-, deadline-, basis-, and body-digest-bound proof; the Hono adapter opens a fresh `WorldSession` and calls the ordinary Ontology application port. This limits ordinary reach and accidental coupling, but two same-Machine processes are not a security sandbox against total Machine compromise. Strong adversarial process isolation would require separate UIDs/kernel controls or separate Machines and its own evidence.

Isolated runners receive typed leases through a capability broker, not internal repositories. Launch connectors may be image-pinned TypeScript implementations, but they still use the `ConnectorRun` protocol and acquire a narrow credential and egress lease. Third-party code never loads into the authority process. If a native DuckDB failure ever demonstrates unacceptable process blast radius, the identical TypeScript adapter moves to a supervised Node child process; that is containment, not a new product or semantic protocol.

No in-memory leader, timer, cache, or lock is required for correctness. Ontology PostgreSQL owns its leases, idempotency, cuts, and coordination; Eve's isolated Workflow world owns only Eve session execution. `LISTEN/NOTIFY` is only a wake hint. Restarting either process may discard caches and live token chunks, but never committed World truth or a completed Eve step. Redis is forbidden in every role.

## Deep modules

The code is split by what it knows, not by execution stage:

```text
foundation
  opaque values, Result, canonical bytes, clock/nonce interfaces

release-model
  total typed IR, schemas, semantic IDs, catalog and surface facets

door
  Better Auth configuration, credential verification, IdentityProof

ontology
  admission       IdentityProof -> WorldSession
  truth           evidence, identity, belief, Frame, explanation
  semantics       interfaces, object sets, functions and released plans
  agency          Actions, Cases, contributions, receipts
  attention       Watches, checkpoints, Notices
  data            live capture, DatasetVersion, data flow, quality and lineage
  automation      WorkflowInstance, headless AgentRun and ChangeSubscription
  evolution       compile, prove, prepare, activate
  external        EffectIntent, reconciliation, Settlement
  federation      pack installation, cell routing and federated exchange
  commit          AuthorityCommit for meaning; ProgressCommit for allowlisted operations

eve
  relationship    relationship, Focus and channel binding
  conversation    Eve sessions/turns/steps, typed materializations and context
  spaces          governed multi-party journals, retention and supervision
  attention       silence, merge, defer, timing and delivery
  presentation    released document -> web or excellent plain text

  adapters
  PostgreSQL, Eve Workflow Postgres, channel-state Postgres, Tigris/S3, DuckDB, Cedar, Restate, models, channels
  live gateways, connector/sandbox runners, pack registry and cell directory

surfaces
  Hono API, MCP, CLI client and generated browser client

composition roots
  Hono assembles Door/Ontology; Eve's supported agent build assembles conversation
```

These are deep modules, not one package per noun. A module gets a workspace package only when it needs a separately enforceable export boundary, build target, browser target, or executable.

## Dependency constitution

```text
foundation <- release-model <- ontology
     ^              ^             ^
     |              |             |
    door           eve      adapter implementations
     ^              ^             ^
     └──────── contracts ──────────┘
                    ^
          composition roots
```

- Ontology imports no Hono, Better Auth, Cordis, model SDK, channel SDK, React, Restate, DuckDB, S3 client, or PostgreSQL driver.
- Eve depends on the generated `EveOntologyClient` and shared capability-protocol values, never Ontology repositories, constructors, or authority credentials.
- Door exports only identity proof behavior. It knows no World, membership, delegation, subject, or capability.
- Eve-native hooks and a plain typed `EveAttemptContext` own scoped attempt composition. Cordis is not a launch dependency and may be evaluated only behind the recorded three-need gate.
- Eve's tool surface is allowlisted rather than inherited: disabled default/optional capabilities, a fail-closed disabled sandbox, and generated approval-explicit Ontology tools are enforced in source and build output.
- Adapters implement ports and may depend inward on their types. Domain modules never depend outward on adapters.
- Browser and CLI packages import only generated public contracts.
- The Hono composition root may assemble Door, Ontology, and authority adapters. The Eve composition root may assemble only Eve, channel/model adapters, its Workflow world, the isolated channel-state adapter, and the generated capability client.
- Connector, model, executor, planner, and mini-app runtimes receive only signed capability leases. None imports or receives an authority repository.
- A data-flow scheduler, workflow runtime, or cell directory can wake and route work. PostgreSQL records canonical runs, versions, and transitions.
- Package `exports`, TypeScript project references, ESLint, and dependency-cruiser enforce this graph. These controls prevent honest accidents; they are not a security sandbox.

## Process calls

Calls inside the Hono authority process are ordinary typed function calls. Eve and Ontology cross exactly one internal serialization seam: a closed authenticated HTTP protocol on `127.0.0.1:8081`. It exists because Eve's supported runtime is a separate Nitro process, not because Eve owns a separate ontology. There is no service discovery, public internal API, repository-shaped RPC, or second semantic implementation.

External callers use stable protocols:

- the browser uses JSON commands and SSE presentation events;
- the CLI uses the public Ontology API and Better Auth OAuth device flow;
- hosted MCP uses Streamable HTTP and Better Auth OAuth resource tokens;
- the local MCP stdio bridge is a CLI adapter to the same hosted protocol;
- Hono raw-proxies both complete Eve route families to Nitro; Kapso, native Telegram, and Resend email terminate in Eve at their fixed paths, with Kapso/Resend operational state isolated in `eve_channels`;
- Eve tools call only `EveOntologyClient`; Hono validates the service proof and opens a fresh purpose-bound session for every protected operation;
- Restate invokes only the signed `ZoenEffect` handler.

Released live subscriptions, object-set reads, functions, change subscriptions, data flows, agent runs, finance operations, and pack installation use the same Ontology API grammar. A surface never exposes a connector runner, query engine, artifact registry, cell address, or workflow scheduler as domain authority.

## Semantic application platform

`WorldRelease` publishes `InterfaceDefinition`, `ObjectSetPlan`, `FunctionDefinition`, Actions, Watches, data flows, workflows, agent definitions, and presentation documents as one semantic catalog. The compiler generates idiomatic API, CLI, MCP, Eve, and Living World facets. An interface supplies structural polymorphism across object types. An object-set plan supplies a bounded released query algebra. A function is closed IR, an image-pinned trusted handler, or proposal-only isolated compute. A change subscription is an authorized projection of admitted semantic transitions.

Workshop, notebooks, headless agents, and external SDK clients use these contracts. They can inspect, calculate, subscribe, render, and propose. They cannot submit SQL, mutation plans, connector payloads, Cedar expressions, or authority envelopes. An `ActionPlannerArtifact` may propose a released Action and inputs; Ontology recomputes consequences and opens the ordinary Case.

The developer platform lives in the existing surfaces. Studio in `apps/conversation` owns proposal, semantic diff, EvaluationWorld, proof, app, data-flow, agent, and pack workbenches. `apps/cli` owns headless build, validation, journey, publish, and generated-client commands. Hosted API and MCP expose authorized developer capabilities. A registry distributes immutable `PackArtifact` bytes and signatures; it cannot install, activate, grant, or supply credentials.

## Cells, edge Worlds, and federation

A `CellDirectory` resolves a World to exactly one authority cell and epoch before `WorldSession` admission. Auxiliary read, dense, compute, and edge cells receive signed, expiring capabilities that identify the authority cell and head basis. They do not acquire a World authority role. A cell is a deployment boundary, not a product or a public semantic identity.

An offline site that must make local decisions receives its own edge World and normal `WorldHead`. It can use the same release, packs, Actions, Cases, receipts, and Parquet protocol while disconnected. When connectivity returns, federation exchanges immutable evidence, manifests, proposals, and receipts. Two cells never issue commits for the same World epoch.

`FederationAgreement` is a released and approved contract between Worlds. It pins trust roots, identity and semantic mappings, permitted capabilities, rights, retention, residency, audit, revocation, and expiry. A `FederatedFrame` retains each component World, cell, knowledge basis, disclosure, rights proof, and lineage. It has no invented global cut. A cross-World operation is a protocol of independently committed requests and receipts with explicit partial and compensating outcomes, not a distributed AuthorityCommit.

## Failure domains

Two supervised processes in one Machine are the supported early topology. The boundary reduces coupling and credential distribution but is not, by itself, a hostile-code sandbox. Database roles, filtered environments, least-privilege credentials, realm isolation, purpose-bound sessions, request-bound proofs, and adapter-specific secret leases limit ordinary reach. Split them into separate Machines only for a demonstrated property:

- contractual secret or operator isolation;
- a native crash that harms availability;
- a workload that must scale independently and cannot be bounded locally;
- regulated residency requiring a separate authority cell.

The split follows an existing deep port. It never follows a noun list and never distributes `AuthorityCommit`.

## Scaling without redesign

1. Add identical Fly Machines. PostgreSQL leases distribute background work; all public commands remain idempotent.
2. Partition append-heavy interaction, transition, and manifest metadata only after measured table pressure.
3. Keep authoritative reads and writes in one region and on the primary. Replicas may serve explicitly historical, cut-pinned exports, never an allegedly current Frame.
4. Route a large World to a dedicated PostgreSQL authority cell before creating its WorldSession. A transaction never spans cells.
5. Add read, dense, live-feed, connector, model, executor, or edge cells behind existing lease-bearing ports when isolation, latency, residency, or independent load requires them.
6. Keep dense points in Parquet, live ticks outside authority, and admit only captures, manifests, DatasetVersions, and other semantic changes into the World cut.

The per-World cut deliberately serializes meaningful authority. Reopen that model only after one World sustains more than 500 authority commits per second or its p99 head-lock wait exceeds 50 ms for 15 minutes after non-semantic work has been removed or batched.
