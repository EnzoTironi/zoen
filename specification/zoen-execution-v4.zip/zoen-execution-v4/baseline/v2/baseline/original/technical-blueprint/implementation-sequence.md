# Implementation sequence

## Sequencing rule

Maximum ambition is an end-state property. The build order must produce one whole, truthful user outcome at a time while preserving explicit target seams for the public capability categories documented by Palantir and Bloomberg. No slice exists only to install infrastructure. No future capability is allowed to bypass the authority, evidence, temporal, disclosure or release contracts established earlier.

S0 through S6 produce the first coherent personal/shared product. S7 through S11 deliberately expand the possibility envelope into live and historical data, governed data flows, Workshop applications, agents, programmable analytics, a developer ecosystem, institutional cells, federation, and the complete finance-execution grammar. `Later` is an implementation order, not an architectural ceiling.

## S0: Constitutional skeleton

**User outcome:** a person can sign in, create a private World, enter it for an explicit purpose, and receive an honest empty-state response from Eve, API, CLI and MCP.

Build:

- pnpm workspace, Node 24, TypeScript 6.0.3, Ultracite pedantic, dependency-cruiser and Knip;
- three product roots and one OCI image containing two supervised Node processes: Hono public `:8080`, Eve capability loopback `127.0.0.1:8081`, private signed Restate `:9080`, and the supported exact-pinned `eve@0.52.0` Nitro output on `127.0.0.1:4274`;
- raw path-preserving Hono proxying for `/eve/` and `/.well-known/workflow/`, `eve build`/`eve start` supervision, health propagation, bounded drain, and whole-Machine fail-fast behavior;
- closed `EveOntologyClient`/capability-server protocol with boot-, request-, audience-, principal-, purpose-, operation-, deadline-, basis-, and body-digest-bound proofs; Eve receives no Ontology repository or authority credential;
- explicit `disableTool()` sentinels for Eve's `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, and `todo`; no `glob`, `grep`, `Workflow`, `sleep`, skills, or connections; one fail-closed custom disabled `SandboxBackend` so `defaultBackend()` is unreachable;
- Better Auth Door and stable Better Auth subject → `PrincipalId` mapping;
- PostgreSQL roles/schemas, raw `pg`, SQL migration command, full `WorldHead`, a dedicated `eve_workflow` database/role that cannot equal an Ontology connection, and a separate `eve_channels` database whose `kapso` and `email` schemas have migrator-owned DDL and runtime DML-only roles;
- planted canonical `WorldRelease`, JCS identity, `AuthorityCommit`, `ProgressCommit`, commit envelope and outbox skeleton;
- one EvaluationWorld, same-image proof skeleton, structured logs and traces.

Proof:

- auth expiry/revocation, cross-role SQL denial, idempotent World creation, process kill at every commit boundary, Hono/Eve kill and readiness, both proxied route prefixes, raw body/cookie/SSE/cancellation parity, capability-proof replay denial, disabled-sandbox fail-closed behavior, forbidden-tool absence, canonical fixtures, surface semantic-digest parity, signed-image identity. dependency-cruiser and ESLint prove the product/import graph and forbidden Eve imports/calls as static gates; no journey exists only to assert imports.

Delete before exit: every starter route, sample entity, generic CRUD helper, broad database role, warning suppression and unused package.

## S1: One honest Frame

**User outcome:** "What do you know about this?" returns a useful answer with source, valid time, as-known-at cut, uncertainty, gaps and a path into evidence.

Build:

- stable subjects, temporal type assignments and typed links;
- released `InterfaceDefinition`, bounded `ObjectSetPlan` and one pure `FunctionDefinition`;
- immutable raw artifact upload before evidence admission;
- claims, supporting/rival/dependency edges, identity resolution and named belief basis;
- purpose-bound `WorldSession`, Cedar pre-scan disclosure, sparse `WorldFrame`, exact read set and explanation graph;
- one first-class inspect verb projected through Eve, Living World, CLI, JSON API and MCP.

Proof:

- rival claims survive selection; correction never overwrites; valid-time and recorded-time queries differ correctly; a hidden field is absent from discovery, plan, read, result and explanation; old Frame replays after head advancement.

## S2: Eve as one relationship

**User outcome:** Eve remembers what matters across web, WhatsApp, Telegram, and email. It speaks like a trusted person rather than a helpdesk and never carries stale authority forward.

Build:

- Eve durable session/turn/step history and an `InteractionJournal` typed materialization over stable Eve event identifiers, never an independent replay or resumption log; branches and authority-free `Focus` derive from that owner;
- deterministic context compiler over settled Eve history and newly authorized Frames;
- Eve-native hooks and a plain typed `EveAttemptContext` for scoped services, explicit lifecycle/event modes, abort/budget/usage attribution, and cleanup; Cordis is not a launch dependency;
- generated `inspect_*` and `propose_*` Ontology tools only, each declaring `never()`, `once()`, `always()`, or a released input-dependent approval policy explicitly; tool approval improves the interaction but never replaces fresh Door, disclosure, Case, or idempotency checks;
- exact-pinned `ai@7.0.92`, `@ai-sdk/openai@4.0.58`, and `@ai-sdk/anthropic@4.0.49`; direct provider `LanguageModel` values sit behind `ModelPort`, while AI Gateway remains a separately gated profile;
- web streaming over SSE, Kapso `/eve/v1/kapso` through its isolated Chat SDK bridge, native Eve Telegram `/eve/v1/telegram`, and Resend email `/eve/v1/email` through a separate bridge;
- exact-pinned `@workflow/world-postgres@5.0.0-beta.40` in the isolated `eve_workflow` database;
- `ZoenChatStateAdapter` implementing the exact public `chat@4.39.0` `StateAdapter` with raw `pg` and migrator-owned SQL in the dedicated `eve_channels` database; isolated `kapso` and `email` schemas/runtime roles, `streaming: false`, provider-event verification, stable ingress identity, `ChannelIngress` plus outbox before acknowledgement, idempotent delivery into Eve, endpoint binding, and capability-aware rendering; `@chat-adapter/state-pg` is research evidence, not installed code;
- attachment admission that rejects byte-backed AI SDK `file` parts or converts provider/web attachments through a Hono-owned quarantine/evidence path into authorized text and opaque references before Eve session creation; no Eve route can write `/workspace/attachments`;
- Living World focus/deepening transitions from conversation references.

Proof:

- crash during each Eve step, parked wait, hook, stream append, token stream and tool call; repeated startup with parked runs; reconnect, duplicate ingress, provider replay on both sides of acknowledgement, channel switch, focus reopen after membership loss, direct-provider model swap, one settled response per branch, no duplicate runnable Workflow job, Action, or delivery, backup/restore and pairwise Eve/Workflow upgrade, and no hidden chain-of-thought storage. The real channel journeys also prove `StateAdapter` conformance, schema separation, DML-only runtime roles, zero runtime DDL, forbidden tools absent from model discovery, every authored tool's explicit approval, rejected/normalized attachments, no `ctx.getSandbox()` or attachment staging, and deterministic failure if sandbox access is accidentally requested. No production conversation or provider route is enabled until the isolated Workflow store and admission-before-acknowledgement pass kill/replay with real accounts and the open parked-run recovery regression is absent or fixed in the pinned pair.

## S3: Shared Worlds and accountable membership

**User outcome:** a person can invite a partner, family member or colleague, see exactly what they may do, delegate narrowly, and revoke without losing historical accountability.

Build:

- membership, invitation, assurance, delegation chain, purpose and disclosure partitions;
- membership workbench inside Living World, not a separate admin dashboard;
- governed `ConversationSpace` for multi-party discussion with participation, purpose, record, retention, supervision and agent policies that never imply World membership;
- principal-scoped discovery and exports; device/OAuth flow for delegated clients;
- household/team fixture packs using the same grammar as a private World.

Proof:

- concurrent invite acceptance, revoked delegation, multi-device sessions, object/field/evidence separation, no channel-presence promotion, per-participant Frame disclosure in one shared space, legal hold/export policy, and a historical receipt that remains explainable after authority changes.

## S4: Quiet attention

**User outcome:** the World notices a meaningful change and Eve either tells the person well, combines it with related context, waits, or stays silent.

Build:

- released Watch definition, checkpoint, compatibility and materiality;
- semantic `WorldTransition` consumption, one canonical Notice and outbox;
- authorized `ChangeSubscription` over released object-set plans for SSE, Watches and later federation;
- Eve attention arbitration, merge/defer/silence/channel selection, current disclosure on arbitration and immediately before composition;
- Watch management and Notice provenance in Living World.

Proof:

- high-rate evidence produces only released meaningful transitions; concurrent evaluators create one Notice; revoked subscription disclosure closes without leaking a tombstone; delayed Notice loses disclosure safely; channel timeout remains unknown; no raw Parquet point or live tick wakes Eve directly.

## S5: Accountable Action and external reality

**User outcome:** a person or quorum can understand a consequential choice, decide from an authorized view, receive proof of the local decision, and see an honest external outcome.

Build:

- domain Actions, exact dependency set, consequences, expiry and canonical `ActionCase`;
- proposal-only `ActionPlannerArtifact` contract whose output must be decoded and replanned by the released Action;
- principal-specific Case views, `DecisionHandle`, contribution, quorum and stale-case rejection;
- one `AuthorityCommit` for receipt, semantic changes, deterministic `EffectIntent`, events and outbox;
- Restate `ZoenEffect`, provider connectors, attempts, reconciliation and `Observed<DomainOutcome> | Unknown` Settlement.

Proof:

- two differently authorized decision views, malicious planner output, concurrent contributions, duplicate commands, crash before/after provider acceptance, lost acknowledgement, provider idempotency, late callback, connector upgrade and recovery fence.

## S6: Teach once, publish everywhere

**User outcome:** a builder can teach new meaning, inspect the diff, prove it against real journeys, request approval and activate it safely for one World.

Build:

- authored source → closed typed `WorldRelease` IR → `SurfaceManifest`;
- authoring schemas for interfaces, object-set plans, functions, data flows, workflows, agents and artifact references;
- Studio branch, semantic diff, proposal/review, conflict and rebase model;
- deterministic API, CLI, MCP, Eve, Living World, Watch, Case and explanation generation;
- shared Studio/CLI developer protocol for validate, build, journey, semantic diff, proposal and proof;
- isolated EvaluationWorld, ReleaseProof, per-World generation, PreparedActivation and full-head compare-and-swap;
- prior-release reactivation through new proof/preparation, never blind rollback.

Proof:

- malformed/ambiguous release rejection, same semantic digest across surfaces, identical Studio/CLI artifact digest, exact-image evaluation, live credential denial, migration/reprojection catch-up, activation race, stale preparation, upgrade and reactivation.

This establishes Zoen's target seams for the public Palantir Ontology, branching, and OSDK categories; it is not feature parity.

## S7: Dense reality and terminal-grade data foundation

**User outcome:** a person can watch a live entitled market, health, sensor or operational feed, move seamlessly into reproducible history, and ask temporal questions over large series without confusing a transient tick with World truth.

Build:

- `LiveFeedDefinition`, `LiveSubscription`, `LiveObservationEnvelope/Basis`, continuous entitlement checks, sequence/gap and staleness behavior;
- exact `CapturedObservationRef` admission for any Action that relies on a live value;
- signed source `ConnectorArtifact`, brokered credential/egress lease and isolated `ConnectorRun`;
- source/provider contracts, acquisition receipts and four-clock observation model;
- deterministic DuckDB Parquet writer, immutable Zstd segments, manifest DAG, rights provenance, source cursor and compaction;
- `ObservationPlan`, DuckDB worker query adapter, exact numeric/rounding rules, scan budgets and cancellation;
- periodic live-range sealing into raw evidence, Parquet and one admitted manifest; SSE overlays merge visually with the last sealed historical basis;
- positive-grant rights algebra with canonical meet across joins, derivations, models, alerts, exports and executors;
- released `DataFlowDefinition`, PostgreSQL-owned `DataFlowRun`, immutable `DatasetVersion`, field lineage and passed/failed/unknown quality results;
- finance pack foundations: instruments, listings, venues, provider symbology, fields, corporate actions and comparable series;
- released hybrid evidence retrieval with PostgreSQL full-text plus pgvector projection for OAG-style context.

Proof:

- unconflated and latest-value streams, provider sequence gaps, staleness, entitlement revocation while streaming, reconnect from sealed basis, Action capture race, 100 million real-format synthetic points, point-in-time revisions, late/out-of-order batches, entitlement pushdown, rights-meet denial, field lineage, failed/unknown quality, concurrent flow publication, old-cut replay, compaction equivalence, restore with reachable objects, retrieval denial and quality corpus.

Parquet remains permanent. A Rust/DataFusion adapter may compete only on the identical manifests and canonical result corpus.

## S8: Workshop and executable mini-apps

**User outcome:** in conversation or Studio, a person can ask for a purpose-built portfolio cockpit, medication plan, clinic intake, or factory exception board. They can inspect it immediately, refine it, share it under policy and publish it.

Build:

- closed `MiniAppManifest` with layout intent, Frames, tables, charts, forms, Cases, Watches, Scenarios and navigation;
- first-party React renderer using React Aria, TanStack Table/Virtual, React Hook Form, and the released `ChartDocument` contract; modular ECharts 6 is the only launch chart renderer;
- exact-pinned `@tanstack/charts@0.16.0` in EvaluationWorld only, with promotion gates for semantics, accessibility, SSR/export, channels, bundle size, lifecycle, and upgrades;
- draft/proposal/publish lifecycle, provenance, dependency graph, capability request diff and release binding;
- immutable `MiniAppArtifact` and `MiniAppRuntimePort` for richer TypeScript/React presentation;
- object-set, function, live-basis, DatasetVersion and ChangeSubscription components that preserve their released schemas and rights;
- MCP Apps-compatible `ui://` publication, declared app-visible capabilities, content-security metadata, structured/text fallback and Eve/Living World first-party host bridge;
- Rivet Dynamic Apps adapter spike in EvaluationWorld: agentOS sandbox, no ambient authority, portable artifact output, host capability bridge, budgets, immutable build and declarative fallback.

Proof:

- generated app cannot reach PostgreSQL, secrets, metadata endpoint, filesystem or arbitrary egress; hidden data never enters the artifact; every Action opens the normal Case; the identical artifact renders through Eve and an independent MCP Apps host; artifact is replayable/exportable; runtime or UI-host failure falls back usefully; keyboard/mobile/channel deep links work.

The executable contract is part of the target architecture. Rivet becomes the production adapter only after its current Preview runtime and every gate pass.

## S9: Governed playbooks, agents and evaluation

**User outcome:** a person or governed conversation space can ask Zoen to investigate, monitor, coordinate and propose over days without losing context or allowing a conversational or headless agent to become sovereign.

Build:

- released `WorkflowDefinition` as a state machine over Watches, Scenarios, Cases, Actions and Effects;
- durable canonical process state and causality in PostgreSQL; explicit timers/leases/outbox;
- `AgentDefinition`, model/tool policy, context/retrieval plan, budgets, checkpoint and human-judgment nodes;
- released `ModelProfile`, cut-pinned lexical/vector/hybrid `RetrievalPlan`, rights-safe citations and structured `InferenceAttempt`;
- PostgreSQL-owned `HeadlessAgentRun` that opens a fresh purpose-bound WorldSession for every step and waits on normal Cases;
- agent run/attempt evidence, reusable evaluation datasets, rubric and regression evidence;
- Rivet Workflows bakeoff only as `WorkflowRuntimePort` recoverability, never canonical state; Eve remains the conversational attempt-lifecycle owner.

Proof:

- pause/resume for weeks, code version change, replay, duplicated wakeup, forbidden-vector inference, source-rights denial before model context, agent/tool denial, prompt injection corpus, space-participant disclosure mismatch, human checkpoint, cost limit, provider failover, one Action/Effect, and no workflow-journal-only truth.

This defines target seams for the public Palantir AIP Logic, Automate, Chatbot Studio, Threads, and Evals categories while keeping Cases and authority visible; it does not claim their delivered breadth.

## S10: Programmable analytics and scenarios

**User outcome:** an analyst can open a cut-pinned workspace, write or generate TypeScript analysis, query governed objects and Parquet, visualize results, schedule it, and publish the result as evidence or a mini-app without gaining write authority.

Build:

- `AnalysisDefinition` and immutable `AnalysisRun` with release, Frame, data manifest, code, dependency and result digests;
- notebook/workspace UI inside Living World/Workshop;
- isolated `ExecutorArtifact` runtime with CPU, memory, time, storage and egress budgets;
- read-only semantic and dense query capabilities; immutable tables/charts/files as evidence artifacts;
- read-only Scenario branching, comparison and sensitivity analysis; publish/admit/request-Action ceremonies;
- scheduled analysis through Watches/playbooks.
- `PackArtifact` authoring for reusable release fragments, data contracts, connectors, flows, agents, apps, journeys and documentation; local resolution and EvaluationWorld proof use the same CLI/Studio protocol;

Proof:

- deterministic replay, dependency pinning, hostile pack and dependency confusion, registry tampering, signature/revocation, kill/timeout/quota, data-exfiltration denial, hidden-column denial, large result streaming, result lineage, schedule deduplication and explicit transition from analysis evidence to Action.

TypeScript is the first authored language. Generated OpenAPI/MCP clients and a future isolated Python kernel may interoperate without creating a second Ontology implementation; adoption requires the same evidence contract.

## S11: Institutional cells and compounding ecosystem

**User outcome:** the same product grammar works for a family, clinic, fund, trading desk, field site or factory, with enterprise isolation, offline edge operation, governed cross-World collaboration, and a growing library of trusted data, meaning, apps, connectors and workflows.

Build:

- signed `PackArtifact` bundles containing release fragments, mappings, `ConnectorArtifact` values, journeys, mini-apps, agents, data flows and playbooks;
- untrusted byte registry, deterministic dependency resolution, semantic/capability diff, license/right metadata and governed installation through ReleaseProposal;
- institutional identity/federation, approval duties, legal hold/retention/deletion, export and audit operations;
- `CellDirectory`, single-authority-cell epoch, independently scalable read/dense/live/effect/connector/sandbox adapters, multi-Machine availability and region policy;
- separate edge Worlds for offline authority; signed `FederationAgreement`, exported evidence/manifest/receipt exchange and `FederatedFrame` with no fake global cut;
- provider and destination certification, field/identifier catalogs, data-quality scorecards and integration graph;
- complete finance execution lifecycle: pre-trade Case and captured market basis; place/cancel/replace/allocate/affirm/settle Actions; order acknowledgements, partial fills, fills, busts, corrections, confirmation, clearing, cash and custody facts; bounded `ExecutionMandate`; provider reconciliation before retry;
- opt-in collaboration and distribution loops that compound reusable meaning without centralizing private World data.

Proof:

- private/family/clinic/fund/trading-desk/edge/factory packs use the same protocols; cross-cell denial; authority-cell epoch move; offline edge decision and later evidence federation; partial cross-World outcome; regional and credential isolation; backup/restore and disaster drill; pack and connector supply-chain attack; revocation; provider substitution; lost order acknowledgement; fill correction; mandate kill; large-world load; and no transaction spans authority cells.

This is where a defensible ecosystem can begin. The finance grammar permits OMS/EMS-class products but does not supply broker access, venue certification, liquidity, licensed data, compliance operations, or counterparties. Palantir's accumulated implementations and Bloomberg's data/network cannot be obtained by architecture alone; they require years of trusted operation, rights, integrations and user relationships.

## Dependency order

```text
S0 constitution
 └─ S1 truth
     ├─ S2 relationship ─ S3 sharing ─ S4 attention
     └─ S5 agency/effects
          └─ S6 evolution/publishing
              ├─ S7 dense data/retrieval
              ├─ S8 Workshop/mini-apps
              └─ S9 playbooks/agents
                   └─ S10 programmable analytics
                        └─ S11 institutional ecosystem
```

S7, S8 and S9 can proceed in parallel once S6's release/proof contract is real. S10 reuses their artifact, rights and lineage contracts. S11 installs only artifacts proved through that path and builds finance execution only on S5 agency plus S7 live capture and connectors. No slice may define a private publication or authority path to move faster.

## Build discipline for every slice

1. Start with the user journey and the failure/denial journey.
2. Extend the released product grammar only as far as that journey needs while preserving the target seam.
3. Build the thin vertical path through real Door, Eve/Ontology surface, PostgreSQL and required external sandbox.
4. Produce diagnostic evidence under stable public references.
5. Remove superseded code rather than adding compatibility layers before launch.
6. Update the ADR, threat model, dependency ledger and PR Lens view.
7. Exit only with zero static warnings and passing real journeys.

The unit of progress is not a service, table, package or percentage. It is a possibility a user can trust end to end.
