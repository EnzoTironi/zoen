# Zoen technical constitution worklist

- [x] Ground the first architecture pass in the greenfield product synthesis and local Palantir, Bloomberg, DeepSeek Harness, Cordis, and OpenBB research.
- [x] Verify the first technology set against primary documentation.
- [x] Compare three complete implementation shapes under one rubric.
- [x] Cross-judge the candidates: corrected TypeScript modular monolith wins 88.0/100.
- [ ] Reopen and decide Rivet versus Restate, including Actors, Workflows, Dynamic Apps, licensing, maturity, versioning, and product-boundary fit.
- [ ] Audit the chosen npm/OSS stack by problem, including ORM/query layer, Parquet writer, quality tooling, UI/data visualization, migrations, security, and operations.
- [ ] Encode Ultracite type-aware pedantic quality from commit zero.
- [ ] Compare the resulting product and technical constitution capability-by-capability with Palantir OAG/Ontology/AIP and Bloomberg.
- [ ] Write the module map, contracts, repository layout, technology reference, testing constitution, operations model, and build sequence.
- [ ] Record accepted, forbidden, and deliberately deferred decisions as ADRs and a decision register.
- [ ] Render the technical constitution in PR Lens and inspect the result.
- [ ] Run a final consistency audit against the product laws and architecture invariants.
