# Types and protocols

## Type policy

TypeScript makes trusted code legible; it is not the final authority. Every untrusted value is decoded, every released value is checked against its release schema, every sensitive operation reauthorizes at runtime, and PostgreSQL closes concurrency and locality invariants.

The compiler runs with `strict`, `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noImplicitReturns`, `noPropertyAccessFromIndexSignature`, `noUncheckedSideEffectImports`, `useUnknownInCatchVariables`, `verbatimModuleSyntax`, `isolatedDeclarations`, and `erasableSyntaxOnly`. Domain packages forbid `any`, non-null assertions, TypeScript enums, unchecked casts, floating promises, ambient environment access, and direct time or randomness.

Expected outcomes are discriminated unions. Exceptions are reserved for programmer or infrastructure faults and are translated once at an adapter boundary.

```ts
declare const brand: unique symbol;

export type Brand<T, Name extends string> = T & {
  readonly [brand]: Name;
};

export type Result<T, E> =
  | Readonly<{ ok: true; value: T }>
  | Readonly<{ ok: false; error: E }>;

export type NonEmpty<T> = readonly [T, ...T[]];

export type Digest<Name extends string> = Brand<
  `sha256:${string}`,
  Name
>;

export type Realm = "live" | "evaluation";
export type WorldId = Brand<string, "WorldId">;
export type PrincipalId = Brand<string, "PrincipalId">;
export type OperationKey = Brand<string, "OperationKey">;
export type SemanticId = Brand<string, "SemanticId">;
export type Purpose = Brand<string, "Purpose">;
export type WorldCut = Brand<bigint, "WorldCut">;
export type ArtifactKind =
  | "source-connector"
  | "effect-connector"
  | "channel-connector"
  | "trusted-handler"
  | "action-planner"
  | "executor"
  | "mini-app"
  | "pack";
export type ArtifactDigest<K extends ArtifactKind = ArtifactKind> = Digest<`Artifact:${K}`>;
export type DefinitionDigest = Digest<"Definition">;

export type WireValue = unknown;

declare const verifiedValueSeal: unique symbol;

export interface VerifiedReleasedValue {
  readonly schema: SchemaDigest;
  readonly value: ReleasedValue;
  readonly digest: Digest<"ReleasedValue">;
  readonly [verifiedValueSeal]: true;
}
```

Constructors are not exported from domain modules. Boundary decoders return `Result`; only reviewed decoder modules may use narrowing assertions. Values are frozen after construction. Runtime realm and World coordinates remain present even though generic brands also guide the compiler.

## Identity is not authority

```ts
declare const proofSeal: unique symbol;

export interface IdentityProof {
  readonly principal: PrincipalId;
  readonly credential:
    | { readonly kind: "human-session"; readonly sessionId: string }
    | { readonly kind: "oauth-client"; readonly tokenId: string };
  readonly assurance: "session" | "step-up" | "delegated-client";
  readonly authenticatedAt: string;
  readonly expiresAt: string;
  readonly [proofSeal]: true;
}

export interface SessionDoor {
  prove(request: Request): Promise<Result<IdentityProof, DoorError>>;
  stepUp(proof: IdentityProof, reason: Purpose): Promise<Result<IdentityProof, DoorError>>;
}
```

Door alone constructs `IdentityProof`. The proof contains no World, membership, role, delegation, relationship, audience, capability, or purpose.

Enrolled WhatsApp or Telegram presence is not silently promoted to human presence. Eve enters as a resource-bound client principal under an explicit relationship delegation. A decision requiring human assurance produces a step-up continuation through Door.

## Realm and reference model

```ts
declare const realmSeal: unique symbol;

export interface RealmRef<R extends Realm> {
  readonly kind: R;
  readonly id: Brand<string, "RealmId">;
  readonly [realmSeal]: R;
}

export interface WorldRef<R extends Realm> {
  readonly realm: RealmRef<R>;
  readonly id: WorldId;
}

export interface EntityRef<R extends Realm, Kind extends string> {
  readonly world: WorldRef<R>;
  readonly kind: Kind;
  readonly id: Brand<string, Kind>;
}

export type FrameRef<R extends Realm> = EntityRef<R, "FrameId">;
export type CaseRef<R extends Realm> = EntityRef<R, "CaseId">;
export type WatchRef<R extends Realm> = EntityRef<R, "WatchId">;
export type NoticeRef<R extends Realm> = EntityRef<R, "NoticeId">;
export type EffectRef<R extends Realm> = EntityRef<R, "EffectIntentId">;
```

The generic prevents ordinary live/evaluation mistakes. Decoders verify the discriminant. Composite database keys and foreign keys contain `(realm_kind, realm_id, world_id)`. Evaluation uses credentials with no live grants and an object prefix that cannot name live data. These runtime and physical checks are the actual security boundary.

## Focus and WorldSession

```ts
export interface Focus<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly intent: FocusIntent;
  readonly basisIntent: BasisIntent;
  readonly frame?: FrameRef<R>;
  readonly case?: CaseRef<R>;
  readonly watch?: WatchRef<R>;
}

declare const sessionSeal: unique symbol;

export interface WorldSession<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly principal: PrincipalId;
  readonly purpose: Purpose;
  readonly release: ReleaseDigest;
  readonly expiresAt: string;
  readonly [sessionSeal]: R;

  discover(): Promise<Result<AuthorizedCatalog<R>, DiscoveryError>>;
  inspect<I, O>(request: InspectRequest<R, I, O>): Promise<Result<WorldFrame<R, O>, InspectError>>;
  invoke<I>(request: InvokeAction<R, I>): Promise<Result<Invocation<R>, ActionError>>;
  openCase(ref: CaseRef<R>): Promise<Result<OpenedCase<R>, CaseError>>;
  answer(request: AnswerCase<R>): Promise<Result<AnswerOutcome<R>, CaseError>>;
  createWatch<I>(request: CreateWatch<R, I>): Promise<Result<Watch<R>, WatchError>>;
  reviseWatch(request: ReviseWatch<R>): Promise<Result<Watch<R>, WatchError>>;
  openNotice(ref: NoticeRef<R>): Promise<Result<NoticeDisclosure<R>, NoticeError>>;
  scenario(frame: FrameRef<R>): Promise<Result<ScenarioSession<R>, ScenarioError>>;
  explain(ref: ExplainableRef<R>): Promise<Result<Explanation<R>, ExplainError>>;
}
```

`Focus` is serializable continuity and contains no proof, grant, membership, selected evidence payload, authorized Case view, `DecisionContinuation`, or disclosed Notice content. `WorldSession` contains a private server-side grant and is never serialized. Its concrete class has an unexported constructor and a JavaScript private field. Every meaningful method checks expiry and current authorization; sensitive reads recheck just before returning.

## Head, commit, and Frame

```ts
export interface WorldHeadCoordinates<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly headVersion: Brand<bigint, "WorldHeadVersion">;
  readonly cut: WorldCut;
  readonly release: ReleaseDigest;
  readonly generation: DataGenerationDigest;
  readonly observationManifest: ManifestDigest;
}

export interface WorldHead<R extends Realm> extends WorldHeadCoordinates<R> {
  readonly auditRoot: AuditDigest;
}

export interface KnowledgeBasis<R extends Realm> {
  readonly head: WorldHead<R>;
  readonly validAt: string;
  readonly beliefPolicy: SemanticId;
}

export interface ExactReadSet<R extends Realm> {
  readonly head: WorldHead<R>;
  readonly sparse: readonly RecordRevision[];
  readonly beliefs: readonly BeliefDigest[];
  readonly policies: readonly PolicyDigest[];
  readonly denseSlices: readonly ManifestSliceDigest[];
  readonly captures: readonly AdmittedObservationRef<R>[];
  readonly digest: ReadSetDigest;
}

export interface AuthorityCommitPayload<R extends Realm> {
  readonly ref: AuthorityCommitRef<R>;
  readonly operation: SemanticId;
  readonly operationKey: OperationKey;
  readonly intent: IntentDigest;
  readonly actor: PrincipalOrSystem;
  readonly delegatedClient:
    | Readonly<{ kind: "none" }>
    | Readonly<{ kind: "client"; principal: PrincipalId; delegation: Digest<"Delegation"> }>;
  readonly purpose: PurposeDigest;
  readonly authorization: Digest<"AuthorizationDecision">;
  readonly rootCause: CauseRef;
  readonly parent:
    | Readonly<{ kind: "genesis" }>
    | Readonly<{ kind: "commit"; ref: AuthorityCommitRef<R> }>;
  readonly fence: Digest<"AuthorityFence">;
  readonly before: WorldHead<R>;
  readonly advance: WorldHeadCoordinates<R>;
  readonly changes: NonEmpty<StreamTransition>;
  readonly recordedAt: string;
}

export interface AuthorityCommitEnvelope<R extends Realm> {
  readonly payload: AuthorityCommitPayload<R>;
  readonly payloadDigest: Digest<"AuthorityCommitPayload">;
  readonly after: WorldHead<R>;
}

export type AuthorizedAbsence =
  | Readonly<{ kind: "known-absent"; evidence: EvidenceRef }>
  | Readonly<{ kind: "unknown"; missing: readonly SemanticId[] }>
  | Readonly<{ kind: "withheld" }>;

export type FrameDisclosure<R extends Realm, Body> =
  | Readonly<{
      kind: "disclosed";
      sealed: Readonly<{
        body: Body;
        evidence: readonly EvidenceRef[];
        gaps: readonly AuthorizedAbsence[];
        uncertainty: readonly Uncertainty[];
        explanation: ExplanationRef<R>;
        reads: ExactReadSet<R>;
        disclosure: DisclosureDigest;
        result: Digest<"FrameResult">;
      }>;
      presentation: LiveFramePresentation<R>;
    }>
  | Readonly<{
      kind: "redacted";
      reason: "authorization-changed" | "rights-changed" | "purpose-expired";
      disclosure: DisclosureDigest;
    }>;

export interface WorldFrame<R extends Realm, Body> {
  readonly ref: FrameRef<R>;
  readonly basis: KnowledgeBasis<R>;
  readonly purpose: PurposeDigest;
  readonly audience: AudienceDigest;
  readonly result: FrameDisclosure<R, Body>;
}
```

A `KnowledgeBasis` contains one complete `WorldHead`, one domain-valid instant, and one released belief policy; no second type may represent the same temporal coordinate. An `ExactReadSet` repeats that complete head and then names every sparse revision, belief, policy, dense slice, and admitted live capture actually read.

The commit payload contains the complete pre-commit head and the six non-audit coordinates of the proposed next head. Its digest excludes the resulting audit root. The resulting root is `hash(domain, before.auditRoot, payloadDigest)`, and `after` is exactly `advance` plus that root. Database checks require the same World, `headVersion + 1`, `cut + 1`, and exactly one envelope for that cut. This construction has no self-referential digest.

A Frame is constructively either disclosed or redacted. Protected body, evidence, gaps, explanation, exact reads, sealed digest, and live presentation basis exist only in the disclosed branch. If the final authorization or rights check changes, the implementation discards those values and can construct only the redacted branch. Persisting a sealed Frame envelope is an allowlisted `ProgressCommit` read artifact; it does not advance World truth or emit an `AuthorityCommitEnvelope`.

`liveBasis` is explicit inside a disclosed Frame. `{ kind: "sealed-only" }` means every value comes from the pinned head. A live overlay is presentation-only: its bytes never enter the sealed result, exact reads, explanation, model input, export, Notice, Watch, or Action. Any durable or consequential use first follows the separate capture-admission protocol below.

## Live observation plane

The live observation plane serves terminal-grade updates without pretending that every tick is a World transition. It is an entitled, transient overlay on immutable history.

```ts
export type LiveFeedId = Brand<string, "LiveFeedId">;
export type LiveSubscriptionId = Brand<string, "LiveSubscriptionId">;
export type ProviderSequence = Brand<bigint, "ProviderSequence">;

export interface LiveFeedDefinition {
  readonly id: LiveFeedId;
  readonly release: ReleaseDigest;
  readonly source: SemanticId;
  readonly connector: ArtifactDigest<"source-connector">;
  readonly selectorSchema: SchemaDigest;
  readonly fieldSchema: SchemaDigest;
  readonly normalization: DefinitionDigest;
  readonly ordering:
    | Readonly<{ kind: "strict-sequence"; gapTimeoutMs: number }>
    | Readonly<{ kind: "partitioned-sequence"; partition: SemanticId; gapTimeoutMs: number }>
    | Readonly<{ kind: "latest-value"; conflation: "provider" | "zoen" }>;
  readonly clocks: NonEmpty<"provider-event" | "provider-assertion" | "zoen-received">;
  readonly staleness: Readonly<{ warnAfterMs: number; unusableAfterMs: number }>;
  readonly rightsProgram: SemanticId;
  readonly sealPolicy: Readonly<{
    maxIntervalMs: number;
    maxRows: bigint;
    maxUncompressedBytes: bigint;
  }>;
}

export interface LiveSubscription<R extends Realm> {
  readonly id: LiveSubscriptionId;
  readonly world: WorldRef<R>;
  readonly principal: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly release: ReleaseDigest;
  readonly feed: LiveFeedId;
  readonly selector: ReleasedValue;
  readonly fields: NonEmpty<SemanticId>;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly entitlement: Digest<"EntitlementSnapshot">;
  readonly issuedAt: string;
  readonly expiresAt: string;
}

export interface LiveObservationBasis<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly feed: LiveFeedId;
  readonly connector: ArtifactDigest<"source-connector">;
  readonly providerSession: Digest<"ProviderSession">;
  readonly sequence:
    | Readonly<{ kind: "contiguous"; first: ProviderSequence; last: ProviderSequence }>
    | Readonly<{
        kind: "latest-only";
        sequence:
          | Readonly<{ kind: "reported"; last: ProviderSequence }>
          | Readonly<{ kind: "unreported" }>;
      }>
    | Readonly<{ kind: "gap"; expected: ProviderSequence; received: ProviderSequence }>;
  readonly entitlement: Digest<"EntitlementSnapshot">;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly lastSealed: Readonly<{
    cut: WorldCut;
    generation: DataGenerationDigest;
    manifest: ManifestDigest;
  }>;
  readonly observedThrough: string;
  readonly receivedThrough: string;
  readonly freshness: "fresh" | "stale" | "unusable";
}

export interface LiveObservationEnvelope<R extends Realm> {
  readonly subscription: LiveSubscriptionId;
  readonly basis: LiveObservationBasis<R>;
  readonly sequence:
    | Readonly<{ kind: "reported"; value: ProviderSequence }>
    | Readonly<{ kind: "unreported" }>;
  readonly providerTimes:
    | Readonly<{ kind: "event-and-assertion"; eventAt: string; assertionAt: string }>
    | Readonly<{ kind: "event-only"; eventAt: string }>
    | Readonly<{ kind: "assertion-only"; assertionAt: string }>
    | Readonly<{ kind: "unreported" }>;
  readonly receivedAt: string;
  readonly values: ReleasedValue;
  readonly valuesDigest: Digest<"LiveObservationValues">;
}

declare const stagedCaptureSeal: unique symbol;

export interface StagedObservationCapture<R extends Realm> {
  readonly kind: "staged";
  readonly world: WorldRef<R>;
  readonly capture: Digest<"StagedObservationCapture">;
  readonly rawObject: Digest<"RawObservationObject">;
  readonly normalizedValue: Digest<"CapturedNormalizedValue">;
  readonly schema: SchemaDigest;
  readonly verification: Digest<"ObjectVerificationReceipt">;
  readonly basis: LiveObservationBasis<R>;
  readonly capturedAt: string;
  readonly expiresAt: string;
  readonly [stagedCaptureSeal]: true;
}

export interface AdmittedObservationRef<R extends Realm> {
  readonly kind: "admitted";
  readonly world: WorldRef<R>;
  readonly evidence: EvidenceRef;
  readonly stagedCapture: Digest<"StagedObservationCapture">;
  readonly normalizedValue: Digest<"CapturedNormalizedValue">;
  readonly basis: LiveObservationBasis<R>;
  readonly admission: AuthorityCommitRef<R>;
  readonly admittedAt: WorldCut;
  readonly observedAt: string;
}

export type LiveFrameBasis<R extends Realm> =
  | Readonly<{ kind: "sealed-only" }>
  | Readonly<{
      kind: "live-overlay";
      subscriptions: NonEmpty<LiveSubscriptionId>;
      observations: NonEmpty<LiveObservationBasis<R>>;
      overlay: Digest<"LiveOverlay">;
    }>;

export type LiveFramePresentation<R extends Realm> =
  | Readonly<{ kind: "sealed-only" }>
  | Readonly<{
      kind: "live-overlay";
      basis: Extract<LiveFrameBasis<R>, Readonly<{ kind: "live-overlay" }>>;
      values: NonEmpty<LiveObservationEnvelope<R>>;
    }>;
```

A `LiveSubscription` is a short lease, not a bearer entitlement. The live gateway continuously rechecks the subscription, provider entitlement revision, release, fields, geography, and purpose. It terminates or redacts the stream when any input changes. Sequence gaps and staleness remain data, not telemetry.

Ticks do not create `AuthorityCommitEnvelope` records. The source connector periodically closes a batch, writes immutable raw evidence and Parquet, and proposes a manifest payload. One `AuthorityCommit` creates `ManifestAdmission` and advances the complete `WorldHead`.

Capture has two nominally distinct states. The gateway can construct only a sealed `StagedObservationCapture` after writing immutable bytes and a local object-verification receipt. A dedicated Ontology `AuthorityCommit` then rechecks release, connector, sequence, market or device state, current entitlement snapshot, rights decision, and staleness and constructs `AdmittedObservationRef`. Only that admitted reference may appear in an exact read set. A Case or Action that needs the value starts against the post-admission head and pins that reference; an Action transaction never admits and consumes a merely staged capture in one step. Missing, stale, gapped, changed-entitlement, expired, or unadmitted capture cannot influence a model, Notice, export, Case, or authority write.

## One Case, many views

```ts
export interface CanonicalActionCase<R extends Realm> {
  readonly ref: CaseRef<R>;
  readonly action: SemanticId;
  readonly release: ReleaseDigest;
  readonly intent: IntentDigest;
  readonly basis: KnowledgeBasis<R>;
  readonly reads: ExactReadSet<R>;
  readonly decisionRule: SemanticId;
  readonly version: Brand<bigint, "CaseVersion">;
  readonly expiresAt: string;
  readonly state: "open" | "decided" | "expired" | "superseded";
}

export interface AuthorizedCaseView<R extends Realm> {
  readonly case: CaseRef<R>;
  readonly principal: PrincipalId;
  readonly caseVersion: Brand<bigint, "CaseVersion">;
  readonly consequences: readonly AuthorizedConsequence[];
  readonly uncertainty: readonly Uncertainty[];
  readonly progress: AuthorizedProgress;
  readonly disclosure: DisclosureDigest;
  readonly viewDigest: ViewDigest;
  readonly expiresAt: string;
}

declare const continuationSeal: unique symbol;

export interface DecisionContinuation<R extends Realm> {
  readonly case: CaseRef<R>;
  readonly caseVersion: Brand<bigint, "CaseVersion">;
  readonly principal: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly doorSession: Digest<"DoorSession">;
  readonly assurance: IdentityProof["assurance"];
  readonly view: ViewDigest;
  readonly secret: Brand<string, "DecisionContinuationSecret">;
  readonly expiresAt: string;
  readonly [continuationSeal]: R;
}

export type OpenedCase<R extends Realm> =
  | Readonly<{ kind: "view-only"; view: AuthorizedCaseView<R> }>
  | Readonly<{
      kind: "decidable";
      view: AuthorizedCaseView<R>;
      continuation: DecisionContinuation<R>;
    }>;

export type Invocation<R extends Realm> =
  | Readonly<{ kind: "committed"; receipt: DecisionReceipt<R> }>
  | Readonly<{ kind: "impossible"; explanation: Explanation<R> }>
  | Readonly<{ kind: "deliberation"; opened: OpenedCase<R> }>;
```

Ontology, not Door or Eve, issues the `DecisionContinuation`. Its secret is 256 random bits and returned once; Ontology stores only its digest, bound to principal, Door session, assurance, purpose, Case version, authorization digest, view digest, and expiry. It is a continuation, not independent authority. The union makes a view without decisional standing unable to carry a continuation.

An answer writes a durable contribution. Completion locks the Case and eligibility rows, reauthorizes every decisive contribution, and rechecks the exact read set. A change returns `stale`; Zoen never silently refreshes a Case after consent.

## Watch, Notice, Scenario, Effect

```ts
export type NoticeDisclosure<R extends Realm> =
  | Readonly<{ kind: "authorized"; view: AuthorizedNoticeView<R> }>
  | Readonly<{ kind: "redacted"; reason: "disclosure-changed" }>
  | Readonly<{ kind: "suppressed"; reason: SuppressionReason }>;

declare const scenarioSeal: unique symbol;

export interface ScenarioSession<R extends Realm> {
  readonly base: FrameRef<R>;
  readonly [scenarioSeal]: R;
  inspect<I, O>(request: InspectRequest<R, I, O>): Promise<Result<ScenarioFrame<R, O>, ScenarioError>>;
  consider<I>(request: ConsiderAction<R, I>): Promise<Result<ScenarioConsequences, ScenarioError>>;
  // No decide, acquire, publish, commit, Watch, or Effect operation.
}

export interface EffectIntent<R extends Realm> {
  readonly ref: EffectRef<R>;
  readonly world: WorldRef<R>;
  readonly createdBy: AuthorityCommitRef<R>;
  readonly createdAt: WorldCut;
  readonly ordinal: Brand<number, "EffectOrdinal">;
  readonly receipt: DecisionReceiptRef<R>;
  readonly release: ReleaseDigest;
  readonly decisionBasis: WorldHead<R>;
  readonly creationCoordinates: WorldHeadCoordinates<R>;
  readonly connector: ArtifactDigest<"effect-connector">;
  readonly operation: SemanticId;
  readonly destination: Digest<"EffectDestination">;
  readonly input: Readonly<{
    schema: SchemaDigest;
    digest: Digest<"EffectInput">;
    object: Digest<"EffectInputObject">;
  }>;
  readonly authorization: Digest<"AuthorizationDecision">;
  readonly consent: Digest<"DecisionContributionSet">;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly deadline: string;
  readonly retry:
    | Readonly<{ kind: "destination-idempotent"; key: DestinationKey }>
    | Readonly<{
        kind: "reconcile-before-retry";
        capability: SemanticId;
        absenceProof: SemanticId;
      }>;
}

export type EffectAttemptState =
  | Readonly<{ kind: "allocated" }>
  | Readonly<{ kind: "dispatched"; connectorRun: Brand<string, "ConnectorRunId"> }>
  | Readonly<{ kind: "observed"; observations: NonEmpty<EvidenceRef> }>
  | Readonly<{ kind: "ambiguous"; evidence: readonly EvidenceRef[] }>
  | Readonly<{ kind: "transport-failed"; fault: Digest<"EffectTransportFault"> }>;

export interface EffectAttempt<R extends Realm> {
  readonly intent: EffectRef<R>;
  readonly number: Brand<bigint, "EffectAttemptNumber">;
  readonly recoveryEpoch: Digest<"RecoveryEpoch">;
  readonly destinationKey:
    | Readonly<{ kind: "present"; value: DestinationKey }>
    | Readonly<{ kind: "not-supported" }>;
  readonly startedAt: string;
  readonly state: EffectAttemptState;
}

export type EffectSettlementState =
  | Readonly<{
      kind: "observed";
      outcome: VerifiedReleasedValue;
      evidence: NonEmpty<EvidenceRef>;
      observedAt: string;
    }>
  | Readonly<{
      kind: "unknown";
      reason: UnknownReason;
      lastAttempt: Brand<bigint, "EffectAttemptNumber">;
      evidence: readonly EvidenceRef[];
      reconcileAfter: string;
    }>;

export interface EffectSettlement<R extends Realm> {
  readonly intent: EffectRef<R>;
  readonly revision: Brand<bigint, "EffectSettlementRevision">;
  readonly prior:
    | Readonly<{ kind: "initial" }>
    | Readonly<{ kind: "revision"; value: Brand<bigint, "EffectSettlementRevision"> }>;
  readonly state: EffectSettlementState;
  readonly reconciler: SemanticId;
  readonly admittedBy: AuthorityCommitRef<R>;
  readonly admittedAt: WorldCut;
}
```

Ontology owns Watch materiality through Notice creation. Eve stores only `NoticeRef` while it arbitrates, merges, or defers. It opens current disclosure during arbitration and again immediately before composition.

A Scenario can inspect and consider only. `Apply` extracts intent and starts a fresh live Action against current reality.

A `DecisionReceipt` proves a local World transition and the immutable intent it created. An operational `EffectAttempt` records transport work. A later `EffectSettlement` is an Ontology authority revision supported by provider evidence or an explicit ambiguity. There is no generic success state; timeout and lost acknowledgement are `unknown` until a released reconciler proves an outcome.

## Rights algebra

Authorization and licensed-data rights are separate inputs. Cedar decides whether a principal may attempt an operation in a World. The released rights algebra decides whether source terms permit the requested use, combination, derivation, retention, and output. Both must allow the operation.

```ts
export type RightsUse =
  | "inspect"
  | "derive"
  | "model-context"
  | "notify"
  | "execute"
  | "export";

export type UsageConstraint =
  | Readonly<{ kind: "public-source" }>
  | Readonly<{ kind: "entitlement"; entitlement: SemanticId }>
  | Readonly<{ kind: "principal-class"; principalClass: SemanticId }>
  | Readonly<{ kind: "purpose"; purposes: NonEmpty<SemanticId> }>
  | Readonly<{ kind: "use"; uses: NonEmpty<RightsUse> }>
  | Readonly<{ kind: "field"; fields: NonEmpty<SemanticId> }>
  | Readonly<{ kind: "subject"; subjects: NonEmpty<SemanticId> }>
  | Readonly<{ kind: "geography"; regions: NonEmpty<SemanticId> }>
  | Readonly<{ kind: "time-window"; from: string; through: string }>
  | Readonly<{ kind: "retention"; maxSeconds: bigint }>
  | Readonly<{ kind: "output"; classes: NonEmpty<"ephemeral" | "aggregate" | "record" | "redistributable"> }>
  | Readonly<{ kind: "attribution"; notice: SemanticId }>
  | Readonly<{ kind: "prohibit-training" }>
  | Readonly<{ kind: "prohibit-redistribution" }>;

export interface RightsOrigin {
  readonly issuer: SemanticId;
  readonly contract: Digest<"SourceContract">;
}

export interface UsageGrant {
  readonly allOf: NonEmpty<UsageConstraint>;
  readonly origins: NonEmpty<RightsOrigin>;
}

export type UsageObligation =
  | Readonly<{ kind: "attribution"; phase: "with-output"; notice: SemanticId }>
  | Readonly<{ kind: "delete-after"; phase: "after-use"; maxSeconds: bigint }>
  | Readonly<{ kind: "watermark"; phase: "with-output"; policy: SemanticId }>
  | Readonly<{ kind: "minimum-aggregation"; phase: "before-use"; subjects: bigint }>
  | Readonly<{ kind: "record-use"; phase: "before-use"; ledger: SemanticId }>
  | Readonly<{
      kind: "notify-issuer";
      phase: "after-use";
      endpointClass: SemanticId;
      withinSeconds: bigint;
    }>;

export interface DataUsageContract {
  readonly alternatives: NonEmpty<UsageGrant>;
  readonly obligations: readonly UsageObligation[];
  readonly digest: Digest<"DataUsageContract">;
}

declare const entitlementSeal: unique symbol;

export interface EntitlementSnapshot<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly principal: PrincipalId;
  readonly issuer: SemanticId;
  readonly revision: Digest<"EntitlementRevision">;
  readonly grants: readonly SemanticId[];
  readonly evidence: NonEmpty<EvidenceRef>;
  readonly observedAt: string;
  readonly expiresAt: string;
  readonly digest: Digest<"EntitlementSnapshot">;
  readonly [entitlementSeal]: R;
}

export interface UsageRequest<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly head: WorldHead<R>;
  readonly principal: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly use: RightsUse;
  readonly operation: SemanticId;
  readonly subjects: readonly SemanticId[];
  readonly fields: readonly SemanticId[];
  readonly region: SemanticId;
  readonly output: "ephemeral" | "aggregate" | "record" | "redistributable";
  readonly retentionSeconds: bigint;
  readonly requestedAt: string;
  readonly digest: Digest<"UsageRequest">;
}

export type RightsDecision =
  | Readonly<{
      kind: "allowed";
      proof: RightsProofDigest;
      digest: Digest<"RightsDecision">;
      effective: DataUsageContract;
      entitlementSnapshots: readonly Digest<"EntitlementSnapshot">[];
      obligations: readonly UsageObligation[];
      expiresAt: string;
    }>
  | Readonly<{
      kind: "denied";
      reason:
        | "not-entitled"
        | "use-forbidden"
        | "output-forbidden"
        | "expired"
        | "contradictory-contract"
        | "normalization-budget-exceeded";
      digest: Digest<"RightsDecision">;
    }>
  | Readonly<{
      kind: "unknown";
      reason: "entitlement-unavailable" | "contract-unavailable" | "issuer-unreachable";
      digest: Digest<"RightsDecision">;
    }>;

export interface UsageReceipt<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly request: Digest<"UsageRequest">;
  readonly decision: RightsProofDigest;
  readonly output: Digest<"UsageOutput">;
  readonly obligations: readonly Readonly<{
    obligation: UsageObligation;
    discharge:
      | Readonly<{ kind: "fulfilled"; evidence: Digest<"ObligationEvidence"> }>
      | Readonly<{ kind: "pending"; dueAt: string }>;
  }>[];
  readonly recordedAt: string;
  readonly digest: Digest<"UsageReceipt">;
}

export type RightsMeetResult =
  | Readonly<{ kind: "met"; contract: DataUsageContract }>
  | Readonly<{ kind: "conflict"; origins: NonEmpty<RightsOrigin> }>
  | Readonly<{ kind: "budget-exceeded"; attemptedAlternatives: bigint }>;

export interface RightsAlgebra {
  meet(request: Readonly<{
    contracts: NonEmpty<DataUsageContract>;
    maxAlternatives: bigint;
    maxConstraintsPerAlternative: bigint;
  }>): RightsMeetResult;
  decide<R extends Realm>(request: Readonly<{
    contract: DataUsageContract;
    usage: UsageRequest<R>;
    entitlements: readonly EntitlementSnapshot<R>[];
  }>): RightsDecision;
}
```

`meet` forms the canonical conjunction of every input restriction, removes duplicates, eliminates contradictory alternatives, and never widens a grant. Its normalization budget is explicit. Exceeding it fails closed instead of dropping terms or exploding memory. `decide` is pure over one immutable request and locally stored, sealed entitlement snapshots; it performs no provider I/O. An allowed decision carries every enforceable obligation. Output is not released until required local usage receipts exist; a consumptive entitlement is updated in the same `AuthorityCommit` as the governed operation. Missing, expired, contradictory, unavailable, or over-budget inputs deny or return `unknown` and never become public data.

## Released semantic computation

These definitions close the gap between object browsing, governed computation, Actions, and subscriptions without exposing an engine query language.

```ts
export interface InterfaceDefinition {
  readonly id: SemanticId;
  readonly release: ReleaseDigest;
  readonly properties: readonly Readonly<{
    id: SemanticId;
    schema: SchemaDigest;
    required: boolean;
  }>[];
  readonly links: readonly Readonly<{ id: SemanticId; target: SemanticId; cardinality: "one" | "many" }>[];
  readonly functions: readonly SemanticId[];
  readonly actions: readonly SemanticId[];
  readonly compatibility: "exact" | "covariant-read";
}

export type ObjectSetPlan =
  | Readonly<{ kind: "objects"; type: SemanticId }>
  | Readonly<{ kind: "interface"; interface: SemanticId }>
  | Readonly<{ kind: "filter"; input: ObjectSetPlan; predicate: ReleasedPredicateIr }>
  | Readonly<{ kind: "traverse"; input: ObjectSetPlan; link: SemanticId; direction: "out" | "in" }>
  | Readonly<{ kind: "union"; inputs: NonEmpty<ObjectSetPlan> }>
  | Readonly<{ kind: "intersect"; inputs: NonEmpty<ObjectSetPlan> }>
  | Readonly<{ kind: "order"; input: ObjectSetPlan; keys: NonEmpty<ReleasedOrderKey> }>
  | Readonly<{ kind: "page"; input: ObjectSetPlan; limit: number }>;

export interface FunctionDefinition {
  readonly id: SemanticId;
  readonly release: ReleaseDigest;
  readonly input: SchemaDigest;
  readonly output: SchemaDigest;
  readonly reads: readonly SemanticId[];
  readonly effect: "pure" | "read-only" | "proposal-only";
  readonly implementation:
    | Readonly<{ kind: "release-expression"; expression: ReleasedExpressionIr }>
    | Readonly<{
        kind: "trusted-handler";
        handler: SemanticId;
        implementation: ArtifactDigest<"trusted-handler">;
      }>
    | Readonly<{ kind: "executor"; artifact: ArtifactDigest<"executor"> }>;
  readonly budget: Readonly<{ deadlineMs: number; maxRows: bigint; maxBytes: bigint }>;
}

export interface ActionPlannerArtifact {
  readonly artifact: VerifiedArtifactRef<"action-planner">;
  readonly release: ReleaseDigest;
  readonly actions: NonEmpty<SemanticId>;
  readonly input: SchemaDigest;
  readonly output: SchemaDigest;
  readonly requestedReads: readonly SemanticId[];
  readonly dataGrantClass: SemanticId;
  readonly runtime: "isolated-node" | "isolated-oci";
}

export interface ActionPlanCandidate<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly action: SemanticId;
  readonly proposedInput: ReleasedValue;
  readonly planner: ArtifactDigest<"action-planner">;
  readonly reads: ExactReadSet<R>;
  readonly evidence: readonly EvidenceRef[];
  readonly explanation: ExplanationRef<R>;
  readonly digest: Digest<"ActionPlanCandidate">;
}

export interface ChangeSubscription<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly release: ReleaseDigest;
  readonly principal: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly source: ObjectSetPlan;
  readonly fields: readonly SemanticId[];
  readonly changes: NonEmpty<"enter" | "update" | "leave">;
  readonly delivery: "sse" | "watch" | "federation";
  readonly cursor: Digest<"ChangeCursor">;
  readonly disclosure: DisclosureDigest;
  readonly rights: RightsProofDigest;
  readonly expiresAt: string;
}
```

An `InterfaceDefinition` is structural polymorphism in the release, not a TypeScript interface and not a storage superclass. An `ObjectSetPlan` is a bounded closed algebra compiled by Ontology after discovery and disclosure. Its cursor is bound to release, plan, sort, cut, disclosure, and rights. `FunctionDefinition` may run closed IR, an image-pinned trusted handler, or an isolated executor. Executor output remains a derived artifact or proposal.

An `ActionPlannerArtifact` can choose a released Action and propose inputs. It cannot define consequences, grants, quorum, mutations, Effects, or Settlements. Ontology decodes the candidate, recomputes the released Action plan, opens the ordinary Case, and revalidates the exact reads. A `ChangeSubscription` emits only authorized change references. It reauthorizes before each batch and represents revoked visibility as a redaction boundary rather than leaking a tombstone.

## Signed artifacts and connectors

```ts
export interface ArtifactPayload<K extends ArtifactKind> {
  readonly kind: K;
  readonly format: SemanticId;
  readonly source: Digest<"ArtifactSource">;
  readonly build: Digest<"ArtifactBuild">;
  readonly dependencyLock: Digest<"DependencyLock">;
  readonly sbom: Digest<"SBOM">;
  readonly protocolVersion: SemanticId;
  readonly body: Digest<`ArtifactBody:${K}`>;
}

export interface ArtifactSignature<K extends ArtifactKind> {
  readonly artifact: ArtifactDigest<K>;
  readonly signer: SemanticId;
  readonly algorithm: SemanticId;
  readonly signature: Digest<"ArtifactSignatureBytes">;
  readonly signedAt: string;
}

export interface ArtifactEvaluation<K extends ArtifactKind> {
  readonly artifact: ArtifactDigest<K>;
  readonly suite: Digest<"ArtifactEvaluationSuite">;
  readonly environment: Digest<"ArtifactEvaluationEnvironment">;
  readonly result: "passed" | "failed" | "unknown";
  readonly evidence: Digest<"ArtifactEvaluationEvidence">;
  readonly evaluatedAt: string;
}

export type PassedArtifactEvaluation<K extends ArtifactKind> = ArtifactEvaluation<K> &
  Readonly<{ result: "passed" }>;

export interface ArtifactTrustBasis<K extends ArtifactKind> {
  readonly artifact: ArtifactDigest<K>;
  readonly policy: Digest<"ArtifactTrustPolicy">;
  readonly trustEpoch: Brand<bigint, "ArtifactTrustEpoch">;
  readonly signatures: NonEmpty<ArtifactSignature<K>>;
  readonly evaluations: NonEmpty<PassedArtifactEvaluation<K>>;
}

export type ArtifactTrustBundle<K extends ArtifactKind> = ArtifactTrustBasis<K> &
  (
    | Readonly<{
        kind: "trusted";
        revocationCheckedAt: string;
        expiresAt: string;
        digest: Digest<"ArtifactTrustBundle">;
      }>
    | Readonly<{
        kind: "revoked";
        reason: Digest<"ArtifactRevocationReason">;
        revokedAt: string;
        digest: Digest<"ArtifactTrustBundle">;
      }>
  );

export type ExecutableArtifactTrustBundle<K extends ArtifactKind> = Extract<
  ArtifactTrustBundle<K>,
  Readonly<{ kind: "trusted" }>
>;

declare const verifiedArtifactSeal: unique symbol;

export interface VerifiedArtifactRef<K extends ArtifactKind> {
  readonly kind: K;
  readonly digest: ArtifactDigest<K>;
  readonly payload: ArtifactPayload<K>;
  readonly trust: ExecutableArtifactTrustBundle<K>;
  readonly [verifiedArtifactSeal]: K;
}

export interface WireArtifact {
  readonly payload: WireValue;
  readonly signatures: readonly WireValue[];
  readonly evaluations: readonly WireValue[];
}

export interface ConnectorRuntimePolicy {
  readonly runtime: "isolated-node" | "isolated-oci";
  readonly egress: readonly Readonly<{ host: string; port: number; protocol: "https" | "tls" }>[];
  readonly credentialClasses: readonly SemanticId[];
  readonly secretDelivery: "brokered-request" | "short-lived-lease";
  readonly resourceBudget: Readonly<{
    cpuMs: bigint;
    memoryBytes: bigint;
    outputBytes: bigint;
    deadlineMs: number;
  }>;
}

export type ConnectorArtifact =
  | Readonly<{
      kind: "source";
      artifact: VerifiedArtifactRef<"source-connector">;
      runtime: ConnectorRuntimePolicy;
      request: SchemaDigest;
      rawOutput: SchemaDigest;
      cursor: SchemaDigest;
      liveFeed: "supported" | "unsupported";
      rightsMapping: DefinitionDigest;
    }>
  | Readonly<{
      kind: "effect";
      artifact: VerifiedArtifactRef<"effect-connector">;
      runtime: ConnectorRuntimePolicy;
      operations: NonEmpty<SemanticId>;
      request: SchemaDigest;
      observation: SchemaDigest;
      reconciliation: SemanticId;
      idempotency: "provider-key" | "reconcile-before-retry";
    }>
  | Readonly<{
      kind: "channel";
      artifact: VerifiedArtifactRef<"channel-connector">;
      runtime: ConnectorRuntimePolicy;
      channel: "whatsapp" | "telegram" | "email";
      ingress: SchemaDigest;
      delivery: SchemaDigest;
      providerIdentity: SchemaDigest;
    }>;

export interface SourceConnectorLease<R extends Realm> {
  readonly kind: "source";
  readonly world: WorldRef<R>;
  readonly artifact: ArtifactDigest<"source-connector">;
  readonly run: Brand<string, "ConnectorRunId">;
  readonly actor: PrincipalOrSystem;
  readonly purpose: PurposeDigest;
  readonly acquisition: Digest<"AcquisitionRequest">;
  readonly credential: Digest<"CredentialLease">;
  readonly egress: Digest<"EgressLease">;
  readonly objectWrite: Readonly<{
    kind: "content-addressed";
    lease: Digest<"ObjectWriteLease">;
    maxBytes: bigint;
  }>;
  readonly recoveryEpoch: Digest<"RecoveryEpoch">;
  readonly expiresAt: string;
}

export interface EffectConnectorLease<R extends Realm> {
  readonly kind: "effect";
  readonly world: WorldRef<R>;
  readonly artifact: ArtifactDigest<"effect-connector">;
  readonly run: Brand<string, "ConnectorRunId">;
  readonly intent: EffectRef<R>;
  readonly operation: SemanticId;
  readonly destination: Digest<"EffectDestination">;
  readonly credential: Digest<"CredentialLease">;
  readonly egress: Digest<"EgressLease">;
  readonly recoveryEpoch: Digest<"RecoveryEpoch">;
  readonly expiresAt: string;
}

export interface ChannelConnectorLease {
  readonly kind: "channel";
  readonly owner: "eve";
  readonly artifact: ArtifactDigest<"channel-connector">;
  readonly run: Brand<string, "ConnectorRunId">;
  readonly channelAccount: Digest<"ChannelAccount">;
  readonly direction: "ingress" | "delivery";
  readonly credential: Digest<"CredentialLease">;
  readonly egress: Digest<"EgressLease">;
  readonly recoveryEpoch: Digest<"RecoveryEpoch">;
  readonly expiresAt: string;
}

export type ConnectorLease<R extends Realm> =
  | SourceConnectorLease<R>
  | EffectConnectorLease<R>
  | ChannelConnectorLease;

declare const channelIngressSeal: unique symbol;

export interface VerifiedChannelIngress {
  readonly channel: "whatsapp" | "telegram" | "email";
  readonly channelAccount: Digest<"ChannelAccount">;
  readonly providerMessage: Digest<"ProviderMessageIdentity">;
  readonly providerActor: Digest<"ProviderActorIdentity">;
  readonly receivedAt: string;
  readonly normalized: Digest<"NormalizedChannelMessage">;
  readonly rawCapture: Digest<"RawChannelIngress">;
  readonly verification: Digest<"ChannelIngressVerification">;
  readonly digest: Digest<"VerifiedChannelIngress">;
  readonly [channelIngressSeal]: true;
}

export interface AdmittedChannelIngress {
  readonly ingress: Digest<"VerifiedChannelIngress">;
  readonly admission: Brand<string, "ChannelIngressAdmissionId">;
  readonly eveDeliveryMessage: Digest<"EveIngressDeliveryMessage">;
  readonly admittedAt: string;
}

export type ChannelIngressAdmission =
  | Readonly<{ kind: "admitted"; value: AdmittedChannelIngress }>
  | Readonly<{ kind: "duplicate"; value: AdmittedChannelIngress }>
  | Readonly<{ kind: "rejected"; reason: "invalid" | "unauthorized" | "too-large" }>;

export interface ChannelIngressAdmissionPort {
  admit(ingress: VerifiedChannelIngress): Promise<Result<ChannelIngressAdmission, ChannelAdmissionFault>>;
}

export interface ChannelDeliveryIntent {
  readonly id: Brand<string, "ChannelDeliveryIntentId">;
  readonly interaction: Digest<"EveInteraction">;
  readonly channel: "whatsapp" | "telegram" | "email";
  readonly destination: Digest<"ChannelDestination">;
  readonly rendered: Digest<"RenderedChannelMessage">;
  readonly operationKey: OperationKey;
}

export type ChannelDeliveryObservation =
  | Readonly<{ kind: "accepted"; providerDelivery: Digest<"ProviderDeliveryIdentity">; evidence: EvidenceRef }>
  | Readonly<{ kind: "rejected"; evidence: EvidenceRef }>
  | Readonly<{ kind: "unknown"; evidence: readonly EvidenceRef[]; reconcileAfter: string }>;

export type SourceConnectorOutput =
  | Readonly<{ kind: "capture"; raw: Digest<"RawCapture">; proposal: Digest<"EvidenceAdmissionProposal"> }>
  | Readonly<{ kind: "live-transcript"; transcript: Digest<"LiveObservationTranscript"> }>
  | Readonly<{ kind: "unavailable"; evidence: Digest<"ConnectorUnknownEvidence"> }>;

export type EffectConnectorOutput =
  | Readonly<{ kind: "provider-observation"; observation: Digest<"ProviderObservation"> }>
  | Readonly<{ kind: "unknown"; evidence: Digest<"ConnectorUnknownEvidence"> }>;

export type ChannelConnectorOutput =
  | Readonly<{ kind: "ingress"; ingress: VerifiedChannelIngress }>
  | Readonly<{ kind: "delivery"; observation: ChannelDeliveryObservation }>;

export interface ConnectorRunEvidence {
  readonly id: Brand<string, "ConnectorRunId">;
  readonly attempt: Brand<bigint, "ConnectorAttempt">;
  readonly startedAt: string;
  readonly finishedAt: string;
  readonly networkTranscript: Digest<"NetworkTranscript">;
  readonly resourceUse: Digest<"ConnectorResourceUse">;
}

export type ConnectorRun<R extends Realm> =
  | Readonly<ConnectorRunEvidence & {
      kind: "source";
      world: WorldRef<R>;
      artifact: ArtifactDigest<"source-connector">;
      lease: Digest<"SourceConnectorLease">;
      input: Digest<"AcquisitionRequest">;
      output: SourceConnectorOutput;
    }>
  | Readonly<ConnectorRunEvidence & {
      kind: "effect";
      world: WorldRef<R>;
      artifact: ArtifactDigest<"effect-connector">;
      lease: Digest<"EffectConnectorLease">;
      input: EffectRef<R>;
      output: EffectConnectorOutput;
    }>
  | Readonly<ConnectorRunEvidence & {
      kind: "channel";
      owner: "eve";
      artifact: ArtifactDigest<"channel-connector">;
      lease: Digest<"ChannelConnectorLease">;
      input: Digest<"ChannelConnectorInput">;
      output: ChannelConnectorOutput;
    }>;
```

Artifact identity is the domain-separated hash of canonical `ArtifactPayload<K>` bytes. Signatures, evaluations, revocation checks, trust policy, and expiry are separate facts and cannot change that identity. A boundary decoder accepts `WireArtifact`, recomputes the kind-indexed digest, validates every signature and evaluation against the current local trust bundle, and only then constructs the nominally sealed `VerifiedArtifactRef<K>`.

The connector discriminant is preserved through artifact, lease, run, input, and output, so a source lease cannot start an effect run and channel ingress cannot be interpreted as provider settlement. The runner validates the verified artifact, current local trust epoch, lease, egress, credential class, and budget before starting an isolated process. The connector receives no authority database role, object-store master credential, membership API, grant constructor, or Settlement writer.

For channels, one local admission transaction inserts `AdmittedChannelIngress` and its deterministic Eve-delivery outbox row. Only then may the adapter acknowledge the provider. An idempotent dispatcher submits the stable ingress identity to Eve; model work starts only after Eve durably accepts it into Workflow history. `InteractionJournal` is a typed Eve materialization of that history, not the admission transaction or a second scheduler.

Built-in launch connectors are image-pinned implementations of the same contract. Third-party artifacts enter through a proved Pack proposal. A connector cannot make itself trusted through installation, success status, or provider response text.

## Data flows, datasets, quality, and lineage

```ts
export type DataFlowNode =
  | Readonly<{ kind: "source"; source: SemanticId; connector: ArtifactDigest<"source-connector"> }>
  | Readonly<{ kind: "object-set"; plan: ObjectSetPlan }>
  | Readonly<{ kind: "dense-query"; plan: Digest<"ObservationPlan"> }>
  | Readonly<{ kind: "transform"; function: SemanticId }>
  | Readonly<{ kind: "executor"; artifact: ArtifactDigest<"executor"> }>
  | Readonly<{ kind: "quality"; rules: NonEmpty<SemanticId> }>
  | Readonly<{ kind: "publish-dataset"; dataset: SemanticId }>;

export interface DataFlowDefinition {
  readonly id: SemanticId;
  readonly release: ReleaseDigest;
  readonly nodes: NonEmpty<Readonly<{ id: SemanticId; operation: DataFlowNode }>>;
  readonly edges: readonly Readonly<{ from: SemanticId; to: SemanticId; input: SemanticId }>[];
  readonly trigger:
    | Readonly<{ kind: "manual" }>
    | Readonly<{ kind: "schedule"; schedule: SemanticId }>
    | Readonly<{ kind: "change"; subscription: Digest<"ChangeSubscriptionDefinition"> }>;
  readonly incremental:
    | Readonly<{ kind: "full" }>
    | Readonly<{ kind: "keyed"; keys: NonEmpty<SemanticId>; lateDataPolicy: SemanticId }>;
  readonly outputSchema: SchemaDigest;
  readonly qualityPolicy: SemanticId;
  readonly rightsProgram: SemanticId;
}

export interface DataFlowExecutionBasis<R extends Realm> {
  readonly knowledge: KnowledgeBasis<R>;
  readonly reads: ExactReadSet<R>;
  readonly inputAdmissions: readonly Digest<"DatasetAdmission">[];
  readonly denseSlices: readonly ManifestSliceDigest[];
  readonly artifacts: readonly ArtifactDigest[];
  readonly rightsDecisions: readonly Digest<"RightsDecision">[];
  readonly entitlementSnapshots: readonly Digest<"EntitlementSnapshot">[];
  readonly engine: Digest<"DataFlowEngineAttestation">;
  readonly digest: Digest<"DataFlowExecutionBasis">;
}

export type DataFlowAttemptState =
  | Readonly<{ kind: "claimed"; lease: Digest<"DataFlowLease"> }>
  | Readonly<{ kind: "running"; checkpoint: Digest<"DataFlowCheckpoint"> }>
  | Readonly<{ kind: "produced"; candidate: Digest<"DatasetVersion"> }>
  | Readonly<{ kind: "blocked"; reason: "quality" | "rights" | "missing-input" }>
  | Readonly<{ kind: "failed"; fault: Digest<"DataFlowFault"> }>
  | Readonly<{ kind: "abandoned"; reason: "lease-expired" | "superseded" }>;

export interface DataFlowAttempt<R extends Realm> {
  readonly id: Brand<string, "DataFlowAttemptId">;
  readonly run: Brand<string, "DataFlowRunId">;
  readonly attempt: Brand<bigint, "DataFlowAttemptNumber">;
  readonly world: WorldRef<R>;
  readonly definition: DefinitionDigest;
  readonly release: ReleaseDigest;
  readonly basis: DataFlowExecutionBasis<R>;
  readonly startedAt: string;
  readonly state: DataFlowAttemptState;
}

export interface QualityResult {
  readonly rules: NonEmpty<Readonly<{
    rule: SemanticId;
    status: "passed" | "failed" | "unknown";
    observed: Digest<"QualityObservation">;
  }>>;
  readonly score:
    | Readonly<{ kind: "not-scored" }>
    | Readonly<{ kind: "scored"; value: ReleasedValue }>;
  readonly digest: Digest<"QualityResult">;
}

export type LineageInput =
  | Readonly<{ kind: "dataset-field"; dataset: Digest<"DatasetVersion">; field: SemanticId }>
  | Readonly<{ kind: "evidence-field"; evidence: EvidenceRef; field: SemanticId }>
  | Readonly<{ kind: "generated"; function: SemanticId; seedOrBasis: Digest<"GeneratedValueBasis"> }>;

export interface FieldLineage {
  readonly outputField: SemanticId;
  readonly inputs: NonEmpty<LineageInput>;
  readonly transform: SemanticId;
}

export interface DatasetVersionPayload<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly dataset: SemanticId;
  readonly release: ReleaseDigest;
  readonly schema: SchemaDigest;
  readonly basis: DataFlowExecutionBasis<R>;
  readonly inputs: readonly Digest<"DatasetVersion">[];
  readonly lineage: NonEmpty<FieldLineage>;
  readonly quality: QualityResult;
  readonly usage: DataUsageContract;
  readonly materialization: Digest<"DatasetMaterialization">;
  readonly producedBy: Brand<string, "DataFlowAttemptId">;
}

export interface DatasetVersion<R extends Realm> {
  readonly version: Digest<"DatasetVersion">;
  readonly payload: DatasetVersionPayload<R>;
}

export interface DatasetAdmission<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly dataset: SemanticId;
  readonly version: Digest<"DatasetVersion">;
  readonly commit: AuthorityCommitRef<R>;
  readonly cut: WorldCut;
  readonly resultingHead: WorldHead<R>;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly usageReceipt: Digest<"UsageReceipt">;
  readonly qualityDecision: Digest<"DatasetQualityAdmissionDecision">;
}
```

The graph must be acyclic after release compilation. Every node has a typed input and output contract, deterministic or declared nondeterministic behavior, and a bounded execution profile. `DataFlowAttempt` is purely operational and can never have an `admitted` state. A produced `DatasetVersion` is immutable content whose payload includes the full execution basis. Only a separately keyed `DatasetAdmission`, written by `AuthorityCommit`, makes that version reachable and visible to subscriptions. Failed or unknown quality never silently publishes. Incremental processing changes physical work, not dataset identity, lineage, usage rights, or authority.

## Models, retrieval, and headless agents

```ts
export interface ModelProfile {
  readonly id: SemanticId;
  readonly release: ReleaseDigest;
  readonly digest: Digest<"ModelProfile">;
  readonly provider: SemanticId;
  readonly model: string;
  readonly revision: string;
  readonly capabilities: NonEmpty<"text" | "vision" | "audio" | "tools" | "structured-output" | "embedding">;
  readonly residency: readonly SemanticId[];
  readonly retention: SemanticId;
  readonly trainingUse: "forbidden" | "provider-contract";
  readonly inputRightsClasses: readonly SemanticId[];
  readonly pricing: Digest<"ModelPricing">;
}

export type RetrievalSource =
  | Readonly<{ kind: "objects"; plan: ObjectSetPlan; planDigest: Digest<"ObjectSetPlan"> }>
  | Readonly<{ kind: "evidence"; corpus: Digest<"EvidenceCorpusPlan"> }>;

export type RetrievalMethod =
  | Readonly<{
      kind: "lexical";
      index: Digest<"LexicalIndex">;
      analyzer: Digest<"LexicalAnalyzer">;
    }>
  | Readonly<{
      kind: "vector";
      index: Digest<"VectorIndex">;
      embeddingProfile: Digest<"ModelProfile">;
      metric: "cosine" | "inner-product" | "euclidean";
    }>
  | Readonly<{
      kind: "hybrid";
      lexical: Digest<"LexicalIndex">;
      vector: Digest<"VectorIndex">;
      embeddingProfile: Digest<"ModelProfile">;
      ranker: Digest<"RetrievalRanker">;
      tieBreak: SemanticId;
    }>;

export interface RetrievalPlan<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly basis: KnowledgeBasis<R>;
  readonly release: ReleaseDigest;
  readonly query: Digest<"RetrievalQuery">;
  readonly querySchema: SchemaDigest;
  readonly sources: NonEmpty<RetrievalSource>;
  readonly method: RetrievalMethod;
  readonly disclosure: DisclosureDigest;
  readonly usageRequest: Digest<"UsageRequest">;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly budget: Readonly<{
    candidates: number;
    resultBytes: bigint;
    deadlineMs: number;
    hiddenCandidateLeakage: "none" | "constant-shape";
  }>;
  readonly digest: Digest<"RetrievalPlan">;
}

export interface RetrievalHit<R extends Realm> {
  readonly rank: Brand<number, "RetrievalRank">;
  readonly source:
    | Readonly<{ kind: "record"; revision: RecordRevision }>
    | Readonly<{ kind: "evidence"; evidence: EvidenceRef }>
    | Readonly<{ kind: "dense-slice"; slice: ManifestSliceDigest }>;
  readonly excerpt: VerifiedReleasedValue;
  readonly score:
    | Readonly<{ kind: "lexical"; value: Digest<"LexicalScore"> }>
    | Readonly<{ kind: "vector"; value: Digest<"VectorScore"> }>
    | Readonly<{ kind: "hybrid"; value: Digest<"HybridScore"> }>;
  readonly citation: EvidenceRef;
  readonly reads: ExactReadSet<R>;
  readonly disclosure: DisclosureDigest;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly digest: Digest<"RetrievalHit">;
}

export interface RetrievalResult<R extends Realm> {
  readonly plan: Digest<"RetrievalPlan">;
  readonly hits: readonly RetrievalHit<R>[];
  readonly gaps: readonly AuthorizedAbsence[];
  readonly reads: ExactReadSet<R>;
  readonly usageReceipt: Digest<"UsageReceipt">;
  readonly result: Digest<"RetrievalResult">;
}

export interface InferenceInput<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly basis: KnowledgeBasis<R>;
  readonly promptTemplate: Digest<"PromptTemplate">;
  readonly content: Digest<"InferenceInputContent">;
  readonly retrieval: readonly Digest<"RetrievalResult">[];
  readonly offeredTools: readonly SemanticId[];
  readonly outputSchema: SchemaDigest;
  readonly rightsDecisions: readonly Digest<"RightsDecision">[];
  readonly digest: Digest<"InferenceInput">;
}

export interface InferenceAttemptBase<R extends Realm> {
  readonly id: Brand<string, "InferenceAttemptId">;
  readonly world: WorldRef<R>;
  readonly actor: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly modelProfile: Digest<"ModelProfile">;
  readonly observedModel: Readonly<{ provider: SemanticId; model: string; revision: string }>;
  readonly input: Digest<"InferenceInput">;
  readonly budget: Digest<"InferenceBudget">;
  readonly providerRequest: Digest<"ProviderInferenceRequest">;
  readonly startedAt: string;
}

export type InferenceAttempt<R extends Realm> = InferenceAttemptBase<R> &
  (
    | Readonly<{ kind: "running" }>
    | Readonly<{
        kind: "completed";
        output: Digest<"InferenceOutput">;
        usage: Digest<"ModelUsage">;
        retentionReceipt: Digest<"ProviderRetentionReceipt">;
        usageReceipt: Digest<"UsageReceipt">;
        finishedAt: string;
      }>
    | Readonly<{ kind: "aborted"; usage: Digest<"ModelUsage">; finishedAt: string }>
    | Readonly<{
        kind: "failed";
        fault: Digest<"ModelFault">;
        usage: Digest<"ModelUsage">;
        finishedAt: string;
      }>
  );

export interface AgentDefinition {
  readonly id: SemanticId;
  readonly release: ReleaseDigest;
  readonly workflow: DefinitionDigest;
  readonly modelProfiles: NonEmpty<Digest<"ModelProfile">>;
  readonly tools: readonly SemanticId[];
  readonly retrievalPlans: readonly Digest<"RetrievalPlanDefinition">[];
  readonly output: SchemaDigest;
  readonly budgetPolicy: SemanticId;
  readonly humanJudgmentPolicy: SemanticId;
  readonly evaluation: NonEmpty<Digest<"AgentEvaluation">>;
}

export type OntologyWorkflowState<R extends Realm> =
  | Readonly<{ kind: "ready"; nextStep: SemanticId }>
  | Readonly<{ kind: "running"; step: SemanticId; attempt: Brand<string, "WorkflowStepAttemptId"> }>
  | Readonly<{ kind: "waiting-for-case"; case: CaseRef<R> }>
  | Readonly<{ kind: "waiting-for-time"; wakeAt: string }>
  | Readonly<{ kind: "completed"; output: Digest<"AgentOutput"> }>
  | Readonly<{ kind: "stopped"; reason: "budget" | "revoked" | "failed" | "canceled" }>;

export interface OntologyWorkflowInstance<R extends Realm> {
  readonly id: Brand<string, "WorkflowInstanceId">;
  readonly world: WorldRef<R>;
  readonly definition: DefinitionDigest;
  readonly servicePrincipal: PrincipalId;
  readonly purpose: PurposeDigest;
  readonly release: ReleaseDigest;
  readonly basis: WorldHead<R>;
  readonly budget: Digest<"AgentBudget">;
  readonly version: Brand<bigint, "WorkflowVersion">;
  readonly startedAt: string;
  readonly state: OntologyWorkflowState<R>;
  readonly attempts: readonly Brand<string, "InferenceAttemptId">[];
}
```

Pre-scan authorization filters retrieval before term, vector, or candidate access. Each hit keeps its source revision, excerpt, score kind, citation, exact reads, disclosure, and rights decision together; there are no parallel arrays that can drift. A result pins the full head, index, analyzer or embedding/ranker, usage receipt, and canonical hit order. Model output is attributed computation, not a claim, receipt, or Settlement.

Eve owns inference attempts made for a conversation. A headless agent has no Eve relationship and no standing `WorldSession`. Its Ontology-owned workflow state is a versioned discriminated union; a runtime adapter may only wake or claim a step. The workflow opens a fresh purpose-bound session for every step. It can inspect, calculate, draft, and open Cases. It can wait on a Case reference but never receives the human's `DecisionContinuation`, activates a release, or calls a provider except through a released Action and `EffectIntent`.

## Governed conversation spaces

```ts
export interface ConversationSpace<R extends Realm> {
  readonly id: Brand<string, "ConversationSpaceId">;
  readonly relationship: Brand<string, "RelationshipId">;
  readonly worldBindings: readonly WorldRef<R>[];
  readonly purposePolicy: SemanticId;
  readonly participationPolicy: SemanticId;
  readonly retentionPolicy: SemanticId;
  readonly recordPolicy: SemanticId;
  readonly channelBindings: readonly SemanticId[];
  readonly version: Brand<bigint, "ConversationSpaceVersion">;
}

export interface SpaceInteraction<R extends Realm> {
  readonly space: Brand<string, "ConversationSpaceId">;
  readonly workflowEvent: Digest<"EveWorkflowEvent">;
  readonly materializationVersion: Brand<bigint, "SpaceMaterializationVersion">;
  readonly actor: PrincipalId;
  readonly audience: NonEmpty<PrincipalId>;
  readonly purpose: PurposeDigest;
  readonly content: Digest<"SettledInteractionContent">;
  readonly worldReferences: readonly Readonly<{
    frame: FrameRef<R>;
    disclosure: DisclosureDigest;
  }>[];
  readonly digest: Digest<"SpaceInteraction">;
}
```

Eve owns the space and its Workflow history. `SpaceInteraction` is a typed materialized view keyed to its source Workflow event, not another append-only journal or hash chain. Space participation grants access to conversation content only. It never grants access to a bound World. Each participant reopens a Frame under their own current authority. Eve renders a shared reference only to an audience for which Ontology produced a common authorized view; other participants see a withheld marker without protected metadata. Retention, legal hold, supervision, export, moderation, agent participation, and channel delivery are explicit Workflow events. Conversation text cannot serve as an Action contribution unless a participant completes the normal Case ceremony with an Ontology-issued `DecisionContinuation`.

## Packs, cells, edge, and federation

```ts
export type PackComponent =
  | Readonly<{ kind: "release-fragment"; digest: Digest<"ReleaseFragment"> }>
  | Readonly<{
      kind: "connector";
      digest:
        | ArtifactDigest<"source-connector">
        | ArtifactDigest<"effect-connector">
        | ArtifactDigest<"channel-connector">;
    }>
  | Readonly<{ kind: "mini-app"; digest: ArtifactDigest<"mini-app"> }>
  | Readonly<{ kind: "executor"; digest: ArtifactDigest<"executor"> }>
  | Readonly<{ kind: "workflow"; digest: DefinitionDigest }>
  | Readonly<{ kind: "agent"; digest: DefinitionDigest }>
  | Readonly<{ kind: "journey-suite"; digest: Digest<"JourneySuite"> }>
  | Readonly<{ kind: "documentation"; digest: Digest<"PackDocumentation"> }>;

export interface PackArtifact {
  readonly artifact: VerifiedArtifactRef<"pack">;
  readonly name: SemanticId;
  readonly version: string;
  readonly compatibility: Readonly<{
    releaseIr: NonEmpty<SemanticId>;
    protocol: NonEmpty<SemanticId>;
    runtime: NonEmpty<SemanticId>;
  }>;
  readonly components: NonEmpty<PackComponent>;
  readonly dependencies: readonly Readonly<{ pack: ArtifactDigest<"pack">; requirement: string }>[];
  readonly licenses: NonEmpty<Digest<"LicenseTerms">>;
  readonly usage: DataUsageContract;
  readonly migrations: readonly Digest<"PackMigration">[];
  readonly evaluation: NonEmpty<Digest<"PackEvaluationResult">>;
}

export interface DeveloperWorkspace<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly actor: PrincipalId;
  readonly baseHead: Digest<"WorldHead">;
  readonly baseRelease: ReleaseDigest;
  readonly draft: Digest<"WorkspaceDraft">;
  readonly dependencyLock: Digest<"PackDependencyLock">;
  readonly evaluationWorld: WorldRef<"evaluation">;
  readonly expiresAt: string;
}

export interface PackInstallProposal<R extends Realm> {
  readonly target: WorldRef<R>;
  readonly pack: ArtifactDigest<"pack">;
  readonly closure: NonEmpty<ArtifactDigest>;
  readonly baseHead: Digest<"WorldHead">;
  readonly semanticDiff: Digest<"SemanticDiff">;
  readonly capabilityDiff: Digest<"CapabilityDiff">;
  readonly rightsAndLicenseDiff: Digest<"RightsAndLicenseDiff">;
  readonly migrationPlan: Digest<"MigrationPlan">;
  readonly evaluation: Digest<"PackEvaluationResult">;
  readonly state: "draft" | "in-review" | "approved" | "rejected" | "superseded";
}

export type CellKind = "authority" | "read" | "dense" | "compute" | "edge";
export type CellId = Brand<string, "CellId">;
export type CellEpoch = Brand<bigint, "CellEpoch">;

export interface CellAssignment<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly authority: CellId;
  readonly epoch: CellEpoch;
  readonly auxiliary: readonly Readonly<{ kind: Exclude<CellKind, "authority">; cell: CellId }>[];
  readonly residency: SemanticId;
  readonly directoryEpoch: Brand<bigint, "CellDirectoryEpoch">;
  readonly routingDigest: Digest<"CellAssignment">;
  readonly signature: Digest<"CellAssignmentSignature">;
}

declare const authorityLeaseSeal: unique symbol;

export interface AuthorityCellLease<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly cell: CellId;
  readonly epoch: CellEpoch;
  readonly directoryEpoch: Brand<bigint, "CellDirectoryEpoch">;
  readonly fenceToken: Digest<"AuthorityFenceToken">;
  readonly issuedAt: string;
  readonly expiresAt: string;
  readonly signature: Digest<"AuthorityCellLeaseSignature">;
  readonly [authorityLeaseSeal]: R;
}

export type AuthorityFenceState =
  | Readonly<{ kind: "active"; expiresAt: string }>
  | Readonly<{ kind: "transfer-fenced"; transfer: Digest<"CellTransfer"> }>
  | Readonly<{ kind: "revoked"; revokedAt: string }>;

export interface AuthorityFenceRow<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly cell: CellId;
  readonly epoch: CellEpoch;
  readonly fenceToken: Digest<"AuthorityFenceToken">;
  readonly state: AuthorityFenceState;
  readonly revision: Brand<bigint, "AuthorityFenceRevision">;
}

export interface FederationAgreement<R extends Realm> {
  readonly id: SemanticId;
  readonly realm: R;
  readonly parties: NonEmpty<Readonly<{
    world: WorldRef<R>;
    trustRoot: Digest<"FederationTrustRoot">;
  }>>;
  readonly mappings: NonEmpty<DefinitionDigest>;
  readonly capabilities: NonEmpty<SemanticId>;
  readonly usage: DataUsageContract;
  readonly retention: SemanticId;
  readonly revocationEpoch: Brand<bigint, "FederationRevocationEpoch">;
  readonly expiresAt: string;
}

export interface FederatedFrame<R extends Realm, Body> {
  readonly components: NonEmpty<Readonly<{
    cell: CellId;
    world: WorldRef<R>;
    frame: Digest<"ExportedFrame">;
    basis: KnowledgeBasis<R>;
    disclosure: DisclosureDigest;
    rightsDecision: Digest<"RightsDecision">;
    signature: Digest<"FederatedFrameComponentSignature">;
  }>>;
  readonly agreement: SemanticId;
  readonly body: Body;
  readonly effectiveUsage: DataUsageContract;
  readonly lineage: Digest<"FederatedLineage">;
  readonly gaps: readonly AuthorizedAbsence[];
  readonly composedAt: string;
  readonly digest: Digest<"FederatedFrame">;
}
```

The cell directory resolves one authority cell before `WorldSession` admission. The lease alone is insufficient: every AuthorityCommit first locks the World-local `AuthorityFenceRow` and proves that cell, epoch, token, active state, and expiry match the sealed lease. The default single-cell deployment uses the same fence. One World has one authority cell at an epoch, and no authority transaction spans cells. Read, dense, compute, and edge cells receive signed, bounded artifacts or capabilities. They cannot advance a World head.

An offline edge deployment that must decide locally owns a separate edge World and normal authority head. Synchronization exchanges signed evidence, proposals, receipts, and immutable manifests under a realm-qualified `FederationAgreement`; live and evaluation references cannot be mixed. It never turns two databases into simultaneous writers for one World. A `FederatedFrame` is a composite of independently authorized, signed, disclosed Frames. It has no synthetic global cut and cannot back an allegedly atomic cross-World Action. Cross-World work uses independently committed requests and receipts with explicit partial outcomes.

A `PackArtifact` is distribution, not installation. Studio resolves it, displays semantic, dependency, rights, capability, credential, and migration diffs, then creates a `ReleaseProposal`. Evaluation, review, preparation, and activation remain mandatory. A pack cannot grant membership, install credentials, weaken policy, or start a connector by being signed.

## Finance execution lifecycle

```ts
export type CurrencyId = Brand<string, "CurrencyId">;
export type InstrumentId = Brand<string, "InstrumentId">;
export type QuantityUnitId = Brand<string, "QuantityUnitId">;

export interface ExactAmount<Unit> {
  readonly coefficient: bigint;
  readonly scale: Brand<number, "DecimalScale">;
  readonly unit: Unit;
}

export type Money = ExactAmount<CurrencyId>;
export type Quantity = ExactAmount<QuantityUnitId>;

export interface UnitPrice {
  readonly money: Money;
  readonly per: Quantity;
}

export interface ProviderOrderEvidence {
  readonly observation: Digest<"ProviderOrderObservation">;
  readonly providerOrder:
    | Readonly<{ kind: "assigned"; identity: Digest<"VenueOrderIdentity"> }>
    | Readonly<{ kind: "not-assigned" }>;
  readonly providerSequence:
    | Readonly<{ kind: "reported"; value: ProviderSequence }>
    | Readonly<{ kind: "unreported" }>;
  readonly providerAssertedAt: string;
  readonly receivedAt: string;
  readonly evidence: EvidenceRef;
}

export type FinanceOrderState =
  | Readonly<{ kind: "decision-recorded"; receipt: Digest<"DecisionReceipt"> }>
  | Readonly<{ kind: "submitted"; support: ProviderOrderEvidence }>
  | Readonly<{ kind: "accepted"; support: ProviderOrderEvidence }>
  | Readonly<{ kind: "working"; leaves: Quantity; support: ProviderOrderEvidence }>
  | Readonly<{
      kind: "partially-filled";
      cumulative: Quantity;
      leaves: Quantity;
      fills: NonEmpty<Digest<"ExecutionIdentity">>;
      support: ProviderOrderEvidence;
    }>
  | Readonly<{
      kind: "filled";
      cumulative: Quantity;
      fills: NonEmpty<Digest<"ExecutionIdentity">>;
      support: ProviderOrderEvidence;
    }>
  | Readonly<{ kind: "cancel-pending"; request: Digest<"CancelRequest">; support: ProviderOrderEvidence }>
  | Readonly<{ kind: "canceled"; cumulative: Quantity; support: ProviderOrderEvidence }>
  | Readonly<{
      kind: "replaced";
      replacement: Digest<"OrderIdentity">;
      support: ProviderOrderEvidence;
    }>
  | Readonly<{ kind: "rejected"; reason: Digest<"ProviderRejectionReason">; support: ProviderOrderEvidence }>
  | Readonly<{ kind: "expired"; support: ProviderOrderEvidence }>
  | Readonly<{
      kind: "unknown";
      reconciliation: Digest<"ReconciliationState">;
      evidence: readonly EvidenceRef[];
    }>;

export interface FinanceOrder<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly order: Digest<"OrderIdentity">;
  readonly decision: Digest<"DecisionReceipt">;
  readonly intent: EffectRef<R>;
  readonly revision: Brand<bigint, "OrderRevision">;
  readonly prior:
    | Readonly<{ kind: "initial" }>
    | Readonly<{ kind: "revision"; value: Brand<bigint, "OrderRevision"> }>;
  readonly state: FinanceOrderState;
  readonly validAt: string;
  readonly admission: AuthorityCommitRef<R>;
  readonly admittedAt: WorldCut;
}

export interface ExecutionMandate<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly mandate: SemanticId;
  readonly revision: Brand<bigint, "ExecutionMandateRevision">;
  readonly principal: PrincipalId;
  readonly basis: KnowledgeBasis<R>;
  readonly accounts: ObjectSetPlan;
  readonly instruments: ObjectSetPlan;
  readonly venues: NonEmpty<SemanticId>;
  readonly orderTypes: NonEmpty<SemanticId>;
  readonly maxGrossNotional: NonEmpty<Readonly<{
    amount: Money;
    valuationPolicy: SemanticId;
  }>>;
  readonly positionLimits: NonEmpty<Readonly<{
    instruments: ObjectSetPlan;
    maximumAbsolute: Quantity;
  }>>;
  readonly priceProtection: SemanticId;
  readonly participationPolicy: SemanticId;
  readonly timingPolicy: SemanticId;
  readonly lossLimits: NonEmpty<Money>;
  readonly killPolicy: SemanticId;
  readonly compliancePolicy: SemanticId;
  readonly planner: ArtifactDigest<"action-planner">;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly validFrom: string;
  readonly expiresAt: string;
  readonly receipt: Digest<"DecisionReceipt">;
}

export interface MandateReservation<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly mandate: SemanticId;
  readonly mandateRevision: Brand<bigint, "ExecutionMandateRevision">;
  readonly childOrder: Digest<"OrderIdentity">;
  readonly notional: Money;
  readonly valuationBasis: ExactReadSet<R>;
  readonly commit: AuthorityCommitRef<R>;
}

export interface FillObservation<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly order: Digest<"OrderIdentity">;
  readonly execution: Digest<"ExecutionIdentity">;
  readonly venue: SemanticId;
  readonly instrument: InstrumentId;
  readonly quantity: Quantity;
  readonly price: UnitPrice;
  readonly tradeAt: string;
  readonly providerAssertedAt: string;
  readonly receivedAt: string;
  readonly providerRevision: string;
  readonly evidence: EvidenceRef;
  readonly rightsDecision: Digest<"RightsDecision">;
  readonly admission: AuthorityCommitRef<R>;
  readonly admittedAt: WorldCut;
}
```

Place, cancel, replace, allocate, affirm, and settle are distinct released Actions. Pre-trade policy, current entitlements, instrument identity, venue state, limits, and an `AdmittedObservationRef` are explicit Case dependencies. Money, quantity, and unit price are exact, unit-bearing values; `ReleasedValue` cannot stand in for them. A `DecisionReceipt` means only that Zoen accepted the local decision and created an `EffectIntent`. It does not mean that a broker or venue accepted the order.

Provider acknowledgements, order-state updates, fills, busts, corrections, allocations, confirmations, clearing, cash, and custody movements are separate evidence-backed facts admitted through `AuthorityCommit`. Quantity and money use released decimal rules. Positions, cash, exposure, performance, and risk derive from those facts and pin their dataset versions. Financial settlement is a domain lifecycle fact; `EffectSettlement` is Zoen's evidence state for one external effect. The two names must not collapse into one boolean.

Every externally asserted order state embeds the exact provider evidence that supports that revision; an operational connector status cannot construct it. An approved `ExecutionMandate` permits bounded automation, not ambient trading authority. Every child order is planned by the pinned `ActionPlannerArtifact`, rechecked against the current mandate, rights, admitted market capture, portfolio reads, and kill state, and atomically reserves its mandate budget in the child's AuthorityCommit. Concurrent children therefore cannot overspend the same limit. Ambiguous submission is `unknown`; reconciliation precedes retry. Emergency cancel is itself a released Action with an explicit degraded-market policy.

## Public surface mapping

Every released capability has one stable semantic identity and separately authored idiomatic facets:

```text
semantic id   money.reserve.protect
API           POST /ontology/v1/worlds/{world}/money/reserve/protect
CLI           zoen money reserve protect
MCP           money.reserve.protect
Eve           model tool optimized for conversational use
Living World  consequence and decision affordance
```

The server may use a catch-all router internally, but no public caller sees storage-shaped CRUD or a generic query plan. Static kernel routes open Frames, Cases, Notices, explanations, and releases. Released routes remain domain verbs.

The active `WorldRelease` produces one `SurfaceManifest`. Generation emits:

- JSON Schema 2020-12 for released values;
- OpenAPI 3.1 for named HTTP operations;
- MCP tool/resource schemas;
- CLI command/help/completion metadata;
- browser-safe TypeScript clients and presentation types.

Generation is reproducible and CI requires a clean diff. Generated code contains no policy or authority. Runtime schema validation remains mandatory because TypeScript disappears at the wire.

## HTTP, CLI, MCP, and streaming

- JSON uses UTF-8, explicit media types, and stable envelope/error versions. Errors use `application/problem+json` with a stable Zoen code and trace ID.
- Every mutation requires `Idempotency-Key`. Same key and canonical intent replays the result; a different intent conflicts.
- Results identify World, release, generation, cut, result digest, and trace.
- Browser commands use POST. SSE carries transient model tokens, progress, and settled-event references. Reconnection reads committed Eve state; token chunks are never replayed as truth.
- Pagination cursors are opaque, signed, expiring, and bound to release, disclosure, sort, and query digest.
- CLI authentication uses Better Auth OAuth 2.1 device authorization, stores refresh credentials in the operating-system keychain, and requests resource-bound tokens.
- Hosted MCP uses Streamable HTTP and Better Auth's OAuth/MCP composition. Discovery is filtered before names and schemas are revealed. The stdio bridge is a thin CLI client of the same hosted API.
- Cookie mutations require exact-origin and CSRF checks. OAuth clients use PKCE; dynamic registration remains disabled until an interoperability journey requires Client ID Metadata Documents or a reviewed registration flow.

## Error disclosure

Errors distinguish invalid input, expired continuation, stale state, idempotency conflict, and temporary inability only when the distinction is safe. Existence-sensitive failures collapse to `not-found-or-not-disclosable`. Internal SQL, policy identities not authorized for discovery, provider details, and stack traces never cross a public boundary.
