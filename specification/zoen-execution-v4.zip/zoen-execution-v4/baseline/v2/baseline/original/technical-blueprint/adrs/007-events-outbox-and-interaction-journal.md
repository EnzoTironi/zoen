# ADR 007: Meaningful events, transactional outbox, and Eve Workflow materialization

Status: Accepted

## Context

"Event-driven" can mean three incompatible things: an immutable account of changes in authority, a delivery mechanism for asynchronous work, or a transcript of conversational activity. Combining them produces either an authority log full of retries and token chunks or a chat log that can be replayed as if it changed the World.

Zoen needs event semantics without introducing Redis, a broker, or eventual consistency between modules that already share a PostgreSQL transaction.

## Decision

Every AuthorityCommit writes exactly one immutable `AuthorityCommitEnvelope` for its World cut. Its canonical `AuthorityCommitPayload` contains:

- commit ID, realm, World, cut, operation kind, idempotency coordinate, actor, delegated client, purpose, root cause, optional parent commit, and authorization decision digest;
- the complete before `WorldHead` and next non-audit head coordinates;
- a non-empty ordered, closed union of semantic changes, each with stream ID, stream revision, stable change ID, subject, change kind, and canonical payload digest;
- created Case, receipt, effect intent, dense publication, and release proof references;
- authority-cell fence identity and recorded time.

Changes are sorted deterministically. Zoen stores parsed columns and exact canonical payload bytes. `payloadDigest` excludes the resulting audit root. The next root is the versioned, domain-separated hash of the previous root and payload digest; the envelope's complete `after` head is the payload's next coordinates plus that root. Database constraints require `headVersion + 1`, `cut + 1`, one envelope per cut, and equality between the envelope, stored head, and returned receipt. The ordered change union is the public semantic history. Projection builders may replay it, but domain state remains authoritative PostgreSQL state at a cut; the envelope is not a generic event-sourcing framework.

Asynchronous delivery uses transactional outbox rows written in the same AuthorityCommit. Every semantic outbox row references the commit ID and envelope digest and has a deterministic message ID, closed destination kind, payload digest or immutable reference, available time, attempt policy, and handler revision. Workers claim rows with `FOR UPDATE SKIP LOCKED`, perform delivery outside the transaction, and use ProgressCommit to record attempts and durable consumer receipts. Delivery is at least once; consumers deduplicate on message ID.

PostgreSQL `LISTEN/NOTIFY` may wake a worker, but the outbox table is the durable source. Missed notifications are harmless because workers poll. An envelope consumer atomically writes its derived state and a unique `(consumerId, commitId)` receipt. Redis and BullMQ are forbidden in every role under the current constitution. Kafka or NATS may later carry exported envelopes only after a demonstrated external consumer and explicit transport gate; neither can become a local commit boundary.

Channel ingress has a process boundary. After provider authentication and decoding create `VerifiedChannelIngress`, one local transaction inserts `AdmittedChannelIngress` and a deterministic Eve-delivery outbox row. The provider receives 2xx only after that commit. An idempotent dispatcher then submits the stable ingress identity to Eve; model work begins only after Eve durably accepts it. Zoen does not claim a transaction across the channel-admission database and Eve Workflow history.

Eve Workflow history is conversation execution truth for accepted messages, turn claims, model attempts, tool calls/results, assistant messages, Focus changes, Notice arbitration, forks, wakeups, rendering, and delivery work. `InteractionJournal` and space interactions are typed Eve-owned materializations of that history for product reads; they are rebuildable, have no independent resumption cursor or competing hash chain, and cannot schedule work. Model token chunks, typing indicators, and streaming deltas remain transient presentation.

Audit roots include AuthorityCommit envelopes only. An Eve Workflow replay or outbox replay can call a public Ontology verb with a fresh authority check; it cannot replay conversation history as authority.

## Consequences

- There is one semantic event per commit, one reliable Ontology outbox mechanism, one durable channel-admission handoff, and one Eve Workflow execution history. Their guarantees are explicit.
- Internal product coordination remains synchronous and transactional where it should be.
- Consumers must be idempotent and handler revisions must remain available while messages reference them.
- Rebuilding a projection does not rebuild third-party side effects. Effects are governed separately by ADR 015.

## Reopen triggers

- Outbox backlog misses its service objective for seven days after indexing, batching, and worker tuning; evaluate a broker as a delivery adapter while retaining PostgreSQL commit atomicity.
- An independently deployed external consumer requires a standard event transport. Publish the existing closed envelope through an outbox destination; do not create a second event vocabulary.
- AuthorityCommit envelopes cannot support a required historical query. Add a versioned change variant and migration proof; do not insert operational attempts into the authority stream.
- Eve Workflow volume threatens isolation. Scale or move its owner database while preserving stable ingress identities and typed materializations.
- No trigger permits Redis or BullMQ in any role under the current constitution.
