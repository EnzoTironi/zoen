# Candidate A: Rust authority kernel with TypeScript relationship edge

Status: arena candidate, not the recommended architecture by default.

Decision date: 2026-09-04.

## Verdict

This design is coherent, but it does not establish that Zoen should start with two languages.

The durable correctness properties come mainly from the domain model, PostgreSQL constraints, credential separation, deterministic artifacts, and the single `AuthorityCommit` port. Strict TypeScript can implement those properties. Rust adds compile-time resistance to invalid authority states and gives Zoen an excellent native home for DataFusion, Arrow, Wasmtime, a portable CLI, and the official Rust MCP SDK. Those are risk reductions and performance options, not product capabilities that TypeScript cannot express.

Choose this candidate only after one of these gates passes:

1. A representative dense Frame cannot meet its latency and memory budget in the TypeScript candidate without a separate native query process.
2. Governed release modules require an embedded Wasmtime host with deterministic resource limits in the first three product slices.
3. Ontology must ship as an embeddable, offline, single-binary product before the web product proves demand.
4. A comparative implementation finds materially fewer authority or concurrency defects in Rust journeys, after accounting for the seam defects that the second runtime introduces.

Until then, 100% TypeScript has the lower total complexity. Rust can be added later behind the same `OntologyPort` for dense execution or portable distribution without changing the public product model.

Parquet is not conditional on Rust. Immutable Parquet segments, content-addressed manifest DAGs, PostgreSQL admission records, and Frame-pinned manifest roots remain part of every viable candidate. The current evidence does **not** show that Rust plus DataFusion beats TypeScript plus DuckDB by enough to pay for a permanent second language and process. Candidate A remains a benchmark-contingent alternative, not the starting recommendation.

## 1. Product promise

Zoen is one governed World reached through exactly three products:

- Door proves account, session, and device identity with Better Auth.
- Eve owns the relationship, conversation continuity, attention arbitration, wording, and channels.
- Ontology owns published meaning, identity resolution, evidence, belief, authority, domain Actions, Watches, Notices, receipts, and evidence-bound external Settlements. CLI, API, MCP, and builder capabilities are faces of this product.

The runtime preserves one loop:

```text
authority-free Focus
  -> fresh DoorProof
  -> purpose-bound WorldSession
  -> WorldFrame
       -> answer and explanation
       -> domain Action -> ActionCase -> DecisionReceipt
                                         -> EffectIntent -> Settlement
       -> Watch -> Notice -> Eve arbitration and delivery
       -> read-only Scenario -> fresh live ActionCase if applied
```

The user should never need to understand which language or process served a request. A Frame, Case, Notice, receipt, or Settlement has the same identity and semantics in conversation, Living World, CLI, API, and MCP.

## 2. Usage

### 2.1 Person: ask, inspect, decide

A browser caller does not call Ontology directly. It presents a Better Auth cookie to Eve. Eve turns the verified session into a short-lived identity-only `DoorProof`, opens a purpose-bound World session, and uses released capabilities.

```ts
const turn = await eve.beginTurn({
  relationship: relationshipRef,
  message: "Se eu mantiver o ritmo atual, quando minha reserva fica apertada?",
  focus,
})

for await (const event of turn.events()) {
  render(event)
}

// A consequential tool result is not hidden in prose.
const proposal = await turn.propose("finance.protect-reserve", {
  reserveFloor: { amount: "25000.00", currency: "BRL" },
})

switch (proposal.kind) {
  case "committed":
    showReceipt(proposal.receipt)
    break
  case "needs-decision":
    showCase(proposal.view, proposal.handle)
    break
  case "impossible":
    showExplanation(proposal.explanation)
    break
}
```

The browser may put `Focus` in the URL. It may not put a World grant, evidence payload, Case view, DecisionHandle, or Notice disclosure there. Reopening a Focus always repeats Door and World authorization.

### 2.2 Operator: inspect the same World without a dashboard fork

```sh
zoen world enter personal --purpose financial-planning
zoen cash-runway --as-of 2026-09-04T12:00:00-03:00 --explain
zoen case open case_01K... --format json
zoen case answer case_01K... approve --operation-key 01K...
zoen watch list --attention
zoen receipt explain decision_01K...
```

`cash-runway` is a released domain capability. The CLI does not expose `createObject`, `executeMutation`, or other storage-shaped verbs. JSON output is the same semantic result as the human rendering, not a dump of rows.

### 2.3 Builder: teach once, prove, prepare, activate

```sh
zoen release build ./world --out dist/world-release.json
zoen release evaluate dist/world-release.json --journeys ./world/journeys
zoen release publish dist/world-release.json release-proof.dsse
zoen release prepare world_01K... sha256:9da...
zoen release activate world_01K... prepared_01K... --operation-key 01K...
```

`build` emits canonical, immutable bytes. `evaluate` runs the normal Door, Eve, API, CLI, MCP, storage, and effect paths inside an isolated EvaluationWorld. `prepare` is World-specific and cut-specific. Activation is one compare-and-swap of `WorldHead`, never a dual-read rollout.

The source bundle is portable and unsurprising:

```text
world/
  world.json
  objects/*.json
  links/*.json
  capabilities/*.json
  policies/*.cedar
  components/*.wasm
  journeys/*.journey.ts
```

Studio edits the same draft model and exports this bundle. JSON Schema validates JSON files. Cedar is used only for authorization. Wasm components are optional, signed, deterministic semantic functions; they cannot perform I/O.

### 2.4 Agent: discover only what it may use

An MCP client authenticates through Door and declares a purpose and World. Ontology filters tools and resources before listing them.

```text
initialize
  -> Door proves AgentPrincipal
  -> enter(world, purpose)
  -> tools/list returns only released and authorized domain capabilities
  -> tools/call finance.protect_reserve
  -> ActionCase or receipt, never an invented success string
```

An agent receives the same Case, decision rule, receipts, and stale-read behavior as a person. Policy can prevent it from receiving a DecisionHandle even when it may prepare a Case.

### 2.5 Eve harness: model-visible state is durable state

```ts
interface EveModelPort {
  stream(attempt: ModelAttempt): AsyncIterable<ModelEvent>
}

type ModelAttempt = Readonly<{
  attemptId: ModelAttemptId
  relationship: RelationshipRef
  focus: Focus
  releasedTools: readonly ModelTool[]
  journalCut: InteractionCut
  modelProfile: ModelProfileId
}>
```

The model sees only the released, authorized tool catalog and explicit tool results. It never sees a database client, raw session token, connector secret, or generic shell. Every settled model attempt, tool call, result, and assistant message is appended to Eve's journal. Token chunks are transient presentation, not durable truth.

The first model adapter is the official OpenAI Node SDK 7.x using the Responses API. Model names and sampling profiles are release or deployment data, not source constants. The adapter is replaceable because OpenAI types stop at `OpenAiModelAdapter`; Zoen's `ModelAttempt` and `ModelEvent` are the port.

## 3. Core domain types

These sketches are Rust because the candidate puts the authority kernel there. Wire representations are generated, versioned projections. Database and HTTP types do not appear here.

### 3.1 Branded references and realms

```rust
pub trait Realm: sealed::Sealed {
    type Id: Clone + Eq + Hash;
    const KIND: RealmKind;
}

pub enum Live {}
pub enum Evaluation {}

pub struct Ref<K, R: Realm> {
    id: Uuid,
    realm: R::Id,
    _kind: PhantomData<K>,
}

pub type WorldRef<R> = Ref<World, R>;
pub type RelationshipRef<R> = Ref<Relationship, R>;
pub type EffectIntentRef<R> = Ref<EffectIntent, R>;
pub type ChannelBindingRef<R> = Ref<ChannelBinding, R>;
```

The constructors are private to the model crate. There is no cast between `Live` and `Evaluation`. Serialization includes the realm and validates it before construction.

### 3.2 Identity and authority

```rust
pub struct DoorProof {
    account: AccountId,
    session: DoorSessionId,
    device: Option<DeviceId>,
    authentication_time: Instant,
    issued_at: Instant,
    expires_at: Instant,
    nonce: Nonce,
    mac: DoorProofMac,
}

pub struct EnterWorld {
    world: WorldLocator,
    purpose: PurposeId,
    focus: Option<Focus>,
}

pub struct WorldSession<R: Realm> {
    world: WorldRef<R>,
    principal: PrincipalId,
    purpose: PurposeId,
    audience: AudienceId,
    membership_revision: Revision,
    release: ReleaseId,
    expires_at: Instant,
    grant: OpaqueGrant,
}

pub struct Focus {
    subject: Option<SemanticRef>,
    lens: Option<CapabilityId>,
    basis_intent: BasisIntent,
    frame: Option<FrameRef>,
    case: Option<CaseRef>,
    watch: Option<WatchRef>,
}
```

`DoorProof` contains no World, role, membership, delegation, audience, or purpose. `Focus` contains no credential or disclosed content. `WorldSession` is short-lived, single-purpose, opaque on the wire, and rechecks current membership and delegation on consequential operations.

### 3.3 Time, knowledge, and evidence

```rust
pub struct TemporalBasis {
    valid_at: ValidTime,
    recorded_through: KnowledgeCut,
    observations: ManifestRoot,
    belief_policy: BeliefPolicyId,
}

pub struct Evidence<R: Realm> {
    id: EvidenceRef<R>,
    source: SourceRef<R>,
    raw_capture: ArtifactDigest,
    observed_at: Option<Instant>,
    captured_at: Instant,
    admitted_at: Instant,
    rights: EvidenceRights,
    payload_digest: Digest,
}

pub struct Claim<T, R: Realm> {
    subject: SemanticRef,
    predicate: PredicateId,
    value: T,
    valid_during: ValidInterval,
    asserted_by: PrincipalOrSource,
    evidence: NonEmpty<EvidenceRef<R>>,
}

pub enum Belief<T, R: Realm> {
    Accepted {
        value: T,
        valid_during: ValidInterval,
        evidence: NonEmpty<EvidenceRef<R>>,
        policy: BeliefPolicyId,
    },
    Disputed {
        rivals: NonEmpty<ClaimRef<R>>,
        policy: BeliefPolicyId,
    },
    Unknown {
        gap: GapReason,
    },
}

pub struct ReadDependency {
    stream: SemanticStreamId,
    revision: Revision,
    value_digest: Digest,
}
```

Evidence, a claim, and an accepted belief cannot substitute for one another. Recorded time, valid time, provider time, and World cut are distinct types. Money and arbitrary precision quantities cross JSON as validated canonical strings; no authority calculation uses IEEE-754 values.

### 3.4 Frame

```rust
pub struct WorldFrame<R: Realm> {
    id: FrameRef<R>,
    world: WorldRef<R>,
    release: ReleaseId,
    purpose: PurposeId,
    audience: AudienceId,
    basis: TemporalBasis,
    result: ReleasedValue,
    gaps: Vec<Gap>,
    uncertainty: Uncertainty,
    explanation: ExplanationRef,
    reads: NonEmpty<ReadDependency>,
}
```

`ReleasedValue` is validated against the output schema identified by the capability in the same release. It is not an untyped `serde_json::Value`; the wrapper holds canonical bytes, schema identity, and digest.

### 3.5 Action, deliberation, and commit

```rust
pub struct InvokeAction {
    capability: ActionCapabilityId,
    intent: ReleasedValue,
    operation: OperationKey,
}

pub enum InvokeOutcome<R: Realm> {
    Committed(DecisionReceipt<R>),
    NeedsDecision {
        case: CaseRef<R>,
        view: AuthorizedCaseView<R>,
    },
    Impossible(Explanation),
}

pub struct ActionCase<R: Realm> {
    id: CaseRef<R>,
    world: WorldRef<R>,
    release: ReleaseId,
    action: ActionCapabilityId,
    intent_digest: Digest,
    reads: NonEmpty<ReadDependency>,
    rule: DecisionRule,
    version: Revision,
    expires_at: Instant,
}

pub struct AuthorizedCaseView<R: Realm> {
    case: CaseRef<R>,
    principal: PrincipalId,
    audience: AudienceId,
    version: Revision,
    disclosure: DisclosureDigest,
    view_digest: Digest,
    consequences: ReleasedValue,
    handle: Option<DecisionHandle<R>>,
}

pub struct DecisionHandle<R: Realm> {
    token: OpaqueDecisionToken,
    case: CaseRef<R>,
    principal: PrincipalId,
    case_version: Revision,
    view_digest: Digest,
    expires_at: Instant,
}

pub enum AnswerOutcome<R: Realm> {
    Progress(AuthorizedCaseProgress<R>),
    Committed(DecisionReceipt<R>),
    Stale(StaleCase),
    Expired,
    NotDisclosable,
}

pub struct DecisionReceipt<R: Realm> {
    id: DecisionReceiptRef<R>,
    case: Option<CaseRef<R>>,
    world_cut: WorldCut,
    decision_digest: Digest,
    changes: NonEmpty<SemanticChange>,
    effects: Vec<EffectIntentRef<R>>,
    policy: PolicyProof,
    recorded_at: Instant,
}
```

An answer requires the server-issued handle bound to what that principal actually saw. A quorum contribution is durable but not a commitment. Completion reauthorizes all contributors and rechecks every read dependency. The kernel never refreshes intent after consent.

### 3.6 Watch, Notice, and interaction boundary

```rust
pub enum ReleaseTrack {
    Pinned(ReleaseId),
    Compatible(SemanticTrackId),
}

pub struct Watch<R: Realm> {
    id: WatchRef<R>,
    owner: PrincipalId,
    purpose: PurposeId,
    capability: WatchCapabilityId,
    intent_digest: Digest,
    track: ReleaseTrack,
    state: WatchState,
    checkpoint: WatchCheckpoint,
}

pub struct Notice<R: Realm> {
    id: NoticeRef<R>,
    watch: WatchRef<R>,
    caused_by: TransitionRef<R>,
    materiality: MaterialityProof,
    created_at: Instant,
}

pub enum OpenNoticeOutcome<R: Realm> {
    Open(AuthorizedNoticeView<R>),
    Redacted(RedactedNotice),
    Suppressed(SuppressionReason),
}
```

The Ontology outbox sends only `NoticeRef` to Eve. Eve opens it under the durable Watch purpose when arbitrating and again immediately before composition. Eve stores a deferred reference, never a stale `AuthorizedNoticeView`.

### 3.7 Effect and Settlement

```rust
pub struct EffectIntent<R: Realm> {
    id: EffectIntentRef<R>,
    receipt: DecisionReceiptRef<R>,
    connector: ConnectorId,
    operation: ConnectorOperationId,
    request_digest: Digest,
    destination_idempotency: IdempotencySupport,
    state: EffectState,
}

pub enum EffectState {
    Planned,
    AttemptReserved { attempt: AttemptId },
    Reconciling { attempt: AttemptId },
    Settled,
}

pub enum SettlementFact {
    Observed(ReleasedValue),
    Unknown {
        attempt: AttemptId,
        reason: UnknownReason,
        reconciliation: ReconciliationState,
    },
}

pub struct Settlement<R: Realm> {
    id: SettlementRef<R>,
    effect: EffectIntentRef<R>,
    fact: SettlementFact,
    evidence: NonEmpty<EvidenceRef<R>>,
    recorded_at: Instant,
}
```

There is no generic `Succeeded`. A provider timeout or process crash after an unsafe external call becomes `Unknown`; the next invocation reconciles rather than blindly repeating it. Automatic retries are permitted only when the connector contract proves destination idempotency and reuses the same destination key.

### 3.8 Meaning and activation

```rust
pub struct WorldRelease {
    id: ReleaseId,                 // sha256 of exact canonical bytes
    semantic_manifest: ArtifactDigest,
    schemas: SchemaSetDigest,
    cedar_schema: ArtifactDigest,
    cedar_policies: ArtifactDigest,
    components: Vec<WasmComponentDigest>,
    capability_catalog: CapabilityCatalogDigest,
    journey_suite: JourneySuiteDigest,
}

pub struct ReleaseProof {
    release: ReleaseId,
    evaluation_realm: EvaluationRealmId,
    attestations: NonEmpty<Attestation>,
    envelope: DsseEnvelopeRef,
}

pub struct PreparedActivation<R: Realm> {
    world: WorldRef<R>,
    expected_head: WorldHead,
    target_release: ReleaseId,
    data_generation: DataGenerationId,
    ready_through: WorldCut,
    open_case_disposition: Digest,
    watch_disposition: Digest,
    invariant_results: Digest,
}

pub struct WorldHead {
    release: ReleaseId,
    data_generation: DataGenerationId,
    cut: WorldCut,
    revision: Revision,
}
```

Release proof and World preparation are separate facts. Activation requires both and changes `WorldHead` using expected-head compare-and-swap in the same authority transaction that writes its receipt, transition, and outbox.

## 4. Public interfaces and signatures

### 4.1 One Ontology facade

```rust
pub trait Ontology<R: Realm>: Send + Sync {
    async fn enter(
        &self,
        proof: DoorProof,
        request: EnterWorld,
    ) -> Result<WorldSession<R>, EnterError>;

    async fn inspect(
        &self,
        session: &WorldSession<R>,
        capability: InspectCapabilityId,
        input: ReleasedValue,
        basis: BasisIntent,
    ) -> Result<WorldFrame<R>, InspectError>;

    async fn invoke(
        &self,
        session: &WorldSession<R>,
        request: InvokeAction,
    ) -> Result<InvokeOutcome<R>, InvokeError>;

    async fn open_case(
        &self,
        session: &WorldSession<R>,
        case: CaseRef<R>,
    ) -> Result<AuthorizedCaseView<R>, DisclosureSafeError>;

    async fn answer(
        &self,
        session: &WorldSession<R>,
        handle: DecisionHandle<R>,
        answer: ReleasedValue,
        operation: OperationKey,
    ) -> Result<AnswerOutcome<R>, AnswerError>;

    async fn create_watch(
        &self,
        session: &WorldSession<R>,
        capability: WatchCapabilityId,
        intent: ReleasedValue,
        operation: OperationKey,
    ) -> Result<Watch<R>, WatchError>;

    async fn open_notice(
        &self,
        relationship: RelationshipAuthority<R>,
        notice: NoticeRef<R>,
    ) -> Result<OpenNoticeOutcome<R>, DisclosureSafeError>;

    async fn scenario(
        &self,
        session: &WorldSession<R>,
        frame: FrameRef<R>,
    ) -> Result<ScenarioWorld<R>, ScenarioError>;

    async fn explain(
        &self,
        session: &WorldSession<R>,
        subject: ExplainableRef<R>,
    ) -> Result<Explanation, DisclosureSafeError>;
}
```

Callers cannot orchestrate internal acquire, normalize, authorize, validate, save, emit, or settle stages. The methods represent complete semantic promises.

### 4.2 The only authority write port

```rust
pub(crate) trait AuthorityCommit<R: Realm> {
    async fn execute<T>(
        &self,
        context: CommitContext<R>,
        operation: OperationKey,
        intent: IntentDigest,
        mutation: AuthorizedMutation<R, T>,
    ) -> Result<Idempotent<T>, CommitError>;
}
```

Only kernel engines can construct `AuthorizedMutation`. Only the PostgreSQL adapter implements `AuthorityCommit`. Its one serializable transaction writes:

1. the operation-key record;
2. domain changes;
3. the receipt or Settlement;
4. deterministic EffectIntents, if any;
5. causal `WorldTransition` rows;
6. transactional outbox rows;
7. the new World cut and hash-chain root.

No network, model, object-store write, or provider call occurs inside this transaction. A pure plan is computed first; exact reads and policy are revalidated inside the commit. Serialization failures retry the transaction with the same intent digest. Reusing an operation key with different intent returns `IdempotencyConflict`.

### 4.3 Evidence admission

```rust
pub trait EvidenceAdmission<R: Realm> {
    async fn acquire(
        &self,
        lease: SourceLease<R>,
        request: AcquisitionRequest,
    ) -> Result<RawCapture, AcquisitionError>;

    async fn admit(
        &self,
        session: &WorldSession<R>,
        capture: RawCapture,
        operation: OperationKey,
    ) -> Result<AdmissionReceipt<R>, AdmissionError>;
}
```

The raw capture is immutable in object storage before admission. An interrupted capture may leave an unreachable object for later collection; it cannot leave half-accepted truth.

### 4.4 Effect execution

```rust
pub trait EffectControl<R: Realm> {
    async fn reserve_attempt(
        &self,
        intent: EffectIntentRef<R>,
    ) -> Result<AttemptDirective<R>, EffectError>;

    async fn record_settlement(
        &self,
        lease: EffectLease<R>,
        capture: RawCapture,
        observation: SettlementFact,
    ) -> Result<Settlement<R>, SettlementError>;
}

pub enum AttemptDirective<R: Realm> {
    Call(EffectLease<R>),
    RetryIdempotently(EffectLease<R>),
    Reconcile(ReconciliationLease<R>),
    AlreadySettled(SettlementRef<R>),
}
```

The Restate handler may execute only a lease. It cannot form intent, alter a decision, read arbitrary World data, or invent a Settlement.

### 4.5 Public protocol projections

The Rust surface layer derives OpenAPI 3.1 and JSON Schema from the stable runtime model and projects every released capability into native names:

- API: `POST /ontology/v1/worlds/{world}/actions/finance.protect-reserve`
- CLI: `zoen protect-reserve`
- MCP: `finance_protect_reserve`
- Eve tool: `finance.protect-reserve`

The stable runtime supports session entry, capability discovery, Frames, Cases, answers, Watches, Notices, Scenarios, explanations, releases, and receipts. Released schemas supply domain input and output. Discovery is authorized before names or schemas are revealed.

The Rust CLI uses the HTTPS API for runtime commands. It links the exact same release compiler only for offline `release build` and local validation. MCP uses the official `rmcp` Rust SDK and Streamable HTTP. The Node edge authenticates the request and byte-streams MCP and Ontology HTTP to the private Rust service; it does not reinterpret domain payloads.

### 4.6 Exact TypeScript to Rust seam

The seam is intentionally boring:

- Transport: HTTP/1.1 or HTTP/2 over Fly private networking.
- Representation: UTF-8 JSON, with JSON Schema 2020-12 for released values.
- Contract: one generated internal OpenAPI document checked into `contracts/internal/ontology-edge.openapi.json`.
- Client: `openapi-typescript` plus `openapi-fetch`; generated output is never hand-edited.
- Authentication: an app-internal credential plus a 30-second HMAC-SHA-256 `DoorProof` envelope. The envelope is identity-only.
- Deadlines and cancellation: every call has an explicit deadline; browser cancellation propagates through Eve to the kernel when safe.
- Trace context: W3C trace headers.
- Versioning: one image contains both sides. Pre-launch changes update server, contract, client, and journeys atomically; no compatibility shims.

The seam contains only these stable operations:

```text
enter
discover
inspect
invoke domain action
open/answer case
create/manage watch
open notice
open scenario
explain
publish/prepare/activate release
```

It does not expose repositories, SQL-shaped filters, arbitrary event publication, policy evaluation, or generic object mutation. A change that adds such a method fails architecture review.

HTTP/JSON is chosen over gRPC because release-defined values are already JSON-Schema-bound, the public API uses the same representation, browser and MCP paths already require HTTP, and a second IDL would create conversion code without strengthening authority. If measured payload or streaming costs make JSON material, Arrow IPC is used only for dense result bodies, not for authority commands.

## 5. Runtime and module map

### 5.1 Deployment topology

```text
Internet
   |
   v
Fly app: zoen
  edge process group, Node 24
    Hono public ingress
    Better Auth Door
    Eve turn engine and interaction journal
    channel ingress: /eve/v1/kapso and /eve/v1/telegram
    React asset server and SSE
    byte-stream proxy for Ontology API and MCP
          |
          | private HTTP + DoorProof
          v
  ontology process group, Rust 1.98
    Ontology facade and release compiler
    API, MCP, Watch and outbox workers
    DataFusion and Wasmtime hosts
    Restate Rust endpoint over outbound Restate Cloud tunnel
          |                         |
          v                         v
  Neon PostgreSQL 18          Tigris object storage
  Restate Cloud only schedules ZoenEffect
```

This is one Fly app and one OCI image with two process groups. Fly deploys process groups as separate Machines, so the design does not assume loopback. Both groups scale independently but deploy the same image digest. There is no Redis, Kafka, NATS, Temporal, Kubernetes, or general workflow service.

Evaluation runs the same image in CI or an ephemeral job against a separate Neon project/branch, separate database roles, separate Tigris prefix credentials, evaluation-only relationships, channel sinks or provider sandboxes, and sandbox-only source/effect credentials. Production credentials are absent from that job. Types also prevent cross-realm references.

### 5.2 Rust crates

```text
ontology-model
  domain values, branded refs, errors, release-bound values; no I/O

ontology-release
  draft validation, Cedar validation, Wasm validation, canonicalization,
  capability catalog generation, semantic diff, ReleaseProof verification

ontology-kernel
  admission, truth/identity, Frames, agency, attention, scenarios,
  activation; exports only Ontology and worker entrypoints

ontology-postgres
  implements AuthorityCommit and read ports with SQLx; owns all ontology SQL

ontology-artifacts
  immutable object storage, Arrow/Parquet manifests, DataFusion plans

ontology-surfaces
  Axum HTTP, OpenAPI generation, rmcp projection, error disclosure mapping

zoen-effect-dispatcher
  Restate service, connector leases, evidence capture, reconciliation

ontologyd
  composition root; config, pools, workers, graceful shutdown, health

zoen-cli
  HTTPS client plus the offline release compiler entrypoint
```

Allowed dependency direction:

```text
model <- release <- kernel <- surfaces <- ontologyd
model <- kernel <- postgres  <- ontologyd
model <- kernel <- artifacts <- ontologyd
model <- kernel <- effect-dispatcher <- ontologyd
model <- release <- zoen-cli
```

Rules:

- `ontology-model` has no Tokio, SQLx, HTTP, object-store, Restate, or model SDK dependency.
- `ontology-kernel` imports ports, never concrete adapters.
- only `ontology-postgres` imports SQLx or names tables;
- only `ontology-artifacts` imports Arrow, Parquet, DataFusion, or S3 clients;
- only `zoen-effect-dispatcher` imports the Restate SDK and destination connector clients;
- surfaces call the `Ontology` facade, never repositories;
- `.unwrap()` and linter bypasses are denied workspace-wide; generated protocol code is the sole lint exception allowed by policy;
- `unsafe` is denied in first-party crates. Audited dependencies may use it.

Cargo workspace dependency declarations pin one version per crate family. `cargo-deny` rejects duplicate critical libraries, unapproved licenses, advisories, and unknown git sources.

### 5.3 TypeScript modules

`apps/conversation` is the only Node executable. Its internal modules are deep ownership boundaries, not separate services:

```text
src/door/
  Better Auth configuration, session/API-key proof, DoorProof creation

src/eve/
  Eve facade, relationship journal, turn state machine, focus continuity,
  attention arbitration, presentation flattening

src/models/
  EveModelPort and the OpenAI adapter; provider types stay here

src/channels/
  Kapso and Telegram ingress/delivery adapters; no Ontology authority

src/ontology/
  generated client wrapper; the only module allowed to call private Ontology

src/http/
  Hono composition, auth middleware, SSE, static assets, byte-stream proxy

web/
  React Conversation and Living World application
```

Dependency-cruiser enforces:

- `door` imports Better Auth and its own database adapter only;
- `eve` receives `DoorPrincipal`; it cannot import Better Auth session types or tables;
- `models` implements `EveModelPort`; Eve cannot import OpenAI types;
- `channels` calls Eve, never Ontology or model providers;
- only `ontology` imports generated internal contract types;
- no TypeScript module has an Ontology database credential;
- `web` imports only generated public clients and browser-safe presentation types;
- no `shared`, `common`, or `utils` dumping ground is permitted. A third concrete duplication is the threshold to propose a named abstraction.

### 5.4 Technology ledger

Exact package patches are locked in `Cargo.lock` and `pnpm-lock.yaml`; they never float in deploys. The following lines are the architectural pins as of the decision date.

| Area | Decision | Reason |
| --- | --- | --- |
| Authority language | Rust 1.98.1, edition 2024 | Exhaustive algebraic types, realm branding, mature native data/Wasm stack, portable CLI |
| Relationship language | Node.js 24 LTS, TypeScript 6.0.2, ESM, strictest compiler options | Better Auth and model/channel ecosystem without using a TS 7 compiler/API split |
| Package manager | pnpm 11.25, frozen lockfile, install-script allowlist | Workspace efficiency and strict supply-chain defaults |
| Rust async/HTTP | Tokio 1, Axum 0.8.9 | Small, composable HTTP stack |
| Rust database | SQLx 0.8.x with offline metadata and checked SQL | SQL, constraints, and transactions remain visible; no ORM identity map |
| TypeScript HTTP | Hono 4 | Fetch-native routing and direct Better Auth handler integration |
| TypeScript database | Kysely 0.28 with `pg`; separate Door and Eve pools | Typed SQL without active-record objects |
| Authentication | Better Auth 1.6.22, PostgreSQL adapter, passkey, magic-link, and API-key plugins | Door proves identity; it does not model World membership |
| Authorization | Cedar 4.12.0 embedded in Rust | Schema-validated, deny-by-default RBAC/ABAC with explicit determining policies |
| Database | PostgreSQL 18 on Neon, current managed patch, minimum compute always on | Serializable authority, ranges, constraints, native UUIDv7, branches for isolated journey environments |
| Object storage | Tigris S3-compatible private bucket | Immutable raw evidence, releases, manifests, and Parquet near Fly |
| Dense data | Arrow/Parquet 59.x, DataFusion 54.1 | Typed columnar interchange and embedded predicate/projection pushdown |
| Governed code | Wasmtime 48 LTS Component Model, no ambient WASI | Sandboxed, fuel-limited semantic modules with explicit WIT capabilities |
| MCP | official Rust `rmcp` 3.0.1, Streamable HTTP | Ontology implements protocol semantics at the authority boundary |
| Effects | Restate Cloud, Rust SDK 0.12, outbound tunnel | Durable execution only for `ZoenEffect`; no public effect endpoint |
| Web | React 19.2, Vite 8.1, TanStack Router and Query | Authenticated client app, typed URL Focus, no server-component stack |
| Model adapter | official OpenAI Node SDK 7.x, Responses API | First adapter only; Zoen owns journal and tool semantics |
| Contracts | OpenAPI 3.1, JSON Schema 2020-12, `openapi-typescript`, `openapi-fetch` | One JSON-native seam and generated clients |
| Canonical identity | RFC 8785 JCS bytes plus SHA-256; DSSE for signatures | Reproducible content identity and typed signed attestations |
| Telemetry | OpenTelemetry/OTLP plus structured `tracing`; Grafana Cloud | Cross-runtime correlation without domain events becoming logs |
| Build/deploy | GitHub Actions, BuildKit, one signed OCI image, Fly process groups | One release unit, two independently scalable runtimes |

Why TypeScript 6.0 rather than 7.0: TypeScript 7.0 is stable but its first release has no compiler API, while current lint and generation tooling still consumes the TypeScript 6 API. Running two TypeScript compiler packages would add no product value. Reopen at TypeScript 7.1 after the compiler API and required tooling are stable.

Why PostgreSQL 18 on Neon rather than Fly Managed Postgres today: Fly's managed offering currently documents PostgreSQL 16. PostgreSQL 18 gives native UUIDv7 and is available managed on Neon. Use pooled connections for short Door/Eve reads and direct connections for kernel workers, migrations, and `LISTEN`; Neon's transaction pooler does not support `LISTEN`. `NOTIFY` remains a wake hint, so reconnects cannot lose work.

## 6. Storage and event model

### 6.1 Databases, schemas, and roles

One live PostgreSQL cluster contains three schemas and no cross-product table reads:

```text
auth.*       owned by zoen_door
eve.*        owned by zoen_eve
ontology.*   owned by zoen_ontology
```

`zoen_migrator` owns DDL but is unavailable to runtime processes. Better Auth migration generation produces reviewed SQL under `migrations/auth`; it never auto-migrates at process startup. A Rust `zoen-migrate` release command applies `auth`, `eve`, then `ontology` SQL migrations using a direct connection and records checksums.

The Node process opens separate pools with separate roles. No browser receives database credentials. The TypeScript runtime has no `zoen_ontology` credential. Cross-product work goes through the Ontology port. Runtime roles cannot update or delete append-only events, receipts, evidence metadata, or Settlements.

Evaluation uses a separate database and roles. `realm_id` still appears in every reference and artifact path; database isolation is not used as an excuse to omit realm checks.

### 6.2 Sparse authority model

PostgreSQL stores:

- Worlds, heads, memberships, delegations, purpose grants, disclosure markings;
- releases, proofs, preparations, activations, and semantic identities;
- evidence metadata, claims, beliefs, identity rivals and resolutions;
- Frame metadata and read sets;
- Cases, versions, authorized-view digests, decision contributions, receipts;
- Watches, checkpoints, Notices;
- EffectIntents, attempts, Settlement evidence, Settlements;
- operation idempotency, transitions, and outbox;
- Eve relationships, turns, settled interaction events, deferred Notice refs, channel attempts and observations.

Temporal facts use half-open `tstzrange` valid intervals and append-only recorded intervals. Exclusion constraints prevent two simultaneously accepted beliefs for the same single-valued semantic key unless the released belief policy explicitly represents a dispute. Database times are UTC. The API preserves the requested zone separately for presentation.

### 6.3 Identifiers and clocks

- Operational/public entity IDs use UUIDv7.
- `ReleaseId`, artifact IDs, manifest nodes, view digests, and intent digests use SHA-256 over canonical bytes.
- `EffectIntentId` is deterministic over decision receipt, capability, ordinal, and request digest.
- `OperationKey` is caller-generated UUIDv7; its `(world, key)` uniqueness is enforced in PostgreSQL.
- opaque grants and handles are 256-bit random values; only SHA-256 hashes are stored.
- each World has a monotonically increasing `WorldCut` and per-stream revisions.
- `observed_at`, `captured_at`, `admitted_at`, `recorded_at`, `valid_during`, and external settlement time are distinct columns and types.

### 6.4 Meaningful transitions, not universal event sourcing

```rust
pub struct WorldTransition<R: Realm> {
    id: TransitionRef<R>,
    world: WorldRef<R>,
    cut: WorldCut,
    stream: SemanticStreamId,
    revision: Revision,
    actor: PrincipalOrSystem,
    purpose: PurposeId,
    release: ReleaseId,
    root_cause: CausationId,
    parent: Option<TransitionRef<R>>,
    kind: TransitionKind,
    payload: CanonicalPayload,
    payload_digest: Digest,
    previous_world_digest: Digest,
    world_digest: Digest,
    recorded_at: Instant,
}
```

The transition batch and outbox are siblings of the semantic write. Events do not reconstruct raw evidence bytes or dense points. Current/as-of projections remain first-class authority tables. The per-World hash chain makes accidental or unauthorized historical mutation detectable; signed periodic checkpoints make exported Worlds independently verifiable.

### 6.5 Transactional outbox and workers

Every outbox row has a UUIDv7 ID, transition ref, destination class, payload digest, attempt count, availability time, and delivery state. Workers claim queue rows with deterministic ordering and `FOR UPDATE SKIP LOCKED`, which PostgreSQL documents as appropriate for queue-like consumers. Delivery is at least once. Consumer stores deduplicate on outbox ID and semantic operation key.

`LISTEN/NOTIFY` carries only a wake signal. Workers always poll the durable table after startup, reconnect, and every bounded idle interval. This makes dropped notifications harmless and works with a direct Neon connection.

Ontology outbox destinations are restricted code enums:

- `WatchEvaluator`
- `EveNoticeInbox`
- `EffectDispatcher`
- `ProjectionBuilder`
- `AuditCheckpoint`

There is no public `publish(event)` API and no wildcard subscriber mechanism.

### 6.6 Eve journal and turn recovery

Eve appends a discriminated interaction union:

```ts
type EveEvent =
  | UserMessageReceived
  | TurnClaimed
  | ModelAttemptStarted
  | ModelAttemptSettled
  | ToolCallProposed
  | ToolResultRecorded
  | AssistantMessageCommitted
  | FocusChanged
  | NoticeQueued
  | NoticeArbitrated
  | DeliveryAttempted
  | DeliveryObserved
  | TurnAbandoned
```

Incoming channel message IDs and turn IDs are unique. Workers claim pending turns with leases in PostgreSQL. A crash resumes from the last settled event. A model call may repeat if the process died before its response was recorded; only one assistant message can commit. Every Ontology tool call uses an operation key derived from `(turn_id, model_tool_call_id)` and the intent digest, so model replay cannot duplicate authority writes or external Effects.

For a browser turn, the process that accepts the request claims it immediately and streams transient tokens over SSE. Reconnection reads committed journal entries; partial token chunks are not replayed. Background workers reclaim expired leases. Cross-replica notification also uses PostgreSQL as a wake hint, not a message bus.

### 6.7 Dense observations

Raw high-volume points are immutable Parquet segments in Tigris. PostgreSQL stores content-addressed manifest DAG nodes, statistics, semantic field identities, disclosure markings, provider/source rights, watermarks, and the manifest root admitted at each World cut.

DataFusion plans only against a manifest root pinned by the Frame. It pushes time, field, subject, and allowed-marking predicates into Parquet scans. A household balance and a market universe use the same `ObservationSet` and `WorldFrame`; only the physical plan differs.

For small results, API responses are released JSON. For large chart or table slices, the Frame contains an authorized `DenseSliceRef`; a fresh request returns downsampled JSON or Arrow IPC. The reference is not a public object-store URL and cannot bypass current rights.

#### 6.7.1 Parquet is a format decision, not a language decision

The dense-data contract is fixed across the TypeScript and hybrid candidates:

```text
immutable Parquet segments in private object storage
  + content-addressed immutable manifest nodes
  + one manifest root admitted at a PostgreSQL WorldCut
  + disclosure markings and source rights in PostgreSQL
  + a Frame that pins the manifest root and temporal basis
  = reproducible dense truth
```

Changing the query engine must not change the manifest identity, admitted cut, authorization result, released field identity, result digest, or explanation. PostgreSQL remains the authority for admission and the manifest root. Parquet remains the durable columnar form. The engine is replaceable execution code.

The 100% TypeScript candidate can embed DuckDB through the primary `@duckdb/node-api` client. DuckDB ships released native binaries, reads Parquet from S3-compatible storage, and pushes projections and filters into Parquet scans. This adds a native dependency, but Zoen does not own a second implementation language, RPC contract, process, deploy lifecycle, credential set, debugger, or on-call path. That difference matters more than whether every byte executes as JavaScript.

DataFusion is attractive when Zoen needs custom Rust `TableProvider` implementations, direct Arrow integration, async object-store planning, or kernel-local Wasmtime composition. The current DuckDB Node client does not yet expose Arrow APIs or profiling information. Those gaps may add copies or weaken plan diagnostics. They do not prove that a Rust service is worth its permanent cost.

Run both engines against the same manifests and released query plan. Use 10 million and 100 million point corpora, then add a 1 billion point corpus only if a real audience creates that shape. The suite must include:

1. point-in-time lookup across revisions;
2. a two-year marked time series with selective fields;
3. an as-of join across differently revised series;
4. a windowed aggregate and visual downsample;
5. 32 concurrent Frames with different disclosure sets;
6. a cold object-store run and a warm-cache run;
7. manifest replay that verifies identical result and explanation digests.

Record p50, p95, p99, time to first batch, peak resident memory, CPU-seconds, bytes fetched, object requests, cold-start time, result digest, build time, and operator recovery time. Rust plus DataFusion earns the seam only if one of these predeclared gates passes:

- TypeScript plus DuckDB misses a hard user budget after bounded tuning, while Rust plus DataFusion meets it.
- At 100 million points and 32 concurrent Frames, Rust plus DataFusion cuts p95 by at least 50% **and** peak resident memory by at least 40% on two high-priority queries, with identical result digests and no material regression in cold start or operations.
- A required governed computation cannot be implemented within DuckDB's supported Node interface without adding a separately owned native service. DataFusion and Wasmtime implement it within the already justified Rust kernel.

If none passes, use TypeScript plus DuckDB. Keep Parquet and the manifests. A faster engine that does not pay for its language and operational cost is not a better architecture.

### 6.8 Release artifacts and governed code

The compiler performs these deterministic steps:

1. parse the draft bundle and reject duplicate semantic IDs;
2. normalize all semantic JSON into the I-JSON subset;
3. encode decimal, money, instant, duration, and large integer values as canonical strings;
4. validate JSON schemas and Cedar policies against the release's Cedar schema;
5. validate each Wasm Component against the approved WIT world, imports, memory bounds, and forbidden instructions/features;
6. generate the surface-neutral capability catalog;
7. serialize release JSON with RFC 8785 JCS;
8. compute SHA-256 and store exact bytes immutably;
9. run EvaluationWorld journeys;
10. sign the exact release bytes and proof predicates in DSSE envelopes.

Wasm modules receive no filesystem, network, environment, wall clock, random source, database, model, or connector. Host imports are typed reads declared in the capability manifest; each read becomes a Frame dependency. Wasmtime uses deterministic fuel, fixed memory limits, NaN canonicalization, and no memory growth beyond declared bounds. Only pure inspection, belief, action-planning, and Watch detector logic may be a release component. Authority commit and Effects always remain privileged Rust.

This is not “everything is a plugin.” Door, Eve, authority, persistence, release activation, evidence admission, and settlement are privileged code.

### 6.9 Authorization

Cedar handles only access-control questions:

```text
principal + released action + resource/disclosure facet + purpose context
  -> Permit or Deny + determining policy IDs
```

Every release contains a validated Cedar schema and policy set. Default is deny; any matching forbid wins. Resources carry released disclosure facets/markings. The authority engine first computes the permitted facets, then pushes those markings into sparse and dense queries. Field groups that differ in disclosure are distinct released facets, which avoids post-fetch redaction.

Cedar does not decide beliefs, calculate consequences, implement quorum, plan mutations, or evaluate Watch materiality. Those are semantic programs. `PolicyProof` records the release, request digest, principal and entity slice digests, purpose, result, and determining policies. Failures that would reveal unauthorized existence become `not-found-or-not-disclosable`.

### 6.10 Secrets and cryptography

- Fly secrets contain deploy credentials and the short-lived internal DoorProof MAC key; keys rotate on deploy with an overlap window.
- connector OAuth tokens use envelope encryption with an AWS KMS key in the deployment region; ciphertext and encrypted data key live in PostgreSQL;
- release and ReleaseProof DSSE envelopes use a separate AWS KMS asymmetric signing key and a pinned trust policy;
- raw evidence and artifacts are private; fresh Ontology authorization is required before any short-lived download;
- application payloads never appear in logs, metrics, trace attributes, crash reports, or model-provider metadata;
- all public traffic is TLS; database and object-store traffic requires TLS;
- webhook signatures, timestamps, and provider replay IDs are verified before Eve journals an ingress event;
- OCI images are built once, emit an SBOM, are vulnerability-scanned, and are signed with keyless Cosign through GitHub OIDC.

### 6.11 Observability

Both runtimes emit W3C trace context and OTLP telemetry with these safe correlation fields:

```text
world_hash, release_id, world_cut, capability_id, operation_key_hash,
case_id, watch_id, notice_id, effect_id, transition_id, realm_kind
```

Never emit message text, evidence values, prompts, tool arguments, provider tokens, principal email, or raw object IDs. Domain transitions remain in PostgreSQL; telemetry is not an audit log.

Required service-level indicators:

- Door verification and World entry latency/error rate;
- first committed token and complete-turn latency;
- Frame latency by sparse/dense plan and scan bytes;
- serialization retry and idempotency-conflict rate;
- outbox age by destination;
- Watch evaluation lag and Notice suppression/delivery rate;
- EffectIntent age, Unknown rate, reconciliation time, duplicate destination attempts;
- release evaluation, preparation catch-up, and activation failure rate.

Grafana Cloud receives OTLP directly at first. Introduce an OpenTelemetry Collector only when buffering, tail sampling, or credential centralization is measured to be necessary. Rust OTel components remain beta, so structured `tracing` output is retained as an operational fallback and the adapter is isolated.

## 7. Canonical journeys

These are product proofs, not module tests.

### J1: honest first Frame

1. Sign in through real Better Auth.
2. Create a personal World from an attested planted release.
3. Admit a real uploaded statement as immutable evidence.
4. Observe two rival account identities.
5. Resolve them through the released `ResolveAccount` Case.
6. Ask Eve for runway and open the same Focus in Living World.
7. Assert the same Frame identity, basis, evidence, gaps, and explanation under fresh authority.

### J2: invitation cannot move a head

Race one `CreatePersonalWorld` with two attempts to accept the same invitation to an existing shared World. Exactly one acceptance commits, membership appears once, the existing `WorldHead` is unchanged, and retries return the same acceptance receipt.

### J3: quiet Watch, earned Notice, revoked disclosure

Create a runway Watch. Admit ordinary variation and prove only its checkpoint advances. Admit a material change and prove Notice plus checkpoint plus transition plus outbox share one cut. Defer the Notice in Eve, revoke membership, then wake it. `openNotice` returns `Suppressed`; no old amount appears in Eve's message or logs.

### J4: stale quorum and honest external ambiguity

Two principals receive different authorized views of the same `ProtectReserve` Case. One contributes approval. A relevant belief changes. The second answer returns `Stale`; no decision commits. Recreate and complete the quorum. The receipt and EffectIntent commit once. Inject a real network timeout after a provider sandbox accepts the request. Settlement becomes `Unknown`; the retry reconciles and records observed provider evidence without a duplicate destination operation.

### J5: release proof is not activation

Build a release twice on clean machines and assert byte-identical digest. Evaluate it in an isolated realm and sign a ReleaseProof. Advance the live World during preparation. The first activation rejects stale preparation. Catch up to the exact cut, then race two activations. One compare-and-swap wins; the other returns head conflict. Reads see either complete old or complete new head, never a mixture.

### J6: dense as-of and entitlement equivalence

Admit thousands of series in Parquet with different disclosure markings and revision times. Ask the same released comparison from API, CLI, MCP, Eve, and Living World at one valid time and knowledge cut. All surfaces identify the same Frame and allowed values; forbidden fields are absent from discovery, query plan, scanned columns, result, and explanation.

### J7: EvaluationWorld cannot escape

Run every normal surface against an EvaluationWorld. Attempt live World refs, relationship refs, source credentials, channel addresses, object prefixes, and Effect leases. All fail before access. Provider sandbox deliveries are captured with evidence. Cleanup emits a receipt and leaves no live rows or reachable evaluation artifacts.

## 8. Journey verification and CI

### 8.1 Testing law

There are no unit tests, mocks, fakes, stubs, snapshots of invented provider success, `vi.mock`, or import-graph tests. Rust `#[cfg(test)]` modules and TypeScript `*.unit.test.ts` files are forbidden by repository checks. Doctests are disabled for first-party crates so examples do not become a hidden second testing philosophy.

All behavioral verification drives a released product surface against real components:

- Playwright Test is the journey coordinator for browser, API, and SSE;
- the runner invokes the real `zoen` CLI and official MCP Inspector/client where appropriate;
- PostgreSQL 18 is real and isolated per run;
- Tigris uses a real CI bucket and run-scoped prefix;
- Restate uses a real server locally and Restate Cloud for release certification;
- providers and channels use verified sandbox/test accounts;
- Toxiproxy may inject latency, disconnects, half-closes, and timeouts into real connections; it does not synthesize responses;
- generated, property-like journeys use `fast-check`, but every generated action enters through API, CLI, MCP, Eve, or Living World.

If a provider has no usable sandbox, its capability cannot receive a complete effect attestation. Activation policy either blocks that capability or publishes it as read-only. Missing evidence is not replaced with a fake.

### 8.2 Static gates are not tests

Every pull request runs:

- `cargo fmt --check`;
- Clippy with warnings, `unwrap_used`, and unsafe denied;
- `cargo deny check`, `cargo audit`, and unused dependency checks;
- TypeScript strict compile, Biome formatting/lint, dependency-cruiser boundaries, and unused export checks;
- frozen pnpm install, registry signature audit, and install-script allowlist check;
- OpenAPI generation with a clean-diff assertion;
- Cedar schema/policy validation;
- SQL migration checksum, forward application, and deterministic empty-database setup;
- SBOM generation and container vulnerability scan.

These prove source and artifact properties. They do not count as behavioral tests.

### 8.3 CI tiers

| Tier | Trigger | Budget | Required journeys |
| --- | --- | --- | --- |
| Static | every push | 8 minutes | no behavioral claims |
| PR | every pull request | 20 minutes | J1 core, J2, J3 core, idempotency and disclosure smoke paths |
| Main | merge | 45 minutes | J1-J6, concurrent state-machine journeys, migration and restart recovery |
| Nightly | scheduled | 2 hours | provider/channel sandboxes, J4 fault matrix, dense scale, security and load journeys |
| Release proof | candidate release | bounded by suite | J1-J7 through every advertised surface in EvaluationWorld; signed evidence required |

Flaky journeys are failures. Quarantine removes a capability from release eligibility; it does not turn the check green. Each journey publishes trace, exact release digest, database version, object manifest root, provider sandbox identity, and seed so it can be replayed.

### 8.4 Performance budgets

Initial budgets are explicit hypotheses and are revised from production evidence:

- cached Door verification p95 below 40 ms in-region;
- World entry p95 below 100 ms;
- sparse Frame p95 below 250 ms excluding model time;
- dense chart Frame p95 below 1 s for the agreed benchmark corpus;
- authority commit p99 below 300 ms and serialization aborts below 1%;
- outbox and Watch lag p99 below 5 s under normal load;
- first token p95 below 1.5 s when the selected model allows it;
- no duplicate DecisionReceipt or unsafe provider operation under the entire fault matrix.

Only the dense and Wasm budgets can justify Rust in this candidate. If the TypeScript candidate meets them with fewer moving parts, this design loses.

## 9. Repository layout

```text
/
  Cargo.toml
  Cargo.lock
  rust-toolchain.toml
  package.json
  pnpm-lock.yaml
  pnpm-workspace.yaml

  apps/
    conversation/                 # Eve + Door host; Node executable
      src/door/
      src/eve/
      src/models/
      src/channels/
      src/ontology/
      src/http/
      web/                         # Conversation + Living World
    ontologyd/                    # Rust composition root

  crates/
    ontology-model/
    ontology-release/
    ontology-kernel/
    ontology-postgres/
    ontology-artifacts/
    ontology-surfaces/
    zoen-effect-dispatcher/
    zoen-cli/
    zoen-migrate/

  contracts/
    internal/ontology-edge.openapi.json
    public/ontology.openapi.json
    schemas/
    wit/

  migrations/
    auth/
    eve/
    ontology/

  worlds/
    planted/

  journeys/
    product/
    concurrency/
    providers/
    release/
    scale/

  deploy/
    Dockerfile
    fly.toml
    otel/

  docs/
    decisions/
    reference/
```

There is one root task vocabulary. `pnpm build` invokes the Node/web build and `cargo build`; it does not add Turborepo or Nx. Cargo and pnpm workspaces already provide the required graph. Generated files live only under explicit `generated/` directories and are checked for drift.

## 10. Build slices

Each slice ends in a user journey and can ship without pretending later machinery exists.

### S0: executable skeleton

One OCI image, Fly edge and ontology process groups, Better Auth against PostgreSQL, private TypeScript-to-Rust health call, migrations, OpenTelemetry correlation, Tigris access, and a real Playwright journey. No domain framework yet.

Exit gate: browser sign-in produces an identity-only DoorProof; Rust rejects a forged account, expired proof, or any World role smuggled into it.

### S1: one honest Frame

Implement World genesis and invitation as disjoint operations, release-bound capability discovery, immutable evidence capture, rival identity resolution, belief, Frame, explanation, Focus reopening, API/CLI/Eve/Living World projections.

Do not add dense data, Wasm, general quorum, or external Effects.

### S2: one quiet Watch

Implement Watch contract, idempotent state changes, transition consumption, compact checkpoint, materiality, Notice, outbox relay, fresh disclosure, Eve silence/defer/merge/timing, Kapso and Telegram flattening.

### S3: one accountable Action

Implement canonical Case, per-principal views and handles, exact read set, contribution, quorum, stale rejection, `AuthorityCommit`, receipt, deterministic EffectIntent, Restate dispatcher, Unknown and reconciliation in one real provider sandbox.

### S4: continuous Living World

Deepen the single React canvas from Frame to evidence, links, consequence, Case, and read-only Scenario. Preserve the same Focus and new authorization on every reopen. Add no generic dashboard builder.

### S5: teach once

Implement portable draft bundle, release compiler, JCS/SHA-256, Cedar schema and policies, optional Wasm components, semantic diff, EvaluationWorld, signed ReleaseProof, cut-exact preparation, activation CAS, native surface generation.

This is the earliest slice that can justify Wasmtime and much of the Rust-specific investment.

### S6: dense reality

Implement Arrow/Parquet manifests, DataFusion execution, field comparability, revisions/as-of, entitlement pushdown, Arrow IPC slices, and large Watch evaluation. Run the explicit TypeScript-versus-Rust benchmark before committing to this slice's native engine.

### S7: shared and delegated Worlds

Add organizations only as World membership/delegation semantics: households, teams, clinics, funds, factories, purpose constraints, partitions, quorum, and portability. Do not add a separate enterprise model.

## 11. Deployment and operations

### 11.1 Release unit

GitHub Actions builds the Rust binaries, Node server, and React assets into one minimal OCI image. The image runs as a non-root user, has a read-only root filesystem, contains no compilers or package managers, and is identified by digest. Edge and Ontology Fly process groups use the same digest.

The release pipeline is:

```text
static gates
  -> journey environment and signed ReleaseProof for planted World
  -> build once
  -> SBOM + vulnerability policy + Cosign signature
  -> apply checked migrations with zoen-migrate
  -> deploy both process groups
  -> entry/Frame/Effect smoke journey
  -> mark deployment healthy
```

Pre-launch migrations may intentionally require a short maintenance window. Use Fly's immediate replacement strategy so old and new runtime contracts do not overlap. Do not introduce dual reads, dual writes, or compatibility shims. Before the first production user, reopen this policy and define a rolling schema compatibility window or continue with explicit maintenance releases.

### 11.2 Backups and recovery

- Neon point-in-time restore is configured and a restore journey runs monthly.
- Tigris versioning or immutable retention protects release, raw evidence, and manifest objects.
- daily exported signed World checkpoints make semantic recovery independent of provider dashboards;
- every restore replays projection builders from authority tables and verifies World hash roots;
- recovery objectives are set before launch from measured data value, not invented here.

### 11.3 Scaling

- Edge scales on active requests and model-turn concurrency.
- Ontology scales on Frame CPU, Watch lag, and outbox age.
- all workers are stateless apart from PostgreSQL leases and object artifacts;
- singleton behavior is expressed as a row lease or compare-and-swap, never as “one replica” configuration;
- direct PostgreSQL connection budgets are divided by process group and enforced in config;
- DataFusion queries have per-request scan, memory, CPU, and time budgets.

Multi-region writes are deliberately refused. One authority region owns serializable commits. Read replicas and object caching may serve explicitly stale, basis-labelled reads later; they never fabricate a current WorldFrame.

## 12. Proposed ADR set

Each ADR should contain one decision, its invariant, considered alternatives, consequences, and a measurable reopen trigger.

1. `ADR-001 Three products and seven authority partitions`
2. `ADR-002 Hybrid modular monolith and one Fly app`
3. `ADR-003 TypeScript-Rust boundary uses private HTTP and OpenAPI`
4. `ADR-004 DoorProof is identity-only; World grants are opaque and purpose-bound`
5. `ADR-005 PostgreSQL is the sole local authority and AuthorityCommit is the sole write port`
6. `ADR-006 Event-oriented transitions use a transactional outbox; no broker`
7. `ADR-007 UUIDv7, explicit clocks, World cuts, and digest identity`
8. `ADR-008 Evidence, claims, beliefs, and dense observations have separate lifecycles`
9. `ADR-009 Cedar governs authorization facets, not domain semantics`
10. `ADR-010 WorldRelease uses JCS/SHA-256 and ReleaseProof uses DSSE`
11. `ADR-011 Optional release code runs as capability-limited deterministic Wasm`
12. `ADR-012 Dense observations use immutable Parquet manifests; the executor must pass a benchmark gate`
13. `ADR-013 API, CLI, MCP, Eve, and Living World project one release catalog`
14. `ADR-014 Eve owns the interaction journal; model and channel adapters are ports`
15. `ADR-015 Watch creates Notice; Eve alone arbitrates interruption and delivery`
16. `ADR-016 Restate runs ZoenEffect only; Settlement is evidence-bound external truth`
17. `ADR-017 EvaluationWorld isolation and two-part release activation`
18. `ADR-018 Verification is public-surface journeys with real dependencies`
19. `ADR-019 One signed OCI release, OpenTelemetry, and managed state services`
20. `ADR-020 Pre-launch migrations delete obsolete shape without compatibility layers`

## 13. Rejected shapes

- **Rust because “correctness.”** PostgreSQL and domain invariants do most correctness work; language rhetoric does not pay the seam cost.
- **Everything in Rust.** Better Auth, model SDKs, channel libraries, and web iteration are strongest in TypeScript. Reimplementing them moves risk rather than removing it.
- **Everything is a plugin.** Privileged authority and settlement code must remain closed. Only named adapters and pure governed release components are extensible.
- **gRPC between Node and Rust.** A second IDL and conversion layer does not improve the JSON-Schema-bound semantic payloads.
- **Microservices for the seven authorities.** Ownership boundaries are modules and types. Network boundaries would distribute transactions and multiply failure modes.
- **Kafka, NATS, Redis, or Temporal.** PostgreSQL outbox and leases are sufficient; Restate is reserved for Effects.
- **Universal event sourcing.** Transitions explain meaningful change. Raw evidence and dense points have better physical forms.
- **Graph database as the model.** Links are semantic domain facts; a storage engine is an adapter.
- **Provider schemas as canonical objects.** Provider contracts acquire evidence; release mappings create domain meaning.
- **Chat transcript as memory or truth.** Eve owns relationship memory; Ontology owns the World.
- **Per-principal release compilation.** One immutable release plus runtime disclosure preserves shared meaning.
- **JWT World authority.** Revocation, purpose, membership revision, and disclosure require server-side grants and fresh checks.
- **Database RLS as the semantic policy engine.** RLS is useful defense-in-depth but cannot express the complete released purpose and Case semantics safely.
- **Cedar for beliefs, quorum, or Watch logic.** Authorization and domain semantics are different programs.
- **Wasm with WASI access.** Release code is deterministic meaning, not an application runtime.
- **Restate for conversation durability.** Eve's settled interaction journal and leases own that responsibility.
- **Next.js or React Server Components.** The authenticated product is an interactive client; another server runtime and cache model add no value.
- **A generic graph canvas or dashboard builder.** Living World renders released facets around one Focus.
- **Blind effect retries.** Unknown external reality requires reconciliation.
- **Compatibility scaffolding before launch.** Update callers, migrations, journeys, and releases atomically.

## 14. Burden of proof for the second language

### 14.1 No product invariant requires Rust

Strict TypeScript, runtime validation, and PostgreSQL can reproduce every observable correctness property in this document. That includes realm separation, serializable commits, idempotency, temporal cuts, release hashes, authorization, evidence lineage, and settlement honesty. Rust changes how strongly the compiler protects code inside one process. It does not create a user-visible invariant that TypeScript cannot implement.

Rust offers four advantages that the comparison spike can measure:

1. **Non-erasable internal realm and state distinctions.** Rust can keep constructors private, exhaustively match states, and prevent `Live` and `Evaluation` refs from unifying without an explicit unsafe or serialization boundary. TypeScript brands erase at runtime and assertions can bypass them. Runtime schemas, restricted exports, lint rules, and journeys reproduce the runtime behavior, but not the same compiler guarantee. The HTTP seam also serializes the Rust distinctions, so this advantage stops at the kernel boundary.
2. **Native DataFusion, Arrow, and Parquet composition.** Rust can customize the query engine without a foreign-function boundary. TypeScript plus DuckDB already has an in-process native engine through a supported binding, so native execution alone is not a reason for a Rust service.
3. **Native Wasmtime hosting.** Rust has direct access to Wasmtime's resource controls. TypeScript can use a subprocess or binding. This matters only after released governed code becomes a proved product need.
4. **Portable CLI and server binaries.** Rust produces a small standalone distribution with a predictable runtime profile. Node packaging can reproduce the capability, although usually with a larger distribution and more platform packaging work.

These are implementation advantages, not exclusive product capabilities. Process-level credential separation, PostgreSQL constraints, serializable commits, outbox idempotency, JCS, DSSE, Cedar, immutable Parquet manifests, and every public type remain implementable in strict TypeScript.

### 14.2 Permanent cost estimate

These are planning estimates, not measured facts. The S0 spike must replace them with measurements.

| Cost | Expected steady effect |
| --- | --- |
| Two toolchains and dependency streams | two lockfiles, two advisory feeds, two compiler upgrade programs, one larger build image |
| Cross-runtime contract | generated schema/client plus a mandatory cross-version journey for every seam change |
| Local development | both runtimes, two debuggers, private networking simulation, trace correlation |
| Hiring and review | at least two people able to review authority Rust and two able to review Eve TypeScript before launch; otherwise bus factor one |
| Feature delivery | 0-10% overhead for changes contained on one side; 30-70% for changes that alter semantic payloads or orchestration on both sides |
| Overall early backend velocity | estimated 15-25% slower through S4; likely 8-15% slower after the seam stabilizes |
| CI | estimated 5-12 additional minutes without careful caching; larger cache and image transfer |
| Incidents | two runtimes, heap models, profilers, and telemetry SDKs; seam failures become a new incident class |

The estimate assumes the seam stays under 12 operations and that no database access leaks into TypeScript. If more than 20% of merged product changes modify both Rust and TypeScript contracts over any six-week window, the boundary is in the wrong place. Consolidate to TypeScript or move a deeper whole capability behind Rust; do not keep accreting RPCs.

The capacity cost scales with team size. At the steady estimate of 8-15%, a four-person backend team loses about 3.8-7.2 engineer-months each year. A six-person team loses about 5.8-10.8 engineer-months each year. During S0-S4, the 15-25% estimate costs a four-person team 0.6-1.0 engineer-month per calendar month. Replace these estimates with repository and delivery data after the spike. A performance saving must be large enough to repay this recurring capacity loss, not only a better microbenchmark.

### 14.3 Decision experiment

Before selecting Candidate A, implement the same narrow spike in this candidate and the TypeScript candidate:

1. Door sign-in and identity-only proof;
2. one sparse temporal Frame;
3. one serializable idempotent Action commit with outbox;
4. the Parquet suite in Section 6.7.1, using identical manifests and result digests;
5. one deterministic governed component with timeout and memory limits;
6. crash and retry matrix;
7. clean-build, local-feedback, p95 latency, peak RSS, defect, and change-lead-time measurements.

Rust wins only if one of the predeclared gates in Section 6.7.1 passes, governed code requires the Wasmtime host, offline distribution becomes an immediate product requirement, or the journey defect comparison shows a material net reduction after counting seam defects. "Feels safer" is not an acceptance criterion. On the evidence available today, Rust has not won.

## 15. Risks and reopen triggers

| Risk | Mitigation | Reopen trigger |
| --- | --- | --- |
| Language seam becomes a distributed monolith | one deep API, generated contract, no TS Ontology DB credentials | over 12 seam operations or 20% cross-seam change rate |
| Rust delays the trust-ladder product | do S0 comparison before kernel build-out | TypeScript reaches identical journey confidence at materially lower lead time |
| Restate Rust SDK is pre-1.0 | isolate it in one crate, pin 0.12, contract journeys | two breaking upgrades in six months or missing production feature; move only dispatcher adapter to TS |
| Wasmtime expands attack surface | 48 LTS, no WASI, fuel/memory limits, signed components, prompt patching | no governed code in active releases by S6; delete it |
| Cedar entity slicing or marking model is too costly | release validation and authorization/query equivalence journeys | p95 auth budget miss or a non-expressible disclosure rule |
| DataFusion is premature | do not add crates until S6 gate | sparse/SQL plans meet dense budgets; omit native plane |
| Neon pooled/direct split surprises workers | direct listener, durable polling, connection budgets | sustained network latency or disconnects violate commit/outbox SLOs; move Postgres provider/region |
| One Fly app shares secrets across process groups | least-privilege DB roles, scoped KMS, signed leases | compliance or threat model requires OS-level secret isolation; split deployment without inventing a fourth product |
| Rust OTel is beta | isolate adapter, retain structured tracing | telemetry loss or upgrade instability; run Collector or change exporter |
| OpenAI behavior becomes product logic | provider types stop at adapter; journal Zoen events | second provider cannot pass the same journeys without Eve changes |
| Pre-launch immediate deploy causes unacceptable downtime | explicit maintenance state and short migrations | first production commitment; define rolling compatibility policy before launch |

## 16. Rationale

### Problem

Zoen needs a conversational relationship and a high-integrity executable World. The authority kernel must preserve identity, temporal basis, evidence, policy, causality, idempotency, deliberation, and uncertain external settlement while serving conversational, visual, CLI, API, and MCP callers. The question is whether a Rust authority boundary reduces enough risk to justify a permanent TypeScript/Rust seam.

### Usage

People ask Eve, inspect a Frame, decide through a Case, create a quiet Watch, and receive honest settlement. Operators and agents use the same released capabilities and receipts. Builders compile, evaluate, prepare, and atomically activate one immutable release. The caller never coordinates repositories, policies, events, or effects.

### Shape

One TypeScript edge owns Door and Eve. One private Rust Ontology process owns every authoritative semantic read and write. PostgreSQL is the sole local authority; Tigris stores immutable artifacts and dense segments; Restate runs Effects only. Private HTTP/JSON is the one language seam. Authority-free Focus provides continuity. A purpose-bound WorldSession opens Frames, domain Cases, Watches, Notices, Scenarios, explanations, receipts, and Settlements. World releases are canonical and signed; activation joins a release-wide proof to a World-specific preparation.

### Tradeoffs

The split puts each ecosystem near its strongest libraries and creates a clear credential boundary. Rust makes illegal kernel states harder to express and embeds DataFusion and Wasmtime naturally. In exchange, every semantic contract change, incident, build, hire, and dependency upgrade crosses a larger organizational surface. TypeScript can reproduce nearly all correctness invariants when the database and runtime validation are designed well. The hybrid should therefore be earned by measured native-compute or distribution needs.

### Alternatives

1. **100% TypeScript modular monolith.** Leading alternative. Same domain and database design, fewer seams, fastest product learning. Add a native dense worker only when a benchmark requires it.
2. **Rust-first server with minimal TypeScript Door sidecar.** Strong single kernel but expensive model, channel, and UI iteration; risks recreating mature TypeScript libraries.
3. **Elixir/Erlang relationship runtime plus Rust kernel.** Excellent conversational concurrency, but three ecosystems after adding Better Auth/web and no corresponding product need.
4. **Microservices by authority partition.** Independent scaling at the price of distributed commit, more credentials, and a product model hidden by infrastructure.
5. **PostgreSQL functions as authority kernel.** Strong transaction locality but poor domain types, release compilation, portability, and tooling.

### Open questions

1. Do representative dense Frames need DataFusion before product-market evidence reaches S6?
2. Will World builders need arbitrary governed functions, or can released declarative expressions cover the useful set for years?
3. Which first external Action has a genuine provider sandbox and idempotency/reconciliation contract?
4. What actual cross-seam change rate emerges from S1 and S2?
5. Does Cedar's facet model express household, clinical, and institutional disclosure without unsafe post-fetch filtering?
6. What is the correct first model portfolio after real Eve conversation evaluations?

### Next step

Run the seven-part comparison spike in Section 14.3. Start the full implementation in TypeScript unless Rust wins a predeclared dense, sandboxing, portability, or defect criterion. Preserve the public protocol, PostgreSQL invariants, artifact formats, and journeys either way so the choice remains reversible.

## 17. Primary technical sources

The version and capability choices above were checked against primary project documentation on the decision date:

- Rust's official release index lists 1.98.1 and the Rust 2024 release lineage: [Rust release announcements](https://blog.rust-lang.org/releases/).
- Node recommends production use of supported LTS lines and lists Node 24 as LTS: [Node.js releases](https://nodejs.org/en/about/previous-releases).
- TypeScript 6.0 is the stable transition release; TypeScript 7.0 initially ships without the compiler API used by parts of the tooling ecosystem: [TypeScript 6.0](https://devblogs.microsoft.com/typescript/announcing-typescript-6-0/), [TypeScript 7.0](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/).
- Better Auth supports strict TypeScript and PostgreSQL; v1.6.22 was the current stable release line checked: [TypeScript](https://better-auth.com/docs/concepts/typescript), [PostgreSQL adapter](https://better-auth.com/docs/adapters/postgresql), [releases](https://github.com/better-auth/better-auth/releases).
- PostgreSQL 18 documents UUIDv7, serializable transactions, and `SKIP LOCKED` for queue-like access: [UUID functions](https://www.postgresql.org/docs/18/functions-uuid.html), [SET TRANSACTION](https://www.postgresql.org/docs/18/sql-set-transaction.html), [SELECT locking](https://www.postgresql.org/docs/18/sql-select.html).
- Neon supports PostgreSQL 18; transaction-pooled connections do not support `LISTEN`, so workers use direct connections: [PostgreSQL 18 update](https://neon.com/docs/changelog/2026-02-27), [connection pooling](https://neon.com/docs/connect/connection-pooling).
- Cedar provides schema validation, deny-by-default authorization, and forbid precedence; 4.12.0 was current: [Cedar repository](https://github.com/cedar-policy/cedar), [policy validation](https://docs.cedarpolicy.com/policies/validation.html), [4.12.0 release](https://github.com/cedar-policy/cedar/releases/tag/v4.12.0).
- Apache's Rust Parquet implementation integrates with Arrow and object storage. DataFusion uses Arrow as its in-memory form and supports custom table providers, filter pushdown, async execution, and remote object stores: [Parquet Rust API](https://arrow.apache.org/rust/parquet/index.html), [DataFusion introduction](https://datafusion.apache.org/user-guide/introduction.html), [custom table providers](https://datafusion.apache.org/library-user-guide/custom-table-providers.html), [DataFusion releases](https://github.com/apache/datafusion/releases).
- DuckDB's primary Node client embeds released native binaries in a Node process. DuckDB reads S3-hosted Parquet and pushes filters and projections into scans; the current Node client roadmap still lists Arrow APIs and profiling information as incomplete: [Node.js client](https://duckdb.org/docs/lts/clients/node_neo/overview), [Parquet](https://duckdb.org/docs/current/data/parquet/overview), [S3 Parquet](https://duckdb.org/docs/current/guides/network_cloud_storage/s3_import).
- Wasmtime documents deterministic fuel interruption and an LTS cadence: [deterministic execution](https://docs.wasmtime.dev/examples-deterministic-wasm-execution.html), [Wasmtime LTS RFC](https://github.com/bytecodealliance/rfcs/blob/main/accepted/wasmtime-lts.md).
- Restate's official Rust SDK 0.12 adds a typed ingress client and outbound Cloud tunnel; this candidate confines it to Effects: [Rust SDK releases](https://github.com/restatedev/sdk-rust/releases).
- The official MCP Rust SDK supports Streamable HTTP and current tool/resource semantics: [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk).
- Fly documents one app with multiple process groups, each on its own Machines; Tigris is S3-compatible: [Fly process groups](https://fly.io/docs/launch/processes/), [Tigris](https://fly.io/docs/tigris/).
- React 19.2 and Vite 8 are stable lines for the authenticated web client: [React versions](https://react.dev/versions), [Vite 8](https://v8.vite.dev/blog/announcing-vite8).
- OpenTelemetry defines vendor-neutral traces, metrics, and logs, while its Rust signals remain beta: [OpenTelemetry](https://opentelemetry.io/docs/), [OpenTelemetry Rust](https://opentelemetry.io/docs/languages/rust/).
- RFC 8785 defines canonical JSON for reproducible hashes; DSSE binds exact payload bytes to a payload type; RFC 9562 defines UUIDv7: [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785.html), [DSSE](https://github.com/secure-systems-lab/dsse), [RFC 9562](https://www.rfc-editor.org/info/rfc9562/).
- The official OpenAI Node SDK exposes the Responses API and supports Node LTS lines: [OpenAI Node SDK](https://github.com/openai/openai-node), [developer quickstart](https://platform.openai.com/docs/quickstart/make-your-first-api-request).
