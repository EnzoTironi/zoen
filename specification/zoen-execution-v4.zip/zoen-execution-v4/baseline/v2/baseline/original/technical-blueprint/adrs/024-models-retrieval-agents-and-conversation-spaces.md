# ADR 024: Models, retrieval, headless agents, and governed conversation spaces

Status: Accepted target contract. Managed agents and spaces deferred.

## Context

Zoen needs intimate conversation, cited research, reusable agents, unattended investigation, and governed professional rooms. A single model-provider memory or thread cannot serve these needs safely. It would mix relationship history, World facts, retrieval indexes, workflow state, model output, and authority.

Conversational agents and headless agents also have different owners. Eve owns a relationship and how a person experiences a turn. A headless agent may run for days without a conversation. Neither may hold standing authority or convert generated text into a World fact.

## Decision

### Model profiles and inference evidence

`ModelProfile` is a released or deployment-approved description of provider, model name and revision, supported input and output forms, tools and structured output, residency, retention, training use, input-rights classes, and pricing. A mutable alias may select an attempt only when the policy permits it. The settled attempt records the exact observed model identity and provider response metadata.

`InferenceInput` binds one `KnowledgeBasis`, prompt-template and content digests, exact retrieval results, offered-tool manifest, output schema, and data-usage decisions. `InferenceAttempt` is a lifecycle union over a common immutable base: running, completed, aborted, or failed. It binds actor, purpose, World, exact model profile, provider-observed model/revision, provider request, budget, timing, usage, retention receipt, and—when completed—data-usage receipt and attributable output. The type cannot carry completed output in a failed state. A completed output is computation, not evidence admission, a DecisionReceipt, an EffectSettlement, or a release proof.

Conversation inference attempts belong to Eve Workflow history. `InteractionJournal` is a typed, rebuildable Eve read model of that history, not a second attempt log. Non-conversational inference attempts belong to the Ontology-owned workflow or analysis run that requested them. Cordis is not a launch dependency and owns no record or recovery boundary.

### Retrieval is a released, cut-pinned plan

`RetrievalPlan` binds one `KnowledgeBasis`, release, query and schema digests, typed object/evidence sources, lexical analyzer or vector index/metric/embedding profile, hybrid ranker and deterministic tie-break where applicable, disclosure, usage request, rights decision, and candidate/result/leakage budget. Authorization and source rights filter candidates before lexical terms, embeddings, distances, snippets, counts, or ranks become visible. An inaccessible record cannot influence a permitted score.

Each `RetrievalHit` keeps rank, exact record/evidence/dense-slice revision, schema-verified excerpt, method-specific score, citation, exact reads, disclosure, rights decision, and digest together. There are no parallel citation and excerpt arrays. `RetrievalResult` pins ordered hits, safe gaps, unioned exact reads, usage receipt, and canonical result digest. Rebuilding an index creates a new index digest and cannot silently change a retained result. Vector search is a disposable projection over admitted evidence, never truth. A generated answer preserves citations to exact admitted source versions and records missing or withheld context without leaking hidden counts.

### Headless agents use canonical workflows

`AgentDefinition` is released meaning. It pins exact model-profile digests, tools, retrieval definitions, Ontology workflow template, output schema, budget policy, human-judgment rules, and required evaluations.

`OntologyWorkflowInstance` is canonical PostgreSQL state with version, full starting head, service principal, purpose, release, attempts, budget, and a closed state union: ready, running one step/attempt, waiting for Case, waiting for time, completed, or stopped. Runtime wakeups and checkpoints cannot claim completion. The agent has no Eve relationship, provider thread as sole memory, or long-lived `WorldSession`. It opens a fresh purpose-bound session for every step.

A headless agent may inspect, retrieve, calculate, call proposal-only functions, draft an Action, open a Case, create an analysis artifact, or submit a release proposal. It may wait on a Case reference but cannot receive or use the human's Ontology-issued `DecisionContinuation`, approve its own proposal, activate a release, or call an external provider except through an accepted Action and `EffectIntent`. A scheduler or future runtime adapter may wake the run. PostgreSQL remains the sole canonical headless-workflow state.

### Eve owns governed conversation spaces

`ConversationSpace` is an Eve relationship construct for multi-party conversation. It binds a relationship, optional Worlds, participation policy, purpose policy, record and retention rules, legal hold or supervision requirements, channel bindings, agent-participation rules, and version. Space interactions are typed materialized views of settled Eve Workflow events, including actor, explicit audience, purpose, content digest, and World references. They are not an independently appended journal, resumption log, hash chain, or scheduler.

Space participation grants access only to space content. It never creates World membership, delegation, purpose, entitlement, or Action authority. Each participant reopens a referenced Frame under current personal authority. Eve shares one common Frame view only when Ontology produced a disclosure valid for the full intended audience. Other participants receive a withheld marker that reveals no protected identity or schema.

Bots and agents are explicit participants with named principals and policies. Retention, legal hold, supervision, export, edit/correction, moderation, delivery, and deletion are settled Eve Workflow events rather than mutable provider-room settings. A message that says `approve` is conversation content. It becomes a contribution only through the normal Case ceremony, assurance checks, and an Ontology `DecisionContinuation`.

## Consequences

- Eve can remain personal while also supporting governed group and professional collaboration.
- Headless work gains durable recovery without turning Eve, a model thread, or Rivet into workflow authority.
- Retrieval becomes reproducible and rights-aware, at the cost of pinning indexes and evidence versions.
- Users may see withheld or missing context and agents waiting for Cases rather than silently broadened access.
- Provider flexibility remains behind model profiles and attempt evidence.

## Required journeys

1. Exact model revision, failover, abort, timeout, budget, usage, structured-output failure, retention, and residency evidence.
2. Lexical, vector, and hybrid retrieval reproduce at a cut and do not allow a hidden candidate to affect rank, excerpt, count, or timing beyond the declared leakage budget.
3. Index rebuild and embedding-model change produce new digests and preserve old cited results.
4. Headless run survives crash, duplicate wake, provider failover, code upgrade, budget stop, principal revocation, and a weeks-long Case wait.
5. Agent cannot use an undeclared tool, retain a WorldSession, receive or answer a DecisionContinuation, activate its proposal, or bypass EffectIntent.
6. Conversation-space participants with different World access receive valid personal or common views without protected existence leakage.
7. Agent participant, supervision, legal hold, export, channel switch, correction, retention expiry, and membership revocation preserve the space journal without granting World authority.

## Reopen triggers

- A model provider requires a durable server-side thread. Record it as an attempt resource and prove export/replay. It cannot become the sole conversation or agent state.
- PostgreSQL workflow wakeup misses a required scale objective. Evaluate Rivet or another runtime behind `WorkflowRuntimePort` while preserving the canonical run.
- A space needs cross-organization content exchange. Use `FederationAgreement` and per-audience Frames. Do not merge World memberships.
- No trigger permits model output, retrieval rank, agent completion, room membership, or conversation text to become authority without the existing evidence or Action path.
