# ADR 027: Eve channel bridges and durable admission

Status: Accepted, provider enablement gated

## Context

Eve must be one relationship across web and messaging without letting provider SDKs become conversation memory, identity, authority or delivery truth. Launch needs web, WhatsApp, Telegram and email. Existing Eve and Chat SDK webhook implementations schedule message handling through `waitUntil` and can return a successful acknowledgement before Zoen durably appends the ingress. PostgreSQL-backed SDK deduplication improves coordination but does not prove that an accepted input or Eve durable delivery command exists. A process death in that interval can therefore lose an acknowledged message.

## Decision

The launch channel topology is fixed:

- web uses Eve's authenticated first-party experience;
- WhatsApp uses Kapso only at `/eve/v1/kapso`, through one isolated `eve/channels/chat-sdk` bridge and `@kapso/chat-adapter`;
- Telegram is first-class at `/eve/v1/telegram` through native `eve/channels/telegram`; Zoen does not install a generic Telegram Chat SDK adapter;
- email uses a separate `eve/channels/chat-sdk` bridge with `@resend/chat-sdk-adapter` behind the provider-neutral `/eve/v1/email` route.

The Kapso and email bridges use exact-pinned `chat@4.39.0`, `@chat-adapter/state-pg@4.39.0`, distinct adapter maps, credentials and key prefixes, and `streaming: false`. The state adapter receives an isolated `eve_channel_runtime` namespace and role inside Eve's dedicated operational database. Its subscriptions, locks, queues, cursors and dedupe keys are operational state only. `@chat-adapter/state-memory`, Redis state, generic WhatsApp, and generic Telegram adapters are prohibited. Restate does not run channel work.

Provider values terminate at the boundary. Eve owns `ChannelEndpoint`, verified `ChannelBinding`, `ChannelThread`, append-only `ChannelIngress`, `ChannelConsent`, immutable `ChannelDeliveryIntent`, attempts and append-only delivery observations. Eve's durable Workflow session history is the conversation execution truth; `InteractionJournal` is its typed materialization. The transaction that accepts a provider input appends one `ChannelIngress` and one outbox command exactly once. The dispatcher delivers the stable ingress identity into Eve's durable command inbox; replay cannot create a second accepted ingress or settled response. An endpoint or webhook proves provider-side presence only; Door enrollment is required to bind it to a principal, and every disclosure or Action reauthorizes current World access.

The production invariant is durable admission before acknowledgement: after raw-body verification and bounded replay checks, Zoen commits the stable provider event identity, exact-body digest/raw reference, credential version, receive/provider times, normalized envelope and an Eve-delivery outbox command before returning provider success. Model and agent work begins only after Eve durably accepts the delivery command. This requires one of:

1. a public upstream admission hook that awaits Zoen's transaction before the adapter returns `2xx`;
2. a Zoen-owned public ingress gateway that verifies and admits, then passes a trusted admitted event to a private adapter hook with a replay-safe contract; or
3. a pinned upstream release that implements the same order.

A pass-through proxy, process-local dedupe, replaying an expired signed request, or a private permanent fork is insufficient. Hono's ADR 029 reverse proxy preserves raw bytes but does not itself close this gap. Until a route passes its real-provider kill/replay journey, that channel is disabled in production.

Egress uses PostgreSQL leases and one idempotent `ChannelDeliveryIntent`. A timeout is `unknown`; Eve reconciles by provider message ID, callback or history before sending again. Provider observations are append-only and may be duplicate, missing, late or contradictory. API acceptance, mail-server acceptance, device delivery, read/open/click and human decision remain distinct facts.

All outbound forms derive from one semantic `RenderDocument` with complete readable text. Rich controls degrade into truthful text and stable opaque references, never fake buttons, invented URLs or helpdesk scripts. A press, reply or link may select or propose; it cannot manufacture a receipt. Email GET requests never mutate authority.

Apple Messages and consumer iMessage are entirely outside launch. `eve/channels/linq` is the only future seam to evaluate. There is no launch dependency, route, credential, `ChannelKind`, endpoint variant or required journey for it.

## Consequences

- Eve remains the only conversation product while native and generic transport machinery can evolve independently.
- PostgreSQL is reused without confusing Chat SDK coordination tables with Eve history or Ontology authority.
- The architecture exposes an upstream durability gap instead of claiming that SDK acknowledgement semantics are already safe.
- Email becomes first-class but intentionally weak for identity and delivery proof; material consequence still crosses Door and the ordinary Action path.
- Some launch channels may remain unavailable until providers and admission hooks pass protected journeys.

## Required journeys

- bind, unlink and revoke each endpoint through Door; equal labels never merge identities;
- kill before ingress commit and observe provider retry; kill after ingress commit and before Eve delivery, replay the admitted event and settle one turn;
- duplicate and reorder ingress and delivery observations without duplicate response or Action;
- switch web/channel/web while preserving one branch, references and fresh disclosure;
- cut egress after provider submission and reconcile an `unknown` attempt before retry;
- render answer, evidence, Case, receipt, chart and Workshop continuation as useful text on all launch channels;
- run protected Kapso, Telegram and Resend security, threading, consent, limits, attachment, restore and delivery-semantics journeys against real accounts.

## Reopen triggers

- Eve or Chat SDK publishes a stable admission-before-ACK hook. Replace the gateway only after the identical kill/replay corpus passes.
- A bridge's provider-specific semantics cannot be represented losslessly. Add a native Eve channel behind the same closed records; do not fork conversation ownership.
- Linq gains a supported commercial contract and passes identity, consent, admission, retention, delivery and real-account journeys. Add it through a new ADR without changing launch history.
- A provider fails data-use, region, erasure, reliability or cost requirements. Disable or replace only that adapter.

No trigger lets channel presence become identity authority, Chat SDK state become Eve memory, or a delivery callback directly mutate Ontology.
