# ADR 001: Three products in one TypeScript application

Status: Accepted

## Context

Zoen has three products with different promises: Door establishes identity, Eve holds the conversation, and Ontology publishes meaning and governs action. Deploying them as services now would turn those product boundaries into network and operations costs before scale or security requires it. A second implementation language would also create a permanent build, hiring, debugging, observability, and release seam without yet proving a correctness property that TypeScript and PostgreSQL cannot provide.

The application still needs a precise runtime baseline. A vague "TypeScript stack" would let incompatible frameworks, build systems, or internal protocols accrete.

## Decision

- All Zoen-owned application and domain code is TypeScript, compiled by the TypeScript 6.0 compatibility line. The runtime is Node.js 24.20 LTS, Linux, and ESM. Native libraries may sit behind TypeScript ports, but no second Zoen domain implementation is introduced.
- Zoen ships as one OCI image, one Fly application, and initially one steady-state Machine. The image contains one TypeScript application and two supervised Node processes because the supported Eve self-host contract is a generated Nitro service, not a Hono handler.
- The Zoen edge/authority process owns public Hono port `:8080`, a loopback-only Eve capability port on `127.0.0.1:8081`, and the signed infrastructure-only Restate listener on `:9080`. The Eve process runs exact-pinned `eve start` on `127.0.0.1:4274`. Hono proxies `/eve/` and `/.well-known/workflow/` without path rewriting.
- Door and Ontology calls inside the edge/authority process are typed function calls through application ports. Eve crosses one explicit, generated, authenticated loopback contract because it is a separate supported runtime. There is no broker, service discovery, or private duplicate domain API.
- Ordinary HTTP, streams, cancellation, hashing, randomness, and constant-time comparison use Node `fetch`, Web Streams, `AbortSignal`, `crypto`, and WebCrypto. Axios and generic hash or ID frameworks are not dependencies.
- The products own these public paths:
  - Door: `/api/auth/*`
  - Eve: `/eve/v1/*`, including Kapso `/eve/v1/kapso`, native Telegram `/eve/v1/telegram`, and Resend email `/eve/v1/email`
  - Ontology API: `/ontology/v1/*`
  - Ontology MCP: `/ontology/mcp`
- The CLI is an Ontology client, not a fourth product. Channel adapters are Eve adapters, not products. The membership workbench is an Eve experience over Ontology capabilities, not a separate dashboard product.
- One deployment composition root constructs the edge/authority process, its adapters, credential scopes and listeners, then supervises the Eve command. Eve has its own filesystem-first composition root and only an `EveOntologyClient`; domain packages do not read environment variables or create global clients.
- The repository uses pnpm 11 workspaces, committed `pnpm-lock.yaml` and `pnpm-workspace.yaml`, a root version catalog, `workspace:` internal identities, strict peers, workspace-cycle rejection, minimum package age, and an explicit native build-script allowlist. CI uses `pnpm install --frozen-lockfile`. TypeScript project references and plain package scripts form the build graph; Nx, Turborepo, Bazel, Lerna, and a server bundler are absent.

## Consequences

- The first release has one language, one dependency graph, one trace vocabulary, and one artifact. Only Eve-to-Ontology calls pay a serialization seam, which exists to honor Eve's public runtime contract and isolate credentials.
- A Machine crash affects all three products. The Eve child receives an explicit environment allowlist with no Ontology database or release-signing credential, which prevents accidental access; two same-container processes are not a hard security boundary, so an Eve remote-code-execution compromise may still attack its sibling or loopback. ADR 004 physically separates proof-producing evaluation, and ADR 029 requires a Machine split before claiming hostile-code containment.
- The modular boundaries must be enforced statically because deployment topology does not enforce them.
- Independent scaling and release of a product are deliberately deferred. The two processes use one image and release identity. Temporary blue-green overlap is allowed only to drain infrastructure protocols such as Restate and Eve Workflows, not as steady-state topology.

## Reopen triggers

- A threat model or compliance requirement says an Eve compromise must not share a process with Ontology credentials.
- Thirty consecutive production days show more than 50 percent avoidable compute cost because one product must scale independently.
- One product needs a different region or release cadence for a contractual reason.
- Node or Hono misses a measured workload target after profiling and remediation, and a named alternative demonstrates at least a 2x improvement without weakening the constitution.
- Rust is reconsidered only under the measured gates in ADR 018. Preference, benchmark folklore, or a desire for nominal type safety is not a trigger.
- Replace pnpm only if it creates a documented blocking runtime or tooling incompatibility and the replacement preserves frozen installs, strict direct-dependency visibility, workspace identity, cycle rejection, catalog consistency, package-age policy, and lifecycle-script allowlisting.
- Collapse to one process only if Eve publishes a stable server adapter that preserves its routes, schedules, Workflow callbacks, streams, cancellation, and shutdown, and the ADR 029 corpus passes without imports from `eve/internal/*`.
