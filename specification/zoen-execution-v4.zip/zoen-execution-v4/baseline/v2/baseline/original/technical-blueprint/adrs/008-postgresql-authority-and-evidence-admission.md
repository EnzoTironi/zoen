# ADR 008: PostgreSQL authority and governed evidence admission

Status: Accepted

## Context

Zoen must answer what is true, why it is believed, when it was valid, and which release admitted it. A database row that happens to contain JSON is not governed knowledge. Connector payloads, uploads, model outputs, and dense observations are evidence candidates until release-owned schemas, provenance rules, policy, and domain invariants admit them.

The first system also needs one transactional authority. Adding a document store, graph database, broker, or cache as another source of truth would create reconciliation work before a proven query requires it.

## Decision

- Neon PostgreSQL 18 is the transactional substrate for Door security state, Ontology authority, channel admission, and Eve's isolated Workflow store. Ownership and transactions do not cross product boundaries.
- First-party repositories use direct `pg` 8 connections and explicit SQL. AuthorityCommit, migrations, advisory coordination, and `LISTEN/NOTIFY` never traverse a transaction-pooling mode. A pooled endpoint may later serve short Door and Eve reads only after its journeys pass.
- Schemas and database roles follow product ownership:
  - `door` owns Better Auth tables and identity-assurance records only.
  - `ontology` owns Worlds, temporal facts, evidence, entitlement snapshots, rights decisions, Cases, `DecisionContinuation` hashes, Actions, releases, EffectIntents, EffectSettlements, receipts, commits, audit, and its outbox.
  - `ontology_dense` owns immutable segment and manifest payloads, lineage, and separate `ManifestAdmission` records.
  - `ontology_runtime` owns Ontology idempotency, outbox delivery, work leases, connector/effect/data-flow attempts, staging, and projection checkpoints.
  - The `eve_channels` owner database uses explicit migrator-owned `admission`, `kapso`, and `email` schemas. `admission` owns verified/admitted ingress, the Eve-delivery outbox, and delivery observations; `kapso` and `email` isolate each `ZoenChatStateAdapter` state machine. Runtime roles receive DML only.
  - Eve Workflow history lives in its separate owner database described by ADR 029. Eve relationship, Focus, attention, and `InteractionJournal` read models are derived from that history.
- Each runtime adapter has the minimum role for its module. Only the Ontology commit role can advance `WorldHead`. Only a dedicated migrator has DDL. Backup, proof, and support access use separate audited roles. Shared writable `ops` tables and cross-product write roles are prohibited. There is no atomic journal append across the channel gateway and Eve Nitro: channel admission plus its outbox commit locally before 2xx, then idempotent delivery into Eve.
- Row-level security is defense in depth for realm and World isolation. Every repository also requires realm and World in its typed key. Database constraints enforce uniqueness, foreign keys, temporal interval validity, digest shapes, and ProgressCommit write allowlists.

An evidence candidate is a nominally sealed staged value, not an admitted reference. It records source identity, kind-indexed connector artifact, observed time, ingestion time, validity interval, classification, raw object digest, normalized value digest, local object-verification receipt, release schema ID, usage contract, entitlement snapshot, and provenance links. Admission performs:

1. fixed-envelope validation and content limits;
2. immutable object storage and digest verification for large payloads;
3. release-owned JSON Schema validation;
4. normalization without losing the raw evidence reference;
5. provenance, freshness, unit, and confidence checks;
6. pure evaluation of the locally stored `DataUsageContract`, current sealed entitlement snapshots, obligations, and bounded fail-closed meet;
7. Cedar disclosure and operation authorization;
8. release-owned domain invariants and materiality classification;
9. direct AuthorityCommit or creation of a Case for governed decision.

The public capability is one deep `contribute` operation with a receipt or governed Case result. Acquisition, mapping, validation, normalization, and admission remain internal stages so a caller cannot stop after mapping and present half-admitted data as truth. A live capture first becomes `StagedObservationCapture`; a dedicated AuthorityCommit may then create `AdmittedObservationRef`. Only the admitted type may enter a Case exact read set, model context, Notice, export, data flow, federation artifact, or later Action.

A stable `SubjectId` does not depend on its current type. Type assignments, links, and claims are temporal and evidence-backed, so one subject may lawfully gain or lose several classifications without changing identity. Evidence, claims, and belief remain separate records. Admission never deletes rival evidence to manufacture certainty. A released, purpose-specific `KnowledgeBasisDefinition` derives an immutable `ResolutionDecision` that names supporting and rival evidence, assumptions, confidence and uncertainty, algorithm and release digest, and head basis. It remains derived unless a governed Action commits a reference to it.

Temporal facts store both valid time and transaction cut. Corrections append a new revision; they do not overwrite prior truth. Fetch attempts and upload staging are operational progress, but an authoritative source cursor advances only inside the same AuthorityCommit that admits its referenced evidence.

Read models, search indexes, and graph-shaped projections are disposable projections. They name their source cut and can be rebuilt from authoritative rows and commit envelopes.

All SQL values are parameterized. Dynamic identifiers may come only from a closed compiled release registry. Application roles do not own their tables or receive `BYPASSRLS`; realm-sensitive tables use `ENABLE ROW LEVEL SECURITY` and `FORCE ROW LEVEL SECURITY`. Rows, webhook bodies, provider values, artifacts, captures, and entitlement responses are `WireValue`/`unknown` until an owning boundary decoder validates them and constructs a nominally sealed verified value. Verified, staged, admitted, and settled lifecycle variants are distinct unions; casts cannot promote one into another.

Migrations are forward-only handwritten SQL executed over a direct `pg` connection by a small Zoen command. The runner acquires one advisory migration lock, records filename, SHA-256 checksum, deployment identity, and explicit transactional or non-transactional mode, and refuses a changed applied checksum. Transactional DDL commits as one unit; operations PostgreSQL forbids in a transaction run alone and are recorded only after success. `node-pg-migrate`, Postgrator, Graphile Migrate, and ORM-generated schema authority are not launch dependencies.

## Consequences

- Transactions, temporal truth, idempotency, and audit share one consistency boundary.
- JSON Schema allows Worlds to define different fact shapes without schema-per-customer DDL.
- PostgreSQL is not used as a dense analytic file format; ADR 009 assigns that job to Parquet.
- Explicit SQL costs more code than an ORM but makes locks, cuts, and role boundaries reviewable.

## Reopen triggers

- A measured authoritative query remains outside its service objective after indexes, partitioning, and projection design; add a projection, not a second authority.
- Neon cannot meet an agreed residency, recovery, or availability requirement; move PostgreSQL providers while preserving the protocol and restore journeys.
- RLS or role design cannot express a required cell boundary. Introduce a database or project per cell before relaxing realm isolation.
- Three independent modules show that explicit SQL causes the same class of production defect and a typed query builder passes all commit and lock journeys.
- The small migration runner becomes a repeated maintenance or correctness risk. A replacement must preserve handwritten SQL, SHA-256 identity, advisory exclusion, deployment evidence, and explicit transaction mode without becoming a second schema model.
- A graph engine may be introduced only as a cut-addressed, rebuildable projection with no mutation authority.
