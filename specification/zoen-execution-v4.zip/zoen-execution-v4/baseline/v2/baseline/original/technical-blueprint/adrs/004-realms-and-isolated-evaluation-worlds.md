# ADR 004: Realms and isolated EvaluationWorlds

Status: Accepted

## Context

Release evaluation runs adversarial and incomplete proposals. It may invoke trusted evaluators, dense queries, model calls, and connector simulators. If that work can reach live authority rows, production credentials, live effect delivery, or mutable production object prefixes, a proof is not evidence of safety; it is another production mutation path.

Logical tenant filters also do not establish a strong boundary for proof-producing evaluation. A missing predicate or leaked process credential would be enough to cross it.

## Decision

- Every durable record belongs to a `RealmId`. The compile-time `RealmClass` is `live | evaluation`: production is live, while proof, development, journey, and sealed recovery realms are evaluation-class with distinct purposes and credentials.
- World identifiers are only meaningful with their realm. Cross-realm references, sessions, DecisionHandles, idempotency records, cursors, manifests, effects, and releases are rejected before any lookup that could disclose existence.
- Production runs in its production Neon project and production object-storage namespace. Proof-producing EvaluationWorlds run in a separate Neon project, separate object prefixes and encryption context, separate Restate environment, separate model budget, and separate connector credentials.
- A proof-producing evaluation runs in an ephemeral process or Machine whose environment contains no production credential. It runs the exact candidate OCI image through the normal Door, Eve, Living World, API, CLI, MCP, storage, Watch, and Effect paths against an active evaluation head; there is no inactive-release bypass.
- Evaluation credentials cannot read production databases, production object prefixes, production Restate state, production session secrets, or live provider credentials. Production credentials cannot mutate evaluation data except through an explicit cleanup operator.
- Evaluation connectors are verified provider sandboxes or explicitly limited capture and recorded-evidence adapters. The latter prove Zoen mapping or rendering only and never attest provider acceptance. Any allowed external call is enumerated in the release proof plan, egress-restricted, budgeted, and incapable of causing a live effect.
- Evaluation fixtures are synthetic or explicitly admitted, minimized, and de-identified artifacts. Restoring production data into evaluation is prohibited as a shortcut.
- The proof worker receives only immutable release inputs, a seeded EvaluationWorld, evaluation-scoped secrets, and the artifact digest being proven. It cannot read deployment secrets or discover the current production head.
- Evaluation time, randomness, model inputs, model outputs, tool calls, budgets, and connector transcripts are captured as evidence. Hidden chain-of-thought is never requested or stored.
- EvaluationWorld creation and destruction are explicit operations with TTL and an owner. Cleanup produces a receipt proving that no production row or reachable evaluation object was created, and may reclaim unreferenced evaluation objects only after their proof is accepted, rejected, or expired.
- Development and journey realms use disposable databases and isolated object prefixes. They do not share production identity signing keys.

## Consequences

- A proof has a defensible statement: it was produced without live authority or live-effect access.
- Evaluation costs more than a schema namespace because it needs separate infrastructure and credentials.
- Production data needed for evaluation must be synthesized, minimized, or explicitly de-identified and exported; it cannot be queried in place.
- Some end-to-end provider behavior can only be verified with controlled canary journeys after activation. The proof must state that limitation.

## Reopen triggers

- A provider supports a stronger hardware-enforced confidential evaluation environment; adopt it if it preserves the same denial of live authority and live effects.
- Regulation requires a dedicated project, account, or region per customer World; introduce cells while preserving realm-qualified identifiers.
- Evaluation setup p95 exceeds ten minutes for twenty consecutive proof runs; optimize snapshots and seeded fixtures without sharing production credentials.
- A proof needs a live external capability that cannot be simulated. Reopen the capability's proof status and canary design; do not silently grant live credentials to EvaluationWorld.
- Any credential-isolation journey reaches a production resource from evaluation. Block release activation until the boundary is redesigned and re-proved.
