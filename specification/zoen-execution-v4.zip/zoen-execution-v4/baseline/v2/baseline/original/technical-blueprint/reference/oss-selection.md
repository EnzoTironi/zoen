# Open-source and npm selection record

## What “best” means here

There is no universally best library. Zoen selects the smallest mature component that strengthens a named invariant without becoming a second source of product meaning. A candidate scores on semantic fit, failure semantics, type and runtime safety, operational cost, release age, maintainer activity, license, supply-chain surface, portability, and how easily it can be removed behind a Zoen-owned port.

Package metadata and primary documentation were checked on 2026-09-04. Exact patches and integrity hashes belong in `pnpm-lock.yaml`, the dependency evidence ledger, SBOM, and image digest. The versions below are the inspected baseline, not permission for floating production installs.

## Adopt now

| Problem | Selection | Inspected baseline | Why it wins for Zoen |
|---|---|---:|---|
| Production runtime | Node.js LTS | 24.20.0 | One stable ESM runtime for every Zoen-owned application module; mature native and AI ecosystem |
| Language compiler | TypeScript compatibility line | 6.0.3 | Complete ESLint type-aware ecosystem and compiler API while TypeScript 7.0 has no public programmatic API |
| Package manager | pnpm | 11.25.0 | Strict direct-dependency visibility, `workspace:` identity, catalogs, cycle rejection, minimum release age, build-script allowlist, frozen lockfile |
| HTTP | Hono | 4.13.7 | Small Fetch-native boundary for JSON, SSE, Better Auth, and official MCP middleware |
| Identity | Better Auth | 1.7.2 | Session Door, OAuth and MCP-facing identity with a direct official PostgreSQL adapter |
| MCP | `@modelcontextprotocol/server`, `client`, `hono` | 2.0.0 | Official stable v2 line for the 2026-07-28 specification; transport stays separate from released meaning |
| Portable mini-app protocol | MCP Apps specification | 2026-01-26 | Standard `ui://` resources, sandboxed host bridge, capability calls and text fallback without making one builder/runtime proprietary |
| Fixed boundary schemas | Zod | 4.5.4 | Excellent TypeScript ergonomics for code-owned envelopes and adapter decoding |
| Release-owned schemas | Ajv | 8.20.0 | JSON Schema 2020-12 for dynamic, signed release contracts without pretending compile-time types validate data |
| PostgreSQL access | `pg` | 8.23.0 | Exact checked-out-client transactions, SQLSTATE handling, locks and RLS context remain visible |
| Canonical JSON | `canonicalize` | 4.0.0 | Small RFC 8785 implementation, always checked against RFC and Zoen adversarial fixtures |
| Decimal arithmetic | `decimal.js` | 10.6.0 | Explicit arbitrary precision and rounding behind immutable released `DecimalValue`; never leaked as a domain class |
| Time | `@js-temporal/polyfill` | 0.5.1 | `Instant` and timezone-safe calculations on Node 24; remove after a native-runtime parity journey |
| S3 object access | `@aws-sdk/client-s3` | 3.1127.0 | Maintained modular S3 client for Tigris; object keys remain content digests, never truth by listing |
| Dense storage format | Apache Parquet + Zstd | format contract | Language-neutral immutable history with statistics, projection and predicate pushdown |
| Dense query and write | `@duckdb/node-api` | 1.5.5-r.4 | One embedded vector engine reads and deterministically writes Parquet behind bounded ports |
| Hybrid retrieval | pgvector extension / `pgvector` Node codec | 0.8.6 / 0.3.0 | Rebuildable PostgreSQL full-text plus vector projection without adding a vector database or letting retrieval become evidence |
| Horizontal authorization | `@cedar-policy/cedar-wasm` | 4.12.0 | Explicit default-deny admission/disclosure policy; domain transitions remain Zoen code |
| External effect recovery | `@restatedev/restate-sdk` | 1.17.0 | Mature durable invocation and deployment pinning at exactly one boundary: `ZoenEffect` |
| Eve attempt composition | Eve-native hooks + plain typed `EveAttemptContext` | platform code | Eve already owns durable steps, state, cancellation, tools, dynamic capabilities, subagents, and cleanup; no second lifecycle kernel |
| Model interface and providers | `ai`, `@ai-sdk/openai`, `@ai-sdk/anthropic` | 7.0.92 / 4.0.58 / 4.0.49 | Matches Eve's `ai ^7.0.82` peer and supplies direct provider `LanguageModel` values behind `ModelPort`; no raw provider SDK split |
| Conversation kernel | `eve` | exact 0.52.0 | Eve owns durable sessions, turns, steps, hooks, streams, schedules, relationship history, and native Telegram; Preview status is explicit |
| Eve workflow store | `@workflow/world-postgres` | exact 5.0.0-beta.40 | Compatible self-hosted Workflow 5 beta world in a dedicated `eve_workflow` database; production is blocked until recovery gates pass |
| Eve tool/sandbox profile | Eve `disableTool`, approval helpers, and a Zoen-owned disabled `SandboxBackend` | `eve@0.52.0` public APIs | Source-controlled allowlist removes shell/file/web/delegation/todo reach, makes every authored tool's approval explicit, and turns accidental sandbox access into fail-closed denial |
| Cross-provider channel bridge | `chat` | 4.39.0 | Vercel Chat SDK normalizes provider delivery mechanics behind Eve-owned envelopes; it is transport plumbing, not product state or memory |
| WhatsApp bridge | `@kapso/chat-adapter` | 0.1.1 | Launch WhatsApp destination remains Kapso at the fixed Zoen ingress boundary |
| Email bridge | `@resend/chat-sdk-adapter` | 0.3.0 | Resend supplies the launch email transport while Eve retains canonical thread/identity meaning |
| Channel operational state | Zoen-owned `ZoenChatStateAdapter` over raw `pg`, implementing `chat`'s public `StateAdapter` | platform code / `chat@4.39.0` interface | Dedicated `eve_channels` database, isolated `kapso`/`email` schemas, migrator-owned SQL, and DML-only runtime roles without accepting a runtime-DDL package |
| Web shell | React / React DOM | 19.2.8 | One compositional browser model for Eve, Living World and Workshop |
| Web build and routing | Vite / React Router | 8.2.2 / 8.3.1 | Static assets and client routing without server-component or full-stack framework ownership |
| Server state | TanStack Query | 5.102.8 | Explicit cache identity and invalidation around released references; never a source of truth |
| Accessible primitives | React Aria Components | 1.21.0 | Behavior and accessibility without imposing generic product chrome |
| Dense tables | TanStack Table / Virtual | 9.2.4 / 3.14.10 | Headless keyboard-compatible data workbench and bounded rendering |
| Released forms | React Hook Form | 7.87.0 | Efficient controlled boundary around generated domain Action forms; Ajv/server still decides validity |
| Launch chart renderer | Apache ECharts, modular core imports | 6.1.0 | Mature chart breadth, Canvas/SVG, progressive rendering and specialist financial/graph/matrix profiles behind `ChartRendererPort` |
| Logs | Pino | 10.3.1 | Low-overhead structured events; never the audit ledger |
| Traces and metrics | OpenTelemetry Node SDK | 0.222.0 | Vendor-neutral propagation across HTTP, PostgreSQL, models, Restate and providers |
| Product journeys | Playwright | 1.62.1 | One runner can drive browser, HTTP, CLI subprocesses, MCP and evidence capture |
| Real dependency harness | Testcontainers | 12.1.0 | Real PostgreSQL, MinIO and Restate lifecycle without repository fakes |
| Code constitution | Ultracite | 7.10.8 | Curated maximum-strictness rules across TypeScript, React, CSS and formatting |
| Lint implementation | ESLint / typescript-eslint | 10.10.0 / 8.69.0 | Complete current type-aware rule set on TypeScript 6.0, including unsafe values and promises |
| Format and CSS | Prettier / Stylelint | 3.9.6 / 17.15.0 | Ultracite-supported deterministic text and stylesheet gates |
| Module constitution | dependency-cruiser | 18.2.0 | Cycles, product ownership and adapter import restrictions as static evidence |
| Dead code and dependencies | Knip | 6.34.0 | Unused files, exports and dependencies, with explicit generated/entrypoint declarations |

## Deliberately use the platform

These needs do not justify another runtime dependency:

- Node `fetch`, Web Streams and `AbortSignal` for ordinary HTTP and cancellation; no Axios.
- Node `crypto` and WebCrypto for SHA-256, random bytes and constant-time comparison; no generic hash wrapper.
- PostgreSQL 18 `uuidv7()` for database-issued ordered identifiers and `crypto.randomUUID()` for unsequenced client correlation; no global ID framework.
- `node:util.parseArgs` plus release-generated command descriptors for the first CLI; add a CLI framework only when completion or nested-command ergonomics demonstrates a real gap.
- Explicit discriminated unions for `Result`, state machines and errors; no generic effect/result monad in the domain.
- PostgreSQL outbox, receipts and leases for local asynchronous work; no Redis, Kafka, NATS, BullMQ, pg-boss or generic event bus. Redis is forbidden in every role, including cache, session, queue, lock, channel, and live-feed transport.
- A small TypeScript migration command over `pg` and forward-only SQL. It computes SHA-256, owns one advisory lock, records deployment identity, and makes transactional mode explicit. The mechanism is small enough that a migration DSL would add more concepts than it removes.

## Database and ORM decision

Zoen uses no ORM in the authority kernel. The reason is not aesthetic hostility to ORMs; it is that `AuthorityCommit` is primarily a protocol of serializable isolation, lock order, compare-and-set, RLS context, deferred and exclusion constraints, immutable inserts, and whole-command retries. Hiding those statements makes the important code less legible.

- **Adopt:** raw parameterized `pg`, named query modules, runtime row schemas, and a capability-scoped transaction wrapper.
- **Identity exception:** Better Auth receives its official PostgreSQL adapter and isolated `door` role/schema. Its internal Kysely use is not an Ontology dependency.
- **Eve operational exception:** Workflow Postgres internally uses Drizzle and Graphile Worker in its isolated `eve_workflow` database. Those third-party tables are Eve execution internals and never an Ontology schema or ORM abstraction.
- **Channel-state adapter:** `ZoenChatStateAdapter` uses raw `pg` against the dedicated `eve_channels` database and checked-in forward SQL. It is not an ORM exception; the provider runtimes receive DML-only roles and cannot create or alter tables.
- **Best typed alternative:** Drizzle is the strongest full-stack runner-up, but authority still falls through to custom SQL and a second schema description.
- **Best optional query builder:** Kysely may enter one read-only projection package after repeated measured mapping defects. It never enters authority, migrations, settlement, or auth.
- **Reject for authority:** Prisma and MikroORM. Their abstractions leave the decisive PostgreSQL features outside or obscure the exact unit of work.

The full transaction, role, migration and reconsideration contract is in [Database access](database-access.md).

## Parquet decision

Parquet is retained permanently as the durable dense-observation protocol. It is not a DuckDB cache and not a transitional export format.

DuckDB writes segments through a parameterized, allowlisted `COPY ... TO ... (FORMAT PARQUET, COMPRESSION ZSTD)` plan into bounded temporary storage. Zoen hashes the exact completed bytes, uploads them at the digest, verifies metadata, and only then admits the immutable segment and manifest in PostgreSQL. A failed write or upload creates no reachable truth.

This makes `parquetjs`, `parquet-wasm`, Hyparquet and Arrow JS unnecessary in the first write path. Arrow may later be an in-memory interchange optimization. A DataFusion implementation may replace the engine only by reading the same objects and producing the same canonical results. Neither change migrates the Parquet protocol.

## Eve runtime, Workflow world, and model stack

`eve@0.52.0` is adopted through its documented self-hosted surface: `eve build` produces Nitro output and `eve start` serves it. Its public package does not expose a stable generic Hono/Fetch server handler with route, schedule, Workflow, streaming, and shutdown parity. Zoen therefore runs Eve on `127.0.0.1:4274` and raw-proxies both `/eve/` and `/.well-known/workflow/` through Hono. Importing `eve/internal/*` or copying generated handlers is rejected.

Self-hosted Eve defaults to a local disk Workflow world, which is appropriate only for local development and disposable evaluation. The first production candidate is exact-pinned `@workflow/world-postgres@5.0.0-beta.40` because it matches Eve's Workflow 5 beta line. It is not production-approved yet: the upstream world is a reference implementation and open issue #3119 reports startup recovery re-enqueuing parked runs and accumulating duplicate jobs. The dedicated `eve_workflow` database, crash/park/restart corpus, backup/restore, queue-pressure, and pairwise upgrade journeys are hard activation gates.

Eve `0.52.0` peer-requires `ai ^7.0.82`. Zoen exact-pins `ai@7.0.92`, `@ai-sdk/openai@4.0.58`, and `@ai-sdk/anthropic@4.0.49`. Provider factories produce `LanguageModel` values that cross the Zoen-owned `ModelPort`; no raw provider client type enters Eve's relationship or journal contracts. AI Gateway string IDs are supported by Eve, but Gateway remains a separate deployment profile until its routing, data-processing, residency, failure, attribution, and cost behavior pass the named journeys.

DeepSeek/Cordis remains a design reference, not an installed launch dependency. Eve-native hooks plus a plain typed attempt context implement scoped services, explicit lifecycle, cleanup, and attribution with one durable owner. Cordis can be evaluated only after three unrelated needs prove this insufficient.

The official Eve default tool surface is intentionally not the Zoen surface. Authored `disableTool()` sentinels remove `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, and `todo`; Zoen does not opt into `glob`, `grep`, `Workflow`, or `sleep`, and it declares no skills or connections. `ask_question` remains, alongside generated `inspect_*`/`propose_*` tools whose approval is never implicit. Because Eve's omitted sandbox backend calls `defaultBackend()` and its last fallback, `just-bash`, has no network isolation, Zoen supplies a custom disabled `SandboxBackend` that rejects every use. The attachment boundary prevents Eve's automatic `/workspace/attachments` staging by rejecting byte-backed file parts or replacing them with authorized text/reference values first.

Chat SDK exact `4.39.0` exports `StateAdapter`, so Zoen can implement its public contract without importing package internals. The inspected exact `@chat-adapter/state-pg@4.39.0` instead runs unqualified table/index DDL from `connect()` and provides no schema or migration-free switch. That conflicts with a DML-only runtime role and isolated provider schemas. The package remains pinned research evidence, not a launch dependency.

## Rivet, workflows and dynamic mini-apps

Rivet is credible but its three offerings solve different problems:

- **Actors:** possible future Eve locality adapter, never authority and never a second conversation truth.
- **Workflows:** serious future `EffectRuntimePort` candidate, but the standalone 1.0.0 package was four days old at inspection and its queue documentation has contradictory failure/redelivery language.
- **Dynamic Apps:** strategically aligned with Workshop mini-apps. The product contract is adopted; the current 0.3.1 Preview runtime is not yet a constitutional dependency.

The target mini-app system is not intentionally small. A released `MiniAppManifest` may compile into a rich, content-addressed `MiniAppArtifact` with TypeScript/React presentation, routes, local interaction state, tables, charts and composition. Generated execution has no ambient authority: no PostgreSQL, provider credentials, arbitrary egress, or ability to invent a domain Action. The host capability bridge performs every read and Action under fresh Door, World, purpose and disclosure checks. Drafts run only in EvaluationWorld; publication pins provenance, dependencies, permissions, build evidence and digest. A declarative renderer is the safe fallback, not the permanent ceiling.

The portable delivery target is the stable MCP Apps extension: a content-addressed `ui://` resource, host-enforced sandbox and content policy, declared app-visible tools, host-mediated calls and a structured/text fallback. Eve/Living World is Zoen's first-party host; any conforming external MCP host may render the same artifact. Rivet Dynamic Apps is the first implementation spike for generation, build and optional runtime because it already addresses generated apps, but the produced artifact and capability contract must survive without Rivet.

The inspected `@modelcontextprotocol/ext-apps` 1.7.5 package still peers on the legacy aggregate `@modelcontextprotocol/sdk` v1 line, while Zoen selects the official split v2 packages. Therefore Zoen targets the MCP Apps protocol but does not add a second MCP core SDK at launch. It will adopt the package when its v2 line is compatible, or maintain a tiny conformance-proved adapter if that is materially smaller. Rivet is adopted only after the gates in [Rivet and Restate](rivet-vs-restate.md) pass. Restate remains the launch effect runtime and is never broadened into a general application/workflow platform.

## Quality choice: TypeScript 6 versus TypeScript 7

TypeScript 7.0.2 is a major native rewrite and the official compiler reports large speed gains, but 7.0 intentionally ships without a public compiler API. dependency-cruiser states that it expects support at TypeScript 7.1. Oxlint's stable type-aware engine currently implements 59 of typescript-eslint's 61 type-aware rules. For commit-zero pedantry, Zoen chooses TypeScript 6.0.3 plus Ultracite's ESLint path now.

This is not a permanent performance concession. TypeScript 7.1 becomes the default candidate when:

1. the compiler API is public;
2. dependency-cruiser or an equally explicit ESLint boundary gate supports it;
3. Ultracite's Oxlint/Oxfmt path covers the required type-aware rules and suppression reporting;
4. declaration emit, project references, generated contracts and editor behavior pass;
5. the canonical replay and every journey remain identical.

## UI choices and rejected generic shells

The Living World is not a dashboard kit. React Aria supplies behavior; native CSS tokens supply Zoen's visual language; TanStack supplies headless data mechanics; ECharts supplies data marks. Released view documents expose a closed, semantic subset rather than passing arbitrary library configuration through the release.

- ECharts options and TanStack mark objects never become the release schema. A `ChartDocument` says question, measure, dimension, unit, temporal basis, representation proof, interaction, accessibility and evidence references; the selected adapter compiles a disposable render plan.
- Launch with one renderer: modular ECharts through a small first-party React host. Keep exact-pinned `@tanstack/charts` 0.16.0 in EvaluationWorld only; after promotion it becomes the ordinary SVG-first renderer while ECharts remains the named dense/financial/graph specialist.
- TanStack rows carry stable object/evidence references and policy-shaped cells. A client never receives a hidden column and then hides it with CSS.
- React Hook Form manages interaction, not validity or authorization.
- React Aria primitives are composed into first-party product experiences; there is no generic component marketplace in the kernel.

Reject initially: Next.js/RSC, Redux, Tailwind as a runtime dependency, Material UI, shadcn as product identity, AG Grid, React JSON Schema Form, arbitrary HTML from model output, `echarts-for-react`, and `echarts-gl`. TanStack Charts is a gated evaluation dependency, not a second production renderer.

## Security and supply-chain tools

Use purpose-built build tools rather than importing them into the runtime:

- Gitleaks for secrets;
- OSV-Scanner for the resolved dependency graph;
- Trivy for filesystem and OCI configuration/vulnerability policy;
- Syft for SPDX/CycloneDX SBOM;
- Cosign and an in-toto/DSSE statement for image and release-proof signing;
- pinned GitHub Action commit SHAs, pinned base-image digest, no runtime installation, and non-root read-only execution.

`pnpm-workspace.yaml` is part of the security boundary: strict peers, `disallowWorkspaceCycles`, `minimumReleaseAge`, a root version catalog, `workspace:` internal references, and `allowBuilds` for individually reviewed lifecycle scripts. A Renovate PR changes one dependency family at a time and runs the affected journeys. A critical exception requires owner, reason, compensating control and expiry.

## Alternatives assessed and not selected

| Alternative | Why it is not the launch choice | Reconsider when |
|---|---|---|
| Bun or Deno | Smaller dependency compatibility and a second runtime assumption without a product invariant | A required capability or measured 2x whole-journey result pays migration cost |
| TypeScript 7 + Oxlint now | Missing compiler API, boundary-tool gap, and 59/61 type-aware coverage | The five quality gates above pass |
| npm workspaces | Functional but permits flatter accidental dependency visibility and has weaker workspace identity/catalog ergonomics | pnpm creates a documented blocking incompatibility |
| Fastify | Excellent server, but Hono fits the Fetch/MCP boundary with less surface | Hono lacks a safety-critical feature or loses a representative workload by 2x |
| tRPC or oRPC | Makes a TypeScript call graph the public model; released schemas must remain language-neutral and dynamic | Never for the released domain protocol; may be considered for a private nonsemantic utility |
| Drizzle / Prisma / MikroORM | A second authority/schema model or hidden unit-of-work behavior | Database-access gates demonstrate a net correctness gain |
| `node-pg-migrate` | Good lock and PostgreSQL support, but its builder becomes a second DDL form and its standard ledger is not Zoen's checksum/proof contract | Use its SQL loader only if the small runner becomes a maintenance risk |
| Postgrator | Plain SQL and checksums are attractive, but its version/MD5 model still needs Zoen's SHA-256, advisory lock and deployment evidence wrapper | Adopt if it removes more code than the wrapper it still requires |
| Graphile Migrate | Strong SQL-first philosophy, but its development shadow workflow is broader than the first migration contract | Team workflow demonstrates the extra machinery pays for itself |
| DBOS / Temporal / Inngest / Trigger.dev | General durable workflows duplicate the narrow Restate plus PostgreSQL ownership model or add operations | A released workflow kind cannot be expressed as Case, Watch, Scenario, outbox or Effect |
| Rivet Workflows now | Very young standalone API and unresolved delivery semantics | The explicit Restate replacement gate passes |
| `@modelcontextprotocol/ext-apps` now | The stable protocol fits, but the inspected package introduces a legacy MCP v1 peer beside Zoen's v2 stack and no production host implementation is established for Zoen | A v2-compatible package or a conformance-proved tiny adapter passes the independent-host and fallback journeys |
| TanStack Charts in production now | Excellent semantic and React fit, but the inspected 0.16 line is Alpha and permits breaking minor releases | Its exact-pinned adapter passes canonical, accessibility, SSR/export, bundle, lifecycle and upgrade journeys in EvaluationWorld |
| `echarts-for-react` | A small imperative host does not justify another lifecycle and dependency surface | Never unless the first-party host becomes measurably less reliable or larger than the wrapper plus its audit burden |
| `echarts-gl` | Current ECharts 6 ESM compatibility evidence and license-metadata disagreement fail admission | A separate GPU-renderer ADR resolves compatibility/license and a named journey needs GPU |
| Chat SDK memory state | Process-local dedupe and thread state disappear on crash and cannot satisfy durable ingress | Never in production; use `ZoenChatStateAdapter` in the dedicated operational database |
| `@chat-adapter/state-pg@4.39.0` | `connect()` executes unqualified runtime DDL and exposes no schema/migration switch, defeating isolated schemas and DML-only provider roles | Only if a future exact release separates migrations, qualifies a caller-selected schema, and passes conformance, least-privilege, crash, restore, and upgrade journeys with less owned code |
| Chat SDK as Eve | Provider-normalization state does not own relationship, conversation, attribution, or model attempts | Never; bridge it under Eve's channel port |
| Native Parquet JS writers | Another correctness/encoding surface when DuckDB already reads and writes the chosen format | DuckDB output cannot meet a measured encoding requirement |
| Rust/DataFusion now | Second language and service/tooling cost without a unique invariant | Dense benchmark and operational gate passes |
| Kafka, NATS, BullMQ | Another durable ordering and recovery truth | A real cross-cell transport requirement proves a replaceable non-authoritative need |
| Redis | Forbidden in every role; it would add a second cache/queue/session/lock truth without a product invariant | Not a reopen path under this constitution |
| `@deepseek-ai/cordis` at launch | Eve 0.52 already owns the durable event, step, hook, state, cancellation, tool, and subagent lifecycle | EvaluationWorld only after three unrelated needs prove Eve-native hooks plus plain typed contexts insufficient |
| Raw `openai` / `@anthropic-ai/sdk` model clients | Eve peers on AI SDK 7 and accepts provider `LanguageModel` values; raw clients would create a parallel model abstraction | Only for a provider feature that cannot cross AI SDK's model contract and survives a dedicated adapter gate |
| AI Gateway as default model route | Adds another data processor, router, failure mode, and attribution contract before Zoen needs it | A separate endpoint profile passes residency, retention, routing, billing, failover, and direct-provider parity journeys |
| Generic plugin marketplace | Lets installation become ambient authority | All extensions are release-addressed, capability-bounded and EvaluationWorld-proved |

## Primary references

- [Node.js release lines](https://nodejs.org/en/about/previous-releases)
- [TypeScript 7.0 and the 6.0 compatibility API](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/)
- [pnpm motivation](https://pnpm.io/motivation) and [workspace settings](https://pnpm.io/settings)
- [Ultracite](https://www.ultracite.ai/), [Oxlint type-aware status](https://oxc.rs/docs/guide/usage/linter/type-aware), and [dependency-cruiser releases](https://github.com/sverweij/dependency-cruiser/releases)
- [MCP TypeScript SDK v2](https://github.com/modelcontextprotocol/typescript-sdk)
- [MCP Apps extension and stable specification](https://github.com/modelcontextprotocol/ext-apps)
- [Better Auth PostgreSQL adapter](https://better-auth.com/docs/adapters/postgresql)
- [`pg` transactions](https://node-postgres.com/features/transactions)
- [DuckDB Node Neo](https://duckdb.org/docs/stable/clients/node_neo/overview) and [COPY](https://duckdb.org/docs/stable/sql/statements/copy)
- [pgvector PostgreSQL extension](https://github.com/pgvector/pgvector) and [Node codec](https://github.com/pgvector/pgvector-node)
- [Apache Parquet](https://parquet.apache.org/docs/)
- [ECharts features](https://echarts.apache.org/en/feature.html) and [ARIA guidance](https://echarts.apache.org/handbook/en/best-practices/aria/)
- [TanStack Charts documentation](https://tanstack.com/charts/latest), [stability policy](https://tanstack.com/charts/latest/docs/framework/react/overview#api-stability), and [charting evidence ledger](charting-selection.md)
- [Eve](https://eve.dev/), [self-hosting](https://github.com/vercel/eve/blob/main/docs/guides/deployment/self-hosting.md), [execution and durability](https://github.com/vercel/eve/blob/main/docs/concepts/execution-model-and-durability.mdx), and [frontend integration](https://github.com/vercel/eve/blob/main/docs/guides/frontend/overview.mdx)
- [Eve built-in tools](https://github.com/vercel/eve/blob/main/docs/concepts/built-in-tools.md), [tools and approvals](https://github.com/vercel/eve/blob/main/docs/tools/overview.mdx), [sandbox](https://github.com/vercel/eve/blob/main/docs/sandbox.mdx), [security model](https://github.com/vercel/eve/blob/main/docs/concepts/security-model.md), and [responsible use](https://github.com/vercel/eve/blob/main/docs/responsible-use.md)
- [Workflow Postgres README](https://github.com/vercel/workflow/blob/main/packages/world-postgres/README.md) and [startup recovery issue #3119](https://github.com/vercel/workflow/issues/3119)
- [AI SDK provider selection](https://ai-sdk.dev/docs/getting-started/choosing-a-provider), [OpenAI provider](https://ai-sdk.dev/providers/ai-sdk-providers/openai), [Anthropic provider](https://ai-sdk.dev/providers/ai-sdk-providers/anthropic), and [AI Gateway](https://ai-sdk.dev/providers/ai-sdk-providers/ai-gateway)
- [Vercel Chat SDK](https://chat-sdk.dev/), exact [`chat@4.39.0`](https://www.npmjs.com/package/chat/v/4.39.0), rejected exact [`@chat-adapter/state-pg@4.39.0`](https://www.npmjs.com/package/@chat-adapter/state-pg/v/4.39.0), [Kapso Chat adapter](https://www.npmjs.com/package/@kapso/chat-adapter), and [Resend Chat SDK adapter](https://www.npmjs.com/package/@resend/chat-sdk-adapter)
- [Postgrator checksum contract](https://github.com/rickbergfalk/postgrator#checksum-validation)
- [node-pg-migrate locking](https://salsita.github.io/node-pg-migrate/migrations/#locking)
- [Graphile Migrate principles](https://github.com/graphile/migrate)
- [Rivet and Restate evidence ledger](rivet-vs-restate.md)
- [Database and ORM evidence ledger](database-access.md)

## Revalidation rule

“Latest” is not an architecture criterion. At every release proof, automation records available stable versions, advisories, license changes, release age, maintainer status, install scripts, transitive delta and affected journeys. A selected library remains only while it is the simplest component that preserves its invariant. A rejected library may enter through its named gate; no library enters because it is fashionable or has the most stars.
