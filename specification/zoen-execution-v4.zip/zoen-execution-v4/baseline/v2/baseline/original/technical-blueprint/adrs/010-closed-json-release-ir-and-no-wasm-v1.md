# ADR 010: Closed JSON release IR and no Wasm in v1

Status: Accepted

## Context

Worlds need different meanings, Actions, Cases, views, and policies. Letting a release upload JavaScript, SQL, packages, URLs, or arbitrary Wasm would maximize theoretical expressiveness at the cost of determinism, reviewability, credential isolation, and the ability to explain what can happen.

The first release language should describe Zoen's domain, not embed another general-purpose computer.

## Decision

A `WorldRelease` is a closed, versioned JSON intermediate representation. Its tagged unions describe only code-owned concepts:

- entity, fact, relation, observation, unit, evidence-mapping, belief, and released query types;
- Action commands, preconditions, consequences, Case stages, quorum and materiality rules;
- Questions, Packs, views, disclosures, membership roles, and attention rules;
- Cedar policy sets and schema;
- connector, evaluator, renderer, and effect handler references by stable ID and approved implementation digest;
- migrations expressed as a closed set of typed data transformations.

Unknown fields and unknown union tags are errors. The interpreter is total: every valid node returns a declared result or declared domain error, has a complexity budget, and performs no ambient I/O. A release cannot contain uploaded JavaScript or TypeScript, SQL, shell commands, filesystem paths, environment reads, network calls, model calls, native modules, package coordinates, or executable URLs.

Trusted capabilities are compiled into the Zoen image and registered in the composition root by stable handler ID, semantic version, implementation digest, required grants, and resource limits. A release may reference only an allowlisted handler whose digest is present in the artifact being proved.

Published semantic IDs are opaque UUID-based identities. Human labels and approved API, CLI, MCP, Eve, and Living World slugs are facets that may evolve, but a published ID is never aliased or reassigned to another meaning.

Release validation is ordered:

1. Parse bytes while rejecting duplicate keys, invalid Unicode, non-NFC strings, non-finite numbers, negative zero, and ambiguous numeric encodings.
2. Validate the fixed envelope with Zod and release-owned data schemas as JSON Schema 2020-12 with Ajv.
3. Reject unknown fields and unresolved or cyclic semantic references where cycles are not declared.
4. Check stable IDs, global slug uniqueness, schema compatibility, total interpreter coverage, handler availability, and complexity limits.
5. Validate Cedar schema and policies and all release-owned domain invariants.
6. Canonicalize timestamps at fixed precision, sort collections declared as sets, preserve only semantically ordered arrays, and encode with RFC 8785 JSON Canonicalization Scheme.
7. Compute `SHA-256("zoen.world-release.v1\0" || canonicalBytes)` and store the bytes immutably before proof.

The canonical codec is one audited adapter around `canonicalize` 4 plus a lexical JSON parser and Node crypto. It must match the RFC 8785 corpus and Zoen's adversarial canonical journey. PostgreSQL `jsonb` may index parsed content but is never signing input.

Semantic decimals, money, durations, instants, and large integers use constrained canonical strings rather than JSON floating point. The closed release includes its typed IR, schemas, surface catalog, connector and trusted-handler digests, referenced artifacts, and journey-suite digest. The release digest names exact meaning and is never reassigned.

Wasm is not a v1 release capability. There is no WASI runtime, plugin marketplace, hot-loaded package, or escape hatch that executes release-supplied code.

This closes domain meaning, not the product's possibility horizon. ADR 019 defines separate content-addressed `MiniAppArtifact`, `NotebookArtifact`, and `ExecutorArtifact` contracts for general-purpose presentation and computation outside the authority process. A future release may reference an approved artifact digest and capability manifest; its code does not become an IR expression, authority handler, credential holder, or signing input by mutable URL.

## Consequences

- Releases are diffable, hashable, statically inspectable, and executable by one total interpreter.
- New behavior sometimes requires adding a typed IR node and shipping a new Zoen artifact before a release can use it.
- Stable trusted handler references allow controlled extension without turning releases into packages.
- Governed executable artifacts can cover the long tail without allowing arbitrary code to define authority semantics.
- Canonical bytes and domain-separated digests can be shared by API, CLI, MCP, proof, activation, and audit.

## Reopen triggers

- Three unrelated, validated customer capabilities hit the same expressiveness limit and cannot be represented cleanly by another typed IR node or trusted handler.
- If Wasm is then evaluated, the proposal must prohibit WASI, network, filesystem, environment, secrets, clock, randomness, database, model, and effect access; enforce fuel and memory bounds; define canonical inputs and outputs; and pass determinism, denial, timeout, and replay journeys.
- Release size or validation time crosses an agreed service objective. Add indexes or a binary cache keyed by the canonical JSON digest; canonical JSON remains the publication authority.
- A canonicalization standard flaw is discovered. Introduce a versioned codec and domain separator with explicit cross-version proof.
- No trigger permits arbitrary SQL or uploaded runtime packages inside the WorldRelease interpreter or authority process. Separately sandboxed artifacts remain governed by ADR 019.
