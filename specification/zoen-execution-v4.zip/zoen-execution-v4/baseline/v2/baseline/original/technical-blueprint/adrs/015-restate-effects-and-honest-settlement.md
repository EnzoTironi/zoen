# ADR 015: Restate only for effects and honest settlement

Status: Accepted

## Context

After Zoen commits a consequential decision, an external provider may accept, reject, time out, duplicate, or later reverse its work. Local exactly-once claims cannot make an external system exactly once. Treating a timeout as failure can duplicate an effect; treating it as success invents reality.

Restate is valuable at this uncertainty boundary, but using it for Eve, Watches, releases, or local authority would create a second workflow model and weaken PostgreSQL atomicity.

## Decision

Restate TypeScript SDK 1.17 runs one service kind: `ZoenEffect`. It does not run conversation turns, Watches, attention, release evaluation, admission, or AuthorityCommit.

PostgreSQL owns every canonical `EffectIntent`, operational `EffectAttempt`, provider observation, and authoritative `EffectSettlement`. The Restate journal is durable execution evidence, not business authority or permanent idempotency.

An accepted Action writes an immutable `EffectIntent` in its AuthorityCommit. The intent includes realm, World, pre-commit decision basis, known next non-audit head coordinates, source commit and receipt references, ordinal, release, released operation, kind-indexed effect-connector artifact digest, destination digest, schema and canonical payload/object digests, authorization and contribution-set references, data-usage decision, deadline, and retry/reconciliation contract. It contains neither the not-yet-derived resulting audit root nor any provider secret or mutable credential value, so its payload cannot create a commit-digest cycle.

The retry contract is a closed union: `destination-idempotent` with a stable destination key, or `reconcile-before-retry` with a released reconciliation capability. A non-idempotent destination is never called again until reconciliation proves the prior attempt was not accepted.

The `DecisionReceipt` proves only the local AuthorityCommit, its consequences, and created intent references. It never contains or implies external success. Settlement has its own later evidence and audit history.

`EffectIntentId` is deterministic from the realm, World, source commit, effect ordinal, released effect type, and handler digest. The AuthorityCommit also writes an outbox item asking `zoen-effect-dispatcher` to ensure that ID is started.

The dispatcher invokes the private Restate listener with only `EffectIntentId` and a short-lived signed lease bound to realm, connector implementation digest, retry contract, destination-idempotency contract, and the current recovery epoch. Restate requests must verify the configured Restate signing identity, audience, and lease before any database read. The handler reloads the immutable intent through `EffectRuntimePort`, rechecks every lease binding, resolves the exact retained connector implementation and credential reference, and passes the deterministic effect ID as the provider idempotency key whenever the provider supports one. Arbitrary provider payloads are never accepted at the Restate boundary.

`EffectAttempt` is a closed operational lifecycle: allocated, dispatched with one effect-profile `ConnectorRun`, observed, ambiguous, or transport-failed. Attempt allocation has a unique `(intentId, attemptNumber)` coordinate, current recovery epoch, and explicit destination-key presence. Attempts and delivery observations are ProgressCommit records. Provider receipt and observation identities are unique. Restate completion retention never substitutes for those PostgreSQL constraints. A provider observation becomes semantic only when the active released reconciler interprets evidence in an AuthorityCommit.

Settlement is an immutable revision with exactly two evidence states:

```ts
type EffectSettlementState =
  | Readonly<{
      kind: 'observed';
      outcome: VerifiedReleasedValue;
      evidence: NonEmpty<EvidenceRef>;
      observedAt: Instant;
    }>
  | Readonly<{
      kind: 'unknown';
      reason: UnknownReason;
      lastAttempt: EffectAttemptRef;
      evidence: readonly EvidenceRef[];
      reconcileAfter: Instant;
    }>;

interface EffectSettlement<R extends Realm> {
  readonly intent: EffectRef<R>;
  readonly revision: EffectSettlementRevision;
  readonly prior: Initial | PriorSettlementRevision;
  readonly state: EffectSettlementState;
  readonly reconciler: SemanticId;
  readonly admittedBy: AuthorityCommitRef<R>;
  readonly admittedAt: WorldCut;
}
```

There is no generic `Succeeded | Failed` settlement and no mutable attempt status that can stand in for it. A released outcome may be `TransferAccepted`, `AppointmentRejected`, or another domain fact only when provider evidence supports it. Timeout, lost response, ambiguous callback, and exhausted transport retries produce `unknown`. Late evidence appends a new settlement revision through AuthorityCommit. Duplicate and reordered callbacks deduplicate by provider observation identity and intent.

Connector implementations are content-addressed and versioned. A build may not remove one while a retained release, open Case, Watch, PreparedActivation, unsettled EffectIntent, or Restate invocation references it. Deployments drain active invocation revisions or temporarily run the prior revision in blue-green mode; steady state returns to one Machine.

Rivet Actors, Workflows, queues, and Dynamic Apps are not launch dependencies. Actors do not share AuthorityCommit atomicity, the current queue acknowledgement documentation is contradictory, standalone Workflows is too new for this boundary, and Dynamic Apps is preview software. The released static mini-app contract in ADR 014 does not depend on any of them.

Recovery starts behind the fence in ADR 017. Restored pending work is never dispatched until Restate state, provider observations, consumer receipts, and deterministic IDs have been reconciled.

## Consequences

- Zoen is durable without claiming control over external truth.
- Restate concentrates on the one workflow whose retries must survive arbitrary process failure.
- The TypeScript SDK is MIT and the Restate server is BSL 1.1; the dependency ledger records the service license and permitted deployment model.
- The system retains old connector code longer than a conventional stateless API would.
- Users may see `Unknown` and a reconciliation path instead of a comforting but false status.

## Reopen triggers

- Restate cannot preserve signed invocation identity, durable IDs, or version-drain semantics in two release journeys. Evaluate another effect runtime behind `EffectRuntimePort`.
- Restate licensing changes incompatibly with Zoen's deployment or offering. Replace only the runtime adapter; PostgreSQL intent, attempt, Settlement, and idempotency contracts remain.
- An invocation can outlive safe retention of its handler revision. Split effect serving into a separately retained deployment; do not deserialize it into the newest handler.
- Rivet Workflows may compete for `EffectRuntimePort` only after a pinned non-preview version resolves queue acknowledgement semantics, passes real-process lost-response and upgrade journeys, protects inspector access, demonstrates backup and failover, and completes a 30-day soak. It receives no authority role even if selected.
- A provider offers authoritative status lookup or first-class idempotency. Add it to the released reconciliation policy; do not collapse the `Unknown` state globally.
- Effect throughput requires independent scaling for thirty days and causes more than 50 percent waste in the shared Machine. Scale or split only the existing effect adapter and private protocol.
- No trigger permits Restate to decide local World truth, own Eve durability, or promote an attempt into settlement without Ontology reconciliation.
