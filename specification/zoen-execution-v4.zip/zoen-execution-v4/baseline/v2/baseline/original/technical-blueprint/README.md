# Zoen technical constitution

## Decision

Build Zoen as one strict TypeScript application with three product roots:

1. Better Auth Door proves identity.
2. Eve owns the relationship, conversation, attention, and Living World.
3. Ontology owns published meaning, evidence, Actions, and the CLI, API, and MCP faces.

PostgreSQL is the sparse authority. Immutable Parquet objects selected through a content-addressed manifest DAG are the permanent dense history. A separate non-authoritative live plane carries entitled transient observations; a consequential Action can use a live value only after Zoen verifies, admits, and pins an exact `CapturedObservationRef`.

Restate performs only durable `ZoenEffect` attempts. Rivet may later implement workflow or mini-app runtime ports if it passes the declared gates; it never owns conversation or World truth. Authority storage uses explicit SQL through `pg`, not an ORM. Kysely remains a deferred option for read-only projections.

Launch channels are web, WhatsApp through Kapso, native Eve Telegram, and email through Resend. Provider routes stay disabled until durable admission before acknowledgement survives kill and replay. Channel transport state lives in a dedicated `eve_channels` database through the Zoen-owned raw-`pg` `ZoenChatStateAdapter`; it is neither Eve memory nor Ontology truth. Linq is recorded only as a later decision; it adds nothing to the launch graph.

The deployable remains one signed image, one Fly application, and initially one Machine, but it deliberately contains two supervised Node 24 processes. Hono owns the public and authority edge on `:8080`, the authenticated Eve capability endpoint on loopback `:8081`, and the signed Restate endpoint on `:9080`. The supported `eve@0.52.0` Nitro output runs through `eve start` on `127.0.0.1:4274`; Hono transparently proxies both `/eve/` and `/.well-known/workflow/`. Eve reaches Ontology only through a typed, request-bound loopback client and stores Workflow state in an isolated `eve_workflow` database.

Eve starts from an explicit capability allowlist. Zoen disables Eve's default shell, file, web, delegation, and todo tools; declares no skills or connections; keeps only `ask_question` plus generated `inspect_*` and `propose_*` Ontology tools whose approval policy is always explicit. A fail-closed disabled sandbox backend prevents fallback selection, and byte-backed attachments are rejected or normalized into authorized references before an Eve session can stage them.

## What the user gets

A person can talk to Eve, open the exact evidence behind an answer, move into a dense Living World when chat is the wrong shape, and propose a released Action. The same semantic verb works through Eve, the browser, CLI, API, or MCP. Presentation changes by channel; meaning, rights, temporal basis, and consequences do not.

A builder can define meaning once, evaluate it in an isolated `EvaluationWorld`, inspect the semantic and capability diff, and publish a signed release. The same system can later package governed data flows, models, agents, connectors, and Workshop mini-apps without adding a fourth product or a second authority path.

## Start here

Read these files in order:

1. [Arena synthesis](arena-synthesis.md) explains why the corrected TypeScript modular monolith won.
2. [Decision register](decision-register.md) is the compact map of accepted, deferred, and forbidden choices.
3. [System shape](reference/system-shape.md) assigns ownership and shows the execution planes.
4. [Types and protocols](reference/types-and-protocols.md) defines the authority-bearing contracts.
5. [Data, events, live observations, and Parquet](reference/data-events-parquet.md) fixes the sparse, live, and dense models.
6. [Repository and modules](reference/repository-and-modules.md) defines package boundaries and dependency direction.
7. [Technology stack](reference/technology-stack.md), [OSS selection](reference/oss-selection.md), and [database access](reference/database-access.md) record the concrete implementation choices.
8. [Release policy and Eve](reference/release-policy-eve.md) separates released meaning from Eve's durable conversational execution.
9. [Rivet versus Restate](reference/rivet-vs-restate.md), [messaging channels](reference/messaging-channels.md), and [charting selection](reference/charting-selection.md) resolve the main framework questions.
10. [Testing and CI](reference/testing-and-ci.md) and [security and operations](reference/security-and-operations.md) define the proof burden.
11. [Ambition audit](reference/ambition-audit.md), [capability horizon](reference/capability-horizon.md), and [competitive comparison](reference/competitive-comparison.md) separate target protocols from delivered products and commercial moats.
12. [Implementation sequence](implementation-sequence.md) turns the constitution into vertical product slices.
13. [ADR index](adrs/README.md) links every binding architecture decision.

The full source and verification ledger is in [sources.md](sources.md). Candidate designs and the weighted cross-judgment remain in [candidates](candidates/) and [judge.md](judge.md).

## Fixed launch stack

| Concern | Decision |
|---|---|
| Runtime | Node.js 24, two supervised processes in one signed image and one initial Fly Machine |
| Language | Strict TypeScript 6.0.3 for Zoen-owned application and runtime code |
| Workspace | pnpm 11 with strict peers, exact pins, a build-script allowlist, and a frozen lockfile |
| HTTP | Hono 4 on public `:8080`, authenticated Eve capability loopback `:8081`, signed Restate `:9080`; Eve Nitro on loopback `:4274` behind raw prefix proxying |
| Identity | Better Auth behind `DoorPort`; identity is not World authority |
| Authority data | PostgreSQL 18, explicit SQL through `pg`, serializable `AuthorityCommit` |
| Dense history | Immutable Parquet with Zstandard, manifest DAG, DuckDB Node Neo behind a port |
| Live data | Entitled `LiveObservationEnvelope` values outside `WorldHead`; exact capture before consequential use |
| Authorization | Cedar for horizontal admission and disclosure only |
| Release format | Canonical JSON, closed total IR, signed proof, per-World preparation, atomic activation |
| Effects | Restate only for `ZoenEffect`; PostgreSQL owns Intent, Attempt, and Settlement |
| Conversation | Exact-pinned `eve@0.52.0` owns durable sessions on its supported Nitro runtime; exact-pinned Workflow Postgres is isolated and production-gated; Eve-native hooks plus `EveAttemptContext` own composition, with no Cordis launch dependency |
| Eve capability surface | Disable `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, and `todo`; no opt-in tools, skills, connections, or default sandbox fallback; only `ask_question` and generated approval-explicit `inspect_*`/`propose_*` tools |
| Models | Exact-pinned `ai@7.0.92`, `@ai-sdk/openai@4.0.58`, and `@ai-sdk/anthropic@4.0.49` supply direct-provider `LanguageModel` values behind `ModelPort`; AI Gateway is a separately gated profile |
| Channels | Web, Kapso WhatsApp, native Eve Telegram, Resend email; Zoen-owned `StateAdapter` over raw `pg` in isolated `eve_channels` schemas |
| UI | React, React Aria, React Router, TanStack Query, Table, and Virtual |
| Charts | Released `ChartDocument`; modular ECharts 6 at launch; TanStack Charts in `EvaluationWorld` only |
| Mini-apps | Declarative `MiniAppManifest` first; signed `MiniAppArtifact` through MCP Apps-compatible delivery |
| Quality | Ultracite pedantic, ESLint, Prettier, Stylelint, dependency-cruiser, Knip, zero warnings |
| Tests | User journeys only, with real dependencies and fault injection; no mocks, fakes, stubs, or unit-test layer |

## Claim discipline

This blueprint is design evidence. It ships no competitive category and claims no Palantir or Bloomberg parity. It names target seams for the public capability categories reviewed on 2026-09-04 and the evidence required to implement them; licensed data, distribution, integrations, operating history, and production proof remain unsupplied.
