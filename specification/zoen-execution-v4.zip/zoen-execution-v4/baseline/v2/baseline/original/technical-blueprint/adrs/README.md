# Architecture decision records

Every record is accepted unless its status line says that the implementation remains deferred or gated. A successor ADR must replace a decision; code must not create a silent second path.

## Product and application shape

1. [Three products in one TypeScript application](001-three-products-one-typescript-application.md)
2. [Deep modules and one-way dependencies](002-deep-modules-and-boundary-tooling.md)
3. [Door, presence, and purpose-bound authority](003-door-presence-and-purpose-bound-authority.md)
4. [Realms and isolated EvaluationWorlds](004-realms-and-isolated-evaluation-worlds.md)

## Authority, evidence, data, and release

5. [Full WorldHead and one temporal basis](005-full-world-head-and-temporal-basis.md)
6. [AuthorityCommit, ProgressCommit, and exact idempotency](006-authority-progress-and-idempotency.md)
7. [Meaningful events, transactional outbox, and Eve journal](007-events-outbox-and-interaction-journal.md)
8. [PostgreSQL authority and governed evidence admission](008-postgresql-authority-and-evidence-admission.md)
9. [Immutable Parquet and a manifest DAG](009-immutable-parquet-and-manifest-dag.md)
10. [Closed JSON release IR and no Wasm in v1](010-closed-json-release-ir-and-no-wasm-v1.md)
11. [Cedar only for horizontal authorization](011-cedar-only-for-horizontal-authorization.md)
12. [Release proof, preparation, and atomic activation](012-release-proof-preparation-and-activation.md)

## Conversation, public interfaces, effects, and proof

13. [Eve owns conversation; Cordis principles without a second runtime](013-eve-cordis-and-model-attribution.md)
14. [Native public interfaces over one semantic catalog](014-public-interfaces-and-semantic-parity.md)
15. [Restate only for effects and honest settlement](015-restate-effects-and-honest-settlement.md)
16. [User journeys are the only tests](016-user-journeys-and-ci-evidence.md)

## Operations and programmable product

17. [Deployment, security, observability, and recovery](017-deployment-security-observability-and-recovery.md)
18. [Build sequence, scale path, and evidence-gated evolution](018-build-sequence-scale-and-evidence-gated-evolution.md)
19. [Programmable compute and governed executable mini-apps](019-programmable-compute-and-governed-mini-apps.md)

## Maximum-ambition target protocols

20. [Live observation plane and exact Action capture](020-live-observation-plane-and-action-capture.md)
21. [Signed isolated connector artifacts](021-signed-isolated-connector-artifacts.md)
22. [Released semantic computation, subscriptions, and data flows](022-semantic-computation-subscriptions-and-data-flows.md)
23. [Non-widening rights, authority cells, edge Worlds, and federation](023-rights-cells-edge-and-federation.md)
24. [Models, retrieval, headless agents, and governed conversation spaces](024-models-retrieval-agents-and-conversation-spaces.md)
25. [One developer platform and governed PackArtifacts](025-developer-platform-and-pack-artifacts.md)
26. [Evidence-backed finance execution lifecycle](026-finance-execution-lifecycle.md)

## Channels and presentation

27. [Eve channel bridges and durable admission](027-eve-channel-bridges-and-durable-admission.md)
28. [Semantic charts and asymmetric renderers](028-semantic-charts-and-asymmetric-renderers.md)
29. [Eve Nitro runtime and isolated workflow store](029-eve-nitro-runtime-and-workflow-store.md)
