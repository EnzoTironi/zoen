# Technical architecture cross-judgment

> Post-judgment amendments, 2026-09-04: the winning architecture remains Candidate B. The supply-chain audit replaced npm workspaces with pnpm 11. Official `eve@0.52.0` inspection then disproved the proposed in-process Hono mounting: supported self-hosting is `eve build` plus `eve start` as a Nitro service. Candidate B therefore runs two supervised Node processes in one initial Machine and its one-Machine score falls from 5 to 4, reducing the total from 88.0 to 86.0. Eve-native hooks plus plain typed attempt contexts make Cordis unnecessary at launch. The same inspection requires an explicit tool allowlist, a fail-closed disabled sandbox/attachment path, and a separate Workflow database. Chat SDK package inspection also replaces `@chat-adapter/state-pg` with a Zoen-owned raw-`pg` `StateAdapter` in a dedicated channel database. The final constitution and ADRs supersede historical candidate text.

## Decision

Use **Candidate B, the TypeScript modular monolith, as the base**, conditional on the corrections in this judgment being incorporated before implementation. Its amended weighted score is **86.0/100**, versus **79.6** for Candidate A and **78.8** for Candidate C.

The choice is not a concession to language preference. The authority invariants do not require Rust. PostgreSQL constraints, serializable transactions, narrow branded TypeScript values, exhaustive command/result unions, immutable release artifacts, and journeys through real boundaries are sufficient for the system described today. Rust would improve the static expression of some invariants, but neither Rust proposal demonstrates a product workload where that improvement outweighs a second language, a second build graph, and—in A—a second steady-state Machine and internal protocol seam. Both Rust candidates ultimately acknowledge that the evidence gate for Rust has not been met.

Candidate B is not accepted verbatim. Three defects are material:

1. Its Restate section proposes `Succeeded | Failed | Unknown`, contradicting the product definition of Settlement as `Observed<released domain outcome> | Unknown`. This must be replaced, not renamed.
2. Its “one Zod schema system” claim is technically false for released JSON Schema and conflicts with Fastify's Ajv-based validation machinery.
3. Its custom policy IR, vague CLI/MCP bearer-token language, and evaluation-isolation wording leave important authority boundaries less exact than A and C.

With the exact grafts and corrections below, B is the smallest coherent design that preserves the product. Without them, it is not implementation-ready.

**Firm storage decision:** dense observations are immutable **Parquet objects selected only through immutable, hash-addressed manifests**. That is the durable format and publication contract. **DuckDB is the initial query engine**, not the storage model. DataFusion is an engine alternative behind measured reopen gates; it is not a reason to change the Parquet/manifest contract.

## Law screen

No candidate is disqualified at the proposal level. All three preserve the major product divisions: Better Auth as the Door, Eve as conversation owner, Ontology as authority owner, PostgreSQL as authority store, Restate only for `ZoenEffect`, and Parquet manifests for dense observations.

Candidate B nevertheless has one textual product-law conflict that must be corrected before adoption: generic `Succeeded | Failed` settlement proposals collapse distinct external facts. The synthesis is explicit that results are domain outcomes such as `Observed<OrderAccepted>`, `Observed<Filled>`, or `Observed<Rejected>`, plus `Unknown`. Candidate A and Candidate C model that boundary correctly.

Candidate A's “one Fly app, two process groups” is coherent Fly terminology, but it means two Machines in steady state. It therefore loses points under the rubric's **one-Machine** criterion even though it does not violate the one-Fly-app law. Candidate C uses one Machine but two supervised OS processes and two language toolchains. Candidate B also needs two supervised processes, but both are Node/TypeScript and the seam follows Eve's supported public contract rather than a second language or authority kernel.

## Weighted rubric

Scores use the required 1–5 scale. Weighted points are `weight × score / 5`.

| Criterion | Weight | A: hybrid | A points | B: TypeScript | B points | C: Rust-first | C points |
|---|---:|---:|---:|---:|---:|---:|---:|
| Preserves product and authority invariants | 20 | 5 | 20.0 | 4 | 16.0 | 5 | 20.0 |
| Module depth and reader load | 15 | 3 | 9.0 | 4 | 12.0 | 4 | 12.0 |
| Type, concurrency, and temporal correctness | 15 | 5 | 15.0 | 4 | 12.0 | 5 | 15.0 |
| Eve and Living World velocity | 12 | 4 | 9.6 | 5 | 12.0 | 2 | 4.8 |
| Dense observation fit | 10 | 4 | 8.0 | 4 | 8.0 | 4 | 8.0 |
| One-Machine operational simplicity | 10 | 2 | 4.0 | 4 | 8.0 | 3 | 6.0 |
| Journey verifiability and failure diagnosis | 8 | 5 | 8.0 | 5 | 8.0 | 5 | 8.0 |
| Ecosystem maturity and upgrade path | 5 | 4 | 4.0 | 5 | 5.0 | 3 | 3.0 |
| Cost of change and team comprehensibility | 5 | 2 | 2.0 | 5 | 5.0 | 2 | 2.0 |
| **Total** | **100** |  | **79.6** |  | **86.0** |  | **78.8** |

### 1. Preserves product and authority invariants — 20

**A: 5.** A has the most exact authority model: separate Case/View/Handle types, exact read sets, stable lock order, serializable AuthorityCommit, atomic receipt/effect/event/outbox writes, immutable-before-admit evidence, Cedar restricted to admission/disclosure, and honest Settlement facts. Its two-process topology does not move ownership across the seam.

**B: 4.** B gets the database and command topology substantially right: closed authority commands, realm-bearing keys, exact commit transactions, deterministic intents, outbox as wake-up only, and no Redis. It loses a point for the generic Settlement contradiction, underspecified authorization-policy split, and incomplete OAuth and evaluation credential boundaries. These are repairable within TypeScript.

**C: 5.** C expresses the product distinctions most forcefully in types and covers exact OAuth, realm, presence, read-set, effect, and Settlement boundaries. Its language split increases cost, not law risk.

### 2. Module depth and reader load — 15

**A: 3.** The Rust kernel is deep, but every Door/Eve/Ontology crossing pays an internal HTTP contract, dual schema/tooling, dual error model, and dual observability path. The reader must understand two runtimes to follow a request that is conceptually one product operation.

**B: 4.** Packages are divided by ownership and can be kept acyclic with dependency-cruiser. Most authority calls remain direct; Eve crosses one narrow generated loopback contract because its supported Nitro runtime is a separate process. It loses one point because “Zod everywhere,” generic policy IR, and the original combined-server assumption hide meaningful boundary differences that should be named.

**C: 4.** The Rust ownership kernel is cohesive and deeply typed, and the Node Door sidecar is deliberately narrow. It still imposes an RPC seam at authentication and requires two runtime models for every authenticated request.

### 3. Type, concurrency, and temporal correctness — 15

**A: 5.** Rust enums/newtypes, SQLx transactions, exact read-set comparison, and explicit external-observation types give the strongest combined static and database story.

**B: 4.** TypeScript discriminated unions plus PostgreSQL constraints and serializable commit logic are adequate. The missing point is not “TypeScript unsafety”; it is B's overclaim that one runtime schema mechanism covers fixed envelopes, released schemas, and canonical storage, plus the generic Settlement type. Both must be fixed at boundaries.

**C: 5.** Rust's realm-parameterized capabilities and observed-outcome types make illegal cross-realm and receipt/settlement states harder to construct. Database checks still remain the final concurrency authority, as they should.

### 4. Eve and Living World velocity — 12

**A: 4.** Eve remains TypeScript and therefore retains fast provider/channel iteration. The score is reduced by the internal kernel round trip and coordinated dual-language changes for new ontology verbs.

**B: 5.** One language, one source graph, shared fixed-envelope types, Hono/Better Auth/MCP composition, and one generated Eve capability client give the shortest path from a product idea to a journey-proved feature. The loopback hop is real but does not require a second language or semantic implementation.

**C: 2.** Most Living World work crosses Rust, Node, generated contracts, and sidecar lifecycle. Its safety case is strong, but no present product evidence justifies imposing that tax on the most exploratory surface.

### 5. Dense observation fit — 10

**A: 4.** Parquet and DataFusion are a natural pairing, and Arrow-native Rust leaves headroom. The missing point is workload proof: the proposed incremental Frame workload has not yet demonstrated that DataFusion beats the simpler embedded alternative.

**B: 4.** DuckDB's Parquet filter/projection pushdown and Node Neo client are a credible initial engine. The Node Neo API is Promise-based and lossless, but Arrow-result APIs and profiling remain less complete than the core engine. The manifest contract insulates the product from changing the engine later.

**C: 4.** DataFusion provides an excellent engine substrate, but it receives the same score as A because engine fitness still needs the representative benchmark. Language preference cannot substitute for workload evidence in either direction.

### 6. One-Machine operational simplicity — 10

**A: 2.** Two Fly process groups are separate Machines. A also needs two health surfaces, an authenticated internal network seam, coordinated deployment, and old-kernel draining.

**B: 4.** One signed image and one Machine contain a supervised Hono edge/authority process and Eve's supported Nitro process. The topology adds health, drain, proxy, and authenticated loopback obligations, but remains simpler than a second language or a second steady-state Machine.

**C: 3.** One Machine is possible, but two supervised processes, two runtimes, an RPC boundary, and coordinated health/deploy semantics are materially more complex than B.

### 7. Journey verifiability and failure diagnosis — 8

**A: 5. B: 5. C: 5.** All three specify real product journeys, failure injection, trace correlation, real PostgreSQL/object storage, and external-effect uncertainty without mocks. Each is capable of meeting the repository's journey-only rule. The final blueprint should take the strongest individual scenarios from all three.

### 8. Ecosystem maturity and upgrade path — 5

**A: 4.** Rust, SQLx, DataFusion, Cedar, Hono, Better Auth, and TypeScript are all serious ecosystems, but their coordinated upgrade surface is broad and some pinned versions are already stale.

**B: 5.** Node 24 LTS, TypeScript, Hono, Better Auth, MCP v2, Restate's TypeScript SDK, `pg`, Ajv, Zod, and DuckDB Node Neo are mature or vendor-primary paths. The TS 6/7 transition is manageable with the official compatibility compiler.

**C: 3.** Rust itself is mature, but the proposal relies on a comparatively young Rust MCP/Restate edge while retaining Node for Better Auth. That combines ecosystems instead of eliminating one.

### 9. Cost of change and team comprehensibility — 5

**A: 2.** A feature that changes authority inputs or outputs frequently changes Rust, TypeScript, the wire contract, and journeys together.

**B: 5.** The language preference receives its proper burden-of-proof advantage here: absent structural evidence requiring Rust, one language and one workspace are materially easier to change and teach.

**C: 2.** The sidecar is narrow, but the team still owns Rust, TypeScript, generated contracts, and cross-process debugging. The proposal does not show compensating current workload evidence.

## Adopted architecture

### Runtime and module topology

Ship one signed OCI image as one Fly app with one steady-state Machine and two supervised Node 24 LTS processes:

- the Hono edge/authority process listens publicly on `:8080`, exposes a loopback-only Eve capability endpoint on `127.0.0.1:8081`, and serves the signed Restate endpoint on `:9080`;
- the exact `eve@0.52.0` build runs through its supported `eve start` Nitro service on `127.0.0.1:4274`.

Hono is the only public socket. It proxies the complete `/eve/` and `/.well-known/workflow/` prefixes without rewriting paths or reconstructing request bodies. Eve reaches Ontology only through a generated `EveOntologyClient` carrying short-lived boot-, request-, audience-, principal-, purpose-, deadline-, basis-, operation-, and body-digest-bound proofs. Eve receives no Ontology database, object-store write, KMS release, or Restate credential.

The application remains a modular monolith, not a bag of routes. The Hono/Eve process boundary is explicit and typed. The dependency graph is enforced so Door cannot authorize, Eve cannot mutate authority tables, and adapters cannot bypass Ontology application ports. A useful package direction is:

```text
apps/server -> door, ontology-api, mcp, restate-endpoint, eve-capability-server
apps/conversation -> eve, eve-ontology-client, channel-state-postgres, fixed-contracts
eve-ontology-client -> eve-capability-protocol
eve-capability-server -> eve-capability-protocol, ontology-application
channel-state-postgres -> chat StateAdapter, pg
ontology-api/mcp/restate-endpoint -> ontology-application
ontology-application -> ontology-domain, storage-ports, dense-query-port
storage-postgres -> storage-ports
dense-duckdb -> dense-query-port
connectors -> connector-ports
```

Eve's generated Nitro output owns its Workflow routes, schedules, sessions, turns, and steps. Exact-pinned `@workflow/world-postgres@5.0.0-beta.40` receives a dedicated `eve_workflow` database and role. Its open parked-run/startup recovery defect is a production blocker until the pinned pair passes repeated crash, park, wake, restore, and upgrade journeys.

The Eve process receives a source-controlled capability allowlist, not the framework default. `disableTool()` removes `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, root `agent`, and `todo`; Zoen adds no `glob`, `grep`, `Workflow`, `sleep`, skills, or connections. `ask_question` remains alongside generated `inspect_*` and `propose_*` tools, and every authored tool states its approval policy explicitly. A custom disabled `SandboxBackend` is selected directly so `defaultBackend()` cannot choose an environment with permissive egress. Byte-backed attachments are rejected or normalized into authorized text/references before an Eve session can stage them.

Kapso and Resend bridge state lives in a separate `eve_channels` database. The Zoen-owned `ZoenChatStateAdapter` implements the exact public `chat@4.39.0` `StateAdapter` over raw `pg`; checked-in migrations own `kapso` and `email` schemas, and runtime roles have DML only. Exact-pinned `@chat-adapter/state-pg@4.39.0` is rejected because its connection path runs unqualified DDL and offers no schema or migration-free mode.

### DeepSeek/Cordis principles without a second lifecycle kernel

Eve already owns durable turns, steps, hooks, state, cancellation, tools, dynamic capabilities, and subagents. Adding Cordis at launch would create a second event and disposal lifecycle inside the replay boundary without supplying a missing product capability. Zoen therefore adopts the useful design principles—consumer-owned service contracts, explicitly named event modes, scoped cleanup, and attributable context—through Eve-native hooks and a plain typed `EveAttemptContext`.

`@deepseek-ai/cordis` remains EvaluationWorld-only. It may become an adapter only after three unrelated product needs demonstrate that Eve hooks plus plain TypeScript cannot express the required composition and the replay, cancellation, disposal, and journal ownership journeys remain unambiguous. It can never decide admission, disclosure, a World transition, or effect truth.

### Cedar and domain policy

Graft A's policy boundary exactly. Use the official `@cedar-policy/cedar-wasm` package for only:

- authority admission: may this principal invoke this released capability in this World and realm now?;
- disclosure: which fields, facts, consequences, tools, and explanations may this principal receive now?

Cedar must not implement quorum, materiality, preconditions, transition semantics, evidence admission, Watch advancement, Notice truth, Settlement interpretation, or domain consequences. Those belong to versioned release IR and Ontology domain code. Store Cedar policy text and schema in the release bundle, compile/validate at activation, and include the policy digest in exact read sets.

This removes B's bespoke general-purpose “policy IR.” A small domain expression language still exists, but it is not an authorization engine. The official Cedar WASM package is currently 4.12 ([package](https://www.npmjs.com/package/%40cedar-policy/cedar-wasm)).

### Hono rather than Fastify

Replace Candidate B's Fastify listener with Hono 4.

This is a boundary-coherence decision, not a throughput claim. Better Auth has a direct Hono integration, the MCP TypeScript SDK v2 publishes a Hono adapter, MCP handlers expose a web-standard `fetch` face, and Hono's request/response model fits SSE and future edge-compatible adapters without a Node-to-Fetch translation layer ([Better Auth example](https://hono.dev/examples/better-auth), [MCP Hono adapter](https://ts.sdk.modelcontextprotocol.io/v2/api/%40modelcontextprotocol/hono/), [MCP handler](https://ts.sdk.modelcontextprotocol.io/v2/api/%40modelcontextprotocol/server/server/createMcpHandler.html), [Hono streaming](https://hono.dev/docs/helpers/streaming)).

Do not reproduce Fastify's hidden coercion/default/removal behavior. Route adapters explicitly parse and validate; application services receive typed values. Fastify remains a credible server, but its native validation/serialization path is Ajv plus `fast-json-stringify`, so retaining it while claiming Zod is the single boundary system adds conceptual machinery rather than removing it ([Fastify validation](https://fastify.dev/docs/latest/Reference/Validation-and-Serialization/)).

### Zod and Ajv have different jobs

Use both, with a hard boundary:

- **Zod 4** parses fixed, code-owned envelopes: environment, route params, query values, channel ingress envelopes, CLI config, internal adapter results, and fixed metadata rows.
- **Ajv 8** validates dynamic, release-owned JSON Schema 2020-12 for capability inputs, outputs, evidence shapes, and connector configuration.
- compile released schemas only during signed release activation; cache by schema digest; enforce schema size, recursion, regex, and evaluation limits; never compile an unauthenticated request-provided schema;
- signed/canonical content uses the canonical JSON codec, not serializer shortcuts;
- do not generate authoritative release schemas from Zod. Zod-to-JSON-Schema conversion cannot faithfully represent `bigint`, `date`, transforms, maps/sets, and custom values ([Zod JSON Schema](https://zod.dev/json-schema)).

This is not duplication: fixed program boundaries and published user/domain schemas are different products with different lifecycles.

### Raw `pg`, not Kysely, for first-party authority storage

Use `pg` directly inside `storage-postgres`. An `AuthorityCommit` checks out one `PoolClient`, begins `SERIALIZABLE`, sets realm/principal transaction context, acquires stable-order locks, revalidates the exact read set, writes the transition/receipt/effects/events/outbox, and commits or returns a typed retry/stale result.

No query builder may own or conceal that transaction. SQL is colocated with row decoders and named by product operation. Projection reads may share small SQL fragments, but application packages cannot import `pg`.

Better Auth may use its official direct PostgreSQL adapter with a supplied `pg.Pool`; Better Auth internally uses Kysely, but that does not make Kysely a first-party persistence abstraction ([Better Auth PostgreSQL adapter](https://better-auth.com/docs/adapters/postgresql)). A's Kysely use is not grafted.

### Better Auth OAuth for browser, CLI, and MCP

Graft C's Door protocol detail, updated to the current Better Auth package split:

- browser Eve uses the Better Auth session cookie;
- CLI uses an OAuth 2.1 public client with device authorization as the default non-browser flow;
- authorization-code plus loopback redirect and PKCE is an allowed interactive fallback;
- MCP uses Better Auth's MCP OAuth provider/resource-server packages, resource indicators, JWKS validation, and DPoP where supported;
- access tokens are short-lived, audience/resource-bound, and scoped; refresh tokens live only in the OS secure credential store;
- a channel sender identity or delegated client proves channel presence, not current human identity or authority. Sensitive decisions require a fresh Door proof/step-up and principal-bound DecisionHandle;
- Door returns identity/session/token facts only. Ontology performs current membership, role, release, policy, and disclosure checks on every protected operation.

Better Auth documents OAuth 2.1 authorization-code/PKCE and device flows, and its MCP plugin documents resource-bound tokens, JWKS, DPoP, and RFC 9728 metadata ([OAuth provider](https://better-auth.com/docs/plugins/oauth-provider), [device authorization](https://better-auth.com/docs/plugins/device-authorization), [MCP plugin](https://better-auth.com/docs/plugins/mcp)). Pin the separate `@better-auth/oauth-provider`, `@better-auth/mcp`, and `@better-auth/cimd` packages rather than assuming they are bundled transitively.

### Settlement and effect execution

Replace B's settlement proposal with A/C's model:

```ts
type SettlementFact =
  | { kind: "observed"; outcome: ReleasedDomainOutcome; evidenceRef: EvidenceRef }
  | { kind: "unknown"; reason: UnknownReason; attemptRef: EffectAttemptRef };
```

There is no generic success or failure. `Observed<OrderAccepted>`, `Observed<Filled>`, and `Observed<Rejected>` are different released domain facts. A provider timeout or crash after a possibly accepted call is `Unknown`. Automatic retry is legal only when the pinned connector proves destination idempotency and reuses the same destination key; otherwise the next attempt reconciles. A later observation is admitted through a new serializable AuthorityCommit that atomically records evidence, Settlement, causal event, and outbox row. A DecisionReceipt never becomes a Settlement.

### Restate endpoint topology

Keep Restate strictly at the `ZoenEffect` boundary:

1. The authority transaction creates deterministic `EffectIntentId`s and an outbox wake-up row.
2. The outbox dispatcher invokes Restate with only the `EffectIntentId` and stable idempotency identity. The outbox payload is not domain truth.
3. A second `node:http` listener in the same Node process serves Restate's `createEndpointHandler` on port 9080. It is not a product API route.
4. Fly exposes that listener only through an infrastructure hostname/path protected by TLS and Restate request-identity keys. The handler must reject unsigned/unrecognized callers. Restate documents the endpoint handler, default port, and `identityKeys` verification ([serving](https://docs.restate.dev/develop/ts/serving), [security](https://docs.restate.dev/server/security)).
5. The handler reloads the immutable EffectIntent, release digest, realm, lease, and connector version; it cannot accept arbitrary caller-supplied connector payload or make a new World decision.
6. Restate Cloud uses its signed public-endpoint connection initially. A tunnel is a development/private-network option, not an unexplained production dependency ([connecting services](https://docs.restate.dev/cloud/connecting-services)).
7. Release/deployment automation registers the endpoint revision and proves reachability and signature verification before enabling dispatch.

Restate routes existing invocations to the deployment that accepted them, so old deployments normally must remain reachable while those invocations live ([service versioning](https://docs.restate.dev/services/versioning)). A one-Machine pre-launch deployment therefore has an explicit gate: drain active Restate invocations and retain all connector versions referenced by unsettled intents before replacing the Machine. If it cannot drain, a temporary blue/green second Machine remains until the prior revision has no invocations; one Machine remains the steady state, not an excuse to lose durable work. Reopen the topology before production if continuous rolling deploys with long-lived effects become a product requirement.

### Evaluation isolation

Graft C's stronger isolation and make it a release gate:

- evaluation uses a separate Neon project, not merely another schema or branch of live authority data;
- distinct database roles, object-store credentials/prefix, Restate environment/namespace, provider sandbox credentials, encryption material, and observability labels;
- `realm_kind` and `realm_id` remain in domain values, composite keys, RLS transaction context, manifest identity, relationship/source/channel leases, EffectIntent, and Settlement;
- evaluation processes receive no live provider secret or live object-store write credential;
- fixtures are synthetic or explicitly admitted redacted artifacts; no production restore is an evaluation shortcut;
- the complete journey must prove a forged/mismatched realm is rejected at API, SQL, dense-manifest, connector, and Restate boundaries.

The separate project is the credential boundary. Realm discriminants and RLS are defense in depth, not the only wall.

### Dense observations: format versus engine

The non-negotiable contract is:

- observations land immutable-before-admit in object storage;
- sparse authority metadata and manifest heads live in PostgreSQL;
- a manifest contains ordered immutable object references, schema/release/source/realm/World identities, row/time statistics, object hashes, and a canonical manifest digest;
- a Frame pins the exact manifest digest and object set used; queries never list a mutable prefix to discover truth;
- compaction publishes new objects plus a new manifest; old manifests remain readable while referenced;
- duplicate ingestion is content/idempotency addressed and cannot mutate published bytes.

Use DuckDB 1.5 Node Neo initially behind `ObservationQueryPort`. It can push filters and projections into Parquet scans ([DuckDB Parquet](https://duckdb.org/docs/current/data/parquet/overview)); the Node Neo client is DuckDB's primary Node client, while some Arrow and profiling APIs remain roadmap items ([client overview](https://duckdb.org/docs/stable/clients/overview), [Node Neo](https://duckdb.org/docs/lts/clients/node_neo/overview)). Query results cross the port as bounded batches/iterators of domain-decoded rows, never as DuckDB-native objects.

Do not claim that choosing Parquet chooses DuckDB, DataFusion, Arrow Flight, or Rust. It does not.

### Managed PostgreSQL

Choose **Neon PostgreSQL 18** for the initial managed authority database, with a minimum always-on compute setting appropriate to the latency SLO.

- use direct connections for migrations, serializable AuthorityCommit transactions, advisory locks, and `LISTEN`;
- an optional pooled endpoint is acceptable for Better Auth and short Hono-owned read projections after journey verification;
- use separate roles and schemas for Better Auth, Ontology authority, and read-only operations; Eve's Workflow store receives a separate database and role, while `eve_channels` receives separate migrator/DML-only provider roles; neither receives an Ontology credential;
- treat `NOTIFY` as a wake-up hint only; durable outbox rows remain truth;
- put release/evaluation authority in a separate Neon project, not a live branch;
- rehearse backup restore, PITR, connection exhaustion, failover, and region latency before activation.

Neon supports pooled and direct connection strings ([connection pooling](https://neon.com/docs/connect/connection-pooling)). Fly Managed Postgres is rejected for the initial choice because its current documentation advertises PostgreSQL 16 and says some security-patch/version-upgrade automation is still under development ([Fly Managed Postgres](https://fly.io/docs/mpg/)). Colocation alone does not outweigh the authority store's upgrade and isolation needs.

### Package manager, compiler, and build

Adopt B's deliberately boring build with exact corrections:

- pnpm 11 workspaces, one committed `pnpm-lock.yaml`, strict peers, workspace identity, cycle rejection, minimum package age, and an explicit lifecycle-script allowlist;
- `pnpm install --frozen-lockfile` in CI and image builds;
- TypeScript project references and `tsc --build` for packages;
- Vite only for the React client;
- no Nx, Turborepo, Bazel, server bundler, or generic internal RPC framework; the one generated Eve capability client is a closed product protocol;
- dependency-cruiser plus ESLint own import-graph locks; no import-graph tests;
- pin exact runtime dependencies in the lockfile and base-image digest;
- keep architecture documents on supported major/minor families; generate an evidence ledger from the lockfile instead of hand-maintaining patch-number claims.

Use the TypeScript 6 compatibility compiler while essential lint/build tools still need the compiler API, then move to TypeScript 7 when those tools support it. TypeScript 7 is now stable and intentionally does not expose the old compiler API; Microsoft's migration advice is to run TypeScript 6 as a sidecar/alias when tooling requires it ([TypeScript 7](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/), [TypeScript 6](https://devblogs.microsoft.com/typescript/announcing-typescript-6-0/)). Node 24 remains an LTS line ([Node releases](https://nodejs.org/en/about/previous-releases)).

## Exact graft list

### From Candidate A into B

1. Cedar for **admission and disclosure only**, with domain semantics kept out of Cedar.
2. Hono as the public HTTP composition surface.
3. `SettlementFact = Observed(ReleasedDomainOutcome) | Unknown`, destination-idempotency proof, and reconciliation-before-repeat.
4. The explicit EffectAttempt/Settlement evidence chain and versioned connector retention.
5. Engine-neutral Parquet-manifest contract plus comparative dense benchmark gates.
6. Neon PostgreSQL 18, direct-versus-pooled connection discipline, and `LISTEN/NOTIFY` treated only as wake-up.
7. Eve model attempts pinned to journal cut, released tool catalog, model profile/revision, and source references.
8. Stable lock order and exact read-set validation inside one serializable AuthorityCommit.

### From Candidate C into B

1. Better Auth OAuth 2.1 device flow for CLI, PKCE fallback, MCP resource-bound tokens, JWKS/DPoP validation, and OS-keychain refresh storage.
2. Channel presence is a delegated-client fact, never proof of the human principal; protected action requires Door step-up.
3. Evaluation's separate database/project, credentials, Restate namespace, object prefix, and lease isolation.
4. Realm-bearing values and composite database keys across World, relationship, source, channel, effect, and Settlement.
5. Read sets retain the actual sparse revisions, belief/policy digests, release digest, and dense manifest slices—not merely an unexplained aggregate digest.
6. Declarative release IR remains total and bounded; WASM is not admitted until the explicit expressiveness trigger fires.
7. The Rust candidate's journey cases for hidden-consequence refusal, wrong-realm rejection, CLI OAuth expiry/step-up, and unsafe effect timeout/reconciliation.

### Required judge corrections not supplied completely by either loser

1. Eve-native hooks and a plain typed `EveAttemptContext` implement scoped composition; Cordis is EvaluationWorld-only until three unrelated needs prove that insufficient.
2. Zod owns fixed code schemas; Ajv owns released dynamic JSON Schema.
3. Raw `pg` owns first-party persistence; Better Auth's internal Kysely use does not leak outward.
4. The Restate listener, identity validation, registration, and deployment-drain behavior are topology, not a footnote.
5. Eve runs through its supported Nitro build/start contract with an isolated production-gated Workflow Postgres store and a typed authenticated loopback capability client.
6. AI SDK 7 plus direct provider `LanguageModel` packages replace raw provider SDKs at Eve's model boundary; AI Gateway is separately gated.
7. Eve's tool and sandbox defaults are replaced by an explicit least-capability manifest; byte-backed attachments never reach session staging.
8. Chat SDK operational state uses a Zoen-owned raw-`pg` `StateAdapter`, a dedicated database, migrator-owned schemas, and DML-only provider roles; `@chat-adapter/state-pg` is not installed.
9. Patch versions live in a generated dependency evidence ledger, not architecture prose.

## Exact rejections

Reject the following from **Candidate A**:

- a Rust authority kernel now;
- generic internal repository/RPC access that gives Eve ambient Ontology authority; the narrow authenticated loopback capability protocol is required by Eve's supported runtime;
- two steady-state Fly Machines/process groups;
- SQLx as a second persistence stack;
- DataFusion as the default merely because the storage format is Parquet;
- Wasmtime or release-authored WASM now;
- Turborepo or other task orchestration without a measured build problem;
- Kysely as a first-party persistence abstraction;
- manually frozen patch versions such as Kysely 0.28, DataFusion 54.1, and rmcp 3.0.1.

Reject the following from **Candidate C**:

- a Rust-first server now;
- the Node Better Auth sidecar and generated auth RPC boundary;
- a second language runtime and broad generated auth RPC boundary; two Node processes are accepted only for Eve's supported Nitro contract;
- DataFusion as a language-selection premise;
- Rust MCP and Restate SDK maturity as a reason to move the entire authority plane;
- any assumption that stronger Rust types remove the need for PostgreSQL constraints, runtime release validation, or journeys.

Reject the following from **Candidate B as written**:

- Fastify for the initial public listener;
- “Zod is the one schema system”;
- generic `Succeeded | Failed` Settlement;
- a bespoke policy language that mixes authorization with domain policy;
- opaque bearer credentials for CLI/MCP without OAuth 2.1 resource/audience binding and secure refresh storage;
- evaluation isolation based only on rows, RLS, and prefixes in live infrastructure;
- Kysely adoption merely to reduce handwritten SQL;
- any public/product route that exposes the Restate handler;
- mutable object-prefix discovery as a dense query input;
- a release runtime capable of arbitrary JavaScript or WASM execution.

## Technology assertions: verified, stale, and unverified

The comparison was checked on 2026-09-04 against official project documentation and current package registries.

### Verified and current enough to decide

- Node 24 is an LTS line; Node 26 is current. Selecting Node 24 is conservative, not stale.
- TypeScript 7 is stable, but the lack of the old compiler API makes the TypeScript 6 compatibility compiler a reasonable temporary build-tool choice.
- Better Auth 1.7.x has official PostgreSQL, OAuth provider, device authorization, MCP, CIMD, DPoP/JWKS, and resource-indicator paths. The OAuth/MCP packages are now split and must be pinned explicitly.
- MCP TypeScript SDK v2 is stable and supplies official Node and Hono surfaces.
- Restate TypeScript SDK 1.17 and `createEndpointHandler` are current official paths.
- DuckDB 1.5.5 and the Node Neo client are current; Parquet pushdown is supported. Some Node Neo Arrow/profiling facilities remain documented as roadmap.
- Cedar WASM 4.12 is available from the official Cedar project.
- Hono 4.13, Fastify 5.12, Zod 4.5, Ajv 8.20, `pg` 8.23, Kysely 0.29, React 19.2, and Vite 8.2 were the current package lines observed during review.
- `@deepseek-ai/cordis` 4.0.2 exists and its documented context/service/event primitives match the proposed Eve-only use. Its relative youth still justifies an adapter and reopen gate.
- `eve@0.52.0` supports self-hosting through `eve build` and `eve start` as a generated Nitro service, requires both `/eve/` and `/.well-known/workflow/`, and peers on AI SDK 7 rather than the raw OpenAI or Anthropic client APIs.
- The pinned model stack is `ai@7.0.92`, `@ai-sdk/openai@4.0.58`, and `@ai-sdk/anthropic@4.0.49`; direct provider `LanguageModel` values cross `ModelPort`. AI Gateway remains a separately evaluated deployment profile.
- `@workflow/world-postgres@5.0.0-beta.40` is compatible with Eve's Workflow 5 beta line but is production-gated; the open startup-recovery report for parked runs must be disproved or fixed for the pinned pair.
- Eve's default surface includes sandbox shell/file tools and conditional app/provider tools; omitted authored-tool approval permits execution, omitted sandbox backend selects `defaultBackend()`, byte-backed files stage into the sandbox, default egress is allow-all, and the `just-bash` fallback has no network isolation. These are official extensibility defaults, not acceptable Zoen launch permissions.
- Exact `chat@4.39.0` exports `StateAdapter`. Exact `@chat-adapter/state-pg@4.39.0` runs unqualified table/index DDL during `connect()` and has no schema/migration switch, so it cannot satisfy DML-only provider roles or isolated provider schemas.

### Stale or misleading in the candidates

- Candidate A's Kysely 0.28 is behind the current 0.29 line.
- Candidate A's DataFusion 54.1 is behind the current 55 line.
- Candidates A and C cite rmcp 3.0.1; the current line observed was 3.2.
- Candidate C cites Restate Rust SDK 0.11; the current line observed was 0.12.
- Candidate A's Vite 8.1 and some React patch pins lag current patches.
- Candidate B's broad “Zod everywhere” description is not a version problem; it is a capability mismatch. Released JSON Schema needs an actual JSON Schema validator.
- Candidate B's Fastify design cannot truthfully describe Zod as Fastify's sole validation/serialization system without bypassing Fastify's native Ajv/serializer path.
- “One Fly app” does not imply one Machine when using separate process groups, as Candidate A's own deployment section correctly reveals.

### Assertions that remain evidence gates

- DuckDB versus DataFusion performance and memory on Zoen's real manifest/read-set workload is unverified.
- Whether Cordis supplies three independent capabilities beyond Eve-native hooks and plain typed contexts is unverified; it is not a launch dependency.
- Eve/Workflow Postgres crash recovery, parked-run wakeup, duplicate-job behavior, backup/restore, and pairwise upgrades are unverified production blockers.
- `ZoenChatStateAdapter` conformance, provider acknowledgement, crash/replay, database restore, and Chat SDK pairwise upgrade behavior are unverified production blockers for Kapso and Resend routes.
- Neon region-to-Fly p95/p99 latency, failover behavior, restore time, and connection-pressure behavior must be journey-measured.
- Restate Cloud public-endpoint reachability and signed-identity behavior through the selected Fly routing configuration must be proven before dispatch activation.
- No candidate demonstrates that released policy expressiveness requires WASM.
- No candidate demonstrates that Rust eliminates a measured correctness or performance failure in the TypeScript design.

## Reopen triggers

These are decision triggers, not speculative roadmap promises.

### Reopen Rust and/or DataFusion

Reopen the dense engine after compaction, statistics, projection/filter pushdown, and bounded concurrency are implemented if either:

- two representative high-priority Frame journeys over at least 100 million observations miss their agreed p95 latency or memory SLO under 32 concurrent reads; or
- DuckDB lacks a required operator that cannot be implemented behind `ObservationQueryPort` without native code.

Adopt a Rust/DataFusion sidecar only if the same canonical manifest corpus and result-digest journeys show **at least 50% lower p95 latency and 40% lower peak RSS** on two independent priority workloads, including restart and cancellation behavior. This reopens the query engine first, not the authority kernel.

Reopen a Rust authority kernel only after **three independent incidents or journey failures** attributable to states that Rust would make unrepresentable and that database/runtime boundary validation cannot reasonably prevent, or after profiling shows authority CPU is a material bottleneck and a Rust prototype gives a measured twofold gain. A single bug is not an architecture mandate.

### Reopen deployment isolation

Move the already separate Hono and Eve processes into separate Machines only when contractual isolation, availability, or independently sustained scaling justifies another deployment unit. Preserve the same proxy and authenticated capability protocol; a Machine split does not imply another product or language.

### Reopen Hono versus Fastify

Reconsider Fastify only if a representative API/SSE/MCP load journey shows Hono consumes at least twice the CPU or misses the public latency SLO after profiling, or if a required protocol feature exists as a maintained Fastify implementation but cannot be implemented safely on web-standard handlers. Plugin count alone is not a trigger.

### Reopen Zod/Ajv

Keep the two-validator boundary unless one can faithfully cover both fixed TypeScript-owned values and full released JSON Schema 2020-12 with canonical, bounded behavior. Convenience is not a reason to translate published schemas through a lossy representation.

### Reopen raw `pg` versus Kysely

Consider Kysely only for read-only projections after two quarters of evidence show repeated row/column mapping defects or materially excessive maintenance in handwritten projection SQL. It never owns AuthorityCommit, locking, RLS context, or migration SQL.

### Reopen Cordis

Evaluate Cordis only after three unrelated Eve composition needs cannot be expressed cleanly with Eve-native hooks and plain typed contexts. Adoption requires replay, cancellation, disposal, upgrade, and ownership journeys and an adapter whose types never cross an Ontology interface. It can never expand beyond Eve.

### Reopen declarative release IR and WASM

Consider a sandboxed executable extension only after three unrelated released capabilities require the same semantics that cannot be expressed in the bounded IR without unsafe special cases. The proposal must prove deterministic fuel/time/memory bounds, no ambient network/filesystem/clock/randomness, canonical I/O, signature binding, and replay equivalence before activation.

### Reopen managed PostgreSQL

Reconsider Fly Managed Postgres when it offers the required PostgreSQL major version plus demonstrated automated patching/upgrades, PITR/restore, HA/failover, and evaluation isolation, and a measured colocated latency advantage is material. Reconsider Neon immediately if Fly-to-Neon p95 transaction latency exceeds the AuthorityCommit budget, restore drills miss the recovery objective, or connection/failover journeys fail twice.

### Reopen Restate topology

Before the first production commitment, revisit the drain-on-deploy rule. If effects can remain in flight across normal continuous deployments, use revision-addressable endpoints with temporary old-revision capacity or a verified private tunnel topology. Never route durable invocations to a new handler version merely because the app hostname stayed stable.

### Reopen package/build tooling

Reconsider pnpm or add a task orchestrator only if clean CI install plus build exceeds five minutes on the standard runner for ten consecutive runs, lock/install storage exceeds two gigabytes, or redundant workspace work is shown by build traces to dominate CI time. Any replacement must preserve strict direct-dependency visibility, workspace identity, deterministic installs, and reviewed lifecycle scripts while making operations simpler—not merely faster.

### Activation blockers

Regardless of technology choice, activation stops if any journey can:

- cross production/evaluation realms;
- use channel presence as proof of current human authority;
- disclose hidden consequences through a Case/View/Handle mismatch;
- commit against a stale exact read set;
- produce a receipt without its deterministic effects/events/outbox in the same transaction;
- treat timeout as success or blindly repeat a non-idempotent external call;
- query dense truth by mutable prefix instead of pinned manifest;
- reach a Restate endpoint without verified request identity;
- let Eve, Door, or any adapter/composition runtime mutate Ontology authority directly;
- expose an unapproved Eve default/optional tool, omit an authored-tool approval declaration, call `ctx.getSandbox()`, select `defaultBackend()`, stage a byte-backed attachment, or declare a launch skill/connection;
- run channel DDL under a provider role, install `@chat-adapter/state-pg`, share `eve_channels` with Workflow/Door/Ontology, or acknowledge ingress before the durable channel transaction;
- expose either Eve Nitro or the `:8081` capability endpoint publicly, omit either required proxied prefix, or enable production conversation before Workflow Postgres recovery evidence passes.

## Final ruling

Candidate B wins because a corrected TypeScript modular monolith preserves every required authority boundary with the least operational and cognitive surface. Candidate A is the best source of transaction, authorization, settlement, and engine-gate rigor. Candidate C is the best source of OAuth, realm, evaluation, and cross-channel identity rigor. Those strengths should be grafted into B without importing either Rust topology.

The blueprint should therefore say, unambiguously:

> One TypeScript deployable and one steady-state Fly Machine; a supervised Hono edge/authority process plus Eve's supported Nitro process; authenticated typed loopback capability calls; isolated production-gated Eve Workflow Postgres; a locked-down Eve tool/attachment/sandbox profile; Zoen-owned raw-`pg` channel state in a separate database; Eve-native attempt composition; Better Auth as identity-only Door; Cedar only for admission/disclosure; released domain IR for meaning; raw `pg` for authority; Zod for fixed envelopes; Ajv for released JSON Schema; DuckDB behind an engine-neutral port; Parquet plus immutable manifests as durable dense truth; Restate only for Effect execution; separate evaluation infrastructure; and journeys as the only tests.

That is a structural decision. Rust remains a measured escape hatch, not an architectural aspiration.
