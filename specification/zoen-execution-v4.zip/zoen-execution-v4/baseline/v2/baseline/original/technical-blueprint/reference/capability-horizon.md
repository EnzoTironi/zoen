# Capability horizon

## Purpose

This reference sets the capability horizon for Zoen. The first release may be small. The design must survive an attempt to map every major public Palantir and Bloomberg capability to a concrete owner and target protocol.

The phrase "parity of possibility" is too easy to overread. In this reference, it means only that the audit found no known constitutional blocker after the named target protocols are added. It does not mean shipped software, equivalent product depth, production proof, data rights, operations, customers, or scale. Palantir and Bloomberg are mature proprietary platforms. Zoen is a pre-launch design.

The comparison uses five evidence labels:

- **Verified** means that a first-party public source or an accepted Zoen architecture document supports the statement.
- **Zoen Target** means that the constitution requires or permits the capability. It is not a delivery claim.
- **Inference** means that the conclusion follows from verified facts, but no source publishes it as a contract.
- **Unknown** means that public evidence does not expose enough detail to compare the behavior.
- **Vendor claim** means that the vendor publishes the statement, but this reference has not independently tested it.

All external sources were checked on 2026-09-04. Public product descriptions can change. Proprietary internals remain unknown.

Evidence labels and delivery classes answer different questions. The labels above say how a statement is supported. The delivery classes below say what Zoen has earned:

- **Shipped foundation** requires running code and a named end-to-end journey against the release candidate. This greenfield audit assigns no competitive category to that class.
- **Target protocol** has a named contract, owner, authority boundary, failure model, and proof gate. It is still a design.
- **Unproven product** fits the constitution but lacks evidence for usability, latency, scale, reliability, or market fit.
- **Moat** depends on data rights, content, counterparties, network access, support, or accumulated operational knowledge. A schema cannot create it.

[Ambition audit](ambition-audit.md) records the falsification result and the twelve gaps that set the ambition floor.

## Horizon rule

Zoen keeps maximum ambition under one restriction: code, a model, a notebook, a mini-app, or an operator cannot become authority by possessing runtime access. Executable extensions may calculate, render, simulate, gather evidence, and draft governed work. A released Action, current authorization, and the authority commit protocol remain the only path to a World change.

The audit found no need to relax that rule. The result remains unproven until live feeds, connectors, functions, pipelines, cells, and packages pass hostile journeys.

## Palantir capability map

| Palantir category | Public product contract | Zoen target protocol | Delivery class |
|---|---|---|---|
| Ontology | **Verified.** Palantir joins objects, properties, links, interfaces, Actions, functions, security, analytics, SDKs, and applications. [The Ontology system](https://www.palantir.com/docs/foundry/architecture-center/ontology-system) | **Zoen Target.** `WorldRelease`, `WorldHead`, `WorldFrame`, typed identities, evidence, relations, Actions, Watches, policy, and presentation. | Target protocol. Model tooling, indexing, migration, scale, and usability are unproven. |
| Interfaces, object sets, functions, and subscriptions | **Verified.** Palantir exposes typed interfaces, object-set queries, server functions, and real-time object-set subscriptions through OSDK and WebSockets. [Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview), [Functions](https://www.palantir.com/docs/foundry/functions/overview), [OSDK subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions) | **Zoen Target.** Released interfaces, `ObjectSetPlan`, typed `FunctionDefinition`, and basis-bound object subscriptions share one generated catalog. | Target protocol. Query breadth, function operations, and subscription behavior are unproven. |
| Actions | **Verified.** Action types support parameterized changes, validation, permissions, function-backed behavior, side effects, logging, and use across applications. [Action types](https://www.palantir.com/docs/foundry/action-types/overview) | **Zoen Target.** A released Action uses `ActionCase`, authorized views, `DecisionReceipt`, `EffectIntent`, and `Settlement`. | Target protocol. The governance model is more explicit in places, but no evidence shows that it is better or complete. |
| Data Connection | **Verified.** Data Connection covers batch, incremental, CDC, media, streaming, and virtual-table sources, credentials, versioned dataset transactions, and outbound writeback. [Connecting to data](https://www.palantir.com/docs/foundry/data-integration/connecting-to-data), [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview) | **Zoen Target.** `ConnectorArtifact`, `ConnectorLease`, and `ConnectorRun` feed `DatasetVersion` and governed evidence admission. | Target protocol. Connector catalog, source operations, monitoring, and writeback are unproven. |
| Pipelines | **Verified.** Pipeline Builder supports typed graph transforms, schema and output checks, batch and streaming execution, Spark, Flink, DataFusion, and external pushdown. [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview) | **Zoen Target.** `DataFlowDefinition`, `DataFlowRun`, `QualityGateResult`, `LineageEdge`, and isolated executors. | Target protocol. The builder, optimizer, scheduler, compute fleet, and operations are unproven. |
| Time series and streaming | **Verified.** Palantir keeps time-series object metadata separate from dataset-backed or stream-backed indexes and documents continuously running streaming pipelines. [Time series](https://www.palantir.com/docs/foundry/time-series/time-series-overview), [streaming pipelines](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview) | **Zoen Target.** The live observation plane handles ordered hot updates. Immutable Parquet manifests keep sealed history. | Target protocol. Throughput, fan-out, recovery, and latency are unproven. |
| Functions, notebooks, and compute | **Verified.** Functions provide typed Ontology logic. Compute Modules run scalable containers for functions, models, and data integration. Code Workspaces provide JupyterLab and RStudio. [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview), [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview) | **Zoen Target.** `FunctionDefinition`, `AnalyticsPlan`, `NotebookArtifact`, `ExecutorArtifact`, `DatasetGrant`, and `AnalysisRun`. | Target protocol. General compute, notebooks, GPUs, model training, and distributed execution are unproven. |
| Workshop, Pilot, and AIP | **Verified.** Palantir ships application building, generated OSDK applications, agents, model access, workflows, evaluations, and governed tools. Some features, including Pilot, carry beta labels. [Workshop](https://www.palantir.com/docs/foundry/workshop/overview), [Pilot](https://www.palantir.com/docs/foundry/pilot/overview), [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features) | **Zoen Target.** Living World, `WorkspaceDocument`, `MiniAppArtifact`, `ModelProfile`, `RetrievalPlan`, `AgentDefinition`, `AgentRun`, and `EvaluationWorld`. | Target protocol. The entire builder, agent, evaluation, and workspace product is unproven. |
| Branching and proposals | **Verified.** Palantir provides Ontology branches, proposal review, conflicts, rebase, and merge workflows. [Branching the Ontology](https://www.palantir.com/docs/foundry/ontologies/branching-ontology/) | **Zoen Target.** Immutable `ReleaseProposal`, isolated `EvaluationWorld`, `ReleaseProof`, preparation, and one authorized compare-and-swap activation. | Target protocol. Collaborative branch tooling is unproven. |
| Developer platform | **Verified.** Palantir combines APIs, multi-language OSDK, IDEs, MCP for builders and consumers, custom endpoints, code workspaces, and compute modules. [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview) | **Zoen Target.** `SurfaceManifest` generates API, CLI, MCP, browser, and SDK contracts with local realms, trace inspection, and conformance journeys. | Target protocol. A TypeScript generator alone is not developer-platform parity. |
| Marketplace | **Verified.** Marketplace packages versioned products with mapped inputs and outputs, installation, upgrades, and recall. Foundry products add cross-enrollment portability and Apollo management. [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/), [Foundry products](https://www.palantir.com/docs/foundry/marketplace/foundry-products) | **Zoen Target.** `PackArtifact`, `PackDependency`, `PackInstallationPlan`, and `PackInstallationReceipt` install signed release content and executable artifacts through review. | Target protocol. Catalog, distribution, trust, commercial terms, and adoption are unproven. |
| Apollo, cells, and edge | **Verified.** Apollo manages products across cloud, on-premises, air-gapped, edge, connected, intermittent, and disconnected environments. Palantir also documents offline embedded Ontology applications. [Apollo environments](https://www.palantir.com/docs/apollo/core/environments), [offline embedded Ontology](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application) | **Zoen Target.** `DeploymentProfile`, cell bundles, releases and attestations, epoch-bound authority leases, disconnected-operation policy, federation agreements, and basis-explicit federated Frames. | Target protocol. Fleet management, offline behavior, regulated delivery, and edge operations are unproven. Palantir's experience is a Moat. |

## Bloomberg capability map

Bloomberg's product advantage is not one technical feature. It joins licensed data, stable identity, news, analytics, execution, communication, entitlements, and a professional network in one daily workspace.

| Bloomberg category | Public product contract | Zoen target protocol | Delivery class |
|---|---|---|---|
| Terminal workspace | **Verified.** Terminal combines live and historical market data, news, research, charts, alerts, communication, portfolio analysis, and execution. [Bloomberg Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/) | **Zoen Target.** Living World uses `WorkspaceDocument`, `ChartDocument`, dense tables, Watches, Notices, Actions, analysis artifacts, and mini-apps. Eve handles conversation and attention. | Target protocol. Command depth, information density, latency, content, support, and professional habit are unproven. |
| B-PIPE live data | **Verified.** B-PIPE delivers normalized, unconflated real-time data and market depth through installed, cloud, and API options. Bloomberg describes centralized entitlement controls. [Real-Time Market Data Feed](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/) | **Zoen Target.** `LiveFeedDefinition`, `LiveSubscription`, `LiveObservationEnvelope`, `LiveObservationBasis`, and `CapturedObservationRef`, with periodically sealed Parquet history. | Target protocol. Feed content, exchange rights, latency, normalization, and reliability are Moats. |
| BLPAPI | **Verified.** BLPAPI exposes typed service schemas, requests, responses, subscriptions, correlation identifiers, asynchronous events, and authorized identities. [BLPAPI](https://bloomberg.github.io/blpapi-docs/), [`Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html) | **Zoen Target.** `ConnectorArtifact` preserves provider schemas, correlation, event ordering, entitlement snapshots, retries, and raw evidence. | Target protocol. Provider access and certification are unproven. |
| Entitlements and usage rights | **Verified.** Bloomberg describes user, group, application, publishing-service, source, and market-depth entitlements. BLPAPI authorization binds an identity to service entitlements. [B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/), [BLPAPI `Identity`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.3/classBloombergLP_1_1blpapi_1_1Identity.html) | **Zoen Target.** `DataUsageContract`, grants and snapshots, direct and derived rights decisions, obligations, and receipts govern discovery, display, derivation, export, and live subscriptions. | Target protocol. Contractual rights and provider agreements are Moats. |
| Event-Driven Feeds | **Verified.** Bloomberg delivers structured machine-readable news, news analytics, economic indicators, corporate events, and corporate actions for automated applications. [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/) | **Zoen Target.** Source event schemas, corrections, event and retrieval clocks, identity resolution, rights, `LineageEdge`, Watches, and evidence admission. | Target protocol. News production, exclusive sources, and low-latency delivery are Moats. |
| Data and reference identity | **Verified.** Data License and Data License Plus provide reference, pricing, risk, estimates, history, a managed model, and source-file traceability. Bloomberg reference products and FIGI connect instruments, venues, entities, and fields. [Data License](https://professional.bloomberg.com/products/data/data-license/), [Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/), [Reference Data](https://professional.bloomberg.com/products/data/enterprise-catalog/reference/) | **Zoen Target.** `PackArtifact` and data contracts bind provider identities, mappings, rights, quality, lineage, sparse admissions, and dense manifests. | Target protocol. The corpus, field definitions, identity operations, corrections, and commercial distribution are Moats. |
| BQuant and ASKB | **Verified.** BQuant offers entitled data, notebooks, managed compute, scheduled work, and published applications. ASKB offers cited conversational research and exposes BQL in some results. [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/), [AI on Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/ai) | **Zoen Target.** `AnalyticsPlan`, `NotebookArtifact`, `ExecutorArtifact`, `AnalysisRun`, `ModelProfile`, `RetrievalPlan`, and `AgentRun` can publish results into the workspace or Eve. | Target protocol. Finance coverage, compute operations, research quality, and product workflow are unproven. |
| EMS | **Verified.** Bloomberg documents multi-asset execution, automation, broker and venue connectivity, live analytics, auditable workflows, and integration with OMS and post-trade tools. [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/) | **Zoen Target.** Released order lifecycle types use an `ActionCase`, exact live snapshots, effect connectors, immutable execution events, reconciliation, and honest Settlements. | Target protocol. Liquidity, venue access, certification, low latency, and support are Moats. |
| OMS | **Verified.** AIM and TOMS cover portfolio, order, inventory, risk, allocation, compliance, middle-office, and post-trade workflows. [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/), [TOMS](https://professional.bloomberg.com/products/trading/order-management-system/toms/) | **Zoen Target.** Released portfolio and order semantics, long-lived workflows, allocations, reconciled provider events, rights, and domain projections. | Target protocol. Product breadth and operational evidence are unproven. |
| News and professional network | **Verified.** Bloomberg integrates reporting and external sources with market workflows. Instant Bloomberg provides persistent rooms, structured financial context, surveillance, chatbots, and workflow integration. [Bloomberg News](https://professional.bloomberg.com/products/bloomberg-terminal/news/), [Instant Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/instant-bloomberg/) | **Zoen Target.** Evidence packs, Eve relationships, shared packs, cross-organization Cases, and federation agreements can carry governed collaboration. | Target protocol. A newsroom, publisher contracts, counterparties, and an installed professional network are Moats. |

## Target extension contracts

The following names are recommended horizon contracts. They are not claims about current schemas.

| Target contract | Required meaning | Authority boundary |
|---|---|---|
| `LiveFeedDefinition`, `LiveSubscription`, `LiveObservationEnvelope`, `LiveObservationBasis`, and `CapturedObservationRef` | A released feed contract, a short-lived purpose-bound subscription, an ordered transient update, the exact source and sequence basis of displayed updates, and a content-addressed capture for consequential use. | The live feed is not authority. Rights are checked before and during delivery. An Action admits and pins the verified capture. Sealed history enters immutable manifests. |
| `ConnectorArtifact`, `ConnectorLease`, and `ConnectorRun` | A signed isolated source, effect, or channel connector. The contracts also define a narrow credential and egress lease and an immutable execution record. | A connector emits observations, evidence proposals, provider outcomes, or channel events. It cannot call `AuthorityCommit`, grant access, activate a release, or create a `Settlement`. |
| `DatasetVersion`, `DataFlowDefinition`, `DataFlowRun`, `QualityGateResult`, and `LineageEdge` | Immutable input and output versions, a typed batch or stream graph, one execution with checkpoints, explicit quality results, and field or range lineage. | A flow computes proposed data products. Only passed gates and a governed admission can advance a World or a released dataset reference. |
| `DataUsageContract`, `EntitlementGrant`, `EntitlementSnapshot`, `RightsDecision`, `DerivedRightsDecision`, `UsageObligation`, and `UsageReceipt` | Source terms, current grants, point-in-time entitlement evidence, direct and derived rights, required duties, and proof that duties ran. | Rights filtering occurs before discovery and follows data through display, cache, derivation, citation, export, and live delivery. A pack cannot expand a grant. |
| `DeploymentProfile`, `CellBundle`, `CellRelease`, `CellAttestation`, and `AuthorityCellLease{epoch}` | The declared environment, content-addressed deployment inputs, installed release, measured state, and one epoch-bound authority owner. | Only the current cell lease can commit for a World. An expired or superseded epoch cannot write. |
| `DisconnectedOperationPolicy`, `FederatedSyncAgreement`, `WorldSetBasis`, and `FederatedFrame` | Bounded offline operations, explicit cross-World exchange, per-World read bases, and a composite result that preserves partial failure. | Offline work cannot mint unbounded authority. Federation never hides each World's release, cut, rights decision, or receipt. |
| `PackArtifact`, `PackDependency`, `PackInstallationPlan`, and `PackInstallationReceipt` | A signed package of released semantics, data contracts, workflows, agents, connectors, executors, or mini-apps. The contracts include its exact dependency graph, a reviewed plan, and the result. | Installation is a release change. A pack cannot install hidden permissions, mutable dependencies, ambient credentials, or direct database access. |
| `DataPackArtifact` | An immutable, signed bundle of source contracts, semantic mappings, rights, schemas, provider identities, quality rules, and optional manifest roots. | Installation is a governed release proposal. A pack supplies evidence and capabilities, never membership or permission. |
| Released interfaces, `ObjectSetPlan`, `FunctionDefinition`, and object subscriptions | Typed polymorphic objects, bounded set algebra, reusable typed logic, and authorized change delivery. | Functions return values, derived artifacts, or Action proposals. Subscriptions carry an explicit basis and can be revoked or forced to resync. Neither path adds a direct write. |
| `AnalyticsPlan` | A typed, bounded, explainable plan for filters, joins, windows, aggregates, scenario inputs, and outputs. | The release interpreter validates the plan. Results are derived artifacts until an Action admits them. |
| `NotebookArtifact` | Immutable notebook source plus environment, dependency, input-contract, and output-contract digests. | A notebook runs only through an approved `ExecutorArtifact`. It receives scoped data handles, not authority credentials. |
| `ExecutorArtifact` | A signed executable compute artifact with declared runtime, schemas, capabilities, resource limits, egress, determinism class, provenance, and evaluation evidence. | It can emit immutable outputs and proposals. It cannot call `AuthorityCommit`, receive production database credentials, mint grants, activate releases, or deliver external Effects. |
| `MiniAppArtifact` | A signed browser application with a release and `SurfaceManifest` dependency, generated SDK version, declared routes, content policy, requested capabilities, and an MCP Apps-compatible `ui://` resource. | Eve is the first-party host and independent conforming hosts may render it. It acts as the current principal only through short-lived host-mediated capabilities. It cannot access the database, provider secrets, or an internal Ontology port. Writes use released Actions. |
| `WorkspaceDocument`, `ChartDocument`, `ChartRendererPort`, and `RepresentationProof` | A saved professional workspace, renderer-neutral chart intent, an explicit renderer boundary, and evidence that the representation preserves basis, rights, units, warnings, and accessibility. | A chart or workspace reads through authorized Frames and queries. Interaction invokes released Actions. Display state is not authority. |
| `WorkflowDefinition` | A closed-IR state machine with stages, waits, deadlines, principals, transitions, compensation choices, and referenced Actions or Effects. | Authoritative transitions use `AuthorityCommit`. Operational bookkeeping uses the allowlisted `ProgressCommit`. External I/O uses `EffectIntent`. |
| `WorkflowInstance` | A durable instance pinned to World, release, current head and cut, stage, deadlines, inputs, decisions, and Effect or Settlement references. | PostgreSQL owns durable state. A scheduler may wake work but cannot invent a transition. |
| `AgentDefinition` | A released selection of tools, model profiles, budgets, context rules, output contracts, and required evaluations. | An agent carries no standing World authority. Each use obtains a fresh purpose-bound session. Consequential output becomes an Action or proposal. |
| `ModelProfile` and `RetrievalPlan` | Released model selection, provider limits, data policy, context construction, search methods, citations, budgets, and fallback behavior. | A model or retrieval result is computation evidence. It cannot convert an assertion into a World fact or bypass current disclosure. |
| `AgentRun` | An immutable run record with settled context, model identity, tool calls, citations, outputs, cost, timing, and status. | The run is evidence about computation. It is not an authority receipt. |
| `EvalSuite` and `EvalResult` | Versioned journeys, replay cases, policy cases, model criteria, budgets, failures, and artifact digests. | Proof-producing evaluation runs in an isolated realm with no live credentials. Activation policy may require named results. |
| `ReleaseProposal` and `EvaluationWorld` | An immutable base, change set, review history, conflicts, artifacts, and isolated active evaluation World. | A proposal cannot write the production head. Merge is a proved, prepared, authorized activation. |
| `SurfaceManifest` and generated SDKs | A language-neutral catalog of stable reads, Actions, Watches, schemas, errors, and authorization requirements. | SDKs are clients. They cannot expose an operation absent from the active released catalog. |
| `CellDirectory` | A signed mapping from World identity to its authority cell, region, protocol version, and migration state. | Routing completes before `WorldSession`. No Action transaction spans cells. |
| `FederationAgreement` | A governed contract for shared identities, pack rights, disclosure, receipt verification, revocation, and cross-organization Cases. | Each World keeps its own authority. Federation exchanges signed facts, requests, and receipts rather than sharing a database role. |

## Programmable analytics and notebooks

Programmability does not require code inside `WorldRelease`.

The target flow is:

```text
WorldSession
    -> purpose-scoped DatasetGrant
    -> immutable Parquet manifest roots and sparse Frame inputs
    -> NotebookArtifact or AnalyticsPlan
    -> sandboxed ExecutorArtifact
    -> AnalysisRun and immutable result artifacts
    -> evidence proposal, Scenario, Action draft, ReleaseProposal, or MiniAppArtifact
    -> normal proof and authority path if a World change is requested
```

`DatasetGrant` names exact semantic fields, rows or subjects, time bounds, manifest roots, rights, purpose, expiry, and output restrictions. The executor receives a brokered read capability or bounded copy. It never receives object-store master credentials.

An `AnalysisRun` records exact code, environment, release, sparse dependencies, dense manifest roots, query plans, parameters, outputs, warnings, and resource use. A result can be useful without becoming truth. If the result must affect the World, evidence admission or a released Action makes that decision explicit.

Python, R, SQL, native libraries, GPUs, and distributed query engines can run in executor pools outside the TypeScript authority process. Their language does not change the canonical release protocol. DuckDB remains the first dense query adapter, not the limit of the analytics system.

## Executable governed mini-apps

`MiniAppArtifact` and `ExecutorArtifact` must remain different artifact kinds.

### `ExecutorArtifact`

An executor performs server-side or batch computation. Its risk comes from code execution, dependencies, data exfiltration, resource use, nondeterminism, and egress. It therefore runs in a separate sandbox or compute cell with an explicit capability broker. OCI images support broad Python, R, native, and GPU workloads. A future WebAssembly Component profile may support smaller deterministic functions when the ADR 010 reopen gate is met.

Required metadata includes:

- artifact, source, builder, base-image, dependency-lock, and SBOM digests.
- input and output schemas.
- allowed data classes, rights, purposes, and retention.
- CPU, memory, disk, wall-time, output-size, and cost limits.
- egress destinations, DNS policy, and secret-lease classes.
- determinism and replay classification.
- signer, evaluation evidence, revocation, and expiry.

The executor may return `DerivedArtifact`, `EvidenceAdmissionProposal`, `Scenario`, `ActionDraft`, or `ReleaseProposal`. It cannot return a `DecisionReceipt` or `Settlement`. Only Ontology can issue those records after the required authority path.

### `MiniAppArtifact`

A mini-app renders and collects interaction in the browser. Its risk comes from script supply chains, cross-site scripting, confused-deputy behavior, OAuth misuse, and misleading presentation. It therefore runs on a separate origin or sandboxed frame with a strict content policy. Its portable delivery surface follows MCP Apps: content-addressed `ui://` resource, declared app-visible tools, host-mediated calls and structured/text fallback. Eve hosts it first-party. Rivet may generate, build or run it without becoming the protocol. It receives a generated SDK and short-lived user-bound tokens for declared public capabilities.

Required metadata includes:

- bundle, dependency-lock, builder, and source digests.
- compatible release and `SurfaceManifest` ranges.
- requested reads, Actions, Watches, and notification capabilities.
- routes, presentation labels, accessibility evidence, and localization.
- origin, content policy, network destinations, storage limits, and token audience.
- signer, review state, evaluation evidence, revocation, and expiry.

A mini-app can call an executor through a released query or Action. It cannot contain an executor credential. It cannot claim that a local UI event changed a World. It displays the resulting Frame, Case, receipt, or Settlement from Ontology.

Keeping the artifact kinds separate avoids making uploaded code published meaning. It does not prove that an app or analytics ecosystem will form.

## Long-lived workflows

Restate remains restricted to `ZoenEffect`. That restriction does not remove long-lived workflows.

`WorkflowDefinition` extends the closed release IR with finite, typed workflow nodes. `WorkflowInstance` stores each durable stage, wait condition, deadline, principal requirement, input, decision, and output. PostgreSQL leases wake ready instances. Watches wake instances on material World changes. Eve wakeups handle relationship attention. External calls leave the authority transaction as `EffectIntent` and use Restate for delivery and recovery.

The state has three owners:

- Ontology owns semantic stages, Cases, Actions, deadlines that change meaning, receipts, and Settlements.
- Eve owns interaction progress, conversation continuity, human attention, and delivery presentation.
- The scheduler owns leases and wake hints only. It never owns the workflow's truth.

The target state machine has no duration limit in its contract, but long-lived recovery remains unproven. A future scheduler or orchestration adapter must replay the same `WorkflowInstance` protocol and cannot become a second state authority.

## Agents and evaluations

Agents are released users of governed capabilities, not privileged application code.

An `AgentDefinition` can choose models, instructions, tools, retrieval plans, workflow templates, budgets, and required evals. The release compiler checks every tool against the surface catalog and every consequential tool against an Action. Eve records each model attempt and `AgentRun`. Ontology records only the evidence, Action, Case, receipt, Effect, and Settlement records that cross its boundary.

`EvalSuite` covers deterministic replay, policy, denial, tool selection, citation, budget, regression, provider, channel, and domain-outcome cases. Proof-producing evals run the exact candidate image and artifact digests in an `EvaluationWorld`. An eval cannot use a live World branch, live provider credential, or production object-store prefix.

An agent may draft a release, workflow, data pack, executor, notebook, or mini-app. It may run evaluations and prepare review material. It cannot approve its own grant, activate live meaning, or convert a model assertion into a fact without the released evidence path.

## Branching and proposals

Zoen branches meaning, not mutable database state.

A `ReleaseProposal` pins the parent release and complete base head. Its change set and artifacts are immutable. A new edit produces a new proposal digest. An `EvaluationWorld` installs that proposal in an isolated evaluation realm and records proof against exact data, image, evaluator, executor, mini-app, and journey digests.

Review can compare semantic IDs, schemas, policy decisions, disclosed capabilities, migrations, replay results, resource budgets, rights, and user-visible presentation. Rebase reruns the compiler and required evidence against a later parent. Merge creates no hidden dual-read period. It produces a prepared activation and one authorized compare-and-swap over the live `WorldHead`.

Collaborative editing, comments, dependency graphs, proposal queues, and visual diffs are product work. The immutable proposal contract leaves room for them without treating a Neon database branch as released meaning.

## Data packs

A data pack is more than a connector and more than a set of Parquet files. `DataPackArtifact` joins:

- stable provider, dataset, field, subject, instrument, venue, and legal-entity identities.
- source acquisition and revision contracts.
- sparse and dense schemas and deterministic mappings.
- valid, assertion, retrieval, and ingestion times.
- evidence, lineage, quality, rival-source, and correction rules.
- license, entitlement, disclosure, output, and retention restrictions.
- handler, writer, query, and manifest protocol versions.
- journeys, replay fixtures, provider sandbox evidence, and operational limits.

Dense data remains immutable Parquet selected by hash-addressed manifests. Compaction publishes a new manifest. Query engines may change. Sparse semantic admissions and manifest roots enter the World through the same evidence and release rules.

Finance, health, household, clinic, factory, and other packs can share this artifact form. A pack may be commercial, private, or open. No pack may introduce a parallel identity, permission, or write system.

## Hot observations and sealed history

Immutable Parquet manifests are the historical publication contract. They are not an unconflated live-feed protocol.

`LiveFeedDefinition` publishes source schemas, keying, ordering, gap, correction, clock, staleness, rights, and sealing rules. `LiveSubscription` binds a principal, workload, purpose, World, release, fields, subjects or instruments, entitlement snapshot, output budget, and expiry. The service checks rights when it opens the subscription and while it remains active.

Every delivered update carries `LiveObservationBasis`: provider and source, connection and sequence interval, event and receive clocks, normalization and connector versions, entitlement revision, gap state, and the latest sealed manifest. Backpressure or a gap produces an explicit status and resync path. The service does not pretend that a lossy update stream is a complete ledger.

The writer seals immutable segments into Parquet and publishes new manifests. A normal authority admission records each governed synchronization slice. It does not create an `AuthorityCommit` for each market-data cell.

If an Action depends on the live feed, `CapturedObservationRef` identifies the verified immutable capture of the exact quote, order book, or provider state. The Action admits and pins that reference, then states the accepted staleness, market state, and revalidation rule.

## Connectors and data flows

`ConnectorArtifact` is the installable integration unit. Each artifact declares exactly one source, effect, or channel profile. It includes schemas, dependency and SBOM digests, egress destinations, credential classes, resource budgets, idempotency, reconciliation, evaluation evidence, signer, expiry, and revocation.

`ConnectorLease` grants one runtime the minimum realm, World, provider account, operation, secret reference, egress, and time scope. `ConnectorRun` records request, response, checkpoint, raw artifact, and outcome digests.

The profiles have different outputs:

- A source connector produces raw evidence, a `DatasetVersion`, or an evidence-admission proposal.
- An effect connector executes an existing `EffectIntent` and returns provider evidence for reconciliation.
- A channel connector produces verified ingress or delivery observations for Eve.

No connector writes authority or creates a `Settlement`.

`DataFlowDefinition` describes a typed batch, incremental, CDC, or stream graph over immutable `DatasetVersion` inputs. `DataFlowRun` records the executor, parameters, input versions, checkpoints, outputs, resource use, and failures. `QualityGateResult` can stop admission. `LineageEdge` relates exact fields, rows, ranges, code, and output versions.

## Rights survive every transformation

`DataUsageContract` records provider and owner terms. `EntitlementGrant` records current authority to use data. `EntitlementSnapshot` freezes the entitlement evidence used for one operation.

`RightsDecision` covers principal or workload, purpose, World, object or type, field or series, provider, operation, valid and knowledge time, territory, retention, display, citation, derivation, export, and redistribution. It runs before candidate discovery. Errors, counts, cursors, schemas, charts, caches, explanations, and citations cannot reveal denied resources.

`DerivedRightsDecision` computes the rights of an output from every input and transformation rule. It cannot silently widen use. `UsageObligation` records duties such as attribution, delayed release, deletion, metering, or a non-display restriction. `UsageReceipt` proves that the required duty ran.

## Workspace and headless agents

Conversation does not replace a dense professional workspace. `WorkspaceDocument` saves released views, tables, charts, Cases, live panels, analysis artifacts, command bindings, and layout references. `ChartDocument` carries query basis, units, transformations, comparison basis, uncertainty, warnings, and interaction bindings. A `ChartRendererPort` selects a renderer. `RepresentationProof` checks that the rendered form preserves meaning, rights, and accessibility.

Eve remains the conversational product. The launch channels are web, WhatsApp through Kapso, native Eve Telegram, and email.

Agents also run without conversation. `ModelProfile`, `RetrievalPlan`, `AgentDefinition`, and `AgentRun` are available through the generated API, CLI, and MCP catalog under the same current grants. A headless agent cannot gain standing authority by avoiding Eve.

## Pack installation

`PackArtifact` is the distribution envelope for released meaning and optional data, workflow, agent, connector, executor, or mini-app artifacts. `PackDependency` names exact versions and digests. `PackInstallationPlan` resolves inputs, conflicts, rights, migrations, resource budgets, and new capabilities before review. `PackInstallationReceipt` records what the release installed or why it failed.

A store and commercial marketplace remain product work. The protocol only prevents packaging from becoming a permission or supply-chain bypass.

## SDKs and deployment cells

The closed JSON release is a language-neutral publication protocol. `SurfaceManifest` can generate SDKs for TypeScript, Python, Java, C#, Rust, command-line shells, and future agent protocols. Each generated client carries semantic IDs, schemas, declared errors, idempotency requirements, temporal basis, and OAuth audience. Language-specific convenience cannot change the operation catalog.

The first Fly application is a deployment choice, not evidence that the system can operate as a fleet. The target scale path keeps the same public contracts:

1. Add identical whole-application Machines behind one World router.
2. Split executor pools because untrusted code and specialized compute need a harder boundary.
3. Split Eve, Ontology, or Effects only when credentials, residency, failure isolation, or measured scaling require it.
4. Assign a large or regulated World to an authority cell before session admission.
5. Add regional read and artifact cells for historical, cut-pinned work.
6. Add fleet and edge delivery only after release proof, revocation, upgrade, and recovery protocols cover intermittent connectivity.

`DeploymentProfile` declares the target environment. `CellBundle` pins its content. `CellRelease` records an installed bundle. `CellAttestation` reports the measured runtime state. Only the holder of the current `AuthorityCellLease{epoch}` can commit for a World.

`DisconnectedOperationPolicy` enumerates the reads, proposals, and bounded actions that may continue without the authority cell. `FederatedSyncAgreement` governs later exchange. `WorldSetBasis` records each participating World's release, cut, valid time, rights decision, and response state. `FederatedFrame` keeps those bases and partial failures visible.

A global cross-cell authority transaction is not implied. Cross-World work uses governed requests and receipts. None of these protocols proves offline correctness, fleet safety, or Palantir-class deployment operations.

## Network effects

Architecture can avoid blocking a network. It cannot supply one.

The following target contracts could let value accumulate without merging every participant into one authority database:

- reusable `DataPackArtifact`, `WorkflowDefinition`, `AgentDefinition`, `ExecutorArtifact`, and `MiniAppArtifact` packages.
- stable semantic identities and mappings across providers and Worlds.
- signed proofs, receipts, provenance, and Settlement records that another authorized World can verify.
- cross-organization Cases and `FederationAgreement` contracts.
- Eve relationships that retain continuity without retaining authority.
- provider, evaluator, builder, and connector reputation based on observed artifacts and outcomes.

**Inference.** These contracts could support a marketplace and professional collaboration.

**Unknown.** No architecture document can establish whether users, publishers, brokers, clinics, factories, or families will adopt the network. Bloomberg's installed professional network and Palantir's accumulated deployment knowledge remain practical advantages that a schema cannot copy.

## Current decisions and their reopen protocols

| Current decision | Capability concern | Preserved extension path | Required boundary |
|---|---|---|---|
| Closed domain IR | Arbitrary code, notebooks, custom logic, and generated apps appear excluded. | The IR defines authority. `ExecutorArtifact`, `NotebookArtifact`, trusted handlers, and `MiniAppArtifact` add computation and presentation outside it. New common semantics may still become reviewed IR nodes. | Executable output is a proposal or artifact. Only released Actions and evidence admission change a World. |
| One Fly app, one steady-state Machine | Independent scale, hostile code isolation, regulated regions, and fleet deployment appear excluded. | The target ports admit identical Machines, isolated executor apps, product process splits, and per-World cells. `CellDirectory` resolves routing before authorization. | No split may distribute `AuthorityCommit` or change public semantic contracts. |
| TypeScript core | Python and R analytics, native compute, GPUs, and other SDK languages appear excluded. | TypeScript owns the authority application. Polyglot executors and native query adapters use language-neutral schemas, canonical artifacts, generated SDKs, and brokered capabilities. | No foreign runtime receives ambient authority credentials or becomes a second domain implementation. |
| Restate only for Effects | Long-running business processes and agents appear excluded. | `WorkflowInstance`, Cases, Watches, interaction journals, leases, and wakeups store durable semantic progress in PostgreSQL. Restate handles only external Effect execution. | A scheduler may wake work. It cannot decide a domain transition or store the sole copy of workflow truth. |
| Immutable Parquet and manifests | Interactive analytics, live feeds, notebooks, and distributed engines appear limited to DuckDB. | Parquet remains sealed history. The live observation protocol handles ordered hot delivery. `ObservationQueryPort` can admit DuckDB, DataFusion, Spark, Trino, Arrow Flight, or a managed engine after evidence gates. | The hot plane is not authority. Engines return released values or immutable artifacts. They cannot define rights, identity, policy, or authority. |
| Built-in launch connectors | Compiling every integration into the core image would block independent installation and revocation. | `ConnectorArtifact`, leases, runs, and `PackArtifact` define the future isolated integration contract. | A connector cannot write authority, hold ambient credentials, or create a `Settlement`. |

## Structurally impossible and merely deferred

### Structurally impossible under the constitution

The following behaviors require a constitutional reversal, not another adapter:

- uploaded or model-generated code directly writes authority tables, activates a release, grants membership, or mints a `DecisionReceipt`.
- an executor, notebook, mini-app, agent, scheduler, connector, or query engine bypasses a released Action or current disclosure policy.
- mutable bytes retain the same content digest, or a dense query silently selects objects outside its admitted manifest roots.
- evaluation code receives production credentials or proves itself against a mutable live branch.
- an external timeout becomes success or failure without an observed released-domain outcome.
- a transaction claims atomic authority across independently routed World cells.
- a live display hides sequence gaps, staleness, or the entitlement basis of the update.
- an Action relies on an unpinned live quote or order book.
- a product claims Bloomberg's licensed data, newsroom, liquidity, counterparties, or professional network without obtaining the rights and relationships.

The audit found no public Palantir or Bloomberg capability that requires one of these behaviors. That finding does not prove completeness.

### Merely deferred

The following capabilities fit the current constitution and remain product or infrastructure work:

- programmable analytics, Python and R notebooks, GPUs, model training, large distributed queries, and scheduled analysis.
- governed executable mini-apps, an application builder, AI-assisted app generation, and app distribution.
- long-lived workflows, reusable agent workflows, agent builders, broad model support, and managed eval operations.
- collaborative branches, proposal review, semantic diffs, conflict tools, rebase, and release marketplaces.
- multi-language SDKs, local developer environments, richer MCP clients, and generated integrations.
- data-pack catalogs, licensed provider packs, real-time news packs, point-in-time corpora, and security-master operations.
- unconflated live feeds, market depth, object-set subscriptions, gap recovery, and entitlement-aware fan-out.
- batch, incremental, CDC, streaming, and virtual-source data flows with quality gates and field-level lineage.
- broker, venue, OMS, custody, payment, channel, and industrial connectors with certified reconciliation.
- versioned pack installation, dependency resolution, recalls, and a commercial marketplace.
- multiple Machines, specialized compute pools, regulated cells, regional routing, edge delivery, and fleet operations.
- cross-organization Cases, provider and builder reputation, professional collaboration, and network distribution.

## Honest gap statement

**Verified.** The current Zoen blueprint chooses a TypeScript modular monolith, a closed canonical release IR, isolated evaluation realms, PostgreSQL authority, Parquet manifest publication, and Restate only for `ZoenEffect`. [Three products in one TypeScript application](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/001-three-products-one-typescript-application.md:1), [closed release IR](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/010-closed-json-release-ir-and-no-wasm-v1.md:1), [isolated evaluation Worlds](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/004-realms-and-isolated-evaluation-worlds.md:1), [immutable Parquet and manifests](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/009-immutable-parquet-and-manifest-dag.md:1), [Restate effects](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/015-restate-effects-and-honest-settlement.md:1)

**Shipped foundation.** This audit assigns no competitive category to this class. The blueprint and target ADRs are not runtime evidence.

**Zoen Target.** The audit found no known constitutional blocker after the live observation, connector, data-flow, rights, object, cell, execution, agent, workspace, developer, and pack protocols in this reference. Each one still needs an ADR, schema, threat model, product design, real journey, and operating evidence.

**Unproven product.** Zoen has no production evidence for these protocols. The first unconflated feed, hostile connector, licensed derived dataset, institutional workflow, federated Frame, or disconnected cell may expose a missing contract. Each must pass evidence-gated evolution rather than receive a private bypass. [Build sequence and evidence-gated evolution](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/adrs/018-build-sequence-scale-and-evidence-gated-evolution.md:1)

**Moat.** Bloomberg's data rights, newsroom, field corpus, liquidity, connectivity, and network remain outside the architecture. Palantir's deployment record, customer models, integration library, regulated operations, support, and builder familiarity remain outside it too.

## Primary sources

### Zoen

- [Greenfield product synthesis](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/synthesis.md:1)
- [System shape](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/system-shape.md:1)
- [Release language, policy, and Eve](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/release-policy-eve.md:1)
- [Data, events, and Parquet](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/data-events-parquet.md:1)
- [Security and operations](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/security-and-operations.md:1)
- [Competitive comparison](/Users/enzotironi/.codex/visualizations/2026/09/04/01a06d1c-c192-79e2-b97a-07edf9722efa/zoen-greenfield/technical-blueprint/reference/competitive-comparison.md:1)

### Palantir

- [The Ontology system](https://www.palantir.com/docs/foundry/architecture-center/ontology-system)
- [Action types](https://www.palantir.com/docs/foundry/action-types/overview)
- [Workshop](https://www.palantir.com/docs/foundry/workshop/overview)
- [Pilot](https://www.palantir.com/docs/foundry/pilot/overview)
- [AIP architecture](https://www.palantir.com/docs/foundry/architecture-center/aip-architecture)
- [AIP features](https://www.palantir.com/docs/foundry/aip/aip-features)
- [Branching the Ontology](https://www.palantir.com/docs/foundry/ontologies/branching-ontology)
- [Ontology SDK](https://www.palantir.com/docs/foundry/ontology-sdk/overview)
- [Ontology MCP](https://www.palantir.com/docs/foundry/ontology-mcp/overview)
- [Ontology-aware applications](https://www.palantir.com/docs/foundry/ontology/applications)
- [AIP, Foundry, and Apollo](https://www.palantir.com/docs/foundry/architecture-center/platforms)
- [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview)
- [Connecting to data](https://www.palantir.com/docs/foundry/data-integration/connecting-to-data)
- [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview)
- [Streaming pipelines](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview)
- [Time series](https://www.palantir.com/docs/foundry/time-series/time-series-overview)
- [Functions](https://www.palantir.com/docs/foundry/functions/overview)
- [OSDK subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions)
- [Developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview)
- [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview)
- [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/)
- [Foundry products](https://www.palantir.com/docs/foundry/marketplace/foundry-products)
- [Apollo environments](https://www.palantir.com/docs/apollo/core/environments)
- [Offline embedded Ontology](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application)

### Bloomberg

- [Bloomberg Terminal](https://professional.bloomberg.com/products/bloomberg-terminal/)
- [BQuant](https://professional.bloomberg.com/products/bloomberg-terminal/research/bquant/)
- [AI on Bloomberg and ASKB](https://professional.bloomberg.com/products/bloomberg-terminal/ai)
- [Data License](https://professional.bloomberg.com/products/data/data-license/)
- [Data License Plus](https://professional.bloomberg.com/products/data/data-license/dms/)
- [Bloomberg News](https://professional.bloomberg.com/products/bloomberg-terminal/news/)
- [Terminal access and identity](https://professional.bloomberg.com/products/bloomberg-terminal/access/)
- [Bloomberg Reference Data](https://professional.bloomberg.com/products/data/enterprise-catalog/reference/)
- [OpenFIGI](https://www.openfigi.com/about/overview)
- [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/)
- [Instant Bloomberg](https://professional.bloomberg.com/products/bloomberg-terminal/collaboration-tools/instant-bloomberg/)
- [Real-Time Market Data Feed and B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/)
- [BLPAPI](https://bloomberg.github.io/blpapi-docs/)
- [BLPAPI `Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html)
- [BLPAPI `Identity`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.3/classBloombergLP_1_1blpapi_1_1Identity.html)
- [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/)
- [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/)
- [TOMS](https://professional.bloomberg.com/products/trading/order-management-system/toms/)
