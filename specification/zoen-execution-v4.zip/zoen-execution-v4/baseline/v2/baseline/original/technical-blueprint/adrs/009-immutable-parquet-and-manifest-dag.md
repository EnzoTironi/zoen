# ADR 009: Immutable Parquet and a manifest DAG for dense observations

Status: Accepted

## Context

Dense observations do not belong in transactional row storage, but placing Parquet files in an object prefix is not a data contract. Prefix listings are mutable, compaction can silently change query results, garbage collection can delete reproducibility, and two engines can interpret types differently.

Parquet is a durable Zoen artifact, not a temporary optimization. Its identity and publication rules must remain valid if the query engine changes.

## Decision

Dense observations are immutable Parquet segments in content-addressed Tigris object storage through `@aws-sdk/client-s3` 3. The initial query and writer implementation is DuckDB 1.5 Node Neo behind `ObservationQueryPort` and `ObservationWriterPort`. DuckDB is an execution engine, never the manifest, policy, or authority.

The logical observation row has required fields:

```text
world_id, series_id, event_time_utc_us, valid_from_utc_us,
valid_to_utc_us?, revision, value_decimal?, value_text?, unit_id?,
quality_code, source_id, evidence_digest
```

Release-owned columns may extend the row through a schema digest. Semantic decimals use Parquet DECIMAL with declared precision and scale. Timestamps are UTC microseconds. Floating point is allowed only when the release declares its tolerance and canonical comparison rule. Rows are stably sorted by `(series_id, event_time_utc_us, revision)`.

A `SegmentPayload` commits to exact object bytes and byte length, Parquet schema and footer-metadata digests, semantic field IDs, logical key and valid-time range, provider clock bounds, row count, uncompressed and compressed sizes, writer and format version, compression and row-group layout, sort declaration, aggregate statistics, source evidence digests, immutable `DataUsageContract`, disclosure-marking facet IDs, and encryption context. The object digest is SHA-256 over exact Parquet bytes; the descriptor digest is domain-separated canonical JSON over the payload. Its digest is outside the payload. A separate `SegmentVerification` names the local object-verification receipt and time. Neither payload contains the commit or cut that may later admit it. Current audience authorization is never baked into shared segment bytes.

An `ObservationManifestPayload` is a canonical, content-addressed Merkle DAG. Its root payload contains schema version, realm, World, data-generation digest, root-node digest, logical row-set digest, aggregate statistics, a separately named `previousSnapshot`, and format policy. The manifest digest is outside and hashes that payload. Canonical partition nodes contain ordered edges to child-node digests or segment descriptors. Each root is a complete visible snapshot; queries never traverse `previousSnapshot` to discover current data. Append creates a new root that structurally reuses old nodes and includes the added segments. Replacement or governed tombstone metadata names the removed segment or logical range and reason, while the new root contains only the visible set. `previousSnapshot` expresses payload lineage; it is never overloaded as a Merkle parent edge.

`ManifestAdmission` is a separate PostgreSQL authority record keyed by realm, World, manifest digest, and cut. It names the admitting commit, resulting full WorldHead, source-cursor advances, and admission time. Segment and manifest content exists before AuthorityCommit and cannot name that future commit, cut, audit root, or admission time. The commit payload names the precomputed manifest digest; after its audit root is derived, `ManifestAdmission` can name the envelope without any digest cycle. A replacement or compaction must prove the same logical row-set digest when it claims semantic equivalence.

Publication order is:

1. Execute an allowlisted, parameterized DuckDB `COPY ... TO ... (FORMAT PARQUET, COMPRESSION ZSTD)` plan in bounded temporary storage; hash and inspect only the completed bytes; upload them at their content digest; and record unadmitted staging rows. There is no first-path JavaScript Parquet writer.
2. Write the immutable manifest payload, compute its digest, and create local `SegmentVerification` receipts for every referenced object.
3. Prepare the resulting manifest and generation digests.
4. In one AuthorityCommit under the authority fence and full head lock, validate only local immutable payload and verification receipts; insert one `ManifestAdmission`; advance the authoritative source cursor; publish the new root; and move the full `WorldHead` to that root. The transaction performs no object-store, registry, or provider I/O.

Readers use only the generation and manifest root captured in their `WorldHead`. `ObservationQueryPort` accepts a released semantic plan, allowed fields and markings, deterministic numeric and rounding rules, and byte, row, time, and memory budgets. It accepts no caller SQL, object key, URL, or engine expression. The planner intersects current membership, purpose, delegation, source rights, and disclosure policy before selecting segments, fields, and predicates, and checks returned rows again. Results bind manifest-slice digest, schema digest, canonical result and explanation digests, and engine and version attestation. Readers never discover data by listing a prefix or by reading an uncommitted child node. DuckDB extension autoload and arbitrary external access are disabled.

Operational defaults are Zstandard compression, approximately 128 MiB row groups, and 256 to 512 MiB objects. They are recorded in descriptors but excluded from logical row-set identity. Compaction publishes a new manifest, normally with the same data-generation digest, through AuthorityCommit because the manifest component of the head changes.

Arrow may be used as bounded in-memory interchange when an adapter benefits from it. It never replaces Parquet bytes or manifest identity.

Replay starts from an explicit admitted manifest root and verifies `ManifestAdmission`, canonical manifest payload bytes, Merkle root, segment payloads and bytes, schema, logical row-set digest, and query result digest. Retention roots include current and retained historical heads, signed checkpoints, Frames and receipts under retention, Cases, Watches, release preparations and proofs, legal holds, active query leases, and the PostgreSQL PITR window. Garbage collection is mark-and-sweep with a quarantine interval; an object is deletable only when unreachable from every retained root. Governed erasure publishes tombstones or a new generation first, then lets policy-controlled collection remove unreachable ciphertext.

## Consequences

- A dense answer is reproducible without dependence on an object-store listing or one query engine.
- Compaction and deletion become explicit governed operations rather than background file replacement.
- Manifests and retained roots consume metadata and storage, but make audit and recovery possible.
- DuckDB keeps the first implementation in TypeScript and avoids a language/process seam.

## Reopen triggers

- After DuckDB query, layout, caching, and concurrency tuning, Rust/DataFusion demonstrates at least 50 percent lower p95 latency and 40 percent lower peak RSS on two priority workloads at 100 million points and 32 concurrent Frames, with identical canonical results and no material operational regression. Introduce it behind `ObservationQueryPort`, not as authority.
- A new data class cannot be represented without losing required semantics in Parquet. Version the format and prove dual-reader results before publication.
- Object counts or manifest traversal miss service objectives. Add checkpoints or manifest indexes that preserve immutable roots.
- A cryptographic or Parquet compatibility issue requires rewriting segments. Publish a new generation; never mutate content-addressed objects.
- Retention law conflicts with reproducibility. Make the deletion and resulting proof limitation explicit; do not hide missing segments behind a mutable path.
