# ADR 019: Programmable compute and governed executable mini-apps

Status: Accepted target contract; launch adapters deferred

## Context

A closed domain IR gives Zoen deterministic authority, but Palantir Workshop/Pilot and Bloomberg BQuant demonstrate a real possibility requirement: people must eventually build arbitrary rich applications, notebooks, analytics, models and workflows over governed data. Treating every new computation or interface as a kernel release would set an unacceptable ceiling. Letting uploaded or model-generated code run inside authority would create a second, opaque ontology with ambient credentials.

The design needs general-purpose programmability without general-purpose authority.

## Decision

`WorldRelease` remains the only publication of domain meaning. Its closed IR defines identity, evidence, queries, Actions, Cases, Watches, WorkflowDefinitions, policy, presentation semantics and artifact contracts. General-purpose code is stored and executed as a different artifact kind and can only consume released capabilities.

Zoen distinguishes three immutable artifacts:

1. `MiniAppManifest` is a closed declarative presentation document rendered by first-party Living World code.
2. `MiniAppArtifact` is a signed executable browser application for Workshop experiences that exceed the declarative renderer.
3. `ExecutorArtifact` is signed server-side or batch computation used by a `NotebookArtifact`, `AnalysisRun`, model, simulation or specialized transform.

All three are content-addressed and release-bound. An executable artifact records source, builder, base runtime, dependency lock, SBOM, input/output schemas, requested capabilities, rights and purpose classes, resource budgets, allowed egress, determinism class, signer, evaluation evidence, revocation and expiry. A mutable tag or package coordinate is never artifact identity.

### Mini-app boundary

A `MiniAppArtifact` runs on a separate origin or sandboxed frame with a strict content policy. It receives a generated client and a short-lived, user-bound, audience-bound token for only the public capabilities declared in its manifest. It has no PostgreSQL connection, internal Ontology port, provider credential, unrestricted browser storage, arbitrary egress, or ability to mint a grant.

Every read opens or reopens a purpose-bound WorldSession and applies current disclosure. Every write invokes a released domain Action and receives the ordinary Case, DecisionHandle, receipt or denial. A UI click is never proof that a World changed. A mini-app may request an analysis through a released query or Action; it cannot receive the executor credential.

The portable executable contract is MCP Apps: the artifact exposes a content-addressed `ui://` resource with declared app-visible tools, content-security metadata, host-mediated JSON-RPC and a structured/text fallback. Eve/Living World is the first-party host; external conforming MCP hosts may render the same artifact without receiving an internal Ontology port.

The first implementation is the first-party React renderer over `MiniAppManifest`. Rivet Dynamic Apps is the first executable `MiniAppRuntimePort` spike because its product shape matches generated Workshop apps, but Rivet generates/builds/runs an artifact rather than defining its identity or authority. The current 0.3.1 Preview release is not a launch dependency. The inspected `@modelcontextprotocol/ext-apps` package still peers on the legacy aggregate MCP SDK, so Zoen does not install a dual MCP core stack: it waits for v2 compatibility or proves a tiny protocol adapter. Adoption requires the sandbox, replay, export, independent-host, failure fallback, resource and non-preview gates in the Rivet reference.

### Executor boundary

An `ExecutorArtifact` runs outside the authority process in an isolated compute cell. It receives a short-lived `DataGrant` bound to realm, World, principal, purpose, release, sparse subjects, dense manifest roots, field/rights filters, expiry, output class and budget. A capability broker supplies bounded reads or a bounded copy; it never supplies object-store master credentials, authority database credentials, membership APIs, release activation, model/provider secrets outside the declared class, or direct Effect delivery.

An executor may emit only immutable outputs such as `DerivedArtifact`, `AnalysisRun`, `EvidenceAdmissionProposal`, `Scenario`, `ActionDraft` or `ReleaseProposal`. It cannot emit a `DecisionReceipt`, activate a release, alter a head, or claim a `Settlement`. Admission or a released Action decides whether an output becomes World truth.

TypeScript is the first authored notebook/executor language. The authority application remains 100 percent TypeScript. OCI executor profiles may later host Python, R, SQL engines, native libraries, GPUs or distributed engines through the same language-neutral schemas and grants. This is not a second Ontology implementation.

### Generation, proof and publication

A model or person may generate either artifact in Studio or Eve. Draft execution occurs only in an EvaluationWorld with no live credentials. The proof binds source, prompts where retained, model identity, dependency resolution, build image, artifact digest, requested capabilities, denial results, accessibility, resource behavior, replay, export and the exact candidate Zoen image.

Publication is a ReleaseProposal review. Activation pins the approved artifact digest and capability manifest. Changing source, dependency, runtime, requested capability or output contract creates a new digest and requires the affected proof. The generator cannot approve itself.

A useful first-party declarative rendering remains available when an executable mini-app is absent, revoked, incompatible or fails. This is a safety and longevity layer, not the permanent product ceiling.

### Workflows and runtimes

Long-lived business workflows remain closed `WorkflowDefinition` and canonical `WorkflowInstance` state in PostgreSQL. Watches, Cases, Actions, Effects and Eve wakeups compose them. A future Rivet Workflows adapter may improve wake/replay operations behind `WorkflowRuntimePort`, but it cannot own the sole state or broaden Restate. Restate remains `ZoenEffect` only.

## Consequences

- Zoen can host Workshop/Pilot-class applications and BQuant-class computation without putting general-purpose code inside authority.
- Executable ecosystems require a harder sandbox, artifact registry, revocation, supply-chain review and compute operations that the launch product does not yet need.
- A closed IR remains valuable for common explainable semantics; an extension artifact handles the long tail.
- Some advanced applications will lose functionality when falling back to the declarative renderer, but the user still receives a truthful inspectable surface rather than a broken authority path.
- “100 percent TypeScript” describes Zoen's owned authority/application implementation, not a prohibition on isolated user analytics or generated client languages.

## Required gates before executable production use

1. No ambient-authority journey: database, object-store master credentials, metadata service, filesystem, browser parent, cross-realm tokens and arbitrary egress are unreachable.
2. Capability journey: every allowed read and Action is short-lived, purpose-bound, current-authorized, audience-bound and traceable to the artifact request.
3. Supply-chain journey: locked dependencies, source/build/SBOM digest, malicious lifecycle script, registry compromise, revocation and rebuild variance.
4. Resource journey: CPU, memory, disk, network, output, time and cost limits survive hostile code and process death.
5. Replay/export journey: source, environment, inputs, manifest roots, result and artifact digests reproduce or explicitly declare nondeterminism.
6. Failure journey: runtime loss cannot create a receipt, leak a partial privileged result or prevent a useful declarative mini-app view.
7. Evaluation journey: proof uses the exact artifact and Zoen image with no live credential, and the generator cannot activate itself.
8. Rights journey: data cannot be exported, cached, joined or retained beyond the source contract and `DataGrant`.
9. Portability journey: the identical artifact renders through Eve and an independent MCP Apps host, calls only declared capabilities, preserves canonical Action results, and degrades to useful structured/text output when UI rendering is unavailable.

## Reopen triggers

- Three unrelated deterministic extension needs fit one safe Wasm Component profile better than isolated OCI. Reopen ADR 010 with no WASI/I/O and explicit fuel/memory limits.
- A mini-app requires a capability unavailable through the public `SurfaceManifest`. Add a released product capability or reject the app; do not grant an internal port.
- An executor needs to make a consequential external call. It creates an Action draft or released Effect plan; it does not receive provider credentials directly.
- Rivet Dynamic Apps or another runtime passes every gate with materially less code and operations. Adopt it behind `MiniAppRuntimePort` and retain artifact/runtime portability.
- The declarative renderer becomes a material product constraint. Expand its closed semantic document or adopt the executable adapter; do not put arbitrary presentation configuration into domain meaning.

No trigger permits executable code to become authority by proximity, installation, authorship or model confidence.
