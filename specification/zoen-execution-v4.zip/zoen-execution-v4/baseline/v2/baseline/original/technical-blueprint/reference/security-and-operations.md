# Security and operations

## Security model

Zoen assumes every network, model output, provider payload, channel webhook, generated release, browser value, database row decoder, and object reference can be hostile or stale. Security is expressed as ownership boundaries and current proofs, not a filter bolted onto routes.

The four relevant facts remain distinct:

1. **IdentityProof:** Better Auth says which account/client was freshly proven, how, for which audience, and at what assurance.
2. **WorldSession:** Ontology says what that principal may do now in this World, realm, release, purpose, and entity slice.
3. **Disclosure proof:** Cedar says which facts/consequences/explanations may cross this boundary now.
4. **DecisionHandle:** one principal may contribute to one exact authorized Case view before expiry.

No cookie, OAuth scope, MCP token, API key, phone number, Telegram account, model tool choice, or role string substitutes for the latter three.

## Credential and schema ownership

| Owner | Database surface | Runtime credential | May never do |
|---|---|---|---|
| Migration job | all Zoen schemas and grants | one short-lived migration role | serve traffic or hold provider credentials |
| Door | `door` schema | Better Auth role | read/write membership, policy, ontology, relationship journal |
| Eve Workflow migrator | dedicated `eve_workflow` database only | one short-lived upstream-compatible migration role | connect to Door/Ontology databases or serve traffic |
| Channel-state migrator | dedicated `eve_channels` database; owns `kapso` and `email` schemas | one short-lived Zoen migration role | serve traffic, call providers, or connect to Workflow/Door/Ontology |
| Eve Nitro | dedicated `eve_workflow` database plus DML-only `kapso`/`email` roles in `eve_channels` | Eve Workflow/channel roles, direct model/channel leases, and request-bound loopback proof | run DDL, cross provider schemas, receive an Ontology/object-write/KMS/Restate credential, mutate Ontology, or construct World grants |
| Hono/Ontology | `ontology`, admitted dense metadata, outbox | authority role; direct PostgreSQL connection | read Door credentials or call providers inside a commit |
| Effect runner | EffectIntent/attempt read and constrained ProgressCommit/settlement application port | connector-specific leased secret | invent intent, decide authority, or write arbitrary truth |
| Object writer | staging prefix and immutable content keys | write-without-delete credential | change an admitted object or list prefixes as authority |
| Garbage collector | proven-unreachable objects only | delete-only scoped credential | decide reachability without a signed collection plan |
| Evaluation | separate project/bucket/runtime namespace/provider sandboxes | evaluation-only credentials | receive any live credential or write live prefixes |
| Browser/CLI/MCP | public protocols only | session or resource-bound OAuth token | receive database/object/provider credentials |

PostgreSQL uses distinct roles, schema ownership, default-deny grants, composite realm/World keys, and RLS with transaction-local realm/principal/purpose context as defense in depth. The `eve_workflow` and `eve_channels` connections must differ from each other and from every Door/Ontology host/database/role tuple; startup rejects equality instead of silently falling back. `eve_channels` has isolated `kapso` and `email` schemas, migrator-owned DDL, and DML-only provider roles. Application authorization is still checked before SQL; RLS catches boundary failure rather than becoming the product policy language.

The Hono/Eve process seam is a least-privilege protocol boundary, not a claim that two same-Machine processes form a security sandbox. Hono spawns Eve without a shell and with an explicit environment allowlist, and Eve gets no authority credential. A total Machine compromise can still attack loopback or same-kernel process state. If hostile-process containment becomes a requirement, use separately evidenced UIDs/kernel controls or separate Machines; do not market the current seam as RCE isolation.

## Secrets

All connector access goes through `CredentialVaultPort`. Stored connector material is envelope-encrypted, versioned, scoped to realm/World/source or destination, and redacted from logs, traces, receipts, model context, and error bodies. Fly secrets contain only bootstrap material required to obtain/decrypt narrower credentials. Rotation creates a new version; unsettled EffectIntents keep the connector version they were authorized to use.

The first production key adapter is an asymmetric/envelope key in a managed KMS in the chosen region. `ReleaseSignerPort` is a separate key and identity from credential encryption. CI obtains signing authority through workload identity, never a long-lived repository secret. Image provenance is additionally keyless Sigstore/Cosign; ReleaseProof is DSSE/in-toto shaped and binds the exact OCI digest.

Secret access emits non-sensitive audit facts: principal/service identity, credential reference and version, purpose, EffectIntent or SourceLease reference, and time. Plaintext is held only in the adapter call scope and is never persisted in a durable workflow history.

## Boundary defenses

- Hono adapters enforce body, header, URL, decompression, request-time, and concurrency limits. For `/eve/` and `/.well-known/workflow/`, Hono preserves method, raw bytes, signature-relevant headers, cookies, status, streaming, backpressure, cancellation, and paths; it never parses then reconstructs a signed provider body.
- Zod parses fixed envelopes; Ajv compiles only authenticated, bounded release-owned schemas during activation. Request-supplied schemas are data, never executable validators.
- Every SQL value is parameterized. Dynamic identifiers come only from closed compiled release registries, never request strings.
- Object keys are derived from branded identities and digests. Callers never supply URLs, bucket names, SQL, DuckDB fragments, Cedar text, connector IDs, or handler IDs at invocation time.
- Source and connector HTTP clients resolve through allowlisted contracts, block loopback/link-local/private metadata targets unless explicitly owned, cap redirects/body/time, pin TLS expectations where required, and record the resolved contract digest.
- Models receive authorized released documents and opaque tool handles, not credentials, internal object keys, database schemas, hidden fields, or generic network/shell tools. Tool arguments are untrusted and fully reauthorized.
- Browser rendering treats all release/provider/model text as text. No arbitrary HTML, script, `javascript:` URL, remote component, or release-supplied React module enters the main origin.
- Kapso, native Telegram, and Resend email ingress verify vendor signatures/secrets, bind replay windows and message IDs, and still create only channel-presence facts.
- Restate or any replacement runtime has an infrastructure-only endpoint with signed caller identity and a closed handler registry.
- Eve calls Ontology only through `EveOntologyClient` on `127.0.0.1:8081`. `EveServiceProof` binds boot, request, audience, principal evidence, purpose, expected basis, operation, deadline, and body digest; replay, expiry, wrong audience, and direct public access fail closed.
- Redis is forbidden in every role. No cache, session, queue, lock, channel, live-feed, or coordination exception exists.

## Eve tool, attachment, and sandbox profile

Official Eve defaults are broader than Zoen's conversational job: default agents may receive sandbox shell/file tools, app-runtime `web_fetch`, provider `web_search`, durable `todo`, `ask_question`, and root-agent delegation; skills and connections add more conditional tools. Authored tools execute in the trusted app runtime, where environment secrets are reachable, and omitted approval means `never()`. Zoen therefore treats the generated tool manifest as a security artifact rather than accepting framework defaults.

Launch source contains `disableTool()` sentinels named `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, and `todo`. It defines no `glob`, `grep`, experimental `Workflow`, or `sleep`, and declares no skills or connections. `ask_question` remains because durable human clarification is a product capability. The only authored tools are release-generated `inspect_*` and `propose_*` Ontology tools; each declares `never()`, `once()`, `always()`, or an input-dependent policy explicitly. The approval prompt is interaction control, not authority: every call still crosses `EveOntologyClient`, opens fresh Door/World/disclosure context, and routes any consequence through the ordinary Case and idempotency protocol.

Zoen configures an explicit custom `DisabledSandboxBackend` whose `create`/`prewarm` path rejects with a typed fail-closed result. It never imports or calls Eve's availability-based `defaultBackend()`, whose fallback chain may end at `just-bash`; Eve documents that backend as having no network isolation and documents default sandbox egress as allow-all. Static gates forbid `ctx.getSandbox()` and every sandbox-backed tool import. The disabled backend is a tripwire, not an isolation claim.

Eve stages byte-backed AI SDK `file` parts under `/workspace/attachments` before the first model step. Hono/web ingress and provider bridges must therefore reject those parts or convert the attachment through a Hono-owned quarantine, content validation, evidence admission, and disclosure path into authorized text plus an opaque reference before creating the Eve message. Raw bytes, base64 file content, and sandbox paths never enter Eve session history. The raw Hono proxy still preserves signed provider requests; normalization happens only after Eve's channel verifier authenticates the original event and before delivery into a durable session.

Chat transport state follows the same least-privilege rule. `ZoenChatStateAdapter` implements the exact public `chat@4.39.0` `StateAdapter` with parameterized raw `pg` and checked-in migrator-owned SQL. The exact-pinned `@chat-adapter/state-pg@4.39.0` tarball is rejected from launch because `connect()` executes unqualified `CREATE TABLE IF NOT EXISTS`/index DDL and exposes neither a schema choice nor a migration-free mode. No runtime channel credential owns a schema.

## Abuse and privacy

Per-principal, client, relationship, World, source, Action, model, dense-query, export, and connector budgets are explicit. Limits return typed outcomes and never partially commit. Suspicious denial, replay, signature, token, realm, object, and query-budget events are observable without logging forbidden content.

Retention is a released/governed policy with legal-hold override, not ad hoc object deletion. Personal data inventory maps fields to source, purpose, encryption class, retention class, export behavior, and deletion semantics. Deletion produces an authorized plan and receipt, severs keys/references where erasure is required, and waits for manifest/frame/case/watch/proof/legal-hold reachability before object collection. Audit facts retain the minimum lawful tombstone, not the erased content.

Exports are immutable artifacts with audience, purpose, cut, release, manifest, disclosure, expiry, and content digest. Download authorization is current; possession of an old URL is not authority. Signed URLs are short-lived and single-artifact scoped.

## Observability

Every accepted ingress receives a correlation ID. Structured logs and traces connect, without equating:

```text
interaction -> model attempt -> tool request
            -> WorldSession -> Frame/Case -> AuthorityCommitEnvelope
            -> DecisionReceipt -> EffectIntent -> attempt -> Settlement
            -> Watch -> Notice -> Eve decision -> delivery observation
```

Metrics cover latency, availability, lock waits, serialization retries, outbox lag, Watch lag, dense scan/bytes/object requests, model cost and cancellation, connector unknown outcomes, channel delivery, release proof, credential access, and recovery state. High-cardinality public references stay in traces/logs, not metric labels.

The tamper-evident audit chain is the canonical `AuthorityCommitEnvelope` sequence and signed checkpoints. OpenTelemetry and provider dashboards are operational observations, never the authority ledger.

## Deployment

One multi-stage OCI image contains the compiled Hono server, exact `eve build` Nitro output, and static web assets. It contains no compiler, package manager, source map with secrets, migration credential, or runtime download mechanism. Runtime processes use a non-root identity and read-only root filesystem, writable bounded temp space for Parquet construction, resource limits, and explicit health/readiness endpoints. The image's filtered environment and filesystem permissions reduce accidental credential reach but do not turn same-Machine processes into hostile-code isolation.

One Fly app initially runs one steady-state Machine in São Paulo with two supervised Node 24 processes. Hono is public only on `:8080`, serves the authenticated Eve capability endpoint only on `127.0.0.1:8081`, and exposes signed Restate `:9080` only through its authenticated infrastructure route. Exact-pinned `eve@0.52.0` runs its supported Nitro output on `127.0.0.1:4274`. Hono raw-proxies both required Eve route prefixes and exits if Eve exits; Fly restarts the whole Machine. Ontology PostgreSQL, dedicated Eve Workflow PostgreSQL, dedicated channel-state PostgreSQL, Tigris, Restate, KMS, direct model providers, Kapso, Telegram, and Resend are managed dependencies with explicit degradation behavior.

Exact-pinned `@workflow/world-postgres@5.0.0-beta.40` is a production candidate, not an approved assumption. Every production conversation route remains disabled until repeated crash, parked-wait, hook, stream, startup-recovery, duplicate-job, backup/restore, queue-pressure, and pairwise-upgrade journeys pass for the exact pair, including a regression for upstream issue #3119.

Deploy sequence:

1. verify signed image/proof and migration compatibility;
2. acquire deployment fence;
3. apply forward migrations with the migration role;
4. start the Hono process with background claims and public admission disabled, then spawn the exact built Eve output on loopback with its filtered environment;
5. verify release/object/authority-database identity, Eve/Workflow package pair, isolated `eve_workflow` and `eve_channels` databases, DML-only provider grants, generated Eve tool manifest, disabled sandbox identity, attachment policy, Nitro health, both proxied route families, and global readiness;
6. register the effect endpoint revision and prove signed reachability; prove the Eve capability endpoint is loopback-only and rejects replay/wrong-audience proofs;
7. enable public admission, lease claims, and dispatch only for capabilities whose dependencies are healthy and production-approved;
8. run smoke journeys, including one Eve turn and recovery observation;
9. release the fence and retain prior handler/connector versions while referenced.

Before production, deploy topology must support in-flight durable invocations. Pre-launch may drain before replacing the one Machine. If effects routinely outlive deploys, temporarily keep the prior revision addressable or move that adapter to independently revisioned capacity; never strand an invocation to preserve a topology slogan.

## Backup, restore, and recovery fence

Backups cover Ontology PostgreSQL PITR, the isolated Eve Workflow database, the dedicated `eve_channels` database and channel-ingress ledger, immutable object replication/version inventory, release/proof/signature bundles, encrypted credential metadata, and infrastructure configuration. A database backup without its reachable Parquet/object set is not a Zoen backup. A bucket without admitted manifest roots is not truth. Eve Workflow and accepted channel ingress must be restored to a mutually reconcilable fence before outbound delivery resumes.

Restore is rehearsed into a sealed recovery realm:

1. stop public mutations, source acquisition, Watch evaluation, object collection, and Effect dispatch;
2. restore Ontology PostgreSQL, `eve_workflow`, and `eve_channels` to selected points, verify database/schema/migration/package identities and role grants, and keep Eve delivery fenced;
3. verify every active and retained manifest/release/proof object by digest;
4. rotate the global dispatcher lease epoch so pre-restore workers cannot act;
5. enumerate Effects, attempts, Settlements, Eve sessions/runs/hooks/streams, accepted channel ingress, deliveries, source cursors, staged objects, and outbox receipts resurrected by the restore;
6. reconcile against provider/channel/object external facts using pinned connector versions;
7. append new observations/Settlements or Unknowns through normal commits; never edit history to resemble the outside world;
8. run recovery journeys and sign a recovery receipt;
9. lift the recovery fence in ordered stages, with destructive collection last.

RPO and RTO are product SLOs established before launch. Initial activation is blocked until a full restore demonstrates that World heads, audit roots, releases, manifests, Frames, open Cases/Watches, interaction branches, and unsettled Effects remain coherent.

## Incident priorities

1. Contain credential or cross-realm exposure and freeze affected authority.
2. Preserve external facts and stop unsafe repeated Effects.
3. Preserve audit/object evidence before cleanup.
4. Restore correct authorization and disclosure.
5. Reconcile product state through new commits.
6. Restore latency and convenience.

No incident repair edits a DecisionReceipt, Settlement, admitted evidence object, release, or manifest in place. If history is wrong, Zoen records a governed correction with cause and evidence.
