# ADR 026: Evidence-backed finance execution lifecycle

Status: Accepted target contract. Broker, venue, clearing, and custody integrations deferred.

## Context

A Bloomberg-class finance possibility space includes more than prices and charts. Users need instrument identity, portfolios, pre-trade analysis, orders, routing, partial fills, cancel and replace, allocations, confirmations, clearing, cash, custody, compliance, and post-trade analysis. These states cross systems that may acknowledge late, disagree, correct history, or become unreachable.

A generic `trade()` Action and `succeeded` status would collapse a local decision, broker acceptance, venue order state, executions, and financial settlement. Retrying an ambiguous order could duplicate risk. Treating a model or UI event as execution authority would be unsafe.

## Decision

Finance is a released pack over the existing Ontology grammar. It does not receive a special transaction system.

### Stable identity and temporal basis

The finance pack defines instruments, listings, venues, legal entities, accounts, portfolios, currencies, calendars, market sessions, corporate actions, provider symbology, field identities, lot and decimal rules, and identity mappings. Each mapping is temporal and evidence-backed. `Money`, `Quantity`, and `UnitPrice` use exact coefficient/scale and branded unit identities; `ReleasedValue` and IEEE-754 numbers cannot stand in for them. An order names the canonical instrument and venue or routing policy plus the provider identities used by its connector.

Pre-trade Frames pin full `KnowledgeBasis`, exact position/cash/limit/risk/compliance reads, sealed entitlement snapshots, data-usage decisions, instrument and venue state, and source contracts. A price-sensitive Action also pins an `AdmittedObservationRef` with the exact quote, book, reference price, sequence, market state, clocks, rights, and released staleness policy. `StagedObservationCapture`, a browser value, model echo, or live overlay cannot enter the Case. Capture admission is a prior AuthorityCommit, so the Case starts against its resulting head.

### Each command is a domain Action

Place, cancel, replace, route, allocate, affirm, exercise, transfer, and settle are distinct released Actions with separate input, consequence, authorization, quorum, expiry, and Effect contracts. Each opens an `ActionCase` and produces its own deterministic `DecisionReceipt` when accepted.

The receipt proves only Zoen's local decision and the exact immutable `EffectIntent` it created: effect-connector artifact, destination, typed payload, pre-commit decision basis, next non-audit head coordinates, rights decision, deadline, and retry/reconciliation contract. The resulting audit root is obtained from the referenced commit envelope rather than embedded cyclically in the intent. The receipt does not prove broker acknowledgement, venue acceptance, a fill, allocation, confirmation, clearing, cash movement, or custody movement.

An effect connector receives the immutable intent and a short broker or venue credential lease. It uses a deterministic client-order or request key when supported. If acceptance is ambiguous and authoritative status lookup cannot prove absence, the effect becomes `unknown` and reconciliation precedes any retry.

Restate runs only the existing `ZoenEffect` delivery and recovery boundary. PostgreSQL remains the authority for the order intent, attempts, provider observations, order state, and effect Settlement. No finance workflow, strategy, portfolio, or order book moves into Restate state.

### Orders and post-trade facts remain distinct

`FinanceOrderState` is an evidence-derived ADT. Every externally asserted state—submitted, accepted, working, partially filled, filled, cancel pending, canceled, replaced, rejected, or expired—contains the exact `ProviderOrderEvidence` supporting that revision. `decision-recorded` contains only the local receipt; `unknown` contains reconciliation identity and available ambiguity evidence. An operational connector status cannot construct a provider state. The release validates legal transitions, exact cumulative and leaves quantities, fill identities, prior revision, venue identity, sequences, and clocks. Reordered and duplicate messages deduplicate by provider observation identity. A bust or correction appends evidence and a later authoritative revision; it never overwrites a fill.

Each execution fill is its own evidence-backed fact with execution identity, order, branded instrument, venue, exact quantity and unit price, trade time, provider revision, data-usage decision, evidence, admitting commit, and cut. Allocation, affirmation, confirmation, clearing obligation, cash movement, security movement, fee, tax, and custody position are separate facts linked by lineage. Financial settlement is one stage in this domain chain. Zoen's `EffectSettlement` separately records what is known about one external Effect. The two cannot share a boolean status.

Positions, cash, cost basis, exposure, performance, profit and loss, risk, compliance, and transaction-cost analysis are released derived DatasetVersions. They pin input fills, corrections, corporate actions, FX, marks, calendars, algorithms, rights, quality, and field lineage. A projected position is not custody evidence. A broker or custodian statement can be admitted as rival or confirming evidence and reconciled explicitly.

### Bounded automated execution

`ExecutionMandate` is an accepted, versioned, expiring domain decision. It binds principal, full approval basis, accounts, instrument ObjectSetPlan, non-empty venues and order types, exact per-currency gross-notional limits with valuation policies, exact position and loss limits, participation and price limits, timing, compliance, kind-indexed planner artifact, rights decision, kill policy, and receipt. It authorizes only the released operation class inside those bounds.

Every child order is proposed by the pinned `ActionPlannerArtifact` and receives a fresh policy, rights, admitted-market-capture, portfolio, mandate-version, valuation, and kill-state check. Its AuthorityCommit locks mandate and portfolio state and writes `MandateReservation` with child order, exact notional, valuation read set, and commit. Concurrent children therefore cannot each spend the same remaining capacity. Ontology recomputes consequences and commits a distinct receipt and EffectIntent. The planner, model, workflow, and connector have no standing database or broker authority. Exhausted budget, expired mandate, stale market basis, uncertain position, unavailable compliance, or active kill state blocks new orders.

Emergency cancel and kill are released Actions with explicit degraded-market behavior. They may have different quorum and assurance rules, but a timeout still becomes unknown and triggers reconciliation. A cancel decision cannot claim that a venue canceled the order.

### Cross-organization execution

Broker, manager, custodian, administrator, and client Worlds exchange signed requests, observations, confirmations, and receipts under `FederationAgreement`. Each World commits independently. A federated workflow exposes rejection, partial completion, timeout, compensation, and unknown. No trade claims a distributed atomic commit across institutions.

## Consequences

- Zoen can support OMS, EMS, portfolio, risk, compliance, and post-trade product shapes without a finance-only authority kernel.
- Users see the difference between decision, submission, acceptance, fill, financial settlement, and current evidence.
- Automated trading remains possible through explicit mandates and per-order receipts, but adds latency and operational requirements.
- Corrections and rival sources preserve an auditable point-in-time history.
- Architecture supplies no market data rights, broker access, venue certification, liquidity, counterparties, regulatory approval, or support operation.

## Required journeys

1. Instrument/listing/venue identity change, corporate action, market calendar, exact decimal, and provider-symbology correction.
2. Pre-trade denial for rights, entitlement, compliance, limit, stale or gapped capture, market halt, unknown position, and expired Case.
3. Order submission with provider key, lost acknowledgement, status reconciliation, safe retry, duplicate callback, and recovery epoch.
4. Partial fills, cancel race, replace chain, overfill denial, rejection, expiry, bust, correction, late fill, and out-of-order provider messages.
5. Allocation, affirmation, confirmation, clearing, cash, custody, fee, tax, and rival statement lineage.
6. Position, cash, profit and loss, risk, and transaction-cost DatasetVersions replay exactly at old cuts and react correctly to corrections.
7. ExecutionMandate approval, concurrent per-child reservations, exact multi-currency valuation, participation/notional/position/loss limits, budget exhaustion, mandate revision/expiry, and kill action.
8. Broker, manager, and custodian federation produces full, partial, rejected, compensated, and unknown outcomes without a global cut.

## Reopen triggers

- A regulated venue requires lower-latency automated decisions. Define a narrowly delegated authority cell and released mandate semantics with equivalent evidence, kill, reconciliation, and audit. Do not give a strategy or connector ambient authority.
- A provider offers authoritative atomic cancel/replace or status lookup. Model that provider-specific evidence in the connector and released state machine. Do not weaken unknown globally.
- A new asset class requires different lifecycle facts. Extend the finance pack with separate typed Actions and observations while preserving local receipt versus external reality.
- No trigger permits a model suggestion, planner result, UI acknowledgement, local receipt, or timeout to stand in for provider or custody evidence.
