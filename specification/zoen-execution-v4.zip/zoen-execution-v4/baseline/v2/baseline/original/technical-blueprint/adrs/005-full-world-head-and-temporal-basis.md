# ADR 005: Full WorldHead and one temporal basis

Status: Accepted

## Context

An answer such as "as of cut 42" is incomplete if the active release, dense-data generation, observation manifest, or audit chain can differ. Mixing a sparse fact from one cut with a dense segment from another creates a view that never existed. Activation is similarly unsafe if it compares only a release digest or only a numeric version.

Zoen needs one compact head that identifies every component required to reconstruct and verify the World.

## Decision

The authoritative head and the only read basis are:

```ts
type WorldHead<R extends Realm> = Readonly<{
  world: WorldRef<R>;
  headVersion: HeadVersion;
  cut: WorldCut;
  release: ReleaseDigest;
  generation: DataGenerationDigest;
  observationManifest: ManifestDigest;
  auditRoot: AuditDigest;
}>;

type KnowledgeBasis<R extends Realm> = Readonly<{
  head: WorldHead<R>;
  validAt: Instant;
  beliefPolicy: SemanticId;
}>;
```

- `headVersion` is the monotonic compare-and-swap coordinate for any head-changing commit.
- `cut` is the monotonic semantic transaction boundary. It advances exactly once for every AuthorityCommit and never for ProgressCommit.
- `release` names the active immutable release.
- `generation` names the logical sparse-data generation used by reproducible reads.
- `observationManifest` names the immutable root of all visible dense observations.
- `auditRoot` commits to the ordered AuthorityCommit history through this cut.
- `world` is part of the value so a head cannot be replayed into another World.

Every authoritative read captures one full `WorldHead` at admission and wraps it in `KnowledgeBasis`; no `KnowledgeCut`, `ReadBasis`, or digest-only head alias may represent the same coordinate. `ExactReadSet` repeats the complete head and names every sparse revision, belief, policy, dense slice, and `AdmittedObservationRef` actually read. Every Case copies both values, and every receipt and release proof records the full basis it used.

A `WorldFrame` is a closed union. The `disclosed` branch contains body, evidence, gaps, uncertainty, explanation, exact reads, disclosure decision, and sealed result digest. The `redacted` branch contains only a safe reason and disclosure digest. Protected body or metadata cannot coexist with a failed final disclosure check in the type.

Sparse repositories perform temporal reads at the captured cut and generation. Dense queries resolve only segments reachable from the captured observation manifest. Policy and schema resolution use the captured release. Audit verification uses the captured audit root. No read may substitute a newer component to complete a partially stale basis.

Immediately before return, disclosure and data-usage rights are rechecked against the current principal and purpose. If either changed, the materialized values are discarded and only the redacted branch can be constructed; protected values do not leak through a Frame produced under an expired decision.

Head changes use a row lock or compare-and-swap on `(realm, world, head_version)`. The stored row, commit envelope, manifest admission, and returned receipt must agree on the complete post-commit `WorldHead`. `AuthorityCommitPayload` carries the full before head and the next head coordinates without the resulting audit root. Its digest is computed first; the next root is `H(domain, before.auditRoot, payloadDigest)`. `AuthorityCommitEnvelope.after` is exactly those coordinates plus that root. The hash construction has no self-reference.

Membership changes are head changes. `AcceptInvitation` consumes the invitation, creates membership and its receipt, and advances head version, cut, and audit root exactly once; release, generation, and manifest may remain unchanged.

Wall-clock time is evidence and scheduling input, not the authority order. Event occurrence time, ingestion time, validity interval, transaction cut, and head version remain distinct fields.

The foundation wraps `@js-temporal/polyfill` 0.5 for `Instant` and time-zone-safe calculations until native Node behavior passes parity journeys. PostgreSQL `uuidv7()` issues ordered durable record IDs and `crypto.randomUUID()` issues unsequenced correlation IDs; neither is authority order. Exact decimals and rounding use `decimal.js` 10 behind frozen released `DecimalValue` constructors. Library objects never cross a domain or public boundary, and IEEE-754 numbers never represent money.

A `Scenario` is an authority-free hypothetical computation pinned to one full head and explicit assumptions. It can inspect and consider only and returns a distinct `ScenarioFrame` that cannot satisfy an AuthorityCommit input. It has no acquire, publish, decide, Watch, Effect, or commit capability. Applying a scenario means issuing a fresh live command that reloads exact reads, authorization, release, and the current head; no scenario result or stale model context is promoted directly into truth.

## Consequences

- Any Frame, receipt, proof, or audit entry can be reproduced against one named World state.
- Cache keys and cursors become larger, but invalidation is exact.
- A manifest publication that changes visible dense data is an AuthorityCommit, not background bookkeeping.
- Per-World serialization creates a clear contention point that can be measured and moved later without changing semantics.

## Reopen triggers

- A required answer spans multiple Worlds. Define a signed multi-head snapshot rather than weakening `WorldHead`.
- One World sustains more than 500 AuthorityCommits per second, or p99 head-lock wait exceeds 50 ms for 15 minutes after nonsemantic work has been removed from the transaction.
- Reproducibility requires another mutable component. Add its digest to `WorldHead` before that component can affect authoritative reads.
- A digest algorithm becomes cryptographically unsuitable. Introduce an algorithm-tagged head version and an explicitly proven transition.
- No trigger permits returning a Frame assembled from components that did not share a captured head.
