# Decision register

This register is the compact map. The ADRs and references contain the evidence and exact protocol. `Deferred` means the product contract has a stable seam and an evidence gate; it does not mean the possibility is excluded.

## Accepted constitution

| ID | Decision | Why | Record |
|---|---|---|---|
| D01 | Exactly three products: Better Auth Door, Eve, Ontology | Separates identity, relationship and governed meaning without inventing services | [ADR 001](adrs/001-three-products-one-typescript-application.md) |
| D02 | One Node 24 TypeScript deployable; all Zoen-owned domain/application/runtime code in strict TypeScript; deep ownership modules and static dependency rules | Maximum iteration speed and one semantic implementation while supported third-party runtimes stay behind ports | [ADR 001](adrs/001-three-products-one-typescript-application.md), [ADR 002](adrs/002-deep-modules-and-boundary-tooling.md) |
| D03 | pnpm 11 workspaces, TypeScript 6.0.3, Ultracite pedantic on ESLint/Prettier/Stylelint, zero warnings | Strict dependency visibility and complete current type-aware coverage | [Technology](reference/technology-stack.md), [OSS](reference/oss-selection.md) |
| D04 | Hono public boundary and official MCP v2 split packages | One Fetch-native edge, native interface forms, no duplicate business logic | [ADR 014](adrs/014-public-interfaces-and-semantic-parity.md) |
| D05 | Better Auth proves identity only | Presence is evidence; a purpose-bound World grant creates authority | [ADR 003](adrs/003-door-presence-and-purpose-bound-authority.md) |
| D06 | PostgreSQL 18 is sparse semantic authority; raw `pg`, explicit SQL, no authority ORM | Transactions, locks, constraints, RLS and retries must remain visible | [ADR 008](adrs/008-postgresql-authority-and-evidence-admission.md), [Database access](reference/database-access.md) |
| D07 | One complete `WorldHead` and one serializable `AuthorityCommit` per semantic cut | No half-current release, generation, manifest or audit root | [ADR 005](adrs/005-full-world-head-and-temporal-basis.md), [ADR 006](adrs/006-authority-progress-and-idempotency.md) |
| D08 | `ProgressCommit` is separate, weaker, and allowlisted | Operational recovery cannot silently change World meaning | [ADR 006](adrs/006-authority-progress-and-idempotency.md) |
| D09 | Events are selective domain consequences; one ordered commit envelope and transactional outbox | Event orientation preserves causality without turning every row write into theater | [ADR 007](adrs/007-events-outbox-and-interaction-journal.md) |
| D10 | Immutable raw evidence precedes admission; evidence, belief and resolution remain distinct | Zoen can explain what was observed, selected and known at a cut | [ADR 008](adrs/008-postgresql-authority-and-evidence-admission.md) |
| D11 | Apache Parquet is the permanent dense-observation format; content-addressed manifest DAG is authority | Dense history remains portable, immutable, temporal and engine-independent | [ADR 009](adrs/009-immutable-parquet-and-manifest-dag.md) |
| D12 | DuckDB Node Neo is the first bounded Parquet reader and writer | Strong columnar execution with no new service; replaceable by result contract | [Data and Parquet](reference/data-events-parquet.md) |
| D13 | `WorldRelease` is canonical JSON with a closed total domain IR; trusted handlers are image-pinned | Meaning remains reviewable, deterministic, signable and surface-generating | [ADR 010](adrs/010-closed-json-release-ir-and-no-wasm-v1.md) |
| D14 | Cedar performs horizontal admission/disclosure only | Policy does not become domain meaning; domain code does not accrete ad hoc access checks | [ADR 011](adrs/011-cedar-only-for-horizontal-authorization.md) |
| D15 | Release proof, per-World preparation and activation are separate facts; evaluate and deploy the same image digest | No unproved release, stale preparation, rebuild gap or partially active meaning | [ADR 012](adrs/012-release-proof-preparation-and-activation.md) |
| D16 | Eve owns conversation durability and native attempt lifecycle; plain typed `EveAttemptContext` plus Eve hooks implement scoped composition | The relationship has one replay/lifecycle owner while retaining the useful DeepSeek/Cordis design principles | [ADR 013](adrs/013-eve-cordis-and-model-attribution.md) |
| D17 | Restate runs `ZoenEffect` only; Postgres owns Intent, Attempt and Settlement; uncertainty is `Unknown` | Durable recovery without pretending to control external reality | [ADR 015](adrs/015-restate-effects-and-honest-settlement.md), [Rivet/Restate](reference/rivet-vs-restate.md) |
| D18 | Workshop mini-apps are Living World/Ontology surfaces; general compute and executable apps are governed artifacts outside authority; MCP Apps is the portable delivery target | Rich applications and analytics reuse authorized Frames and Actions instead of becoming a fourth product, second ontology, or Rivet-owned protocol | [ADR 014](adrs/014-public-interfaces-and-semantic-parity.md), [ADR 019](adrs/019-programmable-compute-and-governed-mini-apps.md) |
| D19 | Only user journeys are tests; real dependencies, real public boundaries, fault injection, no mocks/fakes/stubs | Evidence follows the product promises and catches distributed failure semantics | [ADR 016](adrs/016-user-journeys-and-ci-evidence.md) |
| D20 | One Fly app and one steady-state Machine initially; one signed OCI artifact contains two supervised Node processes; expansion follows evidence-gated vertical slices | Minimum deployment units without inventing an unsupported Eve mounting API or speculative scale architecture | [ADR 017](adrs/017-deployment-security-observability-and-recovery.md), [ADR 018](adrs/018-build-sequence-scale-and-evidence-gated-evolution.md), [ADR 029](adrs/029-eve-nitro-runtime-and-workflow-store.md) |
| D21 | Live observations are entitled transient overlays; periodic Parquet sealing and exact Action capture create authority | Preserves terminal latency without one World cut per tick or unproved live values in decisions | [ADR 020](adrs/020-live-observation-plane-and-action-capture.md) |
| D22 | Source, effect and channel integrations use signed isolated `ConnectorArtifact` and `ConnectorRun` contracts | Opens an integration ecosystem without loading third-party code or ambient credentials into authority | [ADR 021](adrs/021-signed-isolated-connector-artifacts.md) |
| D23 | Interfaces, object sets, functions, planner artifacts, change subscriptions and data flows are released semantic contracts | Creates target seams for the public Palantir application and data-building categories without public SQL or a second mutation system | [ADR 022](adrs/022-semantic-computation-subscriptions-and-data-flows.md) |
| D24 | Source rights form a non-widening positive-grant algebra; one cell owns one World epoch; federation composes signed Frames, not commits | Licensed data and institutional/edge operation remain enforceable without fake global authority | [ADR 023](adrs/023-rights-cells-edge-and-federation.md) |
| D25 | Model calls and retrieval are attributed computation; headless agents use PostgreSQL workflows and fresh sessions; Eve owns governed conversation spaces | Agents and professional collaboration gain breadth without standing authority or a second conversation owner | [ADR 024](adrs/024-models-retrieval-agents-and-conversation-spaces.md) |
| D26 | Studio, CLI and public protocols form one developer platform; signed `PackArtifact` values install only through proof and release proposals | Meaning, apps, flows and integrations can compound without a permission-granting plugin marketplace | [ADR 025](adrs/025-developer-platform-and-pack-artifacts.md) |
| D27 | Finance execution is a chain of released Actions and evidence-backed order, fill, clearing and custody facts | Local decision, provider acceptance and financial settlement remain honest and separately auditable | [ADR 026](adrs/026-finance-execution-lifecycle.md) |
| D28 | Launch channels are web, Kapso WhatsApp, native Eve Telegram, and Resend email; every provider route requires durable ingress before acknowledgement; `ZoenChatStateAdapter` implements Chat SDK's public `StateAdapter` with raw `pg` in a dedicated `eve_channels` database | Eve remains one relationship while provider transport state stays operational, migrator-owned, isolated, and replaceable | [ADR 027](adrs/027-eve-channel-bridges-and-durable-admission.md), [Channels](reference/messaging-channels.md) |
| D29 | `ChartDocument` owns semantic visualization; modular ECharts 6 is the only launch renderer and TanStack Charts remains EvaluationWorld-only | Chart meaning, rights, evidence, accessibility, export, and channel fallback survive renderer changes | [ADR 028](adrs/028-semantic-charts-and-asymmetric-renderers.md), [Charts](reference/charting-selection.md) |
| D30 | Exact-pinned `eve@0.52.0` runs as its supported Nitro service on loopback; Hono proxies both required prefixes and exposes only an authenticated typed capability client; exact-pinned Workflow Postgres owns an isolated database | Follows Eve's public self-hosting contract without giving Eve authority credentials or creating a second public service | [ADR 029](adrs/029-eve-nitro-runtime-and-workflow-store.md) |
| D31 | Production, EvaluationWorld, and recovery are distinct realms with separate credentials, stores, effects, channels, and expiry/cleanup proof | Evaluation can execute real journeys without gaining or contaminating live authority | [ADR 004](adrs/004-realms-and-isolated-evaluation-worlds.md) |
| D32 | Eve uses an explicit launch allowlist: only `ask_question` and generated approval-explicit `inspect_*`/`propose_*` tools; dangerous defaults and all optional tools are absent; byte attachments cannot stage; a custom disabled `SandboxBackend` fails closed | Eve's permissive defaults otherwise create shell, file, web, delegation, attachment-staging, and fallback-backend reach that Zoen does not need | [ADR 029](adrs/029-eve-nitro-runtime-and-workflow-store.md), [Security](reference/security-and-operations.md) |

## Accepted target contracts, implementation evidence still required

| Target | Constitutional shape | First implementation candidate | Gate |
|---|---|---|---|
| Executable Workshop mini-apps | `MiniAppManifest` → immutable `MiniAppArtifact`; MCP Apps-compatible `ui://` delivery; sandbox has only host capability bridge; drafts in EvaluationWorld; signed publication and static/text fallback | First-party Eve host; Rivet Dynamic Apps for generation/build/runtime | Sandbox denial, deterministic build/pins, independent-host portability, replay/export, resource limits, runtime/UI-host failure fallback, non-preview pinned Rivet release |
| Long-lived governed playbooks | Released state machine composes Watches, Cases, Scenarios and Effects; canonical process state remains PostgreSQL authority | Zoen interpreter first; Rivet Workflows only as recoverability adapter | Crash/replay/version/rollback, no second truth, clear queue acknowledgement, lower operator/code cost than explicit interpreter |
| Programmable analytics | Cut-pinned read-only `AnalysisRun` produces an immutable evidence artifact; publishing or acting requires admission/Action | Isolated TypeScript worker; future WASI/OCI executor adapter | No ambient authority, deterministic inputs, budgets, lineage, egress policy, replay, kill and cleanup |
| Agents and evaluation | Released `AgentDefinition`, capability catalog, context compiler, checkpoints and eval suite; all consequences become Cases/Actions | Eve attempt engine plus EvaluationWorld | Attribution, disclosure, tool denial, crash recovery, approval, budget, regression and same-image proof |
| OAG-grade retrieval | Released hybrid retrieval plan over authorized objects/evidence; result pins cut, model/index and exact references | PostgreSQL FTS + pgvector projection | Pre-scan disclosure, reproducibility at cut, no forbidden-vector inference, retrieval quality corpus |
| Terminal-grade live observations | `LiveFeedDefinition` → short `LiveSubscription` → basis-bearing transient envelopes; periodic immutable Parquet seal; Actions admit an exact `CapturedObservationRef` | Signed source ConnectorArtifact + live gateway + SSE | Unconflated and latest-value feeds, continuous entitlement, gaps/staleness, reconnect from sealed basis, Action capture race, compaction and historical replay |
| Governed data flows | Released acyclic `DataFlowDefinition`; PostgreSQL-owned run; immutable DatasetVersion with field lineage, rights meet and tri-state quality; AuthorityCommit publication | Zoen scheduler plus DuckDB and isolated executors | Schema/lineage determinism, incremental replay, failed/unknown quality, rights non-widening, kill recovery and atomic admission |
| Integration ecosystem | Signed/revocable source, effect and channel ConnectorArtifacts run under short credential, egress and resource leases; outputs are captures, observations or Eve ingress, never authority | Isolated TypeScript/Node runner first; OCI profile later | Malicious package, egress/secret denial, SBOM/signature/revocation, idempotency/reconciliation, runner kill and provider certification |
| Institutional and edge federation | CellDirectory assigns one authority cell per World epoch; offline authority uses a separate edge World; FederationAgreement and FederatedFrame preserve each component basis | One Fly cell first; additional authority/read/dense/compute/edge cells later | Epoch move, split-brain denial, offline operation, revocation, regional isolation, partial cross-World outcomes and no cross-cell transaction |
| Finance execution | Place/cancel/replace/allocate/affirm/settle Actions; captured market basis; versioned order/fill/correction/clearing/custody facts; bounded ExecutionMandate | Finance Pack + broker/venue ConnectorArtifacts | Pre-trade/staleness, lost acknowledgement, reconciliation before retry, partial fill, bust/correction, mandate limits/kill and exact decimal positions |
| Multi-language ecosystem SDKs | Generated clients are projections of `SurfaceManifest`, never alternate domain implementations | TypeScript first; OpenAPI-generated Python/Java later | Semantic digest parity and release-specific compatibility journeys |

## Deliberately deferred implementations

- TypeScript 7.1+ and Ultracite Oxlint/Oxfmt, pending compiler API and boundary-tool parity.
- Kysely for a read-only projection package, pending repeated measured mapping defects.
- Rivet Actors as `EveSessionRuntimePort`, pending proof that Eve's event history remains the sole durable truth.
- `@deepseek-ai/cordis` as an Eve attempt-composition adapter, EvaluationWorld-only unless three unrelated product needs show Eve-native hooks plus plain typed contexts are insufficient and replay/lifecycle ownership remains unambiguous.
- Rivet Workflows as an effect or playbook runtime adapter, pending the exact crash/version/topology gates.
- Rivet Dynamic Apps as executable mini-app adapter, pending its Preview exit and sandbox/replay/export proof.
- The current `@modelcontextprotocol/ext-apps` package, pending compatibility with the official split MCP v2 SDK or a smaller conformance-proved adapter; do not install a second legacy MCP core line.
- Wasm Component executors for pure computation, pending three unrelated expressiveness gaps and no-I/O determinism proof.
- Rust/DataFusion only behind the dense query port, pending a representative 2x/capability gate.
- Arrow as bounded in-memory interchange, never as durable identity.
- WebSocket only for a real bidirectional streaming experience; commands plus SSE remain the default.
- More Machines, authority cells and regions beyond the accepted Hono/Eve two-process topology only after availability, isolation or sustained scaling evidence.
- A specialized search, streaming or graph engine only behind released plans after PostgreSQL/DuckDB evidence shows the need.
- A distributed live-feed or data-flow engine only behind `LiveObservationPort` or `DataFlowRuntimePort`; its checkpoints never become authority.
- Offline authority for the same World in two cells; disconnected operation uses a separate edge World until a proved single-writer epoch-transfer protocol exists.
- Linq channel support, with no launch package, route, credential, `ChannelKind`, endpoint variant, or journey. A later ADR must prove its commercial contract, identity, consent, admission, retention, delivery, and real-account behavior.

## Forbidden by current constitution

- Redis in any role. PostgreSQL protocols and the selected owner-specific durable runtimes must solve the required work without introducing another cache, queue, lock, session, or coordination truth.
- Generic CRUD, `invoke`, SQL, Cedar or object-store APIs as public domain surfaces.
- An ORM entity model or generated migration model as the definition of authority.
- Unit tests, mocks, fakes, stubs, `vi.mock`, snapshot forests or import-graph tests.
- Better Auth roles, channel presence, remembered Focus or model confidence as World authority.
- Restate owning conversation, Watches, releases or local World truth.
- Cordis owning conversation durability, workflow replay, or a second attempt lifecycle beside Eve.
- Eve default `bash`, `read_file`, `write_file`, `web_fetch`, `web_search`, `agent`, or `todo`; opt-in `glob`, `grep`, `Workflow`, or `sleep`; implicit tool approval; skills/connections at launch; `defaultBackend()`; `ctx.getSandbox()`; or byte-backed attachment staging into an Eve session.
- `@chat-adapter/state-pg` as a launch dependency, runtime DDL, a shared channel schema, or an Eve-channel role with DDL privileges.
- Rivet actor state, workflow state or mini-app state becoming canonical World truth.
- Release-supplied JavaScript, TypeScript, SQL, URL or package running inside the authority process.
- Executable mini-app or analytics code with direct PostgreSQL, secrets, unrestricted filesystem or arbitrary egress.
- A generic plugin marketplace in which installation grants ambient authority.
- A ConnectorArtifact loaded into the authority process, given a broad provider secret, or allowed to write a receipt, Settlement, manifest head or interaction truth.
- A live tick treated as a WorldFrame fact, model citation, Watch transition or Action dependency without immutable capture and admission.
- A data-flow checkpoint, model output, retrieval rank or DatasetVersion proposal treated as published World truth.
- Rights composition that unions grants, drops lineage or interprets an unavailable entitlement as permission.
- One World with simultaneous authority cells, a synthetic global cut, or a cross-cell/cross-World AuthorityCommit.
- Conversation-space participation treated as World membership or a transcript message treated as a Case contribution.
- A pack signature treated as installation, permission, credential, activation or network authority.
- An order DecisionReceipt represented as broker acceptance, a timeout represented as rejection, or estimated positions represented as custody facts.
- A provider timeout represented as success or failure without evidence.
- Mutable Parquet objects, object-store listing as truth, or dense points copied into sparse semantic events.
- Compatibility aliases, dual read/write, shadow APIs or preservation work for disposable pre-launch data.

## Decision hygiene

Every dependency and deferred mechanism has one owner, port, failure contract, removal story and evidence gate. Reopening a decision requires a successor ADR with measurements, threat-model changes, migration/rollback plan and affected journeys. Greater ambition may widen the product capability contract. It may not erase authority, provenance, temporal basis or honest uncertainty.
