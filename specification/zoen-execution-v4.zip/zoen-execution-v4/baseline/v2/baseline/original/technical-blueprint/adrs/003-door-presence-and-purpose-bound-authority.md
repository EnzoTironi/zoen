# ADR 003: Door, presence, and purpose-bound authority

Status: Accepted

## Context

An authenticated request is not automatically authorized to act in a World. Messaging channels make this especially easy to get wrong: a valid Kapso, Telegram, or Resend webhook proves only a provider-side event for an address, not that the human behind it has proved identity for a sensitive decision. A conversational focus also cannot become ambient authority.

Palantir-grade governance for ordinary people requires authority to be explicit, narrow, inspectable, and short-lived without making every low-risk interaction feel like enterprise login ceremony.

## Decision

- Better Auth 1.7 is the identity-only SessionDoor. Door validates audience, maps its stable authenticated subject to a Zoen `PrincipalId`, and records authentication strength, session, delegated client, and revocation state. `IdentityProof` carries principal, credential kind and reference, assurance, authentication time, and expiry. It carries no World, membership, role, delegation, relationship, capability, or purpose. Better Auth roles and OAuth scopes never decide Ontology permissions.
- Browser sessions use secure, HTTP-only, same-site cookies, exact-origin checks, CSRF protection, rotation, and server-side revocation. The CLI uses OAuth 2.1 device authorization, stores refresh credentials only in the operating-system keychain, and uses PKCE loopback as fallback. MCP uses resource-bound OAuth metadata, JWKS verification, and DPoP where the client supports it. Dynamic client registration stays disabled until an interoperability journey proves a reviewed registration flow.
- Channel adapters authenticate the provider and resolve a `ChannelPresence`. Presence is a delegated client assertion, never a `HumanIdentityProof`.
- Door emits no `WorldId` from user input. Ontology resolves membership only after a valid identity proof and rejects cross-realm combinations before existence disclosure.
- A `Focus` may remember the conversational subject, World, Case, view, time intent, and opaque references. It carries no grant, proof, membership, selected evidence payload, authorized Case view, DecisionHandle, or disclosed Notice content and cannot be presented to Ontology as authority.
- Ontology creates a server-side `WorldSession` after membership resolution. It contains the principal, realm, World, membership version, authentication strength, authorized views, and expiry. It is never serialized to a client.
- Sensitive acts require an explicit step-up ceremony. The resulting `DecisionHandle` is a random 256-bit secret; only its digest is stored. Its database record is bound to principal, Door session, purpose, Case version, authorization decision, view, authentication strength, and expiry. It is single-purpose and consumed transactionally.
- Authority is least-privileged by operation. Read, propose, approve, activate, disclose, execute, and administer are separate capabilities. Membership does not imply all of them.
- Enumeration-resistant boundaries collapse not-found and forbidden responses where existence itself is protected. Logs record stable internal reason codes without disclosing protected identifiers to the caller.
- Human-facing consent text states actor, action, World, every release-marked decision-required consequence, and expiry before a decision is accepted. If disclosure policy withholds a required consequence, Door cannot issue a DecisionHandle for that view. A generic "confirm" button is insufficient.

## Consequences

- Eve can stay conversational for exploration while Door becomes visible exactly when human proof or consequential consent is required.
- Every sensitive commit can prove which human, session, purpose, Case version, and policy decision authorized it.
- Channel-only users must open a Door ceremony for sensitive acts. This is intentional friction.
- Revocation and step-up records become durable security state and must participate in backup, retention, and incident review.

## Reopen triggers

- A regulated authentication method requires hardware-backed credentials or a different assurance model; add it behind Door without weakening `WorldSession` or `DecisionHandle` bindings.
- Device authorization is unavailable for a target CLI environment and PKCE loopback cannot operate there; adopt another OAuth 2.1 public-client flow after threat review.
- Provider support makes sender-bound MCP tokens universal; require DPoP rather than treating it as capability-dependent.
- A journey demonstrates that a low-risk operation is unnecessarily blocked by step-up; change the release-owned materiality rule, not the distinction between presence and identity.
- Better Auth cannot meet a required revocation, assurance, or audit property after a documented remediation attempt.
