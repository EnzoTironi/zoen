# Candidate B — the TypeScript constitution

Status: leading greenfield hypothesis, not a compatibility plan.  
Technology snapshot: 2026-09-04. Every direct and transitive dependency is committed in `package-lock.json`; version changes require the affected journeys.

## The bet

Build Zoen as one TypeScript application, one Node process per Fly Machine, one deployable Fly app, and one authoritative PostgreSQL database. Keep three products—not three services:

1. **Door** proves identity with Better Auth.
2. **Ontology** publishes meaning and governs Frames, Cases, Watches, Notices, Receipts, Effects, and Settlements through CLI, JSON API, and MCP.
3. **Eve** owns conversation, continuity, interruption, wording, and channel delivery.

The application is a modular monolith. Modules call typed in-process ports. PostgreSQL is the concurrency and integrity machine. Tigris stores immutable bytes and columnar segments. DuckDB reads the dense plane. Restate durably executes only Ontology `ZoenEffect`s. There is no Redis, broker, ORM, generic workflow engine, or internal HTTP.

TypeScript is used at its strongest honest boundary:

- opaque types and capability objects make invalid composition difficult for trusted code;
- Zod parses every untrusted value and every database row;
- module exports and dependency rules prevent accidental authority leaks;
- PostgreSQL constraints, roles, RLS, row locks, compare-and-swap, and serializable transactions enforce the invariants that erased TypeScript types cannot;
- cryptographic digests bind canonical bytes, releases, Frames, views, read sets, and prepared activations.

This is more ambitious than a polyglot split because the whole product grammar remains inspectable in one language and one process. It is more subtractive because language boundaries are introduced only if measurement proves a hot kernel, never as speculative architecture.

## Caller first: what a person experiences

### First minute

Enzo signs in. Door returns an identity proof; it does not create a World implicitly. Eve asks only enough to become useful. The application selects exactly one bootstrap command:

```ts
const proof = await door.requireProof(request);

const bootstrap = inviteToken
  ? await ontology.acceptInvitation(proof, {
      invitation: inviteToken,
      operationKey,
    })
  : await ontology.createPersonalWorld(proof, {
      locale: "pt-BR",
      operationKey,
    });

const session = await ontology.enterWorld(proof, {
  world: bootstrap.world,
  purpose: purpose("answer:first-frame"),
  requestedCapabilities: [semanticId("money.position.inspect")],
});

const frame = await session.inspect({
  capability: semanticId("money.position.inspect"),
  input: { account: "main" },
});
```

`CreatePersonalWorld` creates a new World, genesis `WorldHead`, owner membership, and genesis receipt in one transaction. `AcceptInvitation` locks and consumes an existing invitation and adds a membership; the database makes a WorldHead change by that commit kind impossible.

Eve renders the returned `WorldFrame`, including its cut, freshness, evidence, uncertainty, and authorized absence. Focus remembers the unresolved conversational thread, but carries no grant, session, or disclosed Frame content as authority.

### First day

The person says “me avisa se meu caixa ficar perigoso.” Eve obtains a fresh World session and calls a released verb:

```ts
const result = await session.createWatch({
  capability: semanticId("money.reserve.watch"),
  input: { floor: decimal("10000.00"), currency: currency("BRL") },
  operationKey,
});
```

The Watch stores durable intent, release binding, purpose, checkpoint, detector version, and deduplication state. It does not create noise for unchanged observations. A material committed `WorldTransition` atomically advances the checkpoint and creates one `Notice` plus its outbox entry.

Eve receives only `NoticeId`. On arbitration and again immediately before composition it calls `openNotice`; Ontology reauthorizes membership, delegation, purpose, relationship, Watch state, and current disclosure. If the person lost access while a notice was deferred, Eve gets `Suppressed` or `Redacted`, never stale facts.

### First week

The person asks Zoen to protect a reserve. One domain Action either commits immediately, returns an impossibility, or forms one canonical Case:

```ts
const formed = await session.formCase({
  action: semanticId("money.reserve.protect"),
  intent: { amount: decimal("10000.00"), currency: currency("BRL") },
  operationKey,
});

const opened = await session.openCase(formed.case, purpose("decide:reserve"));
// opened.view is principal-specific; the underlying Case is not.

await session.contributeDecision({
  handle: opened.decisionHandle,
  decision: { kind: "approve" },
  operationKey: nextOperationKey,
});
```

Every eligible principal opens the same protected Case through a fresh session and receives an `AuthorizedCaseView` plus a principal-bound, expiring, database-backed `DecisionHandle`. Contributions are durable. The final contribution revalidates eligibility and the exact read set, evaluates the released quorum rule, and performs one `AuthorityCommit`. The commit writes semantic changes, `DecisionReceipt`, deterministic `EffectIntent`s, meaningful transitions, and outbox rows atomically. External success arrives later as a separate `Settlement`.

### The same product without Eve

The release compiler projects the same semantic capability to native surfaces:

```text
CLI   zoen money reserve inspect --world <id> --account main
API   POST /ontology/v1/worlds/<id>/money/reserve/inspect
MCP   zoen.money.reserve.inspect
UI    Living World → Money → Reserve → Inspect
```

They differ in interaction, not meaning. Every surface resolves a Door proof, opens a purpose-bound session, invokes the same Ontology port, and renders the same typed result. API and MCP never expose a more powerful generic database verb.

## Runtime and exact baseline

| Concern | Baseline | Decision |
|---|---:|---|
| Runtime | Node.js `24.20.0` LTS | ESM, built-in `fetch`, `crypto`, `AsyncLocalStorage`, `worker_threads`, and `util.parseArgs`; compiled JavaScript runs in production. |
| Language | TypeScript `6.0.2` | Install exactly as `"typescript": "npm:@typescript/typescript6@6.0.2"`: strict compiler with a stable programmatic API. TypeScript 7.0.2 is deliberately deferred because 7.0 has no compiler API and official guidance requires a TS 6 sidecar for tools such as typescript-eslint. Reopen at TS 7.1 ecosystem parity. |
| Packages | npm workspaces, lockfile v3 | No workspace orchestrator. `npm ci` is the only install in CI and images. |
| HTTP | Fastify `5.12.3` | Public HTTP, webhooks, SSE, validation hooks, and structured logging. |
| Runtime schemas | Zod `4.5.4` | One boundary schema system; Zod 4 emits JSON Schema for HTTP, MCP, release artifacts, and generated clients. |
| PostgreSQL client | `pg` `8.23.0`, `@types/pg` `8.23.1` | Low-level parameterized SQL and explicit transaction ownership; no ORM/query builder. |
| Identity | Better Auth `1.7.2` | PostgreSQL adapter in isolated `auth` schema; only Door imports it. |
| MCP | `@modelcontextprotocol/core`, `server`, and `node` `2.0.0` | Streamable HTTP and stdio adapters generated from the release catalog. |
| Durable Effects | `@restatedev/restate-sdk` `1.17.0` | Only `ZoenEffect`; signed Restate endpoint on the same Node process. |
| Dense engine | DuckDB `1.5.5`, `@duckdb/node-api` `1.5.5-r.4` | Primary Node Neo client; embedded queries over immutable Parquet, never authority writes. |
| Object storage | `@aws-sdk/client-s3` `3.1126.0` + Tigris | S3-compatible immutable evidence, artifacts, and dense segments. |
| Web | React/React DOM `19.2.8`, React Router `8.3.1`, Vite `8.2.2` | One accessible client for Door, Eve, Living World, and membership workbench; no React Server Components. |
| Logs | Pino `10.3.1` | Structured JSON logs with explicit redaction. |
| Telemetry | OpenTelemetry API/Node SDK and OTLP HTTP exporters `0.222.0` | Traces and metrics; OTel logs remain non-authoritative and Pino-owned. |
| Journeys | Playwright `1.62.1` | Browser, HTTP, CLI, and process orchestration through public surfaces. |
| Static constitution | ESLint `10.10.0`, typescript-eslint `8.69.0`, dependency-cruiser `18.2.0` | Type discipline and import-graph locks; never architecture tests. |

Provider adapters use official SDKs behind `ModelPort`—initially `openai` `7.10.0` for OpenAI-compatible endpoints and `@anthropic-ai/sdk` `0.123.0`. Eve owns provider selection, attempts, and streaming. Ontology never imports a model SDK.

Version evidence is recorded in `docs/technology-baseline.json` with date, package integrity, official source, and reopen condition. A Renovate-like bot may propose upgrades, but no automatic merge crosses journey evidence.

## One coherent process

Each Fly Machine runs one compiled entrypoint and one Node OS process:

```text
Node process
├── Fastify listener :8080
│   ├── Better Auth /api/auth/*
│   ├── Eve /eve/v1/*
│   ├── Ontology JSON /ontology/v1/*
│   ├── MCP Streamable HTTP /ontology/mcp
│   ├── web assets + SSE
│   └── Kapso /eve/v1/kapso; Telegram /eve/v1/telegram
├── Restate Node handler :9080 (identity-verified; ZoenEffect only)
├── background coordinator
│   ├── Watch/outbox leases
│   ├── source acquisition leases
│   ├── projection and cleanup leases
│   └── Eve wakeups
└── bounded worker_threads
    ├── release compilation/replay
    └── DuckDB dense queries/transforms
```

There is no in-memory leader, correctness lock, durable queue, or timer. Background loops query due rows, claim short leases with `FOR UPDATE SKIP LOCKED`, and use `LISTEN/NOTIFY` only as a latency hint. Restarting any process loses only caches and live token chunks. Multiple identical Machines scale horizontally because PostgreSQL owns leases, idempotency, cuts, and authority.

The immutable release cache, Zod validator cache, and DuckDB result cache are keyed by content digest and may vanish at any time. Cache misses affect latency, never behavior.

## Types: compile-time guidance and runtime truth

### Foundations

```ts
declare const brand: unique symbol;
export type Opaque<T, Name extends string> = T & {
  readonly [brand]: Name;
};

export type Realm = "live" | "evaluation";
declare const realmBrand: unique symbol;

export type RealmRef<R extends Realm> = Readonly<{
  realmId: Opaque<string, "RealmId">;
  kind: R;
}> & { readonly [realmBrand]: R };

export type WorldRef<R extends Realm> = Readonly<{
  realm: RealmRef<R>;
  worldId: Opaque<string, "WorldId">;
}> & { readonly [realmBrand]: R };

export type Cut = Opaque<bigint, "WorldCut">;
export type ReleaseDigest = Opaque<string, "sha256:WorldRelease">;
export type DataGeneration = Opaque<string, "sha256:DataGeneration">;
export type OperationKey = Opaque<string, "OperationKey">;
export type PrincipalId = Opaque<string, "PrincipalId">;
export type Purpose = Opaque<string, "Purpose">;

export type Result<T, E extends ZoenError> =
  | Readonly<{ ok: true; value: T }>
  | Readonly<{ ok: false; error: E }>;
```

Opaque constructors are not exported. Boundary packages export parsers such as `parseWorldId(unknown): Result<WorldId, InvalidInput>`. `Readonly`, brands, and generics are developer aids only: JavaScript mutation, `as unknown as`, or malicious code can forge them. Runtime discriminants, canonical parsers, database context, RLS, and composite foreign keys are the authority.

Expected failures are closed unions, not thrown exceptions:

```ts
type ZoenError =
  | { readonly code: "invalid_input"; readonly issues: readonly Issue[] }
  | { readonly code: "not_authorized" }
  | { readonly code: "not_found_or_withheld" }
  | { readonly code: "stale_frame"; readonly currentCut: Cut }
  | { readonly code: "stale_case"; readonly caseVersion: bigint }
  | { readonly code: "idempotency_conflict" }
  | { readonly code: "release_incompatible"; readonly reason: string }
  | { readonly code: "temporarily_unavailable"; readonly retryAfterMs?: number };
```

Adapters may catch unknown operational exceptions, classify them, attach a trace ID, and return a closed external error. Domain code does not throw for ordinary outcomes. Exhaustive switches end in `const unreachable: never = value`.

### Door and purpose-bound authority

```ts
export interface IdentityProof {
  readonly principal: PrincipalId;
  readonly sessionId: Opaque<string, "DoorSessionId">;
  readonly authTime: number;
  readonly assurance: "session" | "step_up";
  readonly expiresAt: number;
}

export interface SessionDoor {
  requireProof(request: RequestLike): Promise<Result<IdentityProof, DoorError>>;
  requireStepUp(proof: IdentityProof, reason: Purpose): Promise<Result<IdentityProof, DoorError>>;
}

declare const sessionSeal: unique symbol;
export interface WorldSession<R extends Realm> {
  readonly world: WorldRef<R>;
  readonly principal: PrincipalId;
  readonly purpose: Purpose;
  readonly expiresAt: number;
  readonly [sessionSeal]: R;

  inspect<I, O>(request: InspectRequest<I>): Promise<Result<WorldFrame<R, O>, InspectError>>;
  formCase<I>(request: FormCaseRequest<I>): Promise<Result<CaseFormed<R>, ActionError>>;
  openCase(ref: CaseRef<R>, purpose: Purpose): Promise<Result<OpenedCase<R>, CaseError>>;
  contributeDecision(request: DecisionRequest): Promise<Result<ContributionResult<R>, CaseError>>;
  createWatch<I>(request: CreateWatchRequest<I>): Promise<Result<WatchRef<R>, WatchError>>;
  openNotice(ref: NoticeRef<R>, purpose: Purpose): Promise<Result<NoticeDisclosure<R>, NoticeError>>;
  openScenario(frame: FrameRef<R>): Promise<Result<ScenarioSession<R>, ScenarioError>>;
}
```

Only `OntologyGateway.enterWorld(proof, request)` creates the concrete class. Its constructor and mutable context are package-private. Every gateway entry checks expiry and opens a scoped database transaction; consequential operations require a fresh proof and may require step-up. A WorldSession is never serialized. HTTP cookies, API tokens, CLI credentials, and MCP authorization are inputs to Door, not alternative authorities.

### Frame, absence, and evidence

```ts
type AuthorizedAbsence =
  | { readonly kind: "known_absent"; readonly basis: EvidenceRef }
  | { readonly kind: "unknown"; readonly missing: readonly SemanticId[] }
  | { readonly kind: "withheld" }; // never explains the hidden fact

export interface WorldFrame<R extends Realm, Body = unknown> {
  readonly ref: FrameRef<R>;
  readonly world: WorldRef<R>;
  readonly release: ReleaseDigest;
  readonly generation: DataGeneration;
  readonly cut: Cut;
  readonly asOf: string;
  readonly body: Body;
  readonly evidence: readonly EvidenceRef[];
  readonly absence: readonly AuthorizedAbsence[];
  readonly freshness: Freshness;
  readonly uncertainty: readonly Uncertainty[];
  readonly readSetDigest: Opaque<string, "sha256:ReadSet">;
  readonly disclosureDigest: Opaque<string, "sha256:Disclosure">;
}
```

The frame body is validated against the active release schema before leaving Ontology. A persisted Frame envelope binds the canonical body digest, release, generation, cut, read set, and disclosure decision. Sensitive evidence is referenced, not copied into every row.

### One canonical Case, many authorized views

```ts
export interface CanonicalActionCase<R extends Realm> {
  readonly ref: CaseRef<R>;
  readonly action: SemanticId;
  readonly release: ReleaseDigest;
  readonly intentDigest: Digest;
  readonly readSetDigest: Digest;
  readonly decisionRuleDigest: Digest;
  readonly version: bigint;
  readonly expiresAt: string;
  readonly state: "open" | "decided" | "expired" | "superseded";
}

export interface AuthorizedCaseView<R extends Realm> {
  readonly case: CaseRef<R>;
  readonly principal: PrincipalId;
  readonly caseVersion: bigint;
  readonly consequences: readonly AuthorizedConsequence[];
  readonly uncertainty: readonly Uncertainty[];
  readonly quorum: AuthorizedQuorumView;
  readonly expiresAt: string;
  readonly viewDigest: Opaque<string, "sha256:CaseView">;
}

export type DecisionHandle = Opaque<string, "DecisionHandle">;

export type OpenedCase<R extends Realm> = Readonly<{
  view: AuthorizedCaseView<R>;
  decisionHandle?: DecisionHandle;
}>;

export interface DecisionContribution {
  readonly case: CaseId;
  readonly principal: PrincipalId;
  readonly caseVersion: bigint;
  readonly viewDigest: Digest;
  readonly authorizationDigest: Digest;
  readonly decision: CanonicalDecision;
  readonly contributedAt: string;
}
```

The handle is 256 random bits. Only its SHA-256 digest is stored, bound to principal, session, purpose, Case version, view digest, authorization digest, and expiry. It conveys no authority alone: contribution also requires a fresh matching WorldSession. The canonical Case never stores an “audience.” A view may redact other voters or consequences, while the quorum evaluator reads the protected canonical state.

Finalization locks the Case and eligibility rows, reopens current policy, recomputes the exact read set, inserts the contribution idempotently, evaluates the release-pinned decision rule, and either leaves the Case open or commits exactly one Receipt. A unique `decision_receipts(case_id)` constraint makes double finalization impossible.

### Watch, Notice, Scenario, and Effect

```ts
export interface Watch<R extends Realm> {
  readonly ref: WatchRef<R>;
  readonly owner: PrincipalId;
  readonly purpose: Purpose;
  readonly releaseBinding: ReleaseDigest | CompatibleTrack;
  readonly detector: SemanticId;
  readonly checkpoint: Cut;
  readonly state: "active" | "paused" | "cancelled";
}

export type NoticeDisclosure<R extends Realm> =
  | { readonly kind: "authorized"; readonly view: AuthorizedNoticeView<R> }
  | { readonly kind: "redacted"; readonly reason: "disclosure_changed" }
  | { readonly kind: "suppressed"; readonly reason: SuppressionReason };

declare const scenarioSeal: unique symbol;
export interface ScenarioSession<R extends Realm> {
  readonly base: FrameRef<R>;
  readonly [scenarioSeal]: R;
  inspect<I, O>(request: InspectRequest<I>): Promise<Result<ScenarioFrame<R, O>, InspectError>>;
  consider<I>(request: ConsiderActionRequest<I>): Promise<Result<ConsideredAction, ActionError>>;
  // Deliberately no decide, acquireEvidence, publish, commit, or effect method.
}

export interface EffectIntent<R extends Realm> {
  readonly id: EffectIntentId;
  readonly realm: RealmRef<R>;
  readonly originatingReceipt: DecisionReceiptId;
  readonly connector: VersionedConnectorId;
  readonly idempotencyKey: OperationKey;
  readonly canonicalInputDigest: Digest;
  readonly deadline: string;
}
```

Evaluation types carry `R = "evaluation"` through World, relationship, source lease, channel binding, EffectIntent, and Settlement. This prevents honest mixing. Runtime rejects mismatched discriminants, PostgreSQL composite foreign keys include `(realm_kind, realm_id, world_id)`, RLS compares transaction-local realm context, and evaluation connectors accept only sandbox leases. That is the actual barrier.

## Product ports

```ts
export interface OntologyGateway {
  createPersonalWorld(
    proof: IdentityProof,
    request: CreatePersonalWorld,
  ): Promise<Result<BootstrapReceipt<"live">, BootstrapError>>;

  acceptInvitation(
    proof: IdentityProof,
    request: AcceptInvitation,
  ): Promise<Result<BootstrapReceipt<"live">, BootstrapError>>;

  enterWorld<R extends Realm>(
    proof: IdentityProof | EvaluationProof,
    request: EnterWorld<R>,
  ): Promise<Result<WorldSession<R>, SessionError>>;
}

export interface EveOntologyPort {
  answer(session: WorldSession<"live">, request: AnswerRequest): Promise<Result<WorldFrame<"live">, AnswerError>>;
  openNotice(session: WorldSession<"live">, ref: NoticeRef<"live">): Promise<Result<NoticeDisclosure<"live">, NoticeError>>;
  formCase(session: WorldSession<"live">, request: FormCaseRequest<unknown>): Promise<Result<CaseFormed<"live">, ActionError>>;
}

export interface ModelPort {
  attempt(input: ModelAttemptInput, sink: TransientTokenSink): Promise<Result<SettledModelAttempt, ModelError>>;
}

export interface AuthorityStore {
  commit<R extends Realm, C extends AuthorityCommand<R>>(
    context: CommitContext<R>,
    command: C,
  ): Promise<Result<CommitOutput<C>, CommitError>>;
}
```

`EveOntologyPort` is deliberately narrower than the full gateway. Eve cannot publish releases, admit evidence, activate meaning, mutate a Watch checkpoint, write a Notice, manufacture a Receipt, or execute an Effect. Ontology never imports Eve. Door knows accounts and sessions, not Worlds or memberships.

The `AuthorityCommand` closed union includes `CreatePersonalWorld`, `AcceptInvitation`, `AdmitEvidence`, `FormActionCase`, `ContributeDecision`, `CommitImmediateAction`, `AdvanceWatchAndNotice`, `ActivateRelease`, `RollbackRelease`, and `RecordSettlement`. Each variant declares its legal output kinds, lock keys, isolation, authorization proof, and idempotency scope.

## Meaning and generated release types

Meaning is data, never uploaded JavaScript. A `WorldReleaseSource` is a strict canonical JSON document containing:

- stable semantic IDs and aliases forbidden after publication;
- object, property, relationship, Action, detector, and evidence mapping schemas;
- declarative policy, quorum, computation, materiality, and migration IR;
- trusted handler references selected from the application’s versioned registry;
- surface metadata for CLI, API, MCP, Eve, and Living World;
- compatibility declarations and required evaluation attestations.

Zod validates the source. `ReleaseCompiler` then typechecks references and IR, rejects cycles and non-total expressions, resolves trusted handler digests, emits JSON Schemas and surface manifests, canonicalizes bytes, and produces an immutable SHA-256-addressed `WorldRelease`.

```ts
export interface ReleaseCompiler {
  compile(source: unknown): Promise<Result<CompiledRelease, readonly ReleaseIssue[]>>;
}

export interface CompiledRelease {
  readonly digest: ReleaseDigest;
  readonly canonicalBytes: Uint8Array;
  readonly catalog: CapabilityCatalog;
  readonly schemaBundle: JsonSchemaBundle;
  readonly surfaceManifest: SurfaceManifest;
  readonly handlerManifest: readonly TrustedHandlerBinding[];
}
```

Dynamic “Teach” meaning compiles to the declarative IR; Node `vm`, `eval`, user-provided Fastify schemas, and user code are prohibited. Native capabilities are authored with typed TS builders and compiled to the same artifact. A release-specific SDK is optional and generated only after publication:

```text
zoen sdk generate --release sha256:<digest> --target typescript
generated/<digest>/types.ts
generated/<digest>/client.ts
generated/<digest>/schemas.json
```

Generated clients contain input/output types and named verbs, not policy or authority. At runtime, released Zod/JSON Schema validators remain the truth because generated TS types are erased.

Release proof and activation are separate:

1. install exact release bytes as the head of an isolated `EvaluationWorld`;
2. run public journeys, replay, semantic, policy, environment, channel-sandbox, and effect-sandbox attestations;
3. issue release-wide `ReleaseProof` for that digest;
4. for each live World, build `ReleasePreparation` from its exact current head and cut;
5. reuse, reproject, or migrate into a non-authoritative `DataGeneration`, catching up only from committed transitions;
6. create content-addressed `PreparedActivation` binding expected head, target release/generation, ready-through cut, open Case/Watch disposition, and invariant results;
7. atomically CAS both `WorldHead.release` and `WorldHead.generation` or do nothing.

There is no inactive-release escape hatch, dual read, dual write, or mutable candidate-to-active row. Rollback is another proved and prepared head transition.

## Canonical bytes

All signed, hashed, idempotent, or content-addressed documents use one internal JCS codec conforming to RFC 8785:

```ts
export interface CanonicalCodec<T> {
  parse(input: unknown): Result<T, CanonicalError>;
  bytes(value: T): Uint8Array;
  digest(value: T): Digest;
}
```

Rules are strict:

- UTF-8 and I-JSON only; duplicate object keys are rejected during raw parsing;
- object keys are recursively sorted by the RFC rule;
- `undefined`, sparse arrays, `NaN`, infinities, unpaired surrogates, and implicit coercion are rejected;
- business decimals, money, timestamps, durations, and 64-bit integers are canonical strings, never JSON floating-point numbers;
- optional means absent; `null` exists only in an explicit union;
- timestamps are normalized UTC RFC 3339 with declared precision;
- digests are lowercase `sha256:<hex>`;
- canonical bytes are stored beside parsed `jsonb`; `pgcrypto.digest(bytes, 'sha256')` checks the recorded digest.

The codec is small, dependency-free, and exercised through a public `zoen doctor canonical` journey against the RFC fixtures. Canonical bytes are the signing/hashing source; PostgreSQL `jsonb` formatting is never treated as canonical.

## PostgreSQL is the authority boundary

### Schemas and roles

```text
auth      Better Auth-owned tables; Door role only
kernel    Worlds, releases, authority, evidence, agency, attention
eve       settled interaction, Focus, attempts, deferrals, channel delivery
dense     manifests, segments, observations, projections
ops       migration ledger, leases, outbox delivery, telemetry pointers
```

Migrations create non-login owner roles and limited login roles. The application never connects as table owner, superuser, or `BYPASSRLS`. Authoritative tables use `ENABLE ROW LEVEL SECURITY` and `FORCE ROW LEVEL SECURITY`.

Every scoped transaction begins on one checked-out `pg.PoolClient`:

```sql
BEGIN ISOLATION LEVEL SERIALIZABLE;
SELECT set_config('zoen.realm_kind', $1, true);
SELECT set_config('zoen.realm_id',   $2, true);
SELECT set_config('zoen.world_id',   $3, true);
SELECT set_config('zoen.principal',  $4, true);
SELECT set_config('zoen.purpose',    $5, true);
```

No domain module imports `pg`; only `storage-postgres` can obtain a client. `pool.query` is forbidden because transactions must retain the same client. The callback always commits, rolls back, and releases in `finally`. SQLSTATE `40001` and deadlock `40P01` retry the whole idempotent operation with capped jitter, never a suffix of the transaction.

RLS is intentionally coarse and row-local: it compares `(realm_kind, realm_id, world_id)` to trusted transaction-local settings. It does not query mutable membership tables, avoiding authorization races documented for RLS subqueries. Fine-grained policy is evaluated by Ontology inside the same serializable transaction and relevant membership/delegation rows are locked. Constraint errors collapse to `not_found_or_withheld` so foreign-key behavior cannot become an enumeration oracle.

### Structural invariants

All authoritative keys and foreign keys carry the realm and World:

```sql
PRIMARY KEY (realm_kind, realm_id, world_id, object_id)
FOREIGN KEY (realm_kind, realm_id, world_id, parent_id)
  REFERENCES kernel.objects (realm_kind, realm_id, world_id, object_id)
```

PostgreSQL enforces:

- no live/evaluation or cross-World reference through composite keys;
- one current `(release_digest, data_generation, head_version)` per World;
- monotonic per-World cuts allocated by locking one `world_clock` row;
- immutable releases, proofs, receipts, contributions, transitions, evidence bytes, and Settlements by revoked `UPDATE/DELETE` grants;
- unique idempotency `(realm, world, principal, operation_kind, operation_key)` with request digest and result reference;
- one final Receipt per Case; one contribution per `(case, principal, decision round)`;
- legal state discriminants and required/forbidden columns through `CHECK` constraints;
- non-overlapping effective intervals through PostgreSQL 18 temporal/range constraints where applicable;
- Watch/Notice deduplication through `(watch_id, detector_version, material_key, transition_cut)` uniqueness;
- one Settlement observation per provider idempotency identity, while allowing superseding observations explicitly;
- exact digest/byte agreement using `pgcrypto`;
- head changes only from commit kinds `CreatePersonalWorld`, `ActivateRelease`, or `RollbackRelease` by binding `world_heads.last_commit_id` to the commit kind in a deferred constraint trigger;
- every committed semantic transition and EffectIntent has an outbox sibling before COMMIT, checked by two small deferred constraint triggers.

The only PL/pgSQL is those audited cross-row constraint triggers and the migration lock helper. Business policy, mapping, quorum, and release logic stay in TypeScript. SQL is the storage constitution, not a second application implementation.

### AuthorityCommit transaction

`AuthorityStore.commit` performs this fixed skeleton:

1. insert or reopen idempotency record; reject same key with different canonical request digest;
2. validate Door/session context and reauthorize under the pinned release;
3. select all aggregate keys from the command and lock them in database `ORDER BY aggregate_kind, aggregate_id`;
4. reread the protected facts and verify expected versions/read-set digest;
5. evaluate the deterministic release rule;
6. allocate the next World cut by updating the World clock row;
7. insert one `authority_commits` envelope and its typed sibling rows;
8. insert semantic mutations, Receipt or Notice, meaningful `world_transitions`, deterministic EffectIntents, and outbox rows;
9. mark the idempotency result, then COMMIT.

There is no await to a model, provider, object store, Restate, or another process inside this transaction. All inputs must already be acquired and admitted. The transaction has a hard statement and wall-clock budget; slow computations occur before it and are revalidated by digest within it.

### What PostgreSQL still cannot prove

Constraints prove shape, locality, uniqueness, immutability, allowed state transitions, and atomicity. They cannot interpret arbitrary release policy IR or know whether a disclosed consequence is semantically sufficient. TypeScript computes those rules and journeys prove behavior. The final commit protects against stale/concurrent state; it cannot protect against a bug in the trusted policy evaluator. Therefore the evaluator is tiny, deterministic, versioned, replayed, and eligible for independent formal/property verification later.

## Event model and durability

Core World state is not rebuilt from an event log. PostgreSQL rows are current authority. Events are selective semantic facts:

```ts
export type WorldTransition =
  | ObjectChanged
  | RelationshipChanged
  | EvidenceAdmitted
  | CaseFormed
  | DecisionCommitted
  | WatchChanged
  | NoticeCreated
  | ReleaseActivated
  | SettlementObserved;
```

Each transition carries `realm`, `world`, `cut`, `commitId`, `release`, canonical payload digest, occurred time, and causation/correlation IDs. High-volume raw points, unchanged polls, projection rows, and token chunks are not WorldTransitions.

The relational outbox is written in the same AuthorityCommit. Consumers use durable `(consumer, partition, transition_id)` receipts and idempotent handlers. Delivery is at least once. `LISTEN/NOTIFY` wakes consumers but carries no truth; polling closes notification loss.

Eve alone event-sources interaction: accepted user message, model attempt, tool request/result, settled assistant message, Focus change, Notice arbitration, defer/merge/suppress decision, channel render, delivery attempt/result, fork, and wakeup. Live token chunks are transient. A crash resumes from the last settled boundary; it may repeat a model attempt, but tool calls retain operation keys and cannot repeat authority.

Restate receives only an `EffectIntentId`. The versioned generic handler reopens the canonical intent, validates its signed Restate identity, claims it idempotently, executes the pinned connector with provider idempotency, and records `Succeeded | Failed | Unknown` as a Settlement proposal. Ontology admits that proposal in a new AuthorityCommit. Timeout is `Unknown`, never success. Connector versions remain in the binary until all referencing intents settle; this is durable-work correctness, not a compatibility shim.

## Evidence and dense reality

Evidence crosses five explicit states:

```text
source lease → acquired immutable bytes → deterministic mapping
→ admission proposal → one AuthorityCommit → World truth
```

Acquisition writes bytes to Tigris under `/<realm>/<world>/<sha256>` and then records the object digest. Object storage and PostgreSQL cannot commit atomically, so uploaded-but-unrecorded bytes are harmless orphans collected after a retention window; recorded bytes are not World truth until admission. Source cursors advance only with the admission commit.

Sparse semantic state lives in PostgreSQL. **Dense observations live permanently as immutable, Zstd-compressed Parquet segments in Tigris.** Parquet plus content-addressed manifests is the durable protocol, not a DuckDB implementation detail and not a migration waypoint. PostgreSQL stores the authoritative manifest DAG:

```ts
interface DenseManifest<R extends Realm> {
  readonly digest: Digest;
  readonly world: WorldRef<R>;
  readonly generation: DataGeneration;
  readonly schema: Digest;
  readonly parents: readonly Digest[];
  readonly segments: readonly SegmentRef[];
  readonly minTime: string;
  readonly maxTime: string;
  readonly rowCount: bigint;
  readonly sourceEvidence: readonly EvidenceRef[];
  readonly admittedThrough: Cut;
}
```

The relational spine is normalized and realm-scoped; abbreviated DDL shows the invariants:

```sql
CREATE DOMAIN kernel.digest32 AS bytea CHECK (octet_length(VALUE) = 32);

CREATE TABLE dense.segments (
  realm_kind       kernel.realm_kind NOT NULL,
  realm_id         uuid NOT NULL,
  world_id         uuid NOT NULL,
  segment_digest   kernel.digest32 NOT NULL,
  object_key       text NOT NULL,
  parquet_schema   kernel.digest32 NOT NULL,
  parquet_metadata kernel.digest32 NOT NULL,
  row_count        bigint NOT NULL CHECK (row_count >= 0),
  min_time         timestamptz NOT NULL,
  max_time         timestamptz NOT NULL CHECK (max_time >= min_time),
  evidence_digest  kernel.digest32 NOT NULL,
  admitted_commit  uuid NOT NULL,
  admitted_cut     bigint NOT NULL CHECK (admitted_cut > 0),
  PRIMARY KEY (realm_kind, realm_id, world_id, segment_digest),
  UNIQUE (realm_kind, realm_id, world_id, object_key),
  FOREIGN KEY (realm_kind, realm_id, world_id, admitted_commit)
    REFERENCES kernel.authority_commits
      (realm_kind, realm_id, world_id, commit_id)
);

CREATE TABLE dense.manifests (
  realm_kind       kernel.realm_kind NOT NULL,
  realm_id         uuid NOT NULL,
  world_id         uuid NOT NULL,
  generation       kernel.digest32 NOT NULL,
  manifest_digest  kernel.digest32 NOT NULL,
  canonical_bytes  bytea NOT NULL,
  schema_digest    kernel.digest32 NOT NULL,
  admitted_through bigint NOT NULL,
  authority_commit uuid NOT NULL,
  PRIMARY KEY (realm_kind, realm_id, world_id, generation, manifest_digest),
  CHECK (digest(canonical_bytes, 'sha256') = manifest_digest)
);

CREATE TABLE dense.manifest_segments (
  realm_kind      kernel.realm_kind NOT NULL,
  realm_id        uuid NOT NULL,
  world_id        uuid NOT NULL,
  generation      kernel.digest32 NOT NULL,
  manifest_digest kernel.digest32 NOT NULL,
  ordinal         integer NOT NULL CHECK (ordinal >= 0),
  segment_digest  kernel.digest32 NOT NULL,
  PRIMARY KEY
    (realm_kind, realm_id, world_id, generation, manifest_digest, ordinal),
  UNIQUE
    (realm_kind, realm_id, world_id, generation, manifest_digest, segment_digest),
  FOREIGN KEY (realm_kind, realm_id, world_id, generation, manifest_digest)
    REFERENCES dense.manifests
      (realm_kind, realm_id, world_id, generation, manifest_digest),
  FOREIGN KEY (realm_kind, realm_id, world_id, segment_digest)
    REFERENCES dense.segments
      (realm_kind, realm_id, world_id, segment_digest)
);

CREATE TABLE dense.generation_heads (
  realm_kind      kernel.realm_kind NOT NULL,
  realm_id        uuid NOT NULL,
  world_id        uuid NOT NULL,
  generation      kernel.digest32 NOT NULL,
  manifest_digest kernel.digest32 NOT NULL,
  version         bigint NOT NULL CHECK (version > 0),
  PRIMARY KEY (realm_kind, realm_id, world_id, generation),
  FOREIGN KEY (realm_kind, realm_id, world_id, generation, manifest_digest)
    REFERENCES dense.manifests
      (realm_kind, realm_id, world_id, generation, manifest_digest)
);
```

Parent edges use a parallel `manifest_parents` table with the same composite keys and acyclicity verified by the preparation/compiler before insertion; reachability is recomputed defensively for GC. Upload attempts live in `ops.object_uploads`, not `dense.segments`. Thus an object may exist before admission, but every `dense.segments` row is already immutable admitted fact. Application roles receive `SELECT, INSERT` on segments/manifests/edges and no `UPDATE, DELETE`; only the generation-head CAS and explicit retention executor are mutable.

The engine boundary is exact and does not expose SQL:

```ts
interface ObservationPlan<R extends Realm, Row> {
  readonly world: WorldRef<R>;
  readonly generation: DataGeneration;
  readonly manifest: Digest;
  readonly schema: Digest;
  readonly projection: readonly SemanticId[];
  readonly predicate: ReleasedPredicateIr;
  readonly aggregation?: ReleasedAggregationIr;
  readonly timeRange: Readonly<{ from: string; through: string }>;
  readonly rowSchema: z.ZodType<Row>;
  readonly budget: Readonly<{
    maxBytesScanned: bigint;
    maxRowsReturned: bigint;
    deadlineMs: number;
  }>;
}

interface ObservationBatch<Row> {
  readonly rows: readonly Row[];
  readonly ordinal: bigint;
  readonly canonicalBatchDigest: Digest;
}

interface ObservationQueryResult<Row> {
  readonly rows: AsyncIterable<ObservationBatch<Row>>;
  readonly queryDigest: Digest;
  readonly manifestDigest: Digest;
  readonly schemaDigest: Digest;
  readonly engineAttestation: Readonly<{ name: string; version: string }>;
}

interface ObservationQueryPort {
  execute<R extends Realm, Row>(
    plan: ObservationPlan<R, Row>,
    signal: AbortSignal,
  ): Promise<Result<ObservationQueryResult<Row>, ObservationQueryError>>;
}
```

Ontology creates `ObservationPlan` only after authorization and pins its generation, manifest, released predicates, and resource budget. Callers cannot submit raw SQL, object keys, or S3 URLs. Every returned batch is parsed through the plan's runtime Zod schema before it can contribute to a Frame or admission proposal.

DuckDB Node Neo is the first `ObservationQueryPort` adapter. It runs in a bounded worker thread, resolves only segments reachable from the pinned authorized manifest, compiles the released IR to a parameterized/allowlisted DuckDB query, pushes predicates into Parquet, enforces cancellation and budgets, and returns typed batches plus query/manifest/schema digests. It has no write credentials to kernel tables.

Arrow is optional interchange, never durable truth: an adapter may use Arrow IPC or Arrow buffers between a native engine and TypeScript when that is measurably faster, but it must yield the same `ObservationBatch<Row>` contract. Parquet remains the stored format and the manifest remains the identity and lineage layer.

Segment publication is explicit. A writer produces canonical Parquet metadata, uploads bytes at the segment content digest, and records an unadmitted upload in `ops.object_uploads`. One `AuthorityCommit` locks the current manifest head, inserts the immutable admitted segment, manifest, and edge rows, CAS-moves the generation's manifest head, advances the admitted source cursor, and emits a `WorldTransition` only when the release says the resulting semantic delta is meaningful. A failed transaction leaves an unreachable object and staging row; it never leaves a half-current manifest. Derived outputs follow the same path.

Manifest publication is compare-and-swap. A query pins one manifest digest for its duration. Garbage collection follows manifest reachability, active leases, release preparations, Frames, Cases, and retention policy. Evaluation object prefixes and credentials cannot address live prefixes. Signed URLs are short-lived and never enter conversation history.

An engine swap occurs behind `ObservationQueryPort`, not through a data migration. Reopen DuckDB only when representative institutional journeys still miss the Frame SLO after compaction and predicate tuning, native crashes exceed one per quarter, or required released operators cannot be pushed down. A replacement must read the same Parquet bytes and manifests and produce byte-identical canonical results across the replay corpus. Query-engine performance is not a reason to abandon Parquet.

## Module constitution

Allowed dependency direction:

```text
foundation ← release-ir ← ontology-domain ← ontology-application ← adapters
     ↑                              ↑                 ↑
door-contract                 eve-ontology-port      composition-root
     ↑                              ↑                 ↑
door-product                    eve-product        apps/zoen
```

Rules:

- `foundation` contains value types, Result, clock/random/hash ports, and canonical codec; no product imports.
- `release-ir` contains schemas and the total expression language; no storage or network.
- `ontology-domain` owns semantic objects and pure decisions; no Fastify, `pg`, Better Auth, Restate, model SDK, React, or filesystem.
- `ontology-application` orchestrates ports and AuthorityCommit; it never imports concrete adapters.
- `door-product` may import Better Auth only through its adapter; it exports `SessionDoor` and proofs.
- `eve-product` imports only `EveOntologyPort`, channel ports, and ModelPort. It cannot import Ontology stores or domain constructors.
- Ontology cannot import Eve. Both can import Door contracts; only the composition root injects implementations.
- `storage-postgres` is the only package importing `pg`; `dense-duckdb` the only package importing DuckDB; `effects-restate` the only package importing Restate.
- `apps/zoen` is the only package allowed to import all adapters and products.
- packages expose explicit `exports`; `/internal/*` is unexported. No cross-package relative paths and no catch-all barrels.

dependency-cruiser and ESLint fail forbidden imports. TypeScript project references and package exports reduce accidental access. These are build controls, not security boundaries: arbitrary code running in the process could bypass them.

Compiler baseline:

```json
{
  "compilerOptions": {
    "strict": true,
    "composite": true,
    "declaration": true,
    "target": "ES2024",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "verbatimModuleSyntax": true,
    "exactOptionalPropertyTypes": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noPropertyAccessFromIndexSignature": true,
    "useUnknownInCatchVariables": true,
    "noUncheckedSideEffectImports": true,
    "isolatedDeclarations": true,
    "types": ["node"]
  }
}
```

Lint denies `any`, unchecked assertions, non-null assertions, floating promises, unsafe enum comparison, accidental thenables, default exports in domain packages, and direct time/random/environment access. The few unavoidable runtime narrowing assertions live in reviewed boundary constructors.

## Repository from zero

```text
/
├── apps/
│   └── zoen/
│       ├── src/main.ts                 # sole composition root
│       ├── src/http.ts                 # :8080
│       ├── src/restate.ts              # :9080
│       ├── src/background.ts
│       └── web/                         # React shell
├── products/
│   ├── door/{contract,application,better-auth}/
│   ├── eve/{domain,application,channels,web}/
│   └── ontology/{domain,application,surfaces,web}/
├── modules/
│   ├── foundation/
│   ├── release-ir/
│   ├── canonical/
│   ├── authority-commit/
│   ├── evidence/
│   ├── agency/
│   ├── attention/
│   ├── scenario/
│   └── release-evolution/
├── adapters/
│   ├── postgres/
│   ├── tigris/
│   ├── duckdb/
│   ├── restate/
│   ├── models/
│   ├── kapso/
│   └── telegram/
├── releases/
│   ├── source/
│   ├── trusted-handlers/
│   └── generated/                       # reproducible artifacts only
├── db/
│   ├── migrations/*.sql
│   ├── roles.sql
│   └── constitution.sql
├── journeys/
│   ├── door/
│   ├── frame/
│   ├── watch-notice/
│   ├── case-effect/
│   ├── release/
│   ├── dense/
│   ├── institutions/
│   └── cross-surface/
├── ops/{Dockerfile,fly.toml,compose.journeys.yml}/
├── docs/{constitution.md,technology-baseline.json,adrs/}/
├── eslint.config.mjs
├── dependency-cruiser.cjs
├── tsconfig.json
├── package.json
└── package-lock.json
```

Workspace package count is earned, not mirrored from every noun. The conceptual modules may begin as directories inside four workspace packages (`foundation`, `ontology`, `eve`, `app`) and split only when an import rule needs a physical boundary.

## Public protocols

### JSON API

Routes are generated from the active release surface manifest but installed only from trusted compiled releases. Requests and responses are `application/json`; errors use `application/problem+json` with stable Zoen codes and trace IDs. Every mutation requires `Idempotency-Key`; the canonical request digest determines replay versus conflict. Consequential verbs require a current Door session and CSRF protection for cookie clients or a scoped bearer for API clients.

An API response includes `world`, `release`, `generation`, `cut`, and result digest. Pagination uses opaque signed cursors bound to release, disclosure, sort, and expiry. HTTP caching is allowed only for public release artifacts or principal-bound immutable Frame digests with `private` cache policy.

### MCP

MCP v2 exposes progressive discovery: a small stable index resource, capability resources, and released tools on demand. Tool names are semantic, schemas come from the same Zod-derived bundle, and every call opens a fresh Door/World session. Streamable HTTP is the hosted transport; stdio is the local CLI bridge. Tool output contains structured content for agents and concise readable text, never raw internal rows or policy traces.

### CLI

The CLI is the Ontology product, not a debug shell. It uses Node `util.parseArgs` and the surface manifest, supports JSON output, stable exit codes, explicit `--world`, `--purpose`, `--operation-key`, and `--at-cut`, and never bypasses Door. Human output names domain verbs; `--json` returns the canonical API envelope.

### Eve channels

Kapso terminates at `/eve/v1/kapso`; Telegram at `/eve/v1/telegram`. Webhook authenticity and replay windows are verified before an interaction event. Structured chrome is flattened to readable messaging text. Eve may include only released, authorized links already present in content; it never invents a URL. Channel rendering follows the same settled assistant message but stores per-channel delivery results.

## Security constitution

- Better Auth sessions live in the isolated `auth` schema; secure, HttpOnly, SameSite cookies and origin/CSRF checks protect browser mutations.
- API/MCP credentials are hashed at rest, scope-limited, expiring, revocable, and always converted into a Door proof before World authorization.
- Membership, delegation, subject identity, and disclosure belong to Ontology—not Better Auth organizations.
- Every consequential read and write carries principal, purpose, realm, release, generation, and cut into trace and audit context.
- Evaluation gets separate realm rows, object prefixes, relationships, channel sinks, source leases, effect leases, and outbound allowlist. No production credential is loaded into an evaluation lease.
- Database credentials are least-privilege; production app roles cannot migrate or disable RLS. Backups run with `row_security=off` so accidental filtered backups fail rather than silently omit data.
- Raw evidence and conversation bodies are never logged. Pino redacts headers, cookies, tokens, handles, messages, evidence, model prompts, and URLs by default.
- Secrets are Fly secrets; release artifacts contain public keys and handler digests, never credentials. Keys rotate with overlapping verification windows and explicit receipts.
- Per-process token buckets are only load shedding. Security quotas and operation budgets use PostgreSQL counters, so horizontal scaling cannot bypass them.
- Package lock integrity, minimal production dependencies, non-root image, read-only root filesystem, SBOM, provenance, and vulnerability gates are release inputs.
- A compromise of the one Node process can access every credential loaded into it. Module boundaries do not contain an attacker. This is an admitted modular-monolith risk with an explicit split trigger below.

## Observability and audit

OpenTelemetry starts before application imports. Traces propagate `trace_id`, `operation_key`, `realm`, opaque World hash, cut, release digest, commit ID, Case/Watch/Notice/Effect ID, and Restate invocation ID. High-cardinality IDs stay in traces/logs, not metric labels.

Core metrics include Door latency/failure, Frame p50/p95/p99, serialization retries, World-clock lock wait, idempotency replay/conflict, outbox lag, Watch evaluation lag, suppressed/deferred Notices, Case age/staleness, Effect Unknown age, Restate retry, dense scan bytes/rows, DuckDB worker saturation, event-loop lag, pool wait, and release preparation catch-up.

Pino logs operational events with trace correlation and no protected payload. Receipts, Settlements, evidence lineage, release proofs, and Eve interaction events are durable product records; logs are never audit truth. SLO burn alerts point to a product promise (“Frames stale”, “Notices late”, “Effects unknown”), not merely CPU.

## Deployment and operations

One multi-stage Docker image pins the Node 24.20.0 base image by digest, runs `npm ci`, compiles server ESM and Vite assets, prunes dev dependencies, and runs as a non-root user. `fly.toml` defines one Fly app and one identical process kind. Each Machine exposes Fastify on 8080 and the identity-verified Restate handler on a separate TLS-routed port. Restate Cloud is infrastructure, not a fourth Zoen product or Fly app.

A Fly `release_command` runs the checksum-verified SQL migrator under a PostgreSQL advisory lock. Migrations are forward-only before production; prelaunch baselines may be consolidated only as an explicit coordinated reset. App readiness requires current migration, database transaction round-trip, active planted `zoen` release loaded and digest-verified, and worker coordinator started. Liveness requires event-loop progress only.

Deployments are rolling with `min_machines_running >= 1`. Shutdown first fails readiness, stops claims, gives HTTP/SSE a deadline, releases leases, closes both listeners, drains `pg`, and exits. Leases expire safely if killed. Database backup/restore, Tigris object versioning, release-artifact export, and a full World restore journey are mandatory before consequential agency.

The Restate handler protocol and connector ID are versioned. A deployment cannot delete a handler/connector version while an unsettled EffectIntent references it. Service identity keys verify all Restate calls. Restate may retry; PostgreSQL intent claims and provider idempotency make execution safe.

## Journey-only verification

No `*.test.ts` imports an internal module. There are no unit tests, mocks, fakes, stubs, snapshots of implementation markup, or `vi.mock`. Playwright journeys launch the built image and real dependencies and use only browser, API, CLI, MCP, webhook, and observable product records.

### Taxonomy

1. **Door and bootstrap:** sign in; create a personal World; accept an invitation; prove invitation acceptance leaves existing WorldHead unchanged; revoke session.
2. **One honest Frame:** acquire/admit evidence; inspect; show cut/evidence/freshness/unknown/withheld correctly; reject cross-World and evaluation/live refs.
3. **Quiet attention:** create/edit/pause/cancel Watch idempotently; unchanged input stays silent; material transition creates one Notice; Eve defers; revoked disclosure suppresses before composition.
4. **Accountable agency:** form one canonical multi-principal Case; open different views; reject copied handle; record concurrent contributions; stale read set prevents decision; one Receipt; crash/retry cannot duplicate Effect.
5. **External truth:** provider success, failure, timeout/Unknown, late reconciliation, and duplicate callback produce the correct Settlement history.
6. **Release evolution:** compile; create EvaluationWorld; prove realm egress denial; run all surfaces; prepare a live World; catch up; CAS activate; lose a concurrent CAS; prepare and execute rollback.
7. **Dense reality:** upload real Parquet through S3 protocol; admit manifest; query with DuckDB; pin a manifest during concurrent publication; reproject generation; collect only unreachable segments.
8. **Cross-surface parity:** the same released capability through Eve, CLI, API, MCP, and Living World yields the same semantic digest and surface-appropriate presentation.
9. **Institutional authority:** household/team/clinic roles, delegated purposes, partitioned disclosure, quorum changes, revocation during open Case/Notice, and authorized absence.
10. **Recovery:** kill the Node process at every durable boundary; sever provider/network; restart; restore database/object snapshot; prove no partial authority or invented success.

Real local dependencies are PostgreSQL 18, Restate server, and a real S3-compatible MinIO service; protected integration/release tiers repeat storage journeys against a disposable Tigris bucket and provider-certified sandboxes. MinIO is not used to claim Tigris behavior. Missing provider sandbox evidence remains a failed attestation, never a fake success.

### CI tiers

| Tier | Trigger | Budget | Evidence |
|---|---|---:|---|
| Constitution | every change | 3 min | format, TS strict check, ESLint, dependency graph, circular exports, migration checksum/role/RLS catalog audit, generated artifact clean diff, lockfile audit. Not called tests. |
| PR journeys | every PR | 12 min | bootstrap, Frame, Watch/Notice, Case concurrency, public surface smoke on real local services. |
| Full journeys | merge queue | 35 min | all taxonomy except external certified sandboxes; browsers plus CLI/API/MCP; process-kill matrix sampled. |
| Nightly proof | nightly | 90 min | replay corpus, concurrency stress, restore, dense scale, RLS probes, failure injection with real process/network termination. |
| Release proof | candidate release | no fixed shortcut | isolated EvaluationWorld on deployed artifact, Tigris, Restate Cloud, channel/model/effect sandboxes, migration/reprojection, activation and rollback evidence. |

Flake is a defect: retry may gather evidence but cannot turn failure green. Journeys use deterministic World clocks through a product-admin evaluation capability, never monkey-patched time.

## Build sequence and slice acceptance

### S0 — constitution and walking skeleton

Create the module graph, strict compiler, canonical codec, migrations/roles/RLS, Fastify composition root, Better Auth Door, planted release loader, public health, Docker/Fly image, and one Playwright journey.

Accept when forbidden imports fail static checks; a non-owner DB role cannot bypass RLS; canonical fixtures match RFC 8785; a killed process restarts without state repair; one image deploys as one Fly app.

### S1 — one honest Frame

Implement explicit create-personal/accept-invite bootstrap, enterWorld, evidence bytes/mapping/admission, sparse facts, Frame planning, authorized absence, one released inspect verb, and projections to Eve/CLI/API/MCP/Living World.

Accept when the same evidence produces one semantic digest on all surfaces; acceptance never moves WorldHead; a live ref cannot enter evaluation or another World in TypeScript, runtime parsing, SQL FK, or RLS probes.

### S2 — one quiet Watch

Implement Watch lifecycle, compact checkpoint, transition outbox, deterministic materiality/staleness detector, atomic Notice, Attention view, and Eve arbitration/defer/merge/channel delivery with two fresh disclosure checks.

Accept when ten thousand unchanged dense points create no WorldTransitions/Notices; one material change creates exactly one; revocation between defer and composition leaks no content.

### S3 — one accountable Action

Implement `ProtectReserve`, canonical Case, principal views/handles, contribution quorum, stale-case rejection, serializable AuthorityCommit, DecisionReceipt, EffectIntent, Restate execution, Unknown, and Settlement reconciliation.

Accept when a concurrency journey with duplicate and reordered decisions produces exactly one legal outcome, one Receipt, deterministic Effects, and no partial semantic mutation under process kills.

### S4 — one continuous Living World

Add evidence lineage, contradictions, freshness, provenance navigation, membership/delegation workbench, and Eve continuity linked by references rather than copied authority.

Accept when a person can understand “what Zoen knows, why, as of when, who may act, and what changed” without an architecture dashboard or helpdesk prose.

### S5 — teach once, publish everywhere

Implement release IR/compiler, trusted handler registry, EvaluationWorld isolation, release-wide proof, per-World preparation, migration/reprojection, CAS activation/rollback, and generated native surfaces/SDK.

Accept when inactive releases are unreachable through normal paths; evaluation cannot reach live DB/object/channel/source/effect destinations; activation swaps release+generation atomically and a failed CAS changes nothing.

### S6 — dense reality

Implement Parquet segments, manifest DAG, DuckDB worker, source cursors, dense-to-semantic admission, generation catch-up, leases, and reachability GC.

Accept at 100M synthetic real-format points when memory stays bounded, Frame p99 meets its SLO, manifest pinning is repeatable, and no point becomes authority without evidence admission.

### S7 — shared and institutional Worlds

Add households, teams, clinics, funds, and factories through released membership, delegation, partition, disclosure, quorum, and portable bundle semantics—without new lifecycle primitives.

Accept when principal-specific views differ lawfully over one canonical Case; role revocation races are serializable; the same Frame/Case/Watch/Notice/Receipt grammar survives institutional load.

## Scale path

### Personal to household

One or two identical Fly Machines, managed PostgreSQL 18, Tigris, and Restate Cloud. Keep all reads authoritative on the primary. Pool size is a fixed per-Machine budget. Dense queries are bounded and cancellable. Release/validator caches are local.

### Team to clinic

Scale identical Machines horizontally; job claims and idempotency already support it. Partition append-heavy transition, interaction, and observation metadata tables by time and World hash. Use PostgreSQL read replicas only for explicitly historical, cut-pinned, non-authoritative exports; Frames, authorization, Cases, Watches, and activation remain on primary. Increase DuckDB worker concurrency independently of HTTP concurrency within the process.

### Factory or large fund

Keep dense points off the semantic commit path. Compact Parquet by manifest, push filters/aggregations into DuckDB, precompute released projections, and admit only semantic deltas. Large Worlds may receive a dedicated database cluster without changing any ID, release, protocol, or product object. World routing is resolved before session creation; a transaction never spans clusters.

The per-World clock deliberately serializes meaningful authority. Reopen the cut model only if a single World sustains more than 500 AuthorityCommits/s or p99 clock-row lock wait exceeds 50 ms for 15 minutes after batching unrelated non-semantic work away. A language rewrite does not solve that serialization point; causal cuts or authority partitions would be a product-semantic ADR.

### Rust accelerator seam, not Rust architecture

The TypeScript ports accept/return canonical bytes and digests, so a Rust N-API or WASM implementation can replace a measured pure kernel without changing callers:

- canonicalization/hash if >100 MB documents or p99 >25 ms;
- release compiler/policy evaluator if compilation >2 s or authorization consumes >10% CPU at target load;
- mapping/materiality vector kernels if Node event-loop lag exceeds 25 ms p99 while workers are saturated;
- specialized dense codecs only if DuckDB cannot meet segment throughput.

Adoption requires byte-for-byte differential journeys over the replay corpus, crash containment, memory limits, and the same error algebra. Rust never receives database credentials or becomes a second authority service. DuckDB already provides native vectorized execution for the dominant dense workload, so a custom accelerator is unlikely before institutional scale.

If process compromise blast radius—not CPU—is the problem, the remedy is separate Fly process groups or apps with separate secrets, not Rust. Reopen when independent compliance boundaries, different operators, or audited secret isolation are contractual requirements.

## Honest TypeScript proof ledger

| Claim | Compile time | Runtime | Database / cryptographic enforcement | Honest conclusion |
|---|---|---|---|---|
| Live and evaluation refs do not mix | Phantom realm generics catch trusted-code mistakes. | Zod checks discriminants and capabilities. | Composite realm keys, RLS, roles, object prefixes, sandbox leases. | Strong in system; not guaranteed by TS alone. |
| Only authorized principal can act | Session capability narrows APIs. | Door proof and policy rechecked at each boundary. | RLS scopes rows; locked membership/delegation and serializable commit close races. | Strong unless the trusted evaluator or whole process is compromised. |
| One canonical Case | Case/View types are distinct. | Gateway never accepts a view as Case state. | Unique Case identity, contribution, and Receipt constraints. | Strong. |
| No stale decision | Types carry cut/version/read digest. | Finalization recomputes and compares. | Conditional updates, row locks, SERIALIZABLE retry. | Strong. |
| No partial Action | Command output union guides implementation. | AuthorityStore has one commit skeleton. | One PostgreSQL transaction and deferred bundle constraints. | Strong. |
| Immutable release/receipt/evidence | Readonly prevents ordinary mutation. | Digest verified on load. | UPDATE/DELETE revoked; digest constraint; object immutability/versioning. | Strong. |
| Scenario cannot act | Interface has no method; constructor hidden. | Capability dispatch rejects scenario authority. | Scenario role has no authority DML/effect rights. | Strong; TS interface alone is not a sandbox. |
| Notice deferral cannot leak stale facts | Eve port returns a union. | Reopen twice; deferral repository accepts only NoticeId. | Deferred rows have Notice FK, no disclosed-content column. | Strong for intended code; compromised Eve can still copy text to its message store. |
| Concurrency is correct | Impossible for TS to prove. | Retry/idempotency protocol. | PostgreSQL SERIALIZABLE, locks, CAS, constraints. | Database-proved, not language-proved. |
| Exhaustive domain evolution | Discriminated unions and `never`. | Zod rejects unknown versions. | Version/digest pinned in records. | Good for trusted compiled code; external values still require parsing. |

Compared with Rust, TypeScript cannot make realm brands unforgeable, cannot express borrow/aliasing rules, cannot statically make async shared state race-free, and does not provide process memory safety or capability isolation. Rust would reduce trusted-code defect classes, especially in parsers and concurrency-heavy in-memory kernels. It would not replace fresh authorization, database transactions, RLS, idempotency, release proof, or journey evidence. In this design the dangerous invariants deliberately terminate in those runtime/database mechanisms, so the remaining TypeScript risk is explicit and auditable rather than wished away.

## ADR set (18)

1. **Three products, one application:** Door, Ontology, Eve are ownership boundaries inside one deployable.
2. **TypeScript/Node only for application code:** optimize one grammar and one debugging path; native accelerators require measurements.
3. **TypeScript 6.0.2 now:** stable tool API beats TS 7 novelty; reopen at 7.1 ecosystem parity.
4. **PostgreSQL 18 is authority:** use constraints, RLS, temporal keys, uuidv7, and serializable transactions.
5. **No ORM:** explicit SQL is shorter and exposes locks, CAS, isolation, and constraints honestly.
6. **Purpose-bound WorldSession:** identity proof alone never grants World authority.
7. **Realm is phantom plus physical:** brands help authors; runtime/DB/storage enforce separation.
8. **Canonical JCS bytes:** one representation for digest, signature, idempotency, and artifacts.
9. **Immutable WorldRelease:** proof is separate; activation swaps release and generation together.
10. **Declarative release IR:** no uploaded JavaScript or `vm`; dynamic meaning is interpreted by trusted total functions.
11. **One canonical ActionCase:** principal views and handles are projections, not divergent Cases.
12. **Selective WorldTransitions:** current rows are authority; events carry semantic change, not every datum.
13. **Eve owns interaction durability:** token streams are transient; settled boundaries are event-sourced.
14. **Restate only for ZoenEffect:** it retries external work and never decides local World truth.
15. **Postgres outbox and leases:** no Redis or broker; notify is a hint.
16. **Sparse Postgres, durable Parquet manifests:** immutable Parquet is the dense protocol; DuckDB Node Neo is the replaceable first `ObservationQueryPort` engine and Arrow only optional interchange.
17. **One process per Machine:** simplest coherent operations; horizontal replicas are identical and stateless outside durable stores.
18. **Journey evidence only:** public product behavior and real boundaries are the proof; static graph checks are not tests.

## Rejected alternatives

- **Rust-first kernel or polyglot services:** stronger local guarantees, but two languages, FFI/RPC schemas, split debugging, and premature operational boundaries. Reopen only at measured accelerator or isolation triggers.
- **Microservices by authority:** network calls cannot make an authority atomic; they multiply partial failure and weaken the one-commit promise.
- **Next.js/React Server Components:** couples interaction rendering to server framework semantics and recently expanded security surface; a Fastify API plus Vite client is smaller and clearer.
- **NestJS:** decorators, reflection, dependency injection container, and framework layers obscure the domain capability graph.
- **GraphQL:** generic graph traversal conflicts with explicit released disclosure and Action verbs; field-level authorization becomes the product accidentally.
- **Generic `/invoke` as the public product:** easy for infrastructure, poor for people and agents; native released verbs remain the public surface.
- **Prisma, Drizzle, or Kysely for Ontology:** convenient CRUD types do not express the decisive transaction/lock/constraint protocol. Better Auth may use its internal Kysely adapter only inside Door.
- **Kafka/NATS/event-sourcing the World:** duplicates PostgreSQL truth and turns local atomicity into distributed choreography. Add a stream export from the outbox only for a proven external consumer need.
- **Redis/BullMQ:** another source of durability, leases, and failure without a product need. PostgreSQL already owns atomic work discovery.
- **Restate for conversation or Watches:** Eve owns conversation durability; Watches are Ontology intent evaluated from committed transitions. Restate is limited to Effects.
- **Every observation as an event:** makes 100M points indistinguishable from meaningful change and prices the product by noise.
- **Arrow as the durable dense format:** useful in-memory interchange, but a weaker long-term object-store contract than immutable Parquet segments with predicate metadata and broad engine support.
- **Coupling manifests to DuckDB:** would make an engine benchmark look like a data migration. Manifests describe semantic schema, lineage, cuts, and Parquet segments independently of the query adapter.
- **Mutable releases or feature flags over meaning:** creates worlds that cannot explain which semantics produced an answer.
- **Dual read/write migrations:** ambiguous authority. Prepare a new generation and atomically move the head.
- **Audience-specific Cases:** creates conflicting agency records. Keep one protected Case and authorize views per principal.
- **Persisting deferred Notice content:** permission can expire. Persist only NoticeId and reopen disclosure before composition.
- **Node `vm` for user ontology code:** Node explicitly does not make it a security boundary. Use declarative IR and trusted handlers.
- **In-memory locks/timers/caches as correctness:** fail across crash and replicas. PostgreSQL owns all durable coordination.
- **Automatic provider-success inference on timeout:** violates external truth. Record Unknown and reconcile.

## Risks and reopen triggers

1. **Single-process credential blast radius.** Reopen deployment isolation when SOC 2/health/financial contracts require separate operator or secret boundaries, or a threat model treats Eve compromise as unable to access Ontology credentials.
2. **Policy evaluator correctness.** Add a separately verified implementation or formal model when policy IR exceeds 25 operators, supports recursion, or protects regulated multi-institution disclosure.
3. **Serializable contention.** Revisit aggregate partitioning at >1% serialization aborts, p99 commit >150 ms, or World clock wait threshold above. Do not lower isolation to hide it.
4. **PostgreSQL RLS covert channels.** Keep policies row-local; run adversarial journeys. Split physical databases if contractual isolation requires eliminating shared-catalog/constraint channels.
5. **Node event-loop stalls.** Move measured CPU work to bounded workers; add native accelerator at stated thresholds. Never move authority transaction coordination off the main typed path.
6. **DuckDB Node Neo maturity.** Pin package/engine, exercise large/cancel/error journeys, and reopen for a separate query process if native crashes can take down HTTP more than once per quarter.
7. **Object-store atomic gap.** Orphan-first protocol is safe but operationally noisy; reopen multipart/staging design if orphan volume exceeds 1% or cleanup threatens retention guarantees.
8. **Restate deployment/version semantics.** Keep handlers stable and versioned; reopen endpoint topology if any invocation can outlive retention of its handler version.
9. **Generated surface drift.** All surfaces hash the same manifest; CI requires a clean regeneration. Reopen generator design on the first semantic digest mismatch, not after users notice.
10. **Type assertion escape hatches.** Keep assertion count budget at zero outside boundary constructors; fail review if a new assertion crosses a realm, authority, or persistence boundary.
11. **Institutional cross-World actions.** Current constitution permits one World per AuthorityCommit. Reopen only for a real action requiring atomic authority across independently governed Worlds; do not simulate it with distributed locks.
12. **Technology age.** Re-evaluate Node, PostgreSQL, Better Auth, MCP, Restate, DuckDB, and TS at every release proof; upgrade only through the same journeys.

## Primary technology evidence

- Node production guidance and current LTS line: [Node.js releases](https://nodejs.org/en/about/previous-releases).
- TypeScript 7’s native release and missing programmatic API: [Announcing TypeScript 7.0](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/).
- PostgreSQL 18.6 current docs, including `uuidv7`, RLS, and serializable isolation: [PostgreSQL 18](https://www.postgresql.org/docs/18/), [row security](https://www.postgresql.org/docs/18/ddl-rowsecurity.html), [transaction isolation](https://www.postgresql.org/docs/18/transaction-iso.html).
- Fastify schema and lifecycle model: [Fastify v5 reference](https://fastify.dev/docs/latest/Reference/).
- Better Auth’s direct PostgreSQL adapter: [Better Auth PostgreSQL](https://better-auth.com/docs/adapters/postgresql).
- MCP v2 Node/TypeScript packages and Streamable HTTP: [MCP TypeScript SDK v2](https://ts.sdk.modelcontextprotocol.io/v2/).
- Restate TypeScript handler and immutable deployment model: [Restate serving](https://docs.restate.dev/develop/ts/serving), [Restate services and deployments](https://docs.restate.dev/foundations/services).
- DuckDB’s primary Node Neo client: [DuckDB Node Neo](https://duckdb.org/docs/lts/clients/node_neo/overview).
- Tigris S3 compatibility in a Fly app: [Fly Tigris docs](https://www.fly.io/docs/tigris/).
- One Fly app can run the configured Node process and expose services: [Fly app configuration](https://fly.io/docs/reference/configuration/).
- Zod 4 first-party JSON Schema: [Zod 4 release notes](https://zod.dev/v4).
- JCS canonical JSON: [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785).
- OTel JavaScript stability: [OpenTelemetry JavaScript](https://opentelemetry.io/docs/languages/js/).
- Real end-to-end browser/process journeys: [Playwright](https://playwright.dev/docs/intro).

## Constitutional sentence

**Zoen is one TypeScript process in which Door proves who is present, an authority-free Focus opens a purpose-bound WorldSession, Ontology returns one cut-bound Frame that can answer, form one canonical Case, or sustain one Watch, and Eve alone turns freshly authorized truth into a human relationship—while PostgreSQL, not TypeScript optimism, enforces realm, concurrency, and atomic authority.**
