# ADR 023: Non-widening rights, authority cells, edge Worlds, and federation

Status: Accepted target contract. Multi-cell implementation deferred.

## Context

Personal and institutional Worlds must combine private records, commercial data, derived results, models, exports, and cross-organization collaboration. Membership authorization alone cannot express source licenses, entitlements, purpose, geography, retention, attribution, training, or redistribution. Ad hoc flags lose restrictions during joins and derivations.

Regulated, high-scale, and disconnected deployments also require cells and edge operation. Treating replicas as coequal writers or synthesizing a global cut would break the single-World authority and temporal model. Refusing edge authority and federation altogether would impose a real capability ceiling.

## Decision

### Rights are a separate positive-grant algebra

Cedar decides horizontal World authorization. A release-owned rights evaluator decides source and output use. Both must allow a request.

`DataUsageContract` is a canonical, digest-addressed disjunction of non-empty positive `UsageGrant` conjunctions plus explicit `UsageObligation` values. Closed constraints cover public or entitled source, principal class, purpose, use, operation, fields, subjects, geography, time window, retention, output class, attribution, training prohibition, and redistribution prohibition. Each grant pins every issuer and source-contract origin. Obligations cover attribution, deletion, watermarking, minimum aggregation, use recording, and issuer notice. There is no arbitrary negation and no ambient `internal-use` grant.

The core operation is bounded `meet`. It canonically conjoins all contributing restrictions, removes duplicates, eliminates contradictions, and cannot widen a grant. It receives explicit maximum alternative and constraint counts. A contradictory meet returns conflict; a combinatorial expansion beyond budget returns `budget-exceeded`. Both fail closed rather than dropping clauses. Joins, functions, models, derived datasets, charts, alerts, mini-apps, executors, notifications, and exports carry the meet of every input plus complete lineage. Alternative sources may remain separate only while each output value identifies which source supplied it.

`EntitlementSnapshot` is a sealed, evidence-backed local snapshot bound to realm, World, principal, issuer, revision, grants, observation time, expiry, and digest. `UsageRequest` binds the full WorldHead, principal, purpose, operation, use, subjects, fields, geography, output, retention, and request time. Rights evaluation is pure over those local values; it performs no provider call.

A rights decision is `allowed`, `denied`, or `unknown`. Allowed decisions include effective contract, proof, exact entitlement snapshots, obligations, and expiry. `UsageReceipt` binds actual output to request, decision, and every fulfilled or pending obligation before release. If use consumes an entitlement or quota, its receipt and consumption are committed in the same AuthorityCommit as the governed operation. Missing contracts, unavailable or expired entitlements, contradictions, normalization overflow, and expiry never become permission. Current audience disclosure remains an additional check and is not frozen into shared Parquet bytes.

### One authority cell owns one World epoch

`CellDirectory` resolves `(realm, World)` to a signed `CellAssignment` and sealed `AuthorityCellLease` before `WorldSession` admission. The assignment contains one authority cell, one monotonically increasing epoch, residency, and optional read, dense, compute, connector, live, or edge cells. The lease binds realm-qualified World, cell, epoch, directory epoch, unguessable fence token, signature, and expiry.

The authority database also stores one `AuthorityFenceRow` per World. Every AuthorityCommit locks that row before the head and verifies matching cell, epoch, fence token, active state, and expiry. The lease or directory alone is never sufficient. The default one-cell deployment uses the same fence, so moving to multiple cells does not introduce a new commit grammar. One World has exactly one authority cell at an epoch. No AuthorityCommit, serializable transaction, World cut, or idempotency coordinate spans cells.

Auxiliary cells receive signed, short-lived capabilities bound to the authority assignment, World head, release, purpose, rights, operation, and expiry. A read cell serves only cut-pinned material. A dense cell executes an authorized plan. A compute or connector cell returns an artifact, observation, or proposal. An auxiliary cell cannot issue a World receipt or advance a head.

Moving a World to a new authority cell is an explicit fenced protocol: change the old local fence row to `transfer-fenced`, stop admission, drain or mark unknown external work, checkpoint and verify the full head and reachable objects, copy and validate authority state, revoke the old row, advance the directory epoch, install a new token and active fence row, then issue the new lease and reopen admission. A crash at any stage leaves zero active writers or the old fenced writer; it never leaves two. Requests with an old cell, epoch, token, or expiry fail. Dual writing is forbidden.

### Offline authority uses a separate edge World

An edge site that only needs reads may use signed, expiring release and data slices from its authority World. An edge site that must decide while disconnected runs a separate edge World with its own World ID, authority cell, head, cut, audit root, memberships, Actions, receipts, and Parquet manifests. It uses the same three products and protocols.

When connectivity returns, the edge and central Worlds exchange signed evidence, DatasetVersions, manifests, proposals, requests, and receipts. Neither replays the other's commits into its own audit chain. The receiving World applies current identity, mapping, rights, evidence, and Action rules before admission.

### Federation composes evidence and Frames, not authority

`FederationAgreement<R>` is a released and approved, realm-qualified contract. Every party is a full `WorldRef<R>` plus trust root; live and evaluation Worlds cannot mix or collide through a bare `WorldId`. It pins semantic and identity mappings, permitted capabilities, effective data-usage contract and obligations, retention, residency, audit, revocation epoch, and expiry.

A `FederatedFrame<R>` contains independently authorized, signed, disclosed component Frames. Each component retains its realm-qualified World, cell, full `KnowledgeBasis`, disclosure, rights decision, signature, lineage, and gaps. The composite has no synthetic global World cut. A current authorization and usage check applies both at export and at access; a redacted Frame is not an export payload.

Cross-World work uses independently committed requests, Cases, receipts, observations, and compensations. The protocol exposes partial, rejected, expired, and unknown outcomes. It does not claim atomicity across Worlds. A remote receipt is evidence to the local World, not a local receipt.

## Consequences

- Licensed-data restrictions survive computation, presentation, model use, export, and federation.
- The same World grammar supports one Fly application, dedicated institutional cells, and offline sites.
- There is no transparent active-active authority for one World.
- Cross-World users must see partial outcomes and component time bases.
- Cell routing, epoch transfer, trust roots, revocation, and rights proofs become critical operational systems.

## Required journeys

1. Data-usage meet across joins, aggregates, model context, alerts, exports, and derived datasets. Contradiction and normalization overflow fail closed; no operation widens or drops a restriction.
2. Missing, expired, contradictory, changed, and unavailable entitlement decisions deny or return unknown.
3. One World routes to one authority cell. A wrong cell or stale epoch cannot read current authority or commit.
4. Authority-cell transfer survives failure before and after each local fence-row transition and never admits two writers; stale cell, epoch, token, and expiry all fail.
5. Cut-pinned read cell, dense cell, connector cell, and compute cell cannot advance the head or escape their lease.
6. Edge World makes an offline decision, then federates evidence and a request without rewriting either audit chain.
7. FederatedFrame preserves component bases, hides a revoked component, and never presents a fake global cut.
8. Cross-World operation produces success, rejection, partial completion, compensation, and unknown without claiming atomicity.

## Reopen triggers

- A product requires single-World offline writes in two places. Define and prove a disjoint authority-partition or lease-transfer semantics in a successor ADR. Infrastructure replication is insufficient.
- Cross-World volume requires an exchange transport. Add a delivery adapter behind signed federation records. It cannot become a distributed commit coordinator.
- Source terms need a missing rights atom. Extend the closed algebra, canonicalization, compiler, and journey corpus before admitting that source.
- No trigger permits rights union by convenience, implicit permission, simultaneous authority cells, or a synthetic global cut.
