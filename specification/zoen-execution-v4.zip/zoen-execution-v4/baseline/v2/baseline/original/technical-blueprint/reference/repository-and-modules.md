# Repository and module constitution

## Shape

One repository contains three product roots, shared release contracts, inward-facing ports, concrete adapters, and journeys. A workspace is earned by an enforceable dependency boundary or a distinct executable/browser target; it is not created for every domain noun.

```text
zoen/
├── apps/
│   ├── server/                 Hono root: public :8080, Eve capability :8081, Restate :9080
│   ├── conversation/           Eve agent + web/Living World; eve build/start -> Nitro :4274
│   └── cli/                    thin OAuth public API/MCP client
├── packages/
│   ├── foundation/             brands, Result, canonical values, clocks at ports
│   ├── release-model/          closed WorldRelease IR and generated facets
│   ├── artifact-protocol/      signed artifact, lease and runner wire contracts
│   ├── door/                   Better Auth identity proof only
│   ├── ontology-domain/        truth, semantics, agency, data, automation, evolution
│   ├── ontology-application/   use cases and consumer-owned ports
│   ├── ontology-protocol/      generated JSON API/MCP/CLI fixed envelopes
│   ├── eve-capability-protocol/ closed loopback requests, results and proofs
│   ├── eve-ontology-client/    generated authenticated client; no repository access
│   ├── eve-capability-server/  :8081 proof verification and application-port adapter
│   ├── eve/                    relationship, Eve event views, attempt context, presentation
│   ├── web/                    React Living World, accessible design system, chart adapters
│   ├── storage-postgres/       explicit SQL, migrations, row decoders, commit protocol
│   ├── storage-objects/        immutable S3/Tigris objects and staging/GC
│   ├── dense-duckdb/           bounded worker adapter for ObservationQueryPort
│   ├── connector-runtime/      isolated signed source/effect/channel artifact runner
│   ├── sandbox-runtime/        executor, planner and mini-app capability broker
│   ├── cell-routing/           World-to-authority-cell directory and signed routing
│   ├── authorization-cedar/    AuthorizationPort implementation
│   ├── effects-restate/        ZoenEffect endpoint and dispatcher adapter
│   ├── channels/               Kapso/Resend bridges, native Telegram, durable ingress
│   ├── channel-state-postgres/ ZoenChatStateAdapter, raw pg, migrator-owned SQL
│   ├── models/                 model provider adapters
│   └── observability/          Pino/OpenTelemetry adapters
├── releases/                   authored release sources and fixture Worlds
├── packs/                      local PackArtifact sources, lockfiles and journeys
├── journeys/                   the only tests
├── operations/                 Fly, local real services, restore and release runbooks
├── architecture/               ADRs and generated evidence ledger
├── package.json
├── pnpm-lock.yaml
├── pnpm-workspace.yaml          catalog, strict peers, install trust policy
├── tsconfig.json
└── eslint.config.js
```

`apps/conversation` remains Eve's visible product home and Eve/Nitro composition root. `eve build` compiles its supported host output and `eve start --host 127.0.0.1 --port 4274` runs it as the second supervised Node process. `apps/server` serves web assets and raw-proxies the complete `/eve/` and `/.well-known/workflow/` prefixes; it does not import private Eve handlers. This does not create a fourth product. Workshop and Living World mini-apps are views over released Ontology capabilities inside Eve. `apps/cli` is an Ontology face, not a product. MCP is an Ontology face, not an agent platform.

The conversation root commits the security surface as source, not deployment folklore:

```text
apps/conversation/agent/
├── tools/
│   ├── bash.ts                 disableTool()
│   ├── read_file.ts            disableTool()
│   ├── write_file.ts           disableTool()
│   ├── web_fetch.ts            disableTool()
│   ├── web_search.ts           disableTool()
│   ├── agent.ts                disableTool()
│   ├── todo.ts                 disableTool()
│   ├── inspect_*.ts            generated, approval declared explicitly
│   └── propose_*.ts            generated, approval declared explicitly
├── sandbox.ts                  explicit fail-closed DisabledSandboxBackend
└── agent.ts                    no skills, connections, or optional tools
```

`ask_question` is the only retained built-in. No `glob`, `grep`, `Workflow`, or `sleep` file exists. Build evidence inspects the generated Eve manifest so source intent and model-visible capability set cannot drift.

## Public package surfaces

Each package has a narrow `exports` map. Deep imports are forbidden. Public types express capabilities rather than repositories:

```ts
export interface DoorPort {
  prove(request: IdentityRequest): Promise<Result<IdentityProof, IdentityError>>;
}

export interface EveOntologyClient {
  request(
    request: AuthenticatedEveCapabilityRequest,
    signal: AbortSignal,
  ): Promise<Result<EveCapabilityResult, EveCapabilityError>>;
}

export interface ObservationQueryPort {
  execute<R extends Realm, Row>(
    plan: ObservationPlan<R, Row>,
    signal: AbortSignal,
  ): Promise<Result<ObservationResult<Row>, ObservationQueryError>>;
}

export interface LiveObservationPort {
  subscribe<R extends Realm>(
    request: OpenLiveSubscription<R>,
    signal: AbortSignal,
  ): Promise<Result<LiveObservationStream<R>, LiveObservationError>>;

  capture<R extends Realm>(
    request: CaptureLiveObservation<R>,
  ): Promise<Result<CapturedObservationRef<R>, LiveCaptureError>>;
}

export interface ConnectorRuntimePort {
  run<R extends Realm>(
    request: ConnectorRunRequest<R>,
    signal: AbortSignal,
  ): Promise<Result<ConnectorRun<R>, ConnectorRunError>>;
}

export interface DataFlowRuntimePort {
  execute<R extends Realm>(
    request: DataFlowRunRequest<R>,
    signal: AbortSignal,
  ): Promise<Result<ProposedDatasetVersion<R>, DataFlowRunError>>;
}

export interface AuthorizationPort {
  decide(request: AuthorizationRequest): Promise<Result<PolicyProof, PolicyError>>;
}

export interface EffectRuntimePort {
  ensureStarted(intent: EffectIntentRef): Promise<Result<InvocationRef, DispatchError>>;
}
```

`AuthenticatedEveCapabilityRequest` is a generated closed union of released inspect/propose/deepen operations. Its envelope binds boot, request, audience, principal evidence, purpose, expected release/head basis, operation ID, deadline, and body digest. The loopback server validates that proof, opens a fresh `WorldSession`, and dispatches to the same Ontology use case as a public surface. The client cannot submit an `AuthorityCommitEnvelope` or carry a standing World capability.

`LiveObservationPort` returns an expiring stream whose envelopes expose basis, sequence, rights, and freshness. It never returns a provider credential. `capture` writes immutable bytes and returns a staged reference; the later Action admits it. `ConnectorRuntimePort` starts only a signed artifact under a brokered lease. `DataFlowRuntimePort` can produce a proposed DatasetVersion but cannot publish it.

Repositories are private implementation details of `storage-postgres`. Application code asks for an atomic use case or a read capability, never a table-shaped CRUD abstraction. There is no `BaseRepository`, generic event bus, service locator, global container, or universal `Entity` type.

## Dependency direction

```text
foundation
   ↑
release-model
   ↑
ontology-domain ← ontology-application ← protocol adapters
                                     ↑
                      concrete storage/policy/dense/effect adapters

foundation ← door
foundation + release facets ← eve ← channel/model adapters
                                 ↑
eve-capability-protocol ← eve-ontology-client ← apps/conversation
             ↓
eve-capability-server → ontology-application

chat StateAdapter ← channel-state-postgres ← apps/conversation

apps/server assembles Door/Ontology; apps/conversation assembles Eve/Nitro
```

Enforced rules:

1. `ontology-domain` imports only `foundation` and `release-model`.
2. `ontology-application` owns its ports; adapters depend inward to implement them.
3. `eve` may import the generated `EveOntologyClient` and fixed protocol values, never Ontology storage, domain constructors, Cedar, Restate, or `pg`.
4. `door` imports Better Auth but no World, membership, policy, Action, or relationship concept.
5. Eve-native hooks and plain typed `EveAttemptContext` own attempt composition. Cordis is absent from the launch graph; an EvaluationWorld adapter may import it only after the three-need gate passes.
6. `effects-restate` reloads an immutable EffectIntent through an application port; it never accepts an arbitrary provider payload.
7. `channels` cannot construct a principal or DecisionHandle. Channel presence remains delegation evidence.
8. Browser and CLI import generated public contracts, not server implementation modules.
9. `apps/server` alone assembles authority adapters. `apps/conversation` may assemble Eve, channel/model adapters, exact-pinned Workflow Postgres, `channel-state-postgres`, and `eve-ontology-client`, but no authority adapter.
10. `channel-state-postgres` implements the public `chat@4.39.0` `StateAdapter` directly with raw `pg`. It can reach only the dedicated `eve_channels` database; `kapso` and `email` runtime roles are DML-only and schema DDL belongs to the Zoen migrator. It cannot import Ontology, Door, Workflow, or `@chat-adapter/state-pg`.
11. `connector-runtime` and `sandbox-runtime` import wire contracts and broker clients only. They cannot import `ontology-domain`, `ontology-application`, `storage-postgres`, Better Auth, Cedar, or Restate.
12. `cell-routing` resolves a World before admission. It cannot proxy or coordinate an `AuthorityCommit` across cells.
13. `artifact-protocol` contains transport-safe schemas and signatures only. Artifact installation semantics remain in Ontology evolution.
14. Eve launch code cannot import a sandbox backend factory, call `ctx.getSandbox()`, construct byte-backed AI SDK file parts, declare skills/connections, or add tools other than the explicit disable sentinels, `ask_question`, and generated `inspect_*`/`propose_*` set.

ESLint catches forbidden source imports, dependency-cruiser proves the workspace graph, TypeScript references prevent build-time cycles, and `exports` prevents accidental deep entry. These checks are static gates, not journey files.

## Deep Ontology modules

`ontology-domain` is internally divided by laws:

- **truth:** evidence admission, identity, beliefs, valid/recorded time, Frame and explanation;
- **semantics:** interfaces, object sets, functions, retrieval plans and subscriptions;
- **agency:** released Action, canonical Case, authorized views, contributions, decision, receipt;
- **attention:** Watch definition, checkpoint materiality, Notice truth;
- **data:** live captures, DatasetVersion, data-flow definitions, quality and field lineage;
- **automation:** WorkflowInstance, headless AgentRun, budgets and checkpoints;
- **evolution:** release identity, proof, preparation, activation, replay;
- **external:** EffectIntent, attempts, reconciliation, Settlement facts;
- **federation:** Pack proposals, trust agreements, exported Frames and cell epochs;
- **commit:** plans and validates the exact semantic write set, but knows no SQL driver.

These directories can begin inside two workspaces (`ontology-domain`, `ontology-application`). Split one out only if it forms a genuinely deep, stable interface with multiple consumers. Package count is not an architecture metric.

## Generated surfaces

The release compiler emits one intermediate `SurfaceManifest` from the canonical WorldRelease. Deterministic generators derive:

- JSON API route descriptors and OpenAPI facets;
- MCP tool/resource descriptors;
- CLI command descriptors and help;
- browser client schemas and form/presentation metadata;
- declarative `MiniAppManifest` documents for Workshop and Living World;
- Eve's currently authorized tool catalog;
- interface, object-set, function, change-subscription, data-flow, agent, and pack developer schemas.

Generated output contains semantic IDs, stable approved slugs, released input/output JSON Schemas, consequence/explanation metadata, and digests. Each surface adapter maps its transport to the same application command. It may never add a domain verb.

The first-party React renderer consumes only the closed mini-app document. It can compose released Frames, tables, charts, explanations, Cases, and Actions, but a visual component never receives a database client or infrastructure credential. If a future Rivet Dynamic Apps adapter produces executable presentation code, that code runs behind `MiniAppRuntimePort` in a sandbox and calls the same authorized surface capabilities. Its source, dependency graph, requested capabilities, build evidence, and artifact digest are pinned. A useful declarative rendering remains available when the executable adapter is absent or fails.

Generation is checked for drift. Golden content is compared by canonical digest inside release journeys, not by brittle snapshots of incidental formatting.

## Artifact and developer-platform boundaries

`artifact-protocol` defines canonical bytes for `SignedArtifactHeader`, `ConnectorArtifact`, `MiniAppArtifact`, `ExecutorArtifact`, `ActionPlannerArtifact`, and `PackArtifact`. It also defines request and result schemas for isolated runners. It contains no dynamic loader and no trust decision. Ontology evolution checks registry trust, signatures, revocation, compatibility, rights, proof, and the requested capability diff before a release may reference an artifact.

`connector-runtime` is a separately executable security boundary even when the first deployment supervises it in the same Fly Machine. It starts one artifact per lease with a read-only root, no inherited environment, no authority network route, an egress allowlist, brokered secret access, a write-only content-addressed object broker, bounded resources, and a network-transcript digest. Source, effect, and channel profiles return different closed result unions. The runner cannot list existing objects or load an arbitrary npm dependency from the network at run time.

`sandbox-runtime` shares the lease and evidence protocol but not the connector result algebra. Executors, planners, and mini-app builds receive scoped data or host capabilities. They emit immutable artifacts or proposals. They never receive a connector credential or authority repository.

The developer platform does not get a fourth root. Studio features remain in `apps/conversation`; headless commands remain in `apps/cli`; publication remains in Ontology evolution. A builder can create a release fragment, interface, object-set plan, function, data flow, workflow, agent, mini-app, executor, connector, or pack; run the real journey suite in an isolated EvaluationWorld; inspect the semantic and capability diff; then submit a proposal. The CLI and Studio consume the same generated authoring schemas and proof API.

`packs/` contains source inputs, not installed authority. The build emits a content-addressed `PackArtifact` with dependency lock, licenses, rights, SBOM, signatures, components, migrations, and evaluation evidence. A registry is an untrusted byte distributor. Installation always creates a release proposal and never installs credentials, memberships, grants, background jobs, or network access.

## Cell and federation modules

`cell-routing` has one pre-admission responsibility: resolve `(realm, World)` to an authority cell and epoch, then verify its signed routing record. Once `WorldSession` opens, one application instance and one PostgreSQL authority cell own the operation. Read, dense, live, compute, connector, and edge adapters receive the cell assignment as a lease constraint.

Federation remains inside Ontology's application and domain modules until it earns a separate build target. It verifies `FederationAgreement`, remote trust roots, exported Frame signatures, rights, revocation, and semantic mappings. It admits received material as evidence or a proposal in the local World. It does not expose a repository that writes both Worlds. An edge site that needs offline authority runs a separate World through the same packages and later federates records.

## Composition and configuration

`apps/server` parses only Hono/Door/Ontology configuration with Zod, constructs authority adapters, and passes explicit dependencies into those roots. It starts `eve start` without a shell and supplies a filtered Eve-only environment; no authority database URL, object-store write key, release signer, or Restate identity enters that child environment. `apps/conversation` parses its own Eve, model, channel, `eve_workflow`, and `eve_channels` configuration. The channel connection is asserted different from Workflow, Door, and Ontology connections, and each provider receives only its schema-scoped DML role. Long-lived infrastructure clients may be process singletons owned by their root; mutable request, turn, subscription, connector, flow, or agent state never is.

Eve uses its native hooks and one plain typed `EveAttemptContext` per attempt; Eve owns cancellation, durable steps, state, and cleanup. `InteractionJournal` materializes stable Eve Workflow event identities instead of writing a second replay log. Ontology uses ordinary typed dependencies and no dependency-injection framework. Worker loops receive lease repositories and use-case ports explicitly.

Startup order is: validate Hono configuration; verify the image and artifact trust roots; establish safe authority database/object-store clients; resolve local cell assignments; load active releases and verify digests; verify applied `eve_channels` migrations and DML-only provider grants; start the `:8081` capability and `:9080` Restate listeners; spawn the exact built Eve output on `127.0.0.1:4274` with its filtered environment; verify Eve route, Workflow world, package identities, generated tool manifest, disabled sandbox backend, attachment policy, and channel-state connectivity; start public `:8080`; then claim background leases. Global readiness requires both processes, the active release, migrations, authority storage, production-gated Eve world, and exact locked-down capability surface. Optional models, live feeds, connector runners, provider channels, registries, and auxiliary cells publish separate capability health.

Shutdown order stops Hono admission, revokes live and runner leases, stops new work claims, asks Eve/Nitro to drain, aborts connector/executor sandboxes, data flows, agents, and dense queries, lets authority transactions finish within a bound, checkpoints allowlisted progress, drains all listeners, forwards termination, and closes Workflow, channel-state, and authority clients. If Eve exits unexpectedly Hono exits and Fly restarts the entire Machine; no local restart loop hides a crash. Kill journeys prove recovery from the isolated Workflow/channel databases and authority stores.

## Migration discipline

Migrations are explicit SQL in one monotonic checked-in chain. They contain database invariants, grants, indexes, and schema changes. They do not contain released domain policy. Setup runs migrations transactionally where PostgreSQL permits and records checksum and application compatibility.

Before launch, incompatible internal changes update callers and journeys atomically. Development/test databases may be recreated. Do not create compatibility aliases, dual reads, dual writes, backfills for disposable data, or shadow APIs. Consolidating the baseline is a deliberate coordinated operation with database reset, never incidental cleanup.
