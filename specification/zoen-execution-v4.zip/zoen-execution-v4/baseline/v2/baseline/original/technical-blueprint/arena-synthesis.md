# Architecture synthesis

## Problem

Zoen needs one architecture that can feel personal in conversation, govern consequential action, support dense institutional work, and remain understandable to a small team. The difficult part is not selecting a database or framework. The design must preserve identity, evidence, temporal basis, authorization, conversation, and external uncertainty while exposing explicit target seams for the public modeling, live-data, and professional-workflow categories documented by Palantir and Bloomberg.

## Usage, from the caller's view

A person asks Eve a question. Eve opens a freshly authorized `WorldSession`, reads a cut-exact `WorldFrame`, and answers with evidence references. If the answer needs density, the same semantic document opens in the Living World. If the person wants a consequence, Eve proposes a released Action and opens its ordinary Case. A channel event, model output, mini-app, notebook, connector, or workflow can propose work. None of them can bypass that path.

A builder authors a `WorldRelease`, evaluates it against real product journeys in an isolated `EvaluationWorld`, reviews the proof and capability diff, prepares the exact release for the current full `WorldHead`, and performs one authorized compare-and-swap activation. API, CLI, MCP, Eve, and browser contracts derive from the same `SurfaceManifest`.

The detailed types and signatures are in [types and protocols](reference/types-and-protocols.md). The package boundaries that implement them are in [repository and modules](reference/repository-and-modules.md).

## Shape

The chosen design is a TypeScript modular monolith packaged as one signed image and initially deployed as one Fly Machine. It runs two supervised Node 24 processes because `eve@0.52.0` supports self-hosting as a generated Nitro service, not as a generic Hono handler. Hono owns public `:8080`, authenticated Eve capability loopback `:8081`, and signed Restate `:9080`; `eve start` owns `127.0.0.1:4274`. Hono proxies `/eve/` and `/.well-known/workflow/` without rewriting or reconstructing provider bodies. Eve uses separate `eve_workflow` and `eve_channels` databases, a Zoen-owned raw-`pg` Chat SDK state adapter, an explicit tool allowlist, and a fail-closed disabled sandbox. PostgreSQL constraints and serializable transactions remain the final authority boundary.

The interface is small relative to the behavior it hides. `DoorPort` proves identity. `EveOntologyClient` asks a loopback capability server to open a freshly authorized World for one closed operation. Ontology use cases own complete semantic operations. `AuthorityCommit` is the only path that advances `WorldHead`. `LiveObservationPort`, `ConnectorRuntimePort`, `DataFlowRuntimePort`, `EffectRuntimePort`, and `ChartRendererPort` expose narrow capabilities without leaking provider clients, storage schemas, renderer configuration, or workflow state.

Three execution planes keep different truths separate:

- Authority runs trusted released semantics and can advance a World cut.
- Live delivery, effects, and workflows carry revocable operational work but cannot invent World truth.
- Isolated compute, connectors, models, and executable UI return evidence, artifacts, or proposals for later admission.

This shape gives the public caller one semantic system while keeping complex storage, provider, rights, replay, and rendering rules behind owner-specific interfaces.

## Synthesis decision

Three whole architectures competed under one weighted rubric:

- Candidate A used a Rust authority kernel with a TypeScript relationship edge.
- Candidate B used one strict TypeScript modular monolith.
- Candidate C used a Rust-first server with a narrow TypeScript Door sidecar.

The corrected Candidate B won with an amended 86.0 points. Candidate A scored 79.6 and Candidate C scored 78.8. Official Eve runtime evidence reduced Candidate B's one-Machine simplicity score from 5 to 4 but did not change the result: no current authority invariant requires a second language, while one language materially shortens product iteration, review, deployment, and debugging. PostgreSQL still supplies the concurrency proof that neither language can replace.

The synthesis did not accept Candidate B unchanged. It took the complete `WorldHead`, exact read sets, evidence model, immutable Parquet manifest contract, honest external outcomes, credential isolation, and dense-engine gates from Candidate A. It took the stronger realm, presence, OAuth, EvaluationWorld, restore, and public-surface boundaries from Candidate C. The judge replaced Fastify with Hono, separated Zod from Ajv, selected raw `pg` for authority, restricted Cedar, and corrected Settlement to released observed outcomes or `Unknown`.

The later ambition audit added two missing contracts. A non-authoritative live observation plane removed the per-tick authority ceiling. Signed isolated `ConnectorArtifact` values removed the integration-ecosystem ceiling. Neither addition changed the three products or the single authority path.

## Tradeoffs accepted

- We accept explicit SQL in exchange for reviewable locks, transaction context, RLS, and commit order.
- We accept two supervised processes inside one initial Machine because that follows Eve's supported runtime. A typed, authenticated loopback seam is cheaper and safer than importing private Eve/Nitro internals.
- We accept a closed release IR in exchange for deterministic proof; arbitrary computation runs outside authority and returns artifacts or proposals.
- We accept that Parquet cannot serve live fan-out in exchange for immutable, portable, engine-independent history.
- We accept provider-specific channel bridges and a small Zoen-owned `StateAdapter` in exchange for preserving Kapso, Telegram, and email semantics without giving a third-party adapter schema-creation rights.
- We accept ECharts as the only launch renderer in exchange for current breadth; `ChartDocument` prevents it from becoming released meaning.
- We accept that many ambitious contracts remain unproved in exchange for naming their proof gates instead of pretending that installing infrastructure delivers the product.

## Alternatives considered

The Rust kernel lost because its stronger local type guarantees did not remove PostgreSQL transactions, release protocols, or journey tests. It added a permanent language, RPC, build, deployment, and debugging seam to nearly every new ontology verb.

The Rust-first server lost for the same reason and slowed the most exploratory parts of Eve and the Living World. It remains a credible future dense-compute adapter if representative workloads cross the recorded gate.

Microservices lost because the product boundaries do not yet need network boundaries. A service per concern would expose retries, schemas, health, rollout, and observability to callers without hiding corresponding domain complexity.

A universal workflow engine lost because conversation, local authority, external effects, and application workflows have different truth models. Restate owns only effect recovery. Rivet can implement a named port only after it proves that PostgreSQL and Eve remain canonical.

An ORM authority model lost because identity maps and generated migration abstractions obscure the exact transaction that changes World meaning. Kysely remains available for a future read-only projection package if measured repetition earns it.

## Open questions and risks

- Can the Zoen-owned Chat SDK `StateAdapter` and admission boundary pass the complete public `StateAdapter` conformance, provider-acknowledgement, crash, replay, schema-isolation, and upgrade corpus?
- Can exact-pinned `@workflow/world-postgres@5.0.0-beta.40` pass the parked-run/startup recovery corpus, including the open duplicate-job report, before any production conversation route is enabled?
- Can Rivet Dynamic Apps leave Preview, export a portable artifact, and pass sandbox, replay, failure, and MCP Apps host journeys?
- Which first domain pack best falsifies the general contracts: household finance, clinic coordination, or portfolio operations?
- Do representative dense workloads justify DataFusion, Arrow interchange, a worker process, or more Machines?
- Can the team operate rights propagation, connector isolation, live entitlements, and finance reconciliation at the promised depth?
- Which data, provider, and distribution relationships can Zoen actually acquire? Architecture leaves room for them but cannot substitute for them.

## Next implementation step

Build S0 as a walking product skeleton: one signed image, Better Auth Door, a planted `zoen`, Hono API and MCP, the supported Eve Nitro build/start path, isolated `eve_workflow` and `eve_channels` databases, the locked-down Eve tool/sandbox profile, explicit PostgreSQL migrations and roles, and one empty World. Prove the user outcome with a real journey; prove every forbidden dependency path with dependency-cruiser and ESLint as static gates, not with a disguised test.
