# Ambition audit

## Question

Does the greenfield constitution leave Zoen a credible route to the publicly documented capability categories of Palantir and Bloomberg?

This is a falsification audit, not a launch claim. It tests whether a current decision makes a category impossible without replacing Zoen's authority model. It does not compare private vendor internals.

## Delivery classes

| Class | Evidence required | What it does not mean |
|---|---|---|
| Shipped foundation | Running code plus a named end-to-end journey against the release candidate. | An ADR, type sketch, port, or existing partial implementation does not qualify. |
| Target protocol | A named contract, owner, authority boundary, failure model, and proof gate. | The capability has not been delivered or operated. |
| Unproven product | The protocol fits the constitution, but usability, latency, scale, reliability, or market fit lacks production evidence. | Architectural compatibility is not product parity. |
| Moat | Data rights, content, network access, counterparties, field operations, support, or accumulated customer knowledge. | A schema cannot create it. Zoen must acquire or earn it. |

This audit assigns no competitive category to **Shipped foundation**. The greenfield blueprint is design evidence. A future release can earn that label only through its journeys.

## Verdict

The first pass exposed two real ceilings.

1. The immutable observation design had no honest path for an unconflated, entitlement-aware, order-sensitive live feed. Writing one `AuthorityCommit` per tick cannot match the shape of Bloomberg B-PIPE or a high-rate industrial stream.
2. Image-compiled connectors had no independent installation, isolation, credential, or revocation contract. That design could not support a Palantir-style integration and product ecosystem.

The target protocols below remove both known constitutional blockers. The audit found no other known blocker across the public capability categories that it examined. That conclusion is conditional. The protocols are not shipped, their product qualities are unproven, and a new workload can still falsify the design.

## Twelve gaps that set the ambition floor

| Priority | Capability gap | Required target protocol | Class after this audit | Failure that the protocol must prevent |
|---|---|---|---|---|
| P0 | Live observations | `LiveFeedDefinition`, `LiveSubscription`, `LiveObservationEnvelope`, `LiveObservationBasis`, and `CapturedObservationRef` | Target protocol and unproven product | An authority transaction per tick, stale display without a basis, lost sequence gaps, or an Action using an unpinned quote. |
| P0 | Installable connectors | `ConnectorArtifact`, `ConnectorLease`, and `ConnectorRun` for source, effect, and channel profiles | Target protocol and unproven product | Third-party code holding ambient credentials, writing authority, inventing a `Settlement`, or remaining active after revocation. |
| P0 | Licensed-data rights | `DataUsageContract`, `EntitlementGrant`, `EntitlementSnapshot`, `RightsDecision`, `DerivedRightsDecision`, `UsageObligation`, and `UsageReceipt` | Target protocol and unproven product | Denied data leaking through discovery, counts, charts, citations, cache entries, derived output, export, or an expired live subscription. |
| P1 | Typed object work | Released interfaces, `ObjectSetPlan`, typed `FunctionDefinition`, and object-set subscriptions | Target protocol and unproven product | Each interface inventing its own nouns, filters, functions, or mutation path. |
| P1 | Data integration | `DatasetVersion`, `DataFlowDefinition`, `DataFlowRun`, `QualityGateResult`, and `LineageEdge` | Target protocol and unproven product | Treating a connector call as a governed pipeline, losing checkpoints or schema history, or admitting failed output. |
| P1 | Cells, offline work, and federation | `DeploymentProfile`, `CellBundle`, `CellRelease`, `CellAttestation`, `AuthorityCellLease{epoch}`, `DisconnectedOperationPolicy`, `FederatedSyncAgreement`, `WorldSetBasis`, and `FederatedFrame` | Target protocol and unproven product | Split-brain authority, an unbounded offline grant, or a federated answer that hides per-World release, cut, rights, and failures. |
| P1 | OMS and EMS | Released order lifecycle types, order Cases and Actions, live observation bases, connector reconciliation, execution events, allocations, and Settlements | Target protocol and unproven product | A generic Effect claiming venue success, unsafe retry, or an order state detached from broker and venue evidence. |
| P1 | Models, retrieval, and headless agents | `ModelProfile`, `RetrievalPlan`, `AgentDefinition`, `AgentRun`, `EvalSuite`, and the generated API, CLI, and MCP catalog | Target protocol and unproven product | A conversational runtime becoming the only agent interface, or a model gaining standing authority. |
| P1 | Professional workspace and charts | `WorkspaceDocument`, `ChartDocument`, `ChartRendererPort`, and `RepresentationProof` | Target protocol and unproven product | A chart becoming an untraceable screenshot, a mini-app gaining private writes, or dense work collapsing into chat bubbles. |
| P1 | Governed conversation | Eve's interaction journal, `Focus`, `Watch`, `Notice`, current disclosure, channel identity, and delivery receipts | Target protocol and unproven product | Conversation memory carrying an old grant or a delayed message disclosing data that the person can no longer see. |
| P1 | Developer platform | `SurfaceManifest`, generated SDKs, conformance journeys, local tooling, trace inspection, test realms, and signed artifacts | Target protocol and unproven product | A nominal SDK that lacks debugging, lifecycle, compatibility, or the same authorization semantics as the product. |
| P1 | Product packaging | `PackArtifact`, `PackDependency`, `PackInstallationPlan`, and `PackInstallationReceipt` | Target protocol and unproven product | A marketplace package installing hidden permissions, unresolved dependencies, mutable code, or an unreviewed release. |

## The two ceiling fixes

### Live observation plane

Bloomberg describes B-PIPE as consolidated, normalized, real-time data that includes unconflated updates and market depth. BLPAPI exposes long-lived, identity-bound subscriptions and event streams. Those contracts are not a batch ingestion problem. [B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/), [BLPAPI `Session`](https://bloomberg.github.io/blpapi-docs/cpp/3.26.6/classBloombergLP_1_1blpapi_1_1Session.html)

The live plane remains non-authoritative. It can deliver ordered `LiveObservationEnvelope` updates under a short-lived `LiveSubscription`. Each envelope carries source, connection, sequence interval, event and receive clocks, entitlement revision, normalization version, gap state, and staleness. The runtime rechecks rights during the subscription.

The plane periodically seals immutable segments into Parquet and admits their manifest root through the normal authority path. Parquet remains the durable dense-data contract. It is not the live fan-out protocol.

If an Action depends on a live value, `CapturedObservationRef` identifies the verified immutable capture of the exact quote, book, or provider state. The Action admits that capture and also states its staleness limit, market-state requirement, and revalidation rule. A screen update alone cannot become an Action dependency.

### Installable connector plane

Palantir Data Connection supports built-in and extensible source types, credentials, syncs, schedules, and monitoring. Compute Modules can run custom containers for functions and data integration. Foundry Marketplace packages versioned products with declared inputs and outputs. [Data Connection](https://www.palantir.com/docs/foundry/data-connection/overview), [Compute Modules](https://www.palantir.com/docs/foundry/compute-modules/overview), [Marketplace](https://www.palantir.com/docs/foundry/marketplace/overview/)

`ConnectorArtifact` is a signed, isolated artifact with one declared profile: source, effect, or channel. It includes schemas, a dependency lock, an SBOM, an egress allowlist, a credential class, budgets, idempotency and reconciliation rules, evaluation evidence, expiry, and revocation.

`ConnectorLease` narrows access to one realm, World, provider account, operation set, secret reference, egress set, and time range. `ConnectorRun` records immutable request, response, checkpoint, and outcome digests.

A source connector emits raw evidence or an evidence-admission proposal. An effect connector executes an existing `EffectIntent` and returns provider evidence. A channel connector emits verified ingress or delivery observations to Eve. None can write authority or create a `Settlement`.

## Palantir breadth that the first comparison missed

The public Palantir contract extends well beyond an Ontology and Workshop.

| Product area | Public capability | Zoen requirement | Classification |
|---|---|---|---|
| Data Connection | Batch, incremental, CDC, media, streaming, and virtual-table connections with credentials and versioned dataset transactions. | `ConnectorArtifact` plus `DataFlowDefinition` and `DatasetVersion`. | Target protocol. Operations are unproven. |
| Pipeline Builder | Typed graph and form transforms, schema checks, batch and streaming execution, Spark, Flink, DataFusion, and external compute pushdown. | `DataFlowDefinition`, `DataFlowRun`, `QualityGateResult`, and pluggable executors. | Target protocol. Builder UX and compute breadth are unproven. |
| Functions and compute | Typed Ontology functions plus horizontally scaled container functions, models, and integration jobs. | Released `FunctionDefinition` for common semantics and isolated `ExecutorArtifact` for arbitrary compute. | Target protocol. Runtime breadth is unproven. |
| Time series | Object metadata points to separately indexed, dataset-backed or stream-backed series. | Live observations for the hot path and immutable Parquet manifests for sealed history. | Target protocol. Throughput and latency are unproven. |
| Subscriptions | TypeScript OSDK and WebSocket subscriptions report object-set changes under application permissions. | Authorized object-set subscriptions with explicit basis, gap, resync, and revocation behavior. | Target protocol. |
| Developer platform | SDKs, APIs, IDE support, MCP, custom endpoints, code workspaces, and compute modules. | One `SurfaceManifest`, generated clients, a local test realm, trace tools, and conformance journeys. | Target protocol. The developer experience is unproven. |
| Marketplace | Versioned products declare inputs and outputs, support installation and recall, and can span enrollments through Apollo-managed Foundry products. | `PackArtifact`, dependencies, an installation plan, a receipt, revocation, and release proof. | Target protocol. Distribution and trust are unproven. |
| Apollo and edge | Apollo manages products across connected, intermittent, disconnected, cloud, on-premises, air-gapped, and edge environments. Palantir also documents an offline embedded Ontology client. | Deployment and cell protocols with epoch leases, attestations, bounded disconnected operation, and governed federation. | Target protocol. Fleet operation is unproven. |

Primary references: [Pipeline Builder](https://www.palantir.com/docs/foundry/pipeline-builder/overview), [streaming pipelines](https://www.palantir.com/docs/foundry/building-pipelines/streaming-overview), [time series](https://www.palantir.com/docs/foundry/time-series/time-series-overview), [OSDK subscriptions](https://www.palantir.com/docs/foundry/ontology-sdk/typescript-subscriptions), [developer toolchain](https://www.palantir.com/docs/foundry/dev-toolchain/overview), [Apollo environments](https://www.palantir.com/docs/apollo/core/environments), [offline embedded Ontology](https://www.palantir.com/docs/foundry/developer-console/create-embedded-ontology-application).

## Bloomberg breadth that the first comparison missed

| Product area | Public capability | Zoen requirement | Classification |
|---|---|---|---|
| B-PIPE | Normalized, unconflated real-time data, market depth, several delivery models, and centralized entitlement controls. | The live observation protocol, field and book semantics, continuous rights checks, gap recovery, and sealed history. | Target protocol. Data, latency, and exchange rights are Moats. |
| BLPAPI | Typed service schemas, requests, responses, subscriptions, correlation identifiers, asynchronous events, and identity-bound entitlements. | A connector SDK that preserves provider schemas, event ordering, correlation, entitlement snapshots, and source evidence. | Target protocol. Provider certification is unproven. |
| EMRS and data rights | User, group, application, publishing-service, and source-level entitlement management for Bloomberg and internal data. | The full rights algebra, derived-rights propagation, obligations, and receipts. | Target protocol. Rights agreements are Moats. |
| Event-Driven Feeds | Structured machine-readable news, news analytics, economic indicators, corporate events, and corporate actions. | Event schemas, source-time semantics, corrections, identity resolution, rights, and Watches over admitted evidence. | Target protocol. News production and source access are Moats. |
| EMS | Multi-asset execution, automation, broker and venue connectivity, live analytics, and auditable workflows. | A specialist order and execution lifecycle built on governed Actions, live snapshots, connector runs, and honest Settlements. | Target protocol. Liquidity, venue access, certification, latency, and support are Moats. |
| OMS | AIM and TOMS cover portfolio, order, inventory, risk, allocation, middle-office, compliance, and post-trade work. | Released portfolio and order semantics, long-lived workflows, allocations, reconciled events, and domain-specific projections. | Target protocol. Product depth and operations are unproven. |

Primary references: [B-PIPE](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/), [BLPAPI](https://bloomberg.github.io/blpapi-docs/), [Event-Driven Feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/event-driven-feeds/), [Execution Management](https://professional.bloomberg.com/products/trading/execution-management-system/), [Order Management](https://professional.bloomberg.com/products/trading/order-management-system/), [TOMS](https://professional.bloomberg.com/products/trading/order-management-system/toms/).

## Product and channel boundary

The architecture still has three products: Better Auth Door, Eve and the Living World, and Ontology through CLI, API, and MCP. A data builder, workspace, marketplace, or connector catalog is a feature of those products. It is not a fourth product.

The launch channel set is web, WhatsApp through Kapso, native Eve Telegram, and email.

## Moats remain outside the protocol

The following gaps cannot be closed by adding types:

- Bloomberg's licensed data, exchange and contributor agreements, field definitions, newsroom, historical corrections, liquidity, broker and venue network, and installed professional network.
- Palantir's deployment history, accumulated customer ontologies, integration library, support organization, regulated and edge operations, and builder familiarity.
- either vendor's reliability record, procurement position, training, support, and product habits.

Zoen can design contracts that let these assets attach without corrupting authority. It still has to obtain the rights, build the operations, earn trust, and create repeated use.

## Claim that survives the audit

After the two ceiling fixes and the remaining target protocols, the audit found no known constitutional blocker to the examined Palantir and Bloomberg capability categories.

The claim stops there. Zoen has no shipped parity, no proven scale, no Bloomberg-class data or network, no Palantir-class application and deployment suite, and no evidence that its proposed differences produce a better product. Each target protocol needs an ADR, schema, threat model, real journey, operating evidence, and a user experience that people choose.
