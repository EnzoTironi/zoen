# Eve messaging channels

**Decision date:** 2026-09-04  
**Status:** launch decision; every provider route remains gated by real journey evidence  
**Launch:** Eve web, WhatsApp through Kapso, native Eve Telegram, and email through Resend

## Decision

Eve owns one durable relationship across web and messaging. Its Workflow session event history is the conversation execution truth; `InteractionJournal` is the typed Eve-owned materialization of that history. A channel proves that a provider observed an account or address. It does not prove the human, grant World authority, or make delivery certain. Every transport terminates in Eve and reaches Ontology only through the authenticated `EveOntologyClient` and the ordinary Frame, Case, Action, Watch, and receipt protocols.

The launch integrations are fixed:

| Experience | Eve integration | Public ingress | Dependency |
|---|---|---|---|
| Web | Eve's authenticated first-party web experience | authenticated application route | no messaging adapter |
| WhatsApp | one `eve/channels/chat-sdk` bridge with Kapso | `/eve/v1/kapso` | `@kapso/chat-adapter` |
| Telegram | native `eve/channels/telegram` | `/eve/v1/telegram` | no Chat SDK platform adapter |
| Email | a separate `eve/channels/chat-sdk` bridge with Resend | `/eve/v1/email` | `@resend/chat-sdk-adapter` |

The two Chat SDK bridges use `chat@4.39.0` and `@chat-adapter/state-pg@4.39.0`. Their adapter maps contain one provider each, their PostgreSQL key prefixes differ, and both set `streaming: false`. Pin `@kapso/chat-adapter@0.1.1` and `@resend/chat-sdk-adapter@0.3.0` in the launch lockfile. These versions were current and semver-compatible with Chat SDK 4.39.0 on the decision date. [Chat SDK packages](https://chat-sdk.dev/docs), [PostgreSQL state adapter](https://www.npmjs.com/package/@chat-adapter/state-pg), [Kapso adapter](https://www.npmjs.com/package/@kapso/chat-adapter), [Resend adapter](https://www.npmjs.com/package/@resend/chat-sdk-adapter).

Do not install `@chat-adapter/telegram`, `@chat-adapter/whatsapp`, `@chat-adapter/state-memory`, `@chat-adapter/state-redis`, or `@chat-adapter/state-ioredis`. PostgreSQL is the only Chat SDK state backend in every environment. Restate does not run channel work. Eve owns conversation durability.

Chat SDK is an adapter and routing convenience. It does not own identity, consent, disclosure, Eve session history, or delivery truth. Its PostgreSQL adapter stores subscriptions, locks, deduplication entries, queues, lists, and cache entries. Those records are coordination state, not the Zoen record. [Chat SDK state contract](https://chat-sdk.dev/docs/state-adapters).

## Separate bridges

Kapso and email use separate `chatSdkChannel` instances. This keeps credentials, route names, thread encodings, provider failures, and upgrade evidence independent. Eve documents per-adapter route overrides and one-message delivery through `streaming: false`. [Eve Chat SDK channel](https://github.com/vercel/eve/blob/main/docs/channels/chat-sdk.mdx).

The configuration shape is:

```ts
const kapsoState = createPostgresState({
  client: evePostgres,
  keyPrefix: "eve:chat-sdk:kapso",
});

const kapsoBridge = chatSdkChannel({
  userName: "Eve",
  adapters: { kapso: createKapsoAdapter(kapsoCredentials) },
  routes: { kapso: "/eve/v1/kapso" },
  state: kapsoState,
  streaming: false,
});

const emailState = createPostgresState({
  client: evePostgres,
  keyPrefix: "eve:chat-sdk:email",
});

const emailBridge = chatSdkChannel({
  userName: "Eve",
  adapters: { email: createResendAdapter(resendCredentials) },
  routes: { email: "/eve/v1/email" },
  state: emailState,
  streaming: false,
});
```

This is the intended composition, not proof that the stock webhook path satisfies Zoen's durability rule. The admission gate below must pass first.

## Zoen owns the channel record

Provider types stop at the channel boundary. Eve persists this closed launch protocol:

```ts
type ChannelKind = "whatsapp" | "telegram" | "email";

type ChannelEndpoint =
  | {
      kind: "whatsapp";
      channelAccountId: string;
      phoneNumberId: string;
      whatsAppUserId: string;
    }
  | {
      kind: "telegram";
      channelAccountId: string;
      chatId: string;
      senderUserId: string | null;
      messageThreadId: string | null;
      businessConnectionId: string | null;
    }
  | {
      kind: "email";
      channelAccountId: string;
      remoteMailbox: string;
    };

type SubmissionOutcome =
  | { kind: "accepted"; providerMessageId: string }
  | { kind: "rejected"; code: string; retryable: boolean }
  | { kind: "unknown"; attemptId: string; reconcileAfter: string };

type DeliveryObservationKind =
  | "provider-accepted"
  | "recipient-server-accepted"
  | "device-delivered"
  | "read"
  | "opened-unreliable"
  | "clicked-unreliable"
  | "delayed"
  | "bounced"
  | "complained"
  | "failed";
```

Web uses the Door principal and Eve session. It does not create a provider `ChannelEndpoint`.

Eve owns these durable records:

- `ChannelEndpoint` is a provider-scoped address, never a principal.
- `ChannelBinding` joins an endpoint to a relationship after explicit Door enrollment. It records the proof, scope, consent, assurance, expiry, and revocation.
- `ChannelThread` maps a provider conversation, topic, or email reference chain to one Eve branch. A Chat SDK thread ID is correlation, not authority.
- `ChannelIngress` is append-only and unique on `(channelAccountId, providerEventId)`. It records the exact-body digest, raw-body reference under retention policy, verified credential version, provider time, receive time, and normalized event.
- `AdmittedChannelIngress` is the verified, immutable accepted input. Its transaction appends the ingress and an Eve-delivery outbox command; it does not attempt a cross-process write into Eve's Workflow history.
- Eve durably accepts the stable ingress identity into its command inbox. `InteractionJournal` then materializes the resulting stable Eve session/turn/step events and can be rebuilt from them.
- `ChannelDeliveryIntent` is Eve-owned, immutable, and idempotent. `ChannelDeliveryAttempt` and append-only `ChannelDeliveryObservation` record what the outside world reported without rewriting history.
- `ChannelConsent` records the purpose, categories, source, time, and revocation. An unsubscribe or leave event closes only the matching permission.

All numeric provider identifiers are validated decimal strings at the boundary. Eve never joins identities because phone numbers, usernames, display names, contacts, email addresses, or message content look equal. A person links each endpoint through Door. Link, unlink, merge, and recovery remain visible relationship events.

## Admission before acknowledgement

The target invariant is strict: Eve admission commits `AdmittedChannelIngress` and its delivery outbox command before returning a successful provider acknowledgement. The dispatcher then submits that stable identity to Eve until Eve durably accepts it. Agent work starts only after Eve's acceptance. This order permits fast acknowledgement without risking an accepted but unrecorded message and avoids pretending the two runtime databases share one transaction.

The current upstream integrations do not prove that invariant. `eve/channels/chat-sdk` passes Eve's `waitUntil` into the adapter. Chat SDK's `processMessage` then runs handlers in a detached task, registers that task with `waitUntil`, and lets adapters return `2xx`. Handler errors are logged and intentionally do not ask the provider to retry. `@chat-adapter/state-pg` can claim SDK deduplication state before the response, but it does not append the Zoen admission record or retain a replayable Zoen ingress event. A process loss after `2xx` and before admission can therefore lose the turn. [Eve bridge source](https://github.com/vercel/eve/blob/main/packages/eve/src/public/channels/chat-sdk/chatSdkChannel.ts), [Chat SDK processing source](https://github.com/vercel/chat/blob/main/packages/chat/src/chat.ts), [Resend 0.2.2 release note about detached processing](https://github.com/resend/resend-chat-sdk/releases/tag/v0.2.2).

Native `eve/channels/telegram` has the same launch question today. Its route schedules `dispatchMessage` with `waitUntil` and returns `ok`. Native ownership is the right product boundary, but it is not evidence of admission before acknowledgement. [Eve Telegram route source](https://github.com/vercel/eve/blob/main/packages/eve/src/public/channels/telegram/telegramChannel.ts).

Production enablement requires one stable solution for every route:

1. An upstream Eve or Chat SDK hook awaits Zoen's admission transaction after provider verification and before the adapter returns `2xx`.
2. A Zoen ingress gateway owns the public route, verifies and admits the exact envelope with a delivery outbox command, then hands a trusted admitted event to a private channel hook. Recovery can replay the admitted event without reusing an expired provider signature.
3. An upstream release adds the same ordered contract. Zoen pins that release and proves the contract through a real journey before removing the gateway.

A reverse proxy that only forwards the webhook is not sufficient. A private replay path that calls the public webhook again is also insufficient because a timestamped signature can expire. Do not maintain a hidden fork or depend on private adapter methods. Until one solution passes the admission journey, the corresponding channel is unavailable in production.

After admission, Eve processes asynchronously. Egress uses PostgreSQL leases, not Restate. A `ChannelDeliveryIntent` records the relationship branch and cut, disclosure result, rendered payload digest, destination binding version, consent version, and adapter version. A timeout becomes `unknown`. Eve reconciles it by provider message ID, callback, or history before another send. No callback can create an Ontology commit directly.

Provider observations may be duplicated, delayed, missing, and out of order. Eve appends each observation and derives a partial-order view. It never erases contradictory evidence. "API accepted" is not "delivered", "mail server accepted" is not "in inbox", and an open pixel is not a human decision.

## Identity and threading

| Channel | Endpoint key | Thread key | What it proves | What it does not prove |
|---|---|---|---|---|
| Kapso | channel account, business phone number, and WhatsApp user ID | adapter thread plus Kapso conversation and reply context | that a WhatsApp-side address produced an event for this business number | legal identity, sole phone possession, or World membership |
| Telegram | bot account, chat, and sender, with an optional business connection | chat plus `message_thread_id`, reply anchor, or direct-message topic | that a Telegram account or chat produced an update visible to this bot | phone, email, real-world identity, or group authority |
| Email | exact remote mailbox plus one opaque Zoen reply token | validated `Message-ID`, `In-Reply-To`, and `References`, plus that token | that this message arrived through a mail path with this envelope and content | named sender, sole mailbox control, lasting ownership, delivery, or read |

Eve canonicalizes only the email domain with IDNA and domain case rules. It does not remove dots, discard plus tags, or case-fold local parts globally. A subject is presentation, never a thread key. The reply token is random, hashed at rest, scoped to one relationship and branch, revocable, and free of protected facts. Forwarding can leak the token, so it restores context only. Sensitive reads and material Actions still require Door.

Every group sender remains separate. A Telegram group or multi-recipient email maps to a shared Eve branch only under a released audience policy. The presence of one enrolled participant does not authorize disclosure to the room. WhatsApp groups are not a launch capability.

## Rendering preserves meaning

Every outbound message starts as a released semantic `RenderDocument` with a complete plain-text form. Messaging flattens structured chrome into readable text. It never mimics web buttons with fake syntax, invents a URL, or summarizes a dashboard that the person cannot inspect.

| Semantic form | Web | Kapso | Telegram | Email |
|---|---|---|---|---|
| answer with evidence | full Living World view | text and admitted media with stable references | plain text and admitted media | complete text part with optional sanitized HTML |
| bounded choice | native control | up to the adapter's validated reply buttons | inline keyboard | numbered reply choices or a Door continuation |
| scheduling | full Workshop flow | readable choices; richer forms only after a proved adapter capability | buttons or a validated Mini App | calendar artifact or Door continuation after disclosure |
| complex form | Workshop | stable Living World continuation | constrained Mini App or Living World continuation | Living World continuation, never an authoritative email form |
| material Action | normal Case and Action | opaque proposal handle reopens the Case | callback or continuation reopens the Case | authenticated continuation or parsed reply proposal; GET never mutates |

Native controls carry opaque, short-lived proposal handles. A press can select or propose. It cannot manufacture success. Eve reopens the current release, disclosure, consequences, and authorization. Sensitive Notices default to a minimally revealing sentence and an authenticated continuation.

## WhatsApp through Kapso

Kapso is the only WhatsApp destination. `@kapso/chat-adapter` is the integration point. Do not use the generic WhatsApp Chat SDK adapter and do not build a second direct Meta path. The Kapso adapter verifies Kapso signatures, maps WhatsApp threads, sends text, buttons, and media, and can read Kapso history. Features absent from this adapter remain off or are contributed upstream before use. [Kapso Chat SDK adapter](https://www.npmjs.com/package/@kapso/chat-adapter).

Kapso webhooks are HTTPS requests signed with HMAC-SHA256 over the raw body. They include `X-Idempotency-Key`, require a `200` within 10 seconds, retry failed delivery, and may arrive out of order. The gateway or admission hook preserves the raw bytes and scopes deduplication by channel account plus provider event ID. [Webhook overview](https://docs.kapso.ai/docs/platform/webhooks/overview), [webhook security](https://docs.kapso.ai/docs/platform/webhooks/security), [ordering and retries](https://docs.kapso.ai/docs/platform/webhooks/advanced).

Kapso exposes sent, delivered, read, and failed observations, but each remains an observation rather than a Zoen outcome. A send timeout is `unknown`. Kapso message history and status filters support reconciliation before retry. Outbound attempts are serialized per channel thread because Kapso documents a `409` for concurrent sends to the same recipient. [Message query](https://docs.kapso.ai/api/meta/whatsapp/messages/list-messages), [Kapso changelog](https://docs.kapso.ai/changelog).

The 24-hour user-initiated window is an explicit capability. Outside it, Eve sends only a currently approved, purpose-compatible template that passed disclosure and consent. Missing template or Flow support does not trigger a silent fallback or a direct SDK bypass. [Flow sending](https://docs.kapso.ai/docs/whatsapp/flows/sending-flows), [template lifecycle](https://docs.kapso.ai/docs/whatsapp/templates/lifecycle).

## Telegram first-class

The launch experience is a direct Eve bot through `eve/channels/telegram`. The native channel owns Bot API verification, thread correlation, attachments, inline-keyboard human input, and completed-message delivery. It mounts `/eve/v1/telegram` and sends plain text by default, which matches the no-chrome rule. [Eve Telegram channel](https://github.com/vercel/eve/blob/main/docs/channels/telegram.mdx).

A bot cannot start a conversation with an ordinary user. The user first messages the bot or adds it to a group. Telegram retains Bot API updates for no more than 24 hours. `update_id` supports duplicate and order recovery. Webhooks can carry `X-Telegram-Bot-Api-Secret-Token` and Telegram retries after non-`2xx` responses. [Bot introduction](https://core.telegram.org/bots), [Bot API](https://core.telegram.org/bots/api).

Production uses webhooks with a high-entropy `secret_token`, explicit `allowed_updates`, bounded connections, and durable uniqueness on `(botAccountId, update_id)`. Eve stores `chat_id`, `user.id`, `message_id`, `message_thread_id`, and `business_connection_id` as decimal strings where applicable. Usernames and display names remain labels.

Group Privacy Mode stays on by default. Broad group visibility is a separate administrator-visible capability. Telegram otherwise limits a privacy-mode bot to commands, relevant replies, service messages, and messages sent through the bot. [Telegram bot features](https://core.telegram.org/bots/features).

A successful `sendMessage` proves provider acceptance. The Bot API does not document a general delivered or read callback for ordinary bot messages. Eve stops at `provider-accepted`; a later reply is engagement evidence, not retroactive proof for every prior message.

Mini Apps are optional Workshop renderers. Eve verifies raw `initData` on the server and never trusts `initDataUnsafe`. The result still has only channel-presence authority. Telegram Business connections remain gated until every attempt checks current rights and revocation. [Telegram Mini Apps](https://core.telegram.org/bots/webapps), [Telegram Business behavior](https://core.telegram.org/bots/features).

## Email first-class

Email supports inbound replies, outbound Notices and conversation, RFC threading, attachments, bounces, complaints, consent, and unsubscribe. It is the broadest asynchronous channel and the weakest default identity and receipt channel. Eve never treats HTML, a From display name, a click, an open, or SMTP acceptance as authority.

### Resend behind the email port

`@resend/chat-sdk-adapter` supplies the first provider implementation behind the provider-neutral `/eve/v1/email` route. It receives signed Resend webhooks, sends through Resend, maps standard email headers into threads, exposes attachments, and supports proactive threads. `ChannelThread`, not the adapter's thread cache, remains canonical. [Resend Chat SDK adapter](https://resend.com/docs/chat-sdk).

`EmailChannelPort` is Zoen's provider-neutral boundary for send, inbound retrieval, attachment retrieval, delivery reconciliation, and suppression. The Resend bridge implements that port. Provider credentials, event names, and IDs do not cross it.

Resend provides a 24-hour send idempotency key, signed Svix webhooks over the raw body, at-least-once and out-of-order delivery, inbound retrieval after webhook downtime, raw message and attachment retrieval, lifecycle events, and current `Message-ID` support. [Send idempotency](https://resend.com/docs/dashboard/emails/idempotency-keys), [webhook verification](https://resend.com/docs/webhooks/verify-webhooks-requests), [webhook guarantees](https://resend.com/docs/webhooks/introduction), [receiving](https://resend.com/docs/dashboard/receiving/introduction), [received email retrieval](https://resend.com/docs/api-reference/emails/retrieve-received-email), [threading](https://resend.com/docs/dashboard/receiving/reply-to-emails).

Resend is an adapter choice, not an email-domain contract. A future provider replaces the adapter without changing the public route, endpoint identity, thread record, consent, or delivery observations.

### Authentication, threading, and replies

- The sending domain publishes SPF under RFC 7208, aligned DKIM under RFC 6376 with the stronger guidance in RFC 8301 and RFC 8463, and DMARC under RFC 9989. Enforcement follows monitored alignment across every legitimate stream. [SPF](https://www.rfc-editor.org/rfc/rfc7208), [DKIM](https://www.rfc-editor.org/rfc/rfc6376), [cryptographic updates](https://www.rfc-editor.org/rfc/rfc8301), [Ed25519 DKIM](https://www.rfc-editor.org/rfc/rfc8463), [DMARC](https://www.rfc-editor.org/rfc/rfc9989).
- DMARC authenticates authorized use of the Author Domain. It does not authenticate a person, message truth, display name, lookalike domain, or content. Authentication results inform abuse risk only and cannot bypass Door. [RFC 9989](https://www.rfc-editor.org/rfc/rfc9989).
- Every outbound conversational email has a stable RFC `Message-ID`. Replies set `In-Reply-To` and a bounded `References` chain under RFC 5322. The opaque reply token covers clients and gateways that omit or corrupt headers. [RFC 5322](https://www.rfc-editor.org/rfc/rfc5322).
- Eve detects `Auto-Submitted`, null return paths, delivery-status notifications, list headers, and loop headers before creating a turn. Automated outbound replies set `Auto-Submitted`. [RFC 3834](https://www.rfc-editor.org/rfc/rfc3834).
- The parser prefers decoded `text/plain`. It sanitizes HTML into text and semantic blocks, does not fetch remote images on ingress, and treats quote stripping as a hint. Attachments are size-limited, content-sniffed, hashed, malware-scanned, and admitted separately before a model receives an extracted form.
- A reply can answer a prompt or contribute to a Case. Ambiguous quote boundaries, forwards, changed recipients, automated replies, list mail, and multiple proposed decisions cause clarification, never a guessed Action.

### Consent and actionable email

Transactional and subscribed delivery use separate consent categories. A suppression, hard bounce, complaint, or unsubscribe closes the matching permission before the next leased send. Subscription mail includes a visible unsubscribe path and RFC 8058 one-click headers covered by DKIM. The one-click POST can revoke consent only. [RFC 8058](https://www.rfc-editor.org/rfc/rfc8058), [Gmail sender requirements](https://support.google.com/mail/answer/81126).

Links come from the allowlisted `PublicLinkPort` and carry a short-lived opaque continuation. A GET displays current state or starts navigation. It never mutates a World, approves a Case, or confirms identity because scanners, previews, forwarding, and accidental taps can issue GET requests. The person signs in or steps up through Door and uses the same Action path as web, API, CLI, and MCP. A parsed email command is a proposal, never ambient authority.

Resend's `email.delivered` means that the recipient mail server accepted the message. It does not prove inbox placement, human receipt, or reading. Later failure or silent filtering remains possible. Open and click telemetry is unreliable and never acts as consent, identity, or a business receipt. [Resend event semantics](https://resend.com/docs/webhooks/event-types), [SMTP responsibility](https://www.rfc-editor.org/rfc/rfc5321), [Resend delivery caveat](https://resend.com/docs/dashboard/emails/introduction).

## Parity contract

Zoen promises semantic parity, not identical controls:

- the relationship branch, stable references, current disclosure, governed verbs, provenance, evidence, and receipts survive a channel switch;
- every rich control has a complete text representation;
- every material operation re-enters the same Case and Action;
- provider capabilities can change without changing Ontology.

| Capability | Web | Kapso | Telegram | Email |
|---|---|---|---|---|
| durable Eve conversation | full | full after admission gate | full after admission gate | full after admission gate |
| delivery evidence | first-party session record | sent, delivered, read, and failed provider observations | provider acceptance; no general read receipt | recipient-server acceptance; unreliable open and click signals |
| proactive contact | authenticated product policy | window, template, and consent constrained | only after the user starts or adds the bot | consent, reputation, and recipient filtering constrained |
| Workshop experience | full Living World | readable text and proved adapter controls | Mini App or Living World continuation | complete email plus Living World continuation |
| shared audience | governed membership | no launch group capability | gated group and topic support | multi-recipient mail remains gated |
| channel identifier as person | Door principal | no | no | no |

## Deferred Apple Messages seam

Apple Messages and consumer iMessage are entirely outside launch. Eve already publishes `eve/channels/linq` as a possible later provider integration, so Linq is the only seam to evaluate in a future ADR. Zoen adds no Linq dependency, endpoint, credential, `ChannelKind` case, `ChannelEndpoint` variant, product claim, or required journey now. A later decision must prove supported commercial use, identity boundaries, admission before acknowledgement, consent, retention, delivery semantics, and real-account journeys. Personal Apple Account relays, Mac fleets, reverse-engineered protocols, and Messages database readers remain prohibited. [Eve Linq channel](https://github.com/vercel/eve/blob/main/docs/channels/linq.mdx).

## Required journeys

These journeys use the deployed product, real PostgreSQL, and protected provider accounts. They do not use mocks, fakes, stubs, `vi.mock`, or capture-adapter assumptions.

1. **Binding and revocation.** Enroll each endpoint through Door, move between web and the channel, revoke from another device, and prove that a stale channel can neither disclose nor act. Equal phone or email labels never merge automatically.
2. **Admission before acknowledgement.** Run each public webhook against a real provider. Kill Eve before the journal commit and observe a provider retry. Kill it after commit but before dispatch, restore from `ChannelIngress`, and produce one turn. The journey fails if a stock route returns `2xx` while the journal lacks the event.
3. **Duplicate and order.** Deliver the same verified event twice and lifecycle observations out of order. One ingress settles, all evidence remains, and at most one assistant response and one Action proposal exist.
4. **Cross-channel continuity.** Start in web, continue in one linked channel, and return to web. The branch, cut, references, pending Case, and consent stay coherent without copying provider identity into a principal.
5. **Unknown outbound.** Cut the network after provider submission. Recovery reconciles before any retry and reports `unknown` until an external fact resolves it.
6. **Disclosure at delivery.** Create a Notice, revoke membership while it waits, then release the lease. Eve reopens disclosure and sends an allowed minimal notice or nothing.
7. **Readable degradation.** Render an answer, comparison, Case, receipt, and Workshop continuation on every launch experience. A text-only client keeps the meaning. No renderer invents a URL or fake control.
8. **Kapso.** Cover raw-body HMAC failure, secret rotation, duplicate idempotency key, the 10-second budget, late observations, thread serialization, media quarantine, the 24-hour boundary, the approved-template path, and history reconciliation.
9. **Telegram.** Cover user-start, secret-token failure, duplicate and out-of-order `update_id`, topic and reply correlation, Privacy Mode disclosure, rate limiting, validated Mini App `initData`, and the absence of a fabricated read receipt.
10. **Email threading and spoofing.** Use real external inboxes for aligned and failed SPF, DKIM, and DMARC; display-name and lookalike attacks; replies with and without references; forwards and changed recipients; automated loops; malformed MIME; duplicate and out-of-order signed webhooks; provider retrieval; bounce, complaint, suppression; and server-accepted but unread mail.
11. **Actionable email.** Let a security scanner follow every link and let a forwarded recipient use the reply token. GET causes no mutation, protected state stays hidden, and only Door plus the normal Action path can decide.
12. **Consent.** Unsubscribe through email one-click, a Telegram command, and a WhatsApp preference. Each event closes only its scoped permission before the next leased send.
13. **Restore.** Restore Eve's database, fence old workers, enumerate pending delivery intents, reconcile providers, and avoid repeating an ambiguous external send.

## Open gates

The architecture is fixed. These launch facts still require evidence:

- which admission hook, gateway, or upstream release gives every route a replayable Zoen journal commit before `2xx`;
- whether the pinned vendor adapters pass compatibility journeys with `chat@4.39.0` and `@chat-adapter/state-pg@4.39.0` without private APIs;
- whether Kapso's current signature, ordering, status, template, history, media, and concurrency behavior passes the real account journeys;
- whether Telegram Business belongs in launch or follows the direct Eve bot;
- whether Resend passes data-processing terms, region, retention, erasure, deliverability, inbound abuse, attachment, retrieval, support, and cost requirements;
- which country-specific consent, marketing, health, finance, records, and erasure rules constrain proactive delivery;
- the measured payload, attachment, rate, latency, and cost budgets for each provider.

A failed gate disables that channel. It does not change Door, Eve, Ontology, the canonical interaction journal, or the behavior of the other verified experiences.
