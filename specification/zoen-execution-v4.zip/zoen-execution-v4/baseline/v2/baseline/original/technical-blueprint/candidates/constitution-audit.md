# Constitution audit: language-independent gaps

Status: synthesis input.  
Audit date: 2026-09-04.  
Scope: [Candidate A](a-hybrid/design.md), [Candidate B](b-typescript/design.md), and [Candidate C](c-rust-first/design.md).

## Verdict

The candidates agree on the product: three products, one governed World, PostgreSQL authority, immutable evidence, selective events, Parquet for dense observations, Eve-owned conversation durability, and Restate only for `ZoenEffect`.

They do not yet describe one executable constitution. Several differences would let two conforming implementations produce different authority, release, security, and recovery behavior. The final blueprint should resolve the P0 items below before choosing modules or writing migrations.

Candidate B is the best base because it has the most complete PostgreSQL, dense-data, protocol, and CI contracts. Candidate C contributes the clearest event envelope, deep module shape, channel-assurance rule, and conservative release language. Candidate A contributes the strongest signing, benchmark, telemetry, and backup ideas. No candidate should be copied whole.

## Comparison at a glance

| Area | Candidate A | Candidate B | Candidate C | Required synthesis |
| --- | --- | --- | --- | --- |
| `WorldHead` | release, generation, cut, revision; manifest root lives in Frame basis | release and generation in head; generation manifest has a separate mutable head | commit flow mentions manifest root and audit root, but activation changes only release and generation | one full head tuple that includes manifest root and audit root |
| Idempotency | `(world, key)` | `(realm, world, principal, operation kind, key)` | same as B | use the B/C coordinate and define bootstrap scope and authorized replay |
| World event | per-stream `WorldTransition` shape plus an implied batch | transition union, batch semantics not fixed | one commit envelope with ordered stream changes and one audit root | use C's envelope, with canonical bytes and consumer receipts |
| Silent progress | Watch checkpoint advances without a transition, but sole-write-port language is ambiguous | operational writes exist but no named boundary | Watch may remain silent while advancing its checkpoint | separate semantic `AuthorityCommit` from constrained progress transactions |
| Dense storage | strong invariants, high-level manifest | complete tables, publication protocol, query port, and GC roots | good Merkle/rights description, less relational detail | B as base; add C's field/clock/rights metadata and a full head pin |
| Release language | JSON Schema, Cedar, and optional Wasm | closed declarative IR and trusted handler registry | closed total IR; no Wasm initially | choose one v1 language; recommended closed IR, Cedar only for authorization, no Wasm initially |
| Proof signature | DSSE with a managed signing key | signed proof is required but envelope and trust root are not fixed | detached Ed25519; trust root remains open | DSSE predicate with a managed signer registry and rotation |
| Evaluation isolation | separate job, database, roles, prefixes, and credentials | realm and lease isolation inside one application is emphasized | separate process credentials or database/schema set | proof-producing evaluation must run without live credentials |
| Public parity | one catalog, several native names | strongest protocol and JSON-envelope detail | strongest facet model | define semantic equality separately from presentation equality |
| Journeys and CI | seven journeys and measured budgets | ten-part taxonomy and strongest tier design | seven journeys and real `CaptureChannel` semantics | seven constitutional journeys with B's recovery cases and tier evidence |
| Restore | PITR, object retention, signed checkpoints, monthly journey | backup/restore required and filtered-backup defense | PITR plus manifest validation | add a recovery fence so restored outboxes cannot repeat unsafe external work |
| Module depth | good dependency rules; public acquire/admit split is too procedural | strong ports; package tree risks one package per noun | strongest knowledge-owned modules | use C's ownership shape with B's narrow Eve port and adapter rules |

## P0 gaps to close before implementation

### P0.1 Define one complete `WorldHead`

All authoritative reads and writes need one immutable snapshot coordinate. The current candidates split the release, derived generation, dense manifest, cut, and audit root in different ways.

Graft this language-neutral contract:

```text
WorldHead = {
  world,
  headVersion,
  cut,
  releaseDigest,
  dataGenerationDigest,
  observationManifestDigest,
  auditRoot
}
```

- A `KnowledgeCut` copies this complete tuple plus `recordedAt`; it never looks up a later generation or manifest.
- A `WorldFrame`, `ActionCase`, Watch evaluation, explanation, and Scenario bind the exact `KnowledgeCut` they read.
- Dense admission atomically changes `observationManifestDigest`, advances `cut` and `headVersion`, and extends `auditRoot` in one `AuthorityCommit`.
- Release activation atomically changes `releaseDigest`, `dataGenerationDigest`, and `observationManifestDigest`; it also advances the cut, version, and audit root.
- A transaction either sees the old tuple or the new tuple. It cannot join a release from one head with a manifest from another.
- `DataGeneration` identifies a release-compatible derived representation. `observationManifestDigest` identifies the exact dense snapshot inside that generation. Neither can stand in for the other.

This resolves the split `generation_heads` risk in Candidate B and the omitted activation manifest in Candidates A and C.

### P0.2 Fix the `AuthorityCommit` protocol and idempotency coordinate

Use one closed internal command algebra. Public callers never submit mutation plans, lock lists, SQL, or event payloads.

```text
OperationCoordinate = {
  realm,
  authorityScope,       // World, or principal bootstrap before a World exists
  authorizationPrincipal,
  operationKind,
  operationKey
}
```

The idempotency row stores the canonical intent digest and an immutable result reference.

- Same coordinate and same intent returns the original result only after fresh authorization to that result.
- Same coordinate and different intent returns `IdempotencyConflict`.
- A bootstrap coordinate uses `(realm, principal, operation kind, key)` because no World exists yet.
- Provider idempotency keys and Restate invocation IDs are derived coordinates with separate namespaces. They are not caller `OperationKey`s.
- One semantic command owns exactly one World. Cross-World atomic commits are forbidden. Exchange between Worlds becomes independently admitted evidence.

Every semantic command follows one fixed transaction skeleton:

1. insert or lock the idempotency coordinate;
2. lock `WorldHead` when the World exists;
3. lock affected aggregates in stable `(kind, id)` order;
4. revalidate the grant, release, head, exact reads, and policy;
5. allocate one next cut;
6. write semantic rows, the receipt, deterministic EffectIntents, one transition envelope, and outbox rows;
7. update the full head tuple and idempotency result;
8. commit or retry the whole transaction on serialization failure.

No model, network, object-store write, Restate call, or provider call occurs inside this transaction.

### P0.3 Separate semantic authority from operational progress

The phrase `sole write port` currently conflicts with silent Watch checkpoints, Frame read receipts, Eve leases, outbox delivery receipts, and prepared projections. Those writes are durable, but they do not all change World truth.

Define two internal transaction classes:

- `AuthorityCommit` may write semantic authority and must advance one World cut with a transition envelope and outbox siblings.
- `ProgressCommit` may update only allowlisted operational rows: leases, consumer receipts, delivery attempts, Watch scan checkpoints, source upload staging, preparation progress, and Frame read artifacts. It cannot write semantic tables, issue a DecisionReceipt, create an EffectIntent, change a manifest head, or advance `WorldCut`.

A silent Watch evaluation atomically advances its scan checkpoint and consumer receipt through `ProgressCommit`. A material evaluation uses `AuthorityCommit` to write the new checkpoint, `Notice`, transition, and outbox at one cut. Persisting a Frame envelope is a read artifact and creates no World transition.

This distinction should be enforced by database roles or stored transaction capabilities, not naming alone.

### P0.4 Make one event envelope the causal record

Use one immutable `AuthorityCommitEnvelope` for each World cut. A multi-object change is one envelope with ordered stream changes, not several unrelated events that happen to share a cut.

```text
AuthorityCommitEnvelope = {
  commitId,
  realm,
  world,
  cut,
  actor,
  purpose,
  releaseDigest,
  rootCause,
  parentCommit?,
  changes: NonEmpty<OrderedStreamChange>,
  recordedAt,
  previousAuditRoot,
  auditRoot
}

OrderedStreamChange = {
  streamId,
  streamRevision,
  kind,
  subjectRef,
  canonicalPayloadDigest
}
```

Compute the audit root with a versioned domain separator over canonical envelope bytes without `auditRoot`. Store the exact canonical bytes and parsed columns. The outbox references the committed envelope. Each consumer atomically writes its state change and unique `(consumerId, commitId)` receipt. Delivery is at least once; duplicate semantic application is impossible.

Raw provider bytes, individual dense points, cache changes, token chunks, lease changes, and projection rows are not World events. One admitted manifest or meaningful watermark change may be a stream change. Eve owns a separate append-only interaction stream and interaction sequence; it does not borrow `WorldCut`.

### P0.5 Freeze the dense Parquet and manifest protocol

Candidate B has the best starting implementation, but the constitution needs a storage-engine-independent contract.

#### Segment contract

Every admitted segment record binds:

- SHA-256 of the exact immutable Parquet bytes and the object byte length;
- Parquet schema and footer-metadata digests;
- writer format version, compression, row-group layout, row count, and aggregate statistics;
- semantic field IDs, valid-time bounds, provider clock bounds, and source evidence digests;
- immutable source-rights terms and disclosure-marking facet IDs;
- the admitting authority commit and cut.

Current audience authorization is not baked into a shared segment or manifest. The query planner intersects current membership, purpose, delegation, source rights, and disclosure policy. The plan contains only allowed segments, fields, and predicates.

#### Manifest contract

A manifest is a canonical, content-addressed Merkle DAG. Edges point from a root or partition node to child nodes and segment descriptors. PostgreSQL records the exact canonical bytes, digest, edges, schema digest, generation, aggregate statistics, previous admitted root, authority commit, and admitted cut. `Parent` must not mean both a Merkle parent and a previous snapshot.

#### Publication contract

1. Upload immutable Parquet bytes at their content digest and record an unadmitted staging row.
2. Build and upload canonical manifest nodes.
3. Start one `AuthorityCommit` and lock the full `WorldHead`.
4. Insert segment, manifest, edge, evidence-lineage, and admission rows.
5. Advance the source cursor and atomically replace the head's manifest root.
6. Emit a transition only for the admitted manifest or a release-defined meaningful watermark change.

An upload without step 3 is an orphan, not truth. A database row may never point at an object whose digest and length were not verified.

#### Query and replay contract

The private `ObservationQueryPort` accepts a released semantic plan, pinned generation and manifest root, allowed fields and markings, deterministic numeric/rounding rules, and byte/row/time/memory budgets. It accepts no caller SQL, object key, URL, or engine expression. Results bind the manifest-slice digest, schema digest, canonical result digest, and engine/version attestation. Every engine must produce the same released result and explanation digest for the replay corpus. Arrow is optional interchange; Parquet remains durable truth.

#### Retention contract

Garbage collection retains anything reachable from current or retained historical heads, Frames, Cases, Watches, release preparations, legal holds, active query leases, signed World checkpoints, and the PostgreSQL point-in-time recovery window. Compaction publishes a new immutable segment and manifest; it never mutates old bytes.

### P0.6 Choose one v1 release language

Candidate A admits optional Wasm and a separate Cedar policy program. Candidates B and C start with a closed declarative language. This changes the meaning of release proof and cannot remain a candidate-specific detail.

Recommended graft:

- `WorldReleaseSource` is authored as closed JSON documents with permanent semantic IDs.
- The compiler emits one versioned, typed, total declarative IR for objects, links, identity, evidence mapping, belief, queries, Actions, quorum, Watches, materiality, migrations, and presentation facets.
- Connector and trusted function implementations are server code referenced by stable ID and implementation digest. Releases contain no arbitrary URL, SQL, JavaScript, Rust, shell, or network-capable plugin.
- Cedar may be the one authorization evaluator. If retained, Cedar answers only permit, forbid, and determining-policy questions. Belief, quorum, Action changes, computation, and Watch materiality remain in the Zoen IR.
- Wasm is absent from v1. Reopen it only after three unrelated released capabilities hit the same expressiveness limit. The new ADR must specify the WIT world, determinism, fuel, memory, forbidden imports, signing, and journeys.

Do not build two overlapping policy languages. If the synthesis rejects Cedar, it must define an equally explicit authorization IR, validator, deny/forbid semantics, and independent equivalence journeys.

### P0.7 Specify canonical release bytes and proof order

RFC 8785 is necessary but not sufficient. The compiler must reject duplicate keys before JSON parsing, deny unknown fields, validate Unicode NFC, reject non-finite and binary business numbers, canonicalize timestamps at fixed precision, sort collections declared as sets, preserve only semantically ordered arrays, and encode decimals, money, durations, and large integers as canonical strings.

Use a versioned domain-separated identity:

```text
ReleaseDigest = SHA-256("zoen.world-release.v1\0" || canonicalReleaseBytes)
```

`WorldRelease` closes over the typed IR, schemas, catalog and interface facets, connector and trusted-handler digests, referenced artifacts, and the journey-suite digest. Authored source layout is not the release identity.

The pipeline order must be:

```text
static gates
  -> compile canonical WorldRelease
  -> build one OCI image
  -> record the immutable image digest and SBOM
  -> run the complete EvaluationWorld suite against that exact image
  -> sign ReleaseProof
  -> deploy the same image digest
  -> run deployment smoke journeys
```

Candidate A currently places `ReleaseProof` before `build once`; that cannot prove the deployed artifact.

Use a canonical DSSE predicate with a versioned payload type. `ReleaseProof` binds the release digest, exact image digest, lockfiles and runtimes, database schema digest, compiler/evaluator versions, journey-suite digest, evaluation environment, replay corpus, attestations, missing sandboxes, and creation/expiry policy. A managed asymmetric signer and trust registry support rotation and revocation. Local Ed25519 files are insufficient as the long-term portable trust root.

A missing required provider attestation blocks activation. It does not become a fake success or a mutable runtime feature flag. To activate without that capability, compile a different immutable release whose catalog states the honest reduced capability.

### P0.8 Bind preparation and activation to the full head

`PreparedActivation` must contain:

```text
{
  world,
  expectedHeadDigest,
  targetReleaseDigest,
  targetDataGenerationDigest,
  targetObservationManifestDigest,
  readyThroughCut,
  migrationReceipts,
  reprojectionReceipts,
  openCaseDisposition,
  watchDisposition,
  invariantResultsDigest,
  worldEvaluationAttestation?,
  preparationDigest
}
```

Preparation stages non-authoritative output and catches up only from committed transition envelopes. Human ambiguity forms a governed Case and leaves preparation blocked. If writes outrun catch-up, a short per-World write fence is the explicit fallback.

Activation receives `ReleaseProof + PreparedActivation + Approval`. The approval binds the World, proof digest, preparation digest, purpose, approver, and expiry. One serializable commit verifies current proof trust, compares the complete expected head, requires `readyThroughCut` to equal the pre-activation cut, swaps release, generation, and manifest root, then writes the receipt, transition, outbox, new cut, and audit root. Rollback follows the same protocol. There is no inactive-release flag, dual read, dual write, partial activation, or blind rollback.

### P0.9 Isolate proof-producing EvaluationWorlds physically

Realm brands and row filters catch mistakes. They do not contain a compromised evaluator. Any run that can sign or satisfy a `ReleaseProof` must execute in an ephemeral process with no live credential loaded.

The evaluation lease owns a separate database role or database, object-store credential and prefix, Restate namespace, relationship IDs, interaction store, outbox coordinates, source leases, effect leases, channel sinks or verified sandboxes, egress allowlist, expiry, and cleanup receipt. Network policy denies production provider endpoints and credentials. The same OCI image and normal CLI, API, MCP, Eve, and Living World paths run against an active evaluation head. There is no inactive-release bypass.

`CaptureChannel` may prove rendering and persistence. Only a verified provider sandbox may prove provider delivery. Missing sandbox evidence remains missing. Cleanup proves that no live row or reachable evaluation object was created.

Candidate B can still use logical EvaluationWorlds for local builder previews, but such a run cannot issue release proof while the process also holds live credentials.

### P0.10 Make restore safe for external reality

All candidates describe backups, but none closes the danger created by restoring an old outbox after an external effect or channel delivery already happened.

Adopt this recovery protocol:

1. Enable PostgreSQL point-in-time recovery and immutable/versioned object retention. Keep every object reachable from the full database recovery window.
2. Emit periodic signed `WorldCheckpoint`s that bind the full head, audit root, release/proof roots, object-manifest root, database recovery coordinate, and Eve interaction cut.
3. Restore into an isolated environment. Verify database constraints, release and evidence digests, complete manifest reachability, audit-root continuity, and encryption-key availability.
4. Rebuild disposable projections from authority records.
5. Start in `RecoveryFenced` mode. Reads are allowed after verification; Effects and non-idempotent channel deliveries are blocked.
6. Rotate the dispatcher lease epoch so pre-restore Restate deliveries cannot execute with stale authority.
7. Reconcile every nonterminal or resurrected EffectIntent and uncertain delivery against provider evidence and destination idempotency identities.
8. Enable dispatch only after the recovery journey proves that no unsafe external operation can repeat.

Run a full restore journey at least monthly and before consequential agency launches. Set numeric recovery point and recovery time objectives before the first production deployment. A backup that has never passed this journey is not a backup claim.

## P1 grafts needed for a complete constitution

### P1.1 Publish a credential and schema ownership matrix

Use schemas for ownership, not infrastructure miscellany:

| Role | May access | Must not access |
| --- | --- | --- |
| Door runtime | Better Auth `auth` schema | World membership, Ontology rows, Eve messages |
| Eve runtime | `eve` interaction and delivery rows; Ontology port | Ontology DML, Better Auth tables, connector secrets |
| Ontology runtime | `ontology`, Ontology-owned dense metadata, disposable projections | Better Auth tables and Eve message bodies |
| Effect dispatcher | immutable EffectIntent view, lease/settlement port, scoped connector lease | arbitrary World reads or writes |
| Migrator | reviewed DDL during release command | runtime traffic |
| Backup | complete database read with `row_security=off` so filtered backup fails | runtime mutation |
| Evaluation roles | evaluation schemas and prefixes only | every live schema, bucket prefix, Restate namespace, and provider credential |

Each product owns its outbox and work rows. Avoid a shared `ops` schema that becomes an authority bypass. `projection` is disposable and cannot be referenced by authoritative foreign keys.

In one-process TypeScript, separate pools and roles prevent accidental authority crossing; they do not contain a process compromise. State this plainly. Add a process/app split only when the threat model, operator separation, or regulation requires it.

### P1.2 Fix presence, step-up, and decision handles

- Door proves account/session/device identity and assurance only. It never stores World roles.
- `WorldSession` is request-scoped, single-purpose, non-serializable server state. Public calls carry Door credentials; the server creates a fresh session.
- A grant binds realm, World, principal, purpose, membership revision, delegation chain, audience, release constraint, assurance, and expiry.
- Focus contains only semantic intent and opaque refs. It contains no grant, disclosed content, or handle.
- A Telegram or Kapso binding proves channel possession, not fresh human presence. Eve enters as a delegated agent for permitted low-risk work. Consequential human decisions require Better Auth step-up.
- `DecisionHandle` is 256 random bits. Store only its digest, bound to principal, Door session, purpose, Case version, view digest, authorization digest, and expiry. It remains unusable without a fresh matching session and may be consumed or revoked.

The database-backed handle in Candidates A and B is safer and easier to revoke than Candidate C's stateless HMAC continuation.

### P1.3 Define public interface parity precisely

Parity does not mean identical prose or one lowest-common-denominator transport. For the same principal, purpose, release, input, and basis:

- every interface resolves the same semantic capability ID and schema digests;
- every mutation uses the same OperationCoordinate and returns the same Case, receipt, or Settlement identity;
- every read returns the same Frame identity, head basis, authorized semantic result digest, gaps, uncertainty, and explanation root;
- stable error codes and withheld-existence behavior agree;
- discovery filters names and schemas before disclosure;
- no interface exposes raw SQL, object keys, provider schemas, generic CRUD, policy evaluation, or internal lifecycle stages.

Presentation remains native. API JSON is the canonical envelope. CLI `--json` emits that envelope. MCP structured content carries it with concise text. Eve and Living World render released facets and stable references. Messaging flattens structured chrome into readable text.

The release `SurfaceManifest` maps every interface name and route back to one semantic ID. Names may be idiomatic, but collisions and unmapped capabilities fail compilation. A cross-interface journey compares canonical semantic digests, not screenshots or human wording.

### P1.4 Adopt one seven-journey constitution

Use seven top-level journeys with subcases:

1. Door, personal World creation, invitation acceptance, and one honest Frame.
2. Focus continuity and public interface parity through Eve, Living World, API, CLI, and MCP.
3. Quiet Watch, material Notice, defer/merge, revocation, redaction, and channel truth.
4. Canonical multi-principal Case, stale reads, concurrency, one receipt, Effect Unknown, and reconciliation.
5. Scenario non-authority and fresh live application.
6. Release determinism, EvaluationWorld isolation, proof, preparation, activation race, and rollback.
7. Dense as-of/rights equivalence, compaction, process kills, backup restore, and recovery fence.

Every journey drives the built product through a public interface and real PostgreSQL. PR tiers may use a real S3-compatible local service and a real local Restate server, but they may not claim Tigris or Restate Cloud behavior. Protected and release tiers use disposable Tigris and Restate Cloud environments. Provider and channel claims require certified sandboxes. Toxiproxy and process termination may disturb real boundaries; neither synthesizes success.

No unit tests, mocks, fakes, stubs, implementation snapshots, `vi.mock`, Rust `#[cfg(test)]` product tests, or architecture `*.test.ts` files are allowed. Generated/property-like journeys may vary inputs only through public interfaces. A deterministic evaluation clock is a product-admin capability, not monkey-patched time.

### P1.5 Normalize CI evidence and artifact flow

Use these target budgets:

| Tier | Target | Required evidence |
| --- | ---:| --- |
| Static constitution | 5 min | format, strict types/compiler, import graph, canonical generation clean diff, migration checksum/from-empty setup, role/RLS catalog audit, lock integrity, license/advisory checks |
| Pull request journeys | 15 min | journeys 1-4 core and public interface smoke on real local services |
| Merge journeys | 40 min | all seven without provider-certified claims; sampled kill/retry matrix |
| Nightly proof | 120 min | dense scale, contention, full fault matrix, RLS probes, object GC, and restore |
| Release proof | no shortcut | exact signed OCI image, real managed services/sandboxes, MCP conformance, migration/reprojection, restore, activation, and rollback |

Budgets are design constraints, not permission to add mocks. If a tier exceeds its budget, optimize realm creation, fixtures, image reuse, and parallel execution. A retry may gather evidence but cannot turn a failed journey green. Quarantine removes the affected capability from release eligibility.

### P1.6 Keep connector implementations available for durable work

A release binds every source/effect connector and trusted handler by stable implementation ID and digest. A deployment cannot delete an implementation while a retained release, open Case, Watch, prepared activation, or unsettled EffectIntent references it. The build checks reachability before pruning implementations.

Restate receives only an `EffectIntentRef` and a signed, epoch-bound lease. It never receives caller payload as authority. The dispatcher verifies Restate identity, realm, connector version, retry contract, and destination idempotency before I/O. Timeout or ambiguous process death records `Unknown` and forces reconciliation.

### P1.7 Resolve deployment and migration overlap

Candidate A uses immediate replacement for incompatible prelaunch changes. Candidate B promises rolling deployment while also rejecting compatibility paths. Both cannot hold for a breaking schema/runtime contract.

Before production:

- nonbreaking image changes may roll;
- a breaking schema or internal contract change enters explicit maintenance, drains work, applies checked migrations, and immediately replaces all Machines with one image digest;
- no dual read, dual write, shadow authority, or compatibility shim is introduced;
- old Restate handler and connector versions remain only when durable work still references them.

Before the first production user, choose either an explicit expand/contract window or scheduled maintenance releases. Revisit this as a deliberate ADR, not during a feature deploy.

### P1.8 Use deep modules, not a package per noun

Recommended dependency direction:

```text
foundation <- release-ir <- ontology-domain <- ontology-application <- adapters <- composition-root
                    ^               ^
                    |               +-- narrow EveOntologyPort <- eve-product
                    +-- Door contract <- door-product
```

Knowledge-owned Ontology modules are `release-evolution`, `admission`, `truth`, `agency`, `attention`, and `external-reality`; `AuthorityCommit` is their shared private closure. Eve owns `relationship`, `conversation`, `attention-arbitration`, and `presentation`. Start with a few physical packages and split only when an import rule needs a boundary.

- Ontology never imports Eve.
- Eve imports only the narrow `EveOntologyPort`, never stores or domain constructors.
- Door exports identity proof only.
- Each product-specific database adapter imports the driver and holds only its role. Do not create one omnipotent `storage` package.
- Provider, model, channel, Fastify/Axum, SQL, MCP, and Restate types stop at adapters.
- Public contribution is one deep operation. `acquire`, `map`, and `admit` remain internal stages so callers cannot form half-truth.
- Ban catch-all `shared`, `common`, `utils`, wildcard barrels, and pass-through service classes.

This keeps Candidate C's knowledge ownership, Candidate B's narrow Eve port, and Candidate A's strict adapter boundaries while removing A's public acquire/admit temporal split.

### P1.9 Add governed retention and deletion

Immutable does not mean immortal. None of the candidates fully reconciles evidence retention, Parquet reachability, backups, legal holds, and a person's deletion request.

Define a governed World retention policy before production. Deletion first removes live reachability and blocks new use. Physical object and backup deletion waits for the declared recovery window and legal holds. Audit records retain digests and receipts without protected payload when law permits. Per-World envelope keys should be considered if cryptographic erasure becomes a requirement. GC emits a deletion receipt and never guesses that an unreferenced object is outside a retained checkpoint.

## P2 decisions to record, not leave accidental

1. **Route and tool naming.** Candidates use different API and MCP patterns. Fix a versioned naming grammar in `SurfaceManifest`; do not hand-code names in adapters.
2. **Numeric service goals.** Keep initial Frame, commit, Watch, and first-token budgets as hypotheses. Dense-engine gates must use the same manifests, concurrency, result digests, and recovery measurements.
3. **Contention trigger.** Start with one serial World cut. Reopen only after a sustained measured threshold such as 500 semantic commits per second or 25-50 ms head-lock p95, not because a large customer exists.
4. **Trust and key provider.** DSSE is the envelope decision. Record the exact managed signer, encryption KMS, region, rotation interval, and emergency revocation process in an operational ADR.
5. **Recovery objectives.** Set RPO, RTO, PITR window, signed-checkpoint cadence, and object-retention minimum before consequential Actions launch.
6. **Authorization engine.** If Cedar wins, pin schema semantics and run policy/query equivalence journeys. If Zoen IR wins, document deny, forbid, entity slicing, explanation, and evaluator verification with the same precision.

## Graft map for the final blueprint

| Final section | Start from | Graft | Do not carry forward |
| --- | --- | --- | --- |
| Product and caller usage | B caller-first flow | C channel assurance; A Frame/Case/Watch loop | language/process details in the product definition |
| Core types | B runtime-honest TypeScript sketch or language-neutral algebra | C `KnowledgeCut` and exact reads; A policy/effect evidence distinctions | `WorldHead` without manifest and audit root |
| Authority and events | C commit envelope | B database constraints and RLS; A restricted outbox destinations | per-stream events with no enclosing commit identity |
| Dense plane | B tables, query port, publication, GC | C semantic fields/provider clocks/rights; A engine benchmark gates | manifest ownership coupled to DuckDB or DataFusion |
| Release IR | C total declarative v1 | B trusted handler registry and generated clients; A Cedar authorization separation | A's day-one Wasm |
| Proof and activation | synthesis flow plus C preparation | A DSSE/KMS and deterministic compiler; B full generation staging | proof before image build; activation without target manifest |
| Security | B role/RLS and web security | C channel/step-up, SSRF, prompt isolation; A envelope encryption | claims that one-process modules contain compromise |
| Journeys and CI | A/C seven journeys | B recovery taxonomy and CI tiers; C honest `CaptureChannel` | provider success inferred from local captures |
| Operations | A checkpoint/restore cadence | B filtered-backup defense; this audit's recovery fence | automatic restored outbox dispatch |
| Modules | C knowledge-owned layout | B `EveOntologyPort`; A adapter import rules | package-per-noun and public acquire/map/admit stages |

## Final synthesis gate

The final blueprint is ready to implement only when it can answer these questions with one unambiguous sentence or type:

1. What exact tuple does every Frame pin?
2. Which writes advance `WorldCut`, and which writes may not?
3. What is the idempotency coordinate before and after a World exists?
4. What exact bytes define a release, manifest node, transition, receipt, and proof?
5. Which manifest root becomes active with a release and data generation?
6. Which process can sign release proof, and can that process address live data or people?
7. What happens when a release-required provider has no sandbox?
8. What semantic digest must agree across Eve, Living World, API, CLI, and MCP?
9. Which real boundary does each CI tier prove?
10. How does a restored deployment prevent an already-executed external operation from running again?
11. Which database role may write each authority partition?
12. Can a caller ever coordinate acquisition, mapping, admission, policy, persistence, and event publication?

If any answer depends on the selected application language, the abstraction is still too low-level. The product constitution must survive a TypeScript, Rust, or hybrid implementation without changing what Zoen means.
