# ADR 016: User journeys are the only tests

Status: Accepted

## Context

Zoen's dangerous failures occur across boundaries: identity plus membership, stale authorization plus concurrency, PostgreSQL plus object storage, commit plus Restate, proof plus deployment, or a crash between durable steps. Isolated tests with mocks can make each component green while the product violates its promise.

The verification system should therefore exercise what a person or client can actually do and preserve honest limits on what each environment proves.

## Decision

There are seven top-level journey families, each with subcases:

1. `J1, One meaning, every interface`: teach or install once, then discover, inspect, invoke, explain, and export through Eve, Living World, CLI, JSON API, and MCP; compare semantic IDs, schemas, basis, policy, consequences, receipt, and result digests rather than wording.
2. `J2, Door, World authority, and disclosure`: browser session, OAuth device flow, MCP token, expiry, revocation, step-up, membership, purpose, hidden values and consequences, channel-presence limits, authority-free Focus, stale views, and forbidden-value pre-scan denial.
3. `J3, Evidence, time, Frames, and Parquet`: immutable evidence and rivals, purpose-specific belief, corrections without overwrite, valid-time and as-known-at queries, dense publication, compaction, old-Frame replay, rights, governed absence, and proof that a ScenarioFrame cannot become live authority without a fresh application.
4. `J4, Concurrency, idempotency, and realms`: duplicate and conflicting commands, concurrent contributions, invitations, head movement, dense admission, activation, Watch evaluation, consumer races, serialization failures and deadlocks, one receipt, deterministic intents, no cross-World transaction, and realm rejection at HTTP, SQL, object, dense, and effect boundaries.
5. `J5, Action, Effect, and honest Settlement`: one canonical multi-principal Case, different authorized views, bound contributions, process kills around provider calls, destination idempotency, possible acceptance followed by timeout, reconciliation, rejection, late observation, and connector upgrade; only `Observed<released outcome>` or `Unknown` is valid.
6. `J6, Eve, Watch, and channels`: verified raw events, durable admission before acknowledgement, model attempts, tool calls, crashes on both sides of the journal boundary, replay, fork, silence, material Notice, merge, defer, SSE reconnect, Kapso WhatsApp, native Eve Telegram, Resend email, readable fallback, fresh disclosure, scoped Cordis disposal, stable semantic references, and no duplicate Action, delivery or settled assistant response per branch.
7. `J7, Release, deployment, and recovery`: malformed release rejection, canonical compilation, build once, isolated EvaluationWorld, proof and signature, preparation against a full head, activation race, same-digest deployment, prior-release reactivation, PostgreSQL and object restore, recovery epoch, reconciliation, and reachability garbage collection.

Every journey drives a built product through a public interface and real PostgreSQL. Playwright 1.62 is the journey runner for browser and multi-interface orchestration. Testcontainers 12 starts PostgreSQL 18, MinIO, and a real local Restate server. Toxiproxy and process controls cut networks, delay responses, exhaust connections, and kill actual processes. k6 runs load and soak variants over public protocols.

Local MinIO proves the S3 protocol used by Zoen, not Tigris behavior. Local Restate proves the local server, not Restate Cloud. Protected nightly and release tiers use disposable Tigris and Restate Cloud environments plus real Kapso, Telegram and Resend accounts and official model-provider sandboxes. Evaluation uses its separate Neon project and the exact candidate image. Provider and channel success claims require their certified environments. `CaptureChannel` proves only what Zoen attempted to send after its boundary; it never proves provider acceptance or human delivery. A stock SDK route returning `2xx` without a Zoen journal row fails the journey.

The repository contains no unit tests, mocks, fakes, stubs, implementation snapshots, `vi.mock`, monkey-patched clocks, or architecture `*.test.ts` files. Generated or property-like journeys may vary inputs only through public interfaces. A deterministic clock is an explicit realm-scoped product-admin capability in EvaluationWorld, not a test replacement for time. Setup may use a shipped privileged `zoen evaluation seed` command that calls normal application use cases and produces receipts. Direct SQL setup is allowed only when database corruption or restore bypass is the subject of the journey.

Static constitution checks are mandatory but are not tests. They use Ultracite 7's pedantic TypeScript, React, CSS, and format policy with zero warnings, `tsc --build`, ESLint 10 and typescript-eslint 8, Prettier 3, Stylelint 17, dependency-cruiser 18, Knip 6, canonical release and generated-interface drift, migration apply-from-zero and schema/grant/RLS/constraint audit, frozen pnpm integrity and build-script policy, Gitleaks, OSV-Scanner, Trivy, Syft SBOM, and OCI configuration checks. A suppression needs a tracked reason and expiry; generated code is isolated at its generator boundary rather than filled with ignores.

CI tiers are:

| Tier | Target | Required evidence |
| --- | ---: | --- |
| Local fast gate | 5 min | format, pedantic lint, strict types, dependency graph, and release or schema compilation |
| Pull request | 15 min | fast gate plus affected deterministic journey shards on real local infrastructure |
| Merge | 40 min | full deterministic suite, migration from zero, image build, and crash or network journeys |
| Nightly | 120 min | protected providers, channels and cloud, concurrency and load, restore, retention, and version compatibility |
| Release | no shortcut | exact-image EvaluationWorld, every required attestation, signed proof, same-digest deployment, migration and reprojection, restore, activation, prior-release reactivation, and smoke |

A retry may collect diagnostic evidence but cannot turn a failed journey green. A flaky journey is a product or harness defect. Quarantine removes the affected capability from release eligibility. On failure CI uploads redacted browser trace and screenshot, CLI transcript, MCP frames, HTTP envelopes, correlation-scoped logs and OpenTelemetry trace, public-reference database rows, object and manifest digests, Restate invocation history, canonical inputs and outputs, fixture and image digests, environment identity, and fault schedule.

## Consequences

- Failures are more expensive to set up but correspond to real product promises.
- Static functions do not need a separate isolated test suite; they are exercised through small, deterministic journeys and release replay corpora.
- Provider claims remain explicitly absent when a certified sandbox is unavailable.
- The journey harness becomes production-grade infrastructure and must be kept fast, inspectable, and deterministic.

## Reopen triggers

- PR journeys exceed 15 minutes for ten consecutive runs. Optimize realm creation, fixture seeding, image reuse, dependency reuse, and parallel execution; do not add mocks.
- A required failure cannot be induced at a real boundary. Add a product-owned administrative fault capability scoped to journey realms and prove it is unavailable in production.
- Provider sandboxes are nondeterministic. Record their uncertainty and separate protocol conformance from provider attestation; never synthesize success.
- Playwright cannot drive a new public interface. Extend the runner or coordinate a real client process while retaining the public boundary.
- The prohibition on unit tests changes only by an explicit revision of the repository constitution, not by an individual ADR exception.
