# ADR 025: One developer platform and governed PackArtifacts

Status: Accepted target contract. Registry and ecosystem deferred.

## Context

Maximum product breadth requires builders to teach meaning, connect systems, construct data flows, create apps, define agents, and distribute proven work. If each capability has a separate build system, plugin format, permission model, and marketplace, the architecture becomes several platforms that happen to share a brand. If a package installation can run code, grant access, create credentials, or activate meaning, the developer ecosystem becomes ambient authority.

Zoen needs a developer experience comparable in possibility to mature ontology and terminal ecosystems while retaining one release, proof, and Action constitution.

## Decision

The developer platform is a capability of the existing three products:

- Studio inside `apps/conversation` gives a person semantic editing, previews, diffs, EvaluationWorld runs, journey evidence, reviews, and activation ceremonies.
- `apps/cli` gives a builder headless validate, generate, build, journey, inspect, diff, propose, prepare, publish, pull, and export commands.
- Ontology API and MCP expose the same authorized developer operations and immutable artifacts.
- Door proves the builder and required assurance. It does not grant release or installation authority.

All three surfaces use the same canonical authoring schemas, `WorldRelease` compiler, artifact codecs, `SurfaceManifest`, EvaluationWorld protocol, and proof records. A Studio build and CLI build from identical inputs must produce the same semantic and artifact digests. Generated TypeScript clients are the first SDK. Later language SDKs project the same SurfaceManifest and cannot add operations.

Builders can author released object and interface definitions, identity and evidence mappings, ObjectSetPlans, Functions, Actions, Watches, data flows, workflows, agent definitions, presentation documents, rights programs, and references to executable artifacts. General source code stays in a `MiniAppArtifact`, `ExecutorArtifact`, `ActionPlannerArtifact`, or `ConnectorArtifact`. It never becomes an inline authority expression.

### PackArtifact

`PackArtifact` is the single immutable distribution envelope. It pins:

- name, version, content digest, format and protocol compatibility.
- source, build, dependency lock, SBOM, signatures, revocation, and expiry.
- release fragments and semantic mappings.
- connector, mini-app, executor, planner, workflow, agent, journey, fixture, and documentation components.
- deterministic dependencies and conflict rules.
- license, data-rights, redistribution, retention, and attribution terms.
- migration and preparation requirements.
- EvaluationWorld results and provider-sandbox limitations.

A data pack is a PackArtifact profile whose components include source contracts, provider and field identities, schemas, mappings, quality rules, rights, connectors, fixtures, and optional immutable manifest roots. A finance, clinic, factory, household, or model pack uses the same envelope. A pack may contain no secret or mutable credential.

### Resolution, trust, and installation

Dependency resolution is deterministic from exact artifact digests and reviewed version requirements. The lock is part of the proposal. Name ownership, publisher signatures, registry origin, evaluation results, and observed reputation are separate trust signals. None grants authority by itself.

A registry is an untrusted distributor of content-addressed bytes and transparency evidence. It cannot install a package, mutate a tag behind a digest, mark an evaluation passed, or supply live credentials. Zoen verifies exact bytes, signatures, trust roots, revocation, SBOM, licenses, rights, compatibility, and dependency closure locally.

Installation always creates a `ReleaseProposal` against one target World. Studio or CLI displays the semantic diff, public-surface diff, requested read and Action capabilities, connector credentials and egress, model and executor data classes, rights and licenses, migrations, resource budgets, and removal behavior. The exact closure runs in an isolated EvaluationWorld. Review, proof, preparation, approval, and one full-head compare-and-swap activation remain mandatory.

A pack cannot grant membership, delegation, policy, credentials, provider accounts, egress, background schedules, or authority through installation. The release may define a capability that an authorized human later configures through a separate ceremony. Removing or revoking a pack creates a new release and explicit disposition for dependent data, Cases, Watches, workflows, connectors, and artifacts.

### Developer feedback contract

Every build result carries stable diagnostics with semantic paths, source locations, codes, explanations, and suggested safe next actions. Preview runs use the same public API, CLI, MCP, Eve, and Living World paths as production. The platform exposes evidence for compiler determinism, surface parity, denial, accessibility, resource use, rights, replay, migration, and failure. It never calls an internal `force-install` or inactive-release route.

## Consequences

- One artifact and release grammar can compound data, meaning, integrations, apps, analytics, workflows, and agents.
- Studio and CLI stay semantically equivalent while remaining idiomatic interfaces.
- Installation requires more ceremony than an npm plugin, but cannot silently gain authority.
- Registry compromise cannot change an artifact digest or bypass local proof, though malicious signed content still requires adversarial evaluation and review.
- Pack removal, rights expiry, and dependency conflicts become first-class product experiences.

## Required journeys

1. Identical Studio and CLI inputs produce identical release, SurfaceManifest, artifact, and dependency-lock digests.
2. Dependency conflict, cycle, substitution, mutable tag, namespace takeover, registry tampering, signature rotation, and revocation.
3. License, rights, attribution, retention, and redistribution conflicts block installation before data access.
4. Malicious connector, executor, planner, and mini-app components cannot reach authority, secrets, undeclared data, or egress in EvaluationWorld or live use.
5. Semantic, public-surface, capability, migration, resource, and removal diffs match the activated closure.
6. Missing provider sandbox remains missing proof and cannot be converted into a pass.
7. Pack upgrade, downgrade through new proof, removal, dependent artifact, retained history, and revoked publisher behavior.

## Reopen triggers

- A component cannot fit the PackArtifact dependency, rights, and proof model. Extend the component union with an explicit authority boundary. Do not add an ambient plugin hook.
- Registry scale requires mirrors or peer distribution. Preserve content identity, transparency, trust, revocation, and local installation decisions.
- A language ecosystem needs package-native clients. Generate wrappers from the pinned SurfaceManifest and pack lock. Do not publish a second domain implementation.
- No trigger permits a package signature, install command, registry role, or model-generated artifact to activate itself or grant credentials.
