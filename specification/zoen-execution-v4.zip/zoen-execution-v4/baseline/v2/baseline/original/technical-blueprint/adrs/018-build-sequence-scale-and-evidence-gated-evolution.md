# ADR 018: Build sequence, scale path, and evidence-gated evolution

Status: Accepted

## Context

Ambition does not require installing every eventual component on day one. It requires a design whose first slice is whole, whose invariants survive scale, and whose escape hatches have measurable entry conditions. Without a sequence, foundational work can become an endless platform project. Without reopen gates, preferences become architecture.

## Decision

Implementation proceeds as twelve complete slices. S0 through S6 produce the first coherent personal and shared product. S7 through S11 deliberately expand the possibility envelope; "later" is build order, not an architectural ceiling. A slice is done only when its user journey, denial journey, and static constitution pass:

1. **S0, constitutional skeleton:** pnpm workspace, repository graph, strict TypeScript, canonical codec, schemas and roles, full `WorldHead`, AuthorityCommit and ProgressCommit skeleton, Hono listeners, Better Auth Door, planted release, one signed image, one EvaluationWorld, and kill-safe startup.
2. **S1, one honest Frame:** stable subjects and temporal links, raw-artifact-first evidence admission, rival claims and named belief basis, Cedar pre-scan disclosure, one released inspect verb, uncertainty and explanation, and semantic parity across Eve, Living World, API, CLI, and MCP.
3. **S2, Eve as one relationship:** settled and attempt journals, branches and authority-free Focus, deterministic context compilation, Cordis scopes and attributed model attempts, web SSE, Kapso, Telegram, crash recovery, and Living World continuity through references rather than copied authority.
4. **S3, shared Worlds and accountable membership:** invitation, assurance, delegation, purpose and disclosure partitions; the membership workbench inside Living World; principal-scoped discovery and export; and household and team packs using the same grammar as a private World.
5. **S4, quiet attention:** released Watch lifecycle, deterministic checkpoint and materiality, semantic transition consumption, atomic Notice and outbox, Eve silence/merge/defer arbitration, and fresh disclosure before composition.
6. **S5, accountable Action and external reality:** canonical multi-principal Case, purpose-bound views and DecisionHandles, concurrent contributions, stale rejection, one AuthorityCommit containing receipt, semantic changes, EffectIntent, events, and outbox; Restate execution; `Unknown`; and reconciliation.
7. **S6, teach once and publish everywhere:** authored source to closed JSON release IR and `SurfaceManifest`, Studio branch/diff/proposal/review/rebase, trusted handler registry, isolated EvaluationWorld, artifact-first proof, prepared activation, migration or reprojection, full-head compare-and-swap activation, and prior-release reactivation through a new proof.
8. **S7, dense reality and terminal-grade data:** source/provider contracts and four clocks, non-authoritative live observation overlays, immutable Action capture, deterministic DuckDB Parquet writer, immutable Zstd segments, full manifest DAG and rights provenance, scan budgets and cancellation, live plus historical queries, finance pack foundations, hybrid PostgreSQL full-text plus pgvector retrieval, and replay/compaction/restore over 100 million real-format synthetic points. Parquet is permanent; a Rust/DataFusion adapter competes only against these identical manifests and canonical results.
9. **S8, Workshop and executable mini-apps:** a closed `MiniAppManifest` over Frames, tables, charts, forms, Cases, Watches, Scenarios, and navigation; a first-party React renderer; governed draft/proposal/publish and capability-diff lifecycle; immutable `MiniAppArtifact`; and a sandboxed `MiniAppRuntimePort` with declarative fallback. Every generated Action still opens the ordinary Case, and neither artifacts nor runtimes receive ambient authority.
10. **S9, governed playbooks, agents, and evaluation:** released `WorkflowDefinition` state machines over Watches, Scenarios, Cases, Actions, and Effects; PostgreSQL as canonical durable workflow state; explicit timers, leases, and outbox; `AgentDefinition` with model/tool policy, retrieval, budgets, checkpoints, and human judgment; immutable run evidence, evaluation datasets, rubrics, and regressions. Any Rivet workflow adapter is replaceable runtime machinery, never canonical truth; Cordis stays inside Eve attempt composition.
11. **S10, programmable analytics and scenarios:** cut-pinned `AnalysisDefinition` and immutable `AnalysisRun`; a Living World/Workshop notebook; isolated, budgeted `ExecutorArtifact`; read-only semantic and Parquet capabilities; immutable table/chart/file evidence; read-only Scenario comparison; and explicit admission or Action ceremonies. TypeScript is the first authored language. A future isolated Python kernel may satisfy the same artifact/evidence contract but cannot become a second Ontology implementation.
12. **S11, institutional cells and a compounding ecosystem:** signed World Packs containing release fragments, mappings, connectors, journeys, mini-apps, and playbooks; a governed registry and dependency/rights model; federation, approval duties, retention, legal hold, export, and audit; authority-cell routing without cross-cell transactions; independently scalable dense/query/effect/sandbox adapters; provider certification and data-quality catalogs; and opt-in distribution that never centralizes private World data.

S7, S8, and S9 may proceed in parallel only after S6 makes release, proof, and activation real. S10 follows the governed agent/workflow evidence model; S11 follows programmable analytics. No later slice may invent a private publication, authorization, write-authority, evidence, or recovery path to move faster. For every slice, the implementation sequence starts with the user and denial journeys, builds one thin path through real boundaries, produces stable diagnostic evidence, deletes superseded pre-launch code, updates the ADR/threat/dependency/PR Lens evidence, and exits with zero static warnings and passing real journeys.

Before first production use, obsolete schemas, aliases, routes, configs, and transitional paths are removed directly. Callers and journeys change atomically. Development and journey databases are recreated instead of receiving compatibility scaffolding. The checked-in migration chain remains coherent; baseline consolidation is an explicit coordinated reset.

Scale preserves semantics:

- First add bounded worker concurrency and identical whole-application Fly Machines when availability or total load requires it. Durable session, lease, idempotency, and outbox state already live outside process memory.
- Partition append-heavy PostgreSQL tables by time and World hash only after measurements require it. Authoritative Frames, authorization, Cases, Watches, and activation remain on the primary. Replicas serve only explicitly historical, cut-pinned exports.
- Give a large World a dedicated authority cell only after routing is resolved before `WorldSession`. IDs and protocols do not change, and no transaction spans cells.
- The per-World semantic clock remains serial. Causal cuts or authority partitions require a product-semantic ADR, not a database tuning patch.

TypeScript is retained because no current invariant requires Rust. Introducing Rust would permanently add a toolchain and advisory stream, a second debugger and profiler, FFI or process contracts, cross-version journeys, larger CI caches, and a requirement that at least two people can review each language. Planning estimates are 15 to 25 percent lower backend velocity through S4 and 8 to 15 percent thereafter; for four backend engineers that is roughly 3.8 to 7.2 engineer-months per year after stabilization. These are estimates, not facts, and any proposal must replace them with a measured spike.

The following gates are binding:

- Rust/DataFusion enters first as the ADR 009 dense adapter only after its latency, memory, canonical-result, and operations gate passes.
- A Rust authority component is considered only after three independent production incidents or journey failures arise from a state that Rust would make unrepresentable and strict TypeScript plus runtime validation plus PostgreSQL cannot reasonably prevent, or a representative authority workload shows at least 2x CPU improvement large enough to repay the recurring team cost. It does not become a service merely to gain Rust.
- Split Eve, Ontology, or effects into separate processes when a contractual credential boundary requires it or a workload incurs more than 50 percent independently scalable waste for 30 days. Existing ports become the seam; product vocabulary does not become RPC-shaped.
- Add a second whole-application Machine when the availability objective cannot be met by one Machine or sustained peak CPU or memory exceeds 70 percent for seven days. One-region PostgreSQL remains the commit authority.
- Reopen the per-World clock above 500 AuthorityCommits per second or p99 head-lock wait above 50 ms for 15 minutes after nonsemantic work is removed.
- Adopt TypeScript 7, expected no earlier than the 7.1 ecosystem, when its public compiler API exists; dependency-cruiser and generators support it; Ultracite's Oxlint or ESLint path has complete required type-aware rules and suppression reporting; declarations, project references, editors, and generated contracts pass; and every canonical replay and journey is unchanged.
- Reopen Hono only when a representative API, SSE, and MCP trace shows at least a twofold CPU disadvantage or a missing safety-critical protocol feature.
- Add a task orchestrator only when clean install plus build exceeds five minutes in ten consecutive standard CI runs and traces show redundant workspace work dominates.
- Consider a typed query builder only for read-only projections after repeated measured row-mapping defects. AuthorityCommit retains explicit SQL.
- Move DuckDB into a crash-isolated process if its native adapter terminates the public process more than once in a quarter. The Parquet and manifest protocol stays unchanged.
- Reopen Cordis, Cedar, Restate, Wasm, database provider, and recovery only through their specific ADR triggers.

Every accepted evolution updates its ADR, dependency evidence ledger, threat model where relevant, release proof, and the seven public journeys. A benchmark that does not use canonical manifests, equivalent concurrency, identical semantic result digests, and recovery measurements cannot approve an architectural change.

## Consequences

- Each slice produces a usable vertical product increment rather than a dormant platform layer.
- Institutional scale reuses the personal product grammar; it does not fork an enterprise edition.
- Deferred technology is not forbidden forever, but the party proposing it carries a concrete evidence burden.
- Some thresholds will be wrong. Their job is to force observation and an explicit new decision, not to predict all scale in advance.

## Reopen triggers

- The first production deployment is imminent. Revisit pre-launch deletion, migration, availability, retention, recovery, and support assumptions as one coordinated constitution change.
- A slice cannot deliver its acceptance journey without violating an earlier ADR. Stop and reopen the conflicting decision rather than adding a private bypass.
- Product evidence shows the three-product grammar cannot express a validated fourth user promise. Revisit product boundaries explicitly; do not promote an adapter or dashboard by accident.
- More than 20 percent of merged changes cross a newly introduced runtime seam for six weeks. The seam is misplaced: consolidate it or move a whole deep capability behind it.
- A threshold above fires. Record the measurements, rejected remediations, new protocol, migration and rollback plan, and journey evidence in a successor ADR before changing the constitution.
