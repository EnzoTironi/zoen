# ADR 011: Cedar only for horizontal authorization

Status: Accepted

## Context

Zoen needs release-owned authorization that can answer whether a principal may perform an operation on a resource in context. It also needs domain rules such as Action admissibility, materiality, quorum, temporal validity, unit compatibility, and effect consequences. Putting both categories into one policy engine makes business semantics hard to type and authorization hard to audit. Using two authorization engines makes disagreement itself a security boundary.

## Decision

- Cedar is the only horizontal authorization language. The TypeScript adapter uses `@cedar-policy/cedar-wasm` behind `AuthorizationPort`.
- Cedar answers admission and disclosure questions of the form: may this principal perform this action on this resource with this context? It is default-deny.
- The active release supplies a Cedar schema, policy set, and stable policy identifiers. Their digests are part of release proof and every durable authorization decision.
- The authorization input contains principal and delegated-client attributes, authentication strength, realm, World and membership version, action, resource type and stable ID, purpose, requested view, Case stage where relevant, captured release digest, and bounded contextual facts. Unbounded payloads are represented by canonical digests.
- `AuthorizationDecision` records decision ID, allow or deny, policy-set digest, release digest, input digest, matched policy IDs, stable reason codes, full `WorldHead` basis, and expiry. Sensitive AuthorityCommits re-evaluate under the head lock and persist the commit-time decision digest.
- Cedar does not implement schema validation, Action preconditions, materiality, quorum, evidence confidence, unit conversion, temporal truth, settlement, rendering, model choice, or effect execution. Those stay in typed release interpreters and domain modules.
- Fixed request limits and identity validation occur before authorization. Protected resource lookup is preceded by an existence-disclosure check where possible. Detailed validation errors are returned only after the caller is authorized to know the resource and schema.
- Dense and sparse planners first authorize only non-sensitive identity, marking, rights, and policy metadata, then compile disclosure into allowed segments, fields, rows, and predicates before protected values are fetched. Returned rows are checked again against the complete decision as defense in depth. If a sound pre-scan plan cannot be produced, the query returns a closed policy-planning error; it does not fetch forbidden values for application-side filtering.
- The adapter has no fallback allow path. An unavailable or invalid policy engine denies consequential operations and returns a stable retryable or configuration error as appropriate.

## Consequences

- One policy language governs access across API, CLI, MCP, and Eve.
- Domain language remains typed and explainable instead of becoming policy strings.
- Authorization decisions can be reproduced against their exact release, head, and input digest.
- Cedar-Wasm is a trusted, image-pinned execution dependency inside the TypeScript application. It is isolated behind one pure port, is not release-supplied Wasm, and does not create a second domain implementation.

## Reopen triggers

- Cedar cannot express a required horizontal authorization rule without unbounded context after a concrete model has been reviewed.
- Cedar evaluation remains outside its latency objective after policy indexing, entity minimization, and caching by immutable input digest.
- A Cedar runtime security or determinism issue cannot be contained behind `AuthorizationPort`.
- A replacement must first run in shadow mode and match Cedar on accepted release proof corpora and authorization-denial journeys. There is never a steady-state mixed-authority mode.
- A rule turns out to concern quorum, materiality, truth, or consequence. Move it to the typed domain interpreter; that is not a reason to add another policy engine.
