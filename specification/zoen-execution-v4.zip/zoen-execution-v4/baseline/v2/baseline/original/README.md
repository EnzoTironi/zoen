# Zoen from zero

This package answers one question: if Zoen started today with no legacy constraint, what product and technical design would give it the most coherent path toward “Poke plus Palantir and Bloomberg for everyone”?

The answer has two layers:

- [Product synthesis](synthesis.md) describes what people experience, the three-product boundary, and why conversation, a Living World, and governed meaning belong together.
- [Technical constitution](technical-blueprint/README.md) fixes the runtime, types, data, events, channels, apps, libraries, tests, operations, ADRs, implementation order, and competitive evidence.

The research does not claim delivered parity. It identifies no known constitutional blocker across the dated public capability categories after adding explicit live-observation and installable-connector protocols. Every target still needs code, hostile journeys, operating evidence, and a product people choose. Licensed data, networks, integrations, support, and accumulated trust remain work that architecture cannot create.
