# Zoen greenfield synthesis

## Decision

Zoen should be designed as one living, governed world reached through three products:

1. **Door** proves who is present. It is Better Auth and nothing more.
2. **Eve** owns the relationship: conversation, continuity, attention, channel, wording, and the Living World.
3. **Ontology** owns published meaning, authorized truth, domain Actions, Watches, scenarios, evidence, decisions, and external settlement. Its native faces are CLI, API, MCP, and the builder Studio.

The irreducible loop is:

```text
authority-free Focus
    ↓ fresh Door proof + one purpose-bound World grant
authorized WorldFrame
    ├─ Answer + explanation
    ├─ domain Action → ActionCase → DecisionReceipt
    │                                  └─ EffectIntent → Settlement
    ├─ Watch + semantic delta → Notice → Eve attention/delivery
    └─ read-only Scenario → fresh live ActionCase if applied
```

This is the architecture's identity. Storage engines, queues, languages, model vendors, channels, and provider APIs are replaceable implementation choices behind it.

## Product promise

Zoen aims at a Poke-quality relationship and a Palantir/Bloomberg-class bar for governed reality, made useful to a person before it is made powerful for an institution. Architecture can preserve that possibility; shipped product depth, licensed data, networks and operating trust must still be earned.

The user should experience one continuous intelligence that can:

- understand what they mean;
- show what it knows, as of when, and from which evidence;
- distinguish ambiguity from ignorance;
- let them inspect the same subject conversationally or spatially;
- propose a consequential domain Action without hiding the decision inside chat;
- stay quiet while nothing material changes;
- interrupt only when a change earns attention;
- prove what Zoen committed and separately report what external reality settled;
- teach a World once and receive native conversation, visual, CLI, API, and MCP behavior.

The product is not a chatbot placed over CRUD, a dashboard with an assistant, a graph database UI, or a generic agent harness. Eve is the relationship. The Ontology is the executable world. The Living World is that same world made inspectable.

## Trust ladder

The product earns agency instead of asking for maximum trust in the first minute.

### First minute — become useful before asking for commitment

1. A new person signs in. If there is no accessible World, Eve offers one legible choice: create a personal World or accept a specific invitation.
2. These are two different Ontology operations. `CreatePersonalWorld` verifies an attested plant and atomically creates a new World, its initial `WorldHead`, owner membership, and `WorldGenesisReceipt`. `AcceptInvitation` verifies and consumes one invitation and atomically creates only membership and an `InvitationAcceptanceReceipt`; it never writes the existing `WorldHead`. Either result is followed by a fresh normal World entry. Door still proves only identity.
3. Eve asks for one useful source—connect an account, forward a statement, or begin with an honest empty World.
4. The first WorldFrame is provisional by design: it shows what is known, as of when, the evidence, and exactly what remains missing.
5. If two accounts may denote the same subject, Eve presents a released `ResolveAccount` ActionCase. The choice and its DecisionReceipt belong to Ontology; the conversation belongs to Eve.
6. Eve answers the runway question. The same authority-free Focus can open Living World, which obtains fresh authority and either reopens the pinned historical Frame or returns a visibly newer Frame.

### First day — earn one interruption

1. The person says what deserves attention in ordinary language.
2. Eve shows the proposed Watch contract: subject, semantic condition, release track, current basis, and what “material” means.
3. Create, edit, pause, resume, and cancel are idempotent governed mutations.
4. Ordinary variation advances an explainable compact checkpoint and remains silent.
5. A material or stale-data transition atomically creates one Notice. Eve—not Ontology—decides silence, merge, defer, timing, wording, channel, and delivery, but receives only `NoticeId` until Ontology returns a freshly authorized Notice view. A deferred Notice is reopened immediately before composition; revocation suppresses it and changed disclosure redacts it.
6. An Attention view answers: what is Zoen watching, what basis was last evaluated, why was a change suppressed, and which Notice is pending?

### First week — deserve consequential agency

1. `ProtectReserve` creates one ActionCase with consequences, uncertainty, expiry, policy proof, and the exact facts it read.
2. Each answer reauthorizes current membership, delegation, purpose, and policy. A quorum answer may return `CaseProgress`; it does not imply commitment.
3. A relevant balance, belief, policy, or observation dependency change returns `Stale`. Zoen never silently refreshes a Case after consent.
4. The completed decision atomically creates a DecisionReceipt, semantic changes, meaningful events, an outbox, and deterministic EffectIntents.
5. A retry with the same operation key and intent returns the same result. Reusing the key for a different intent conflicts.
6. A bank timeout is reported as `Unknown`, never invented success or failure. Later provider evidence is atomically recorded as a separate Settlement.

Together these three moments prove the emotional product and the hard kernel invariants without compressing the trust arc.

## The seven authorities

Seven kinds of truth must never impersonate one another. They are ownership partitions, not seven services, databases, APIs, or event streams.

### Meaning

What kinds of objects, links, evidence, functions, policies, domain Actions, Watches, views, and explanations exist in a released World.

Owner: Ontology through an immutable `WorldRelease`.

### Identity

Which real-world subject a source record or user phrase denotes, including unresolved rivals and the evidence for a resolution.

Owner: Ontology. Door proves account/session/device identity but cannot resolve domain identity.

### Truth

What was observed, asserted, believed, disputed, or unknown; under which evidence, clocks, rights, and knowledge cut.

Owner: Ontology. Evidence is not a claim; a claim is not an accepted belief; an accepted belief is not chat memory.

### Agency

What may be proposed, who must decide, which policy applies, what can commit, and which external effects may be attempted.

Owner: Ontology through released domain Actions, ActionCases, DecisionReceipts, and EffectIntents.

### Attention

Whether a World change is semantically material enough to become a `Notice`.

Owner: Ontology up to Notice creation. It does not own relationship timing or delivery.

### Interaction

What the person and Eve said, what was shown, what remains in Focus, which Notices were merged or deferred, and which channel received a message.

Owner: Eve exclusively.

### External reality

What a bank, broker, calendar, provider, or other destination actually accepted, rejected, or left ambiguous.

The external system owns the outcome. Ontology owns only an evidence-bound `Settlement` record of what was observed; it never infers that record from a local commit.

## Product objects

### WorldRelease — executable meaning

A release closes over semantic identities, object and link types, identity rules, source contracts, evidence and belief programs, policies, domain Actions, Watch detectors, functions, presentation facets, and the digest of the journey suite that defines expected behavior.

`ReleaseCompiler` emits immutable, content-addressed `WorldRelease` bytes; a release is never changed from candidate to active. A separate, release-wide `ReleaseProof` references its exact digest and records journey, replay, semantic, policy, environment, and sandbox-effect attestations from an isolated `EvaluationWorld`.

That proves the release can behave; it does not prove that a particular live World is ready. `ReleasePreparation` compares the current release and cut with the target release, selects an executable reuse, reprojection, or migration plan, stages a non-authoritative data generation, catches it up only from committed `WorldTransitions`, and produces a content-addressed `PreparedActivation`. That artifact binds the World, expected head, target release, ready-through cut, migration and reprojection receipts, the disposition of open Cases and Watches, invariant results, and any required World-specific evaluation attestation. If a semantic mapping requires human judgement, preparation forms governed domain Cases and remains blocked instead of guessing.

Activation is the join of `ReleaseProof + PreparedActivation + approval`. One serializable compare-and-swap changes the mutable `WorldHead` from the expected `{release, data generation}` pair and records a separate `ReleaseActivationReceipt`, event, and outbox. If the live head changed, the transition is rebased. If the cut advanced, preparation catches up and returns `PreparationStale` until it is exact; a short per-World write fence is the explicit fallback when a busy World cannot converge. There is no dual-read, dual-write, partially migrated active state, or blind rollback; rollback is another proved and prepared transition.

An `EvaluationWorld` is a disposable, realm-branded World with its own head, purpose-bound grants, database role, object namespace, interaction store, relationship identities, outbox/Restate namespace, evaluation-only source leases, channel sinks or verified provider sandboxes, sandbox-only effect leases, outbound egress policy, and expiry/cleanup receipt. CLI, API, MCP, Eve, and Living World use their normal path because the target release is active inside that evaluation head; there is no `useInactiveRelease` escape hatch. `WorldRef<R>`, `RelationshipRef<R>`, `ChannelBinding<R>`, `SourceLease<R>`, `EffectIntent<R>`, and `Settlement<R>` make live and evaluation realms non-interchangeable. Evaluation channels can capture a rendered delivery or use a verified sandbox, but can never address a live person; evaluation source leases cannot read production credentials. If a provider has no real sandbox, the proof records the missing attestation instead of inventing success, and activation policy rejects any capability for which that attestation is mandatory.

It is compiled once. Runtime authority filters discovery and data; Zoen does not create a principal-specific ontology artifact.

### Focus — continuity without authority

Focus preserves the semantic subject or lens intent, temporal/basis intent, and opaque Frame, Case, or Watch references across conversation and Living World. It does not persist visible evidence selections that may become stale or newly forbidden. It contains no token, permit, capability, membership authority, or delegation credential.

Every use reopens Focus through Door proof and one new purpose-bound grant. A stolen Focus is a bookmark, not a key.

### WorldFrame — the atomic read

A Frame is more than query data. It pins:

- World and release;
- purpose and authorized audience;
- valid-time coordinate and recorded-time knowledge cut;
- visible observation-manifest snapshot root;
- belief policy and evidence rights;
- result, gaps, uncertainty, and explanation;
- exact read dependencies needed for replay and concurrency checks.

Conversation, Living World, CLI, API, and MCP render different facets of the same Frame.

### ActionCase — the atomic deliberation

A domain Action either commits immediately when no human decision remains, explains why it is impossible, or creates exactly one canonical ActionCase. The Case is policy-protected and bound to World, release, Action, intent, exact read set, decision rule, version, and expiry—not to its initiator's audience. Its protected consequences and quorum state remain under Agency authority.

Each principal reopens the same authority-free `CaseRef` through a fresh `WorldSession` and receives a distinct `AuthorizedCaseView` bound to principal, audience, Case version, disclosure and `viewDigest`. Only an eligible view that reveals enough decision-relevant material yields a server-bound `DecisionHandle`; Zoen never asks someone to approve hidden consequences. An answer becomes a durable `DecisionContribution` recording principal, authorization, Case version, answer digest, and exactly what that principal saw. The canonical rule—not a viewer projection—returns authorized progress or completes one DecisionReceipt. Eligibility and exact dependencies are revalidated when the rule completes.

The DecisionHandle's `answer` is the one legitimate continuation because it represents a real pause for a person or quorum. Focus carries only `CaseRef`, never a CaseView or handle. There are no public prepare/validate/save lifecycle verbs.

### DecisionReceipt — the atomic World change

A DecisionReceipt proves the decision and the local World transition. One `AuthorityCommit` serializable transaction writes all semantic changes, the receipt, deterministic EffectIntents, meaningful events, and outbox entries. These are sibling outputs of one commit, never a chain of independent asynchronous writes. Multi-object Actions lock aggregates in stable order and never partially commit.

### Watch and Notice — durable intent, earned attention

A Watch remembers what matters and evaluates deterministic semantic transitions from one committed, cut-bound `WorldTransition` stream. It pins a release or an explicitly compatible release track and persists compact checkpoints, detector version, and deduplication state—not a permanent receipt for every unchanged poll or observation point. Every background evaluation reauthorizes owner, purpose, delegation, release compatibility, and current rights; revocation stops reads and Notices.

Watch creation, edit, pause, resume, and cancellation use `OperationKey + intent digest`. An incompatible release pauses the Watch or migrates it through a governed decision; it never silently changes an ongoing promise.

Ontology may notice or prepare a Case. It cannot choose quiet hours, interruption budgets, prose, channel, timing, or delivery. Watch checkpoint, Notice, causal event, and outbox are one atomic commit. The outbox gives Eve only `NoticeId`; for every arbitration and again immediately before composition, Eve calls `openNotice` under the durable Watch purpose. Ontology reauthorizes the owner, current membership and delegation, Watch state, relationship, and present disclosure, returning `AuthorizedNoticeView | Redacted | Suppressed`. Eve then decides silence, defer, merge, timing, channel, wording, and delivery. It stores a deferred reference, never stale disclosed content.

### Scenario — counterfactual without authority

A Scenario overlays an explicit Frame and can inspect or consider released domain Actions. It cannot decide, publish meaning, acquire fresh evidence, or form an EffectIntent. “Apply” discards scenario authority and prepares a fresh live ActionCase against current reality.

### Settlement — external truth

Settlement is separate from DecisionReceipt. Results are domain outcomes such as `Observed<OrderAccepted>`, `Observed<Filled>`, or `Observed<Rejected>`, plus `Unknown`; there is no generic success that collapses distinct external facts. Timeouts become `Unknown`. Automatic retry is allowed only when the connector proves destination idempotency. Otherwise Zoen reconciles before proposing another decision. Settlement evidence, record, causal event, and outbox are one atomic authority commit.

## One deep protocol

The public surface should remain intention-shaped:

```text
enter(focus, purpose) -> WorldSession
inspect(released capability, input) -> WorldFrame
invoke(released domain Action, intent, operationKey) -> committed | impossible | CaseRef + AuthorizedCaseView
openCase(caseRef) -> AuthorizedCaseView + DecisionHandle? | not-disclosable
handle.answer(answer, operationKey) -> AnswerReceipt + (AuthorizedProgress | DecisionReceipt | Stale | Expired)
openNotice(noticeRef, deliveryPurpose) -> AuthorizedNoticeView | Redacted | Suppressed
watch(released Watch capability, intent, operationKey) -> Watch
scenario(frameRef) -> ScenarioWorld
explain(any released result or receipt) -> Explanation
```

`WorldSession` is the public runtime handle; its private server-side context contains the short-lived, single-purpose execution grant. Generated bindings retain native domain vocabulary such as `ProtectReserve`, `ResolveAccount`, or `ApproveTreatment`. CLI, API, MCP, Eve tools, and Living World affordances share stable semantic identities but remain idiomatic to their surface.

Policy runs before capability discovery and before data enumeration. Non-disclosure-safe failures collapse to `not-found-or-not-disclosable` where revealing the distinction would leak ontology or entitlement structure.

## Internal kernel

The kernel can be understood as six deep engines behind the protocol:

1. **Release evolution** compiles immutable meaning, proves it in a realm-isolated EvaluationWorld, prepares each live World's compatible data generation through its current cut, and only then atomically moves `WorldHead` with expected-head concurrency.
2. **Admission and authority** exchange Door proof for one short-lived grant bound to one World, principal, purpose, membership revision, delegation chain, audience, release constraint, and expiry.
3. **Truth and identity** acquire evidence, preserve raw bytes, resolve identities without erasing rivals, compute beliefs, atomically admit new knowledge, and open reproducible Frames.
4. **Agency** forms Cases, validates exact read sets, commits Decisions, emits Effects, and explains receipts.
5. **Attention** advances Watches over meaningful cuts and emits material Notices.
6. **External reality** executes idempotent effects when proven safe and atomically records evidence-bound Settlements honestly.

These are conceptual ownership boundaries. They do not imply microservices. A single deep `AuthorityCommit` port closes World creation or invitation acceptance with disjoint write sets, Action contributions and decisions, evidence admission, Notice, release activation, and Settlement transactions. Pre-launch, the elegant deployment is one Fly application with one transactional Postgres authority, isolated live/evaluation roles and namespaces, an artifact/observation store, and Restate only for Ontology Effects.

## Event model

Zoen is event-oriented without event-sourcing every byte.

Meaningful World transitions carry:

- World cut and per-stream revision;
- actor and purpose;
- release identity;
- root cause and immediate parent;
- payload digest and recorded time;
- deterministic consumer/idempotency coordinates.

Delivery is at least once; consumers are idempotent. The database transaction and outbox define the local truth boundary. Watches consume only committed, cut-bound WorldTransitions from that outbox; raw manifests, database tables, and derived projections never wake them independently.

Eve event-sources settled interaction: user messages, model attempts, tool results, assistant messages, Notice arbitration, forks, and wakeups. Live token chunks are transient.

Sparse authority and evidence remain temporal relational records. Dense historical observations remain immutable columnar segments behind content-addressed manifest DAGs. High-rate live observations travel in a separate, non-authoritative provider-sequenced plane with explicit entitlements, watermark, staleness, conflation, gaps and completeness. A tick is not a domain event and does not advance `WorldHead`; a sealed and admitted manifest change may be.

## Evidence admission

Provider endpoints and schemas are acquisition contracts, never the Ontology itself.

One source-owned contribution operation performs:

1. canonical request and rights check;
2. acquisition identity over provider, capability, request, window, checkpoint, adapter, and source contract;
3. immutable raw capture before admission;
4. deterministic mapping under a WorldRelease;
5. identity resolution and evidence validation;
6. creation of an immutable sparse or dense admission proposal;
7. one authority transaction that accepts the proposal, advances the cut, records the admission receipt and event, and writes the outbox.

Interrupted acquisition can leave unreachable immutable artifacts; a collector may remove them later. It cannot leave half-admitted truth.

A live subscription is deliberately different. A released `LiveFeedDefinition` and short-lived `LiveSubscription` produce `LiveObservationEnvelope`s and a visible `LiveObservationBasis` without one authority commit per tick. A consequential Action captures the exact quote, book, event or news item as an immutable `CapturedObservationRef` and applies its released staleness/revalidation rule. Periodic ordered segments are sealed into Parquet, referenced by a new manifest, and only then admitted as historical World evidence.

## Physical memory

The same conceptual contract spans three execution planes:

- **Sparse temporal plane:** Postgres for releases, membership, identity, assertions, beliefs, policy, Actions, Watches, Cases, receipts, events, outbox, settlements, and current/as-of projections.
- **Live observation plane:** provider-sequenced, continuously entitlement-checked, explicitly non-authoritative updates for quotes, books, events, news and other high-rate reality.
- **Dense historical plane:** immutable Parquet segments, manifest DAGs, statistics, rights metadata and sealed watermarks for high-volume history.

`WorldFrame` always pins one authoritative semantic basis and may additionally pin a live basis. Only the semantic basis and sealed admitted manifests belong to the World cut. A household balance and an institutional market feed differ in physical plan, rights and freshness—not in the rules for evidence, explanation or consequential Action.

Projection indexes are disposable accelerators. They cannot become the authority. No Redis is required.

## Harness and learning loop

The DeepSeek-harness lesson is not “put every behavior in a prompt.” It is to make the environment, tools, state transitions, and reward legible enough that agents can reliably operate the product.

Every released capability therefore ships with real journeys that exercise the public product through Door, Eve or a native Ontology surface, real persistence, and real boundaries inside a realm-isolated EvaluationWorld. Its database and interaction writes cannot reach live authority; source acquisition accepts only evaluation leases; Eve delivery accepts only evaluation relationships and channel sinks or verified sandboxes; Effects accept only sandbox leases; one egress policy denies every production credential and endpoint. No mocks, fake tool success, or storage-shaped unit contract substitutes for this proof.

The release loop is:

```text
observe a failed or missing journey
→ propose a meaning draft
→ compile one immutable WorldRelease and native surfaces
→ install it as an EvaluationWorld head
→ run semantic, policy, replay, and end-to-end journeys through real surfaces
→ sign a release-wide ReleaseProof
→ prepare the target live World's migration/reprojection through its current cut
→ inspect the diff and evidence
→ approve and atomically join proof + PreparedActivation into WorldHead
→ measure the live World without self-modifying production meaning
```

Agents may propose and test. They cannot silently rewrite the active World.

## Build sequence

Build vertical outcomes, not infrastructure layers:

### S1 — One honest Frame

Sign in, create or join one World, connect or forward one source, receive an honest provisional Frame, resolve one consequential identity ambiguity through the minimal governed Case/Receipt path, and reopen the same Focus in Living World under fresh authority.

### S2 — One quiet Watch

Durable intent, idempotent create/edit/pause/cancel, compatible-release binding, background reauthorization, compact checkpoint, material/staleness detector, atomic Notice publication, an Attention view, Eve-owned silence/merge/defer/channel delivery, and fresh Notice disclosure authorization at arbitration and immediately before composition.

### S3 — One accountable Action

`ProtectReserve`, one canonical multi-principal ActionCase, principal-specific AuthorizedCaseViews and DecisionHandles, exact read set, durable DecisionContributions, stale-case rejection, idempotent decision, serializable commit, DecisionReceipt, deterministic EffectIntent, Unknown timeout, and reconciliation to Settlement.

### S4 — One continuous Living World

One adaptive Focus canvas deepens from answer to evidence, relationships, consequences, Decision, and read-only Scenario while preserving authority-free continuity and reopening through fresh grants without context loss.

### S5 — Teach once, publish everywhere

Teach mode, meaning draft, immutable `WorldRelease`, realm-isolated `EvaluationWorld`, separate release-wide `ReleaseProof`, per-World migration/reprojection and `PreparedActivation`, approval, compare-and-swap `WorldHead`, `ReleaseActivationReceipt`, stable semantic identities, and native CLI/API/MCP/Eve/Living World projection.

### S6 — Dense reality without semantic drift

Columnar observations, manifest snapshot roots, entitlement pushdown, comparable-field governance, as-of Frames, and Watches over thousands of series using the same public objects.

### S7 — Shared and delegated Worlds

Households, teams, clinics, funds, and factories add membership, principal-specific Case views, canonical quorum contributions, delegation chains, partitions, and portable released bundles without changing Frame, Case, Watch, Receipt, Notice, or Settlement semantics.

## Why this is better

- **The product and kernel share one grammar.** Users see Frames, Cases, Watches, Notices, and Receipts; engineers implement exactly those atomic promises.
- **Authority cannot hide in convenience state.** Focus provides continuity while every consequential operation receives fresh, purpose-bound authorization.
- **The system can tell the truth about time.** Valid time, recorded time, provider clocks, knowledge cuts, observation manifests, and settlement remain explicit.
- **Conversation does not become the database.** Eve remembers the relationship; Ontology proves the World.
- **Proactivity cannot become spam.** Ontology judges materiality; Eve judges interruption.
- **Action cannot masquerade as success.** Local commitment and external settlement are separate, durable facts.
- **Scale does not fork the product.** Personal and institutional Worlds use the same semantic objects while physical execution specializes behind them.
- **Events retain meaning.** Causal transitions are durable; dense raw variation remains data.
- **Live speed does not counterfeit authority.** Users can see terminal-grade updates while every consequential decision captures an exact observation and durable history remains Parquet.
- **Agents can extend the World without becoming sovereign.** They propose releases and prove journeys; humans and policy activate meaning.
- **Meaning cannot outrun data.** A release-wide proof and a cut-exact per-World preparation are independent prerequisites to activation.
- **Deferral cannot outlive permission.** Eve keeps a Notice reference and must reopen current disclosure before it composes or delivers anything.
- **The architecture is ambitious because it is subtractive.** Three products, one loop, seven authorities, a small public protocol, and no infrastructure promoted into product concepts.

## Arena synthesis

The design arena produced three independent greenfield candidates.

- Candidate B supplied the base: authority-free Focus, one authorized Frame, seven authority records, and the deepest intention-shaped protocol.
- Candidate C supplied the mandatory correction: strict `Watch → Notice → Eve`, an unforgeable read-only Scenario, and disclosure-safe absence.
- Candidate A supplied the hard invariants: exact read sets, serializable commits, stable lock ordering, causal events, immutable-before-admit evidence, deterministic idempotency, and honest Unknown settlement.

Rejected shapes include: seven microservices, Ontology-owned delivery policy, per-audience release compilation, Watch disguised as Action, public query plans, multi-purpose grants, single-choice evidence clocks, caller-orchestrated acquire/normalize/admit stages, mandatory language boundaries, universal event sourcing, provider APIs as ontology, public CRUD/lifecycle verbs, graph storage as product model, chat memory as truth, definition drafts reused as scenarios, and commit equated with settlement.

## Architecture sentence

**Zoen is an authority-free Focus opening one authorized WorldFrame; the Frame can answer, form one domain Case, or sustain one Watch; Decisions create World Receipts, external systems create separate Settlements, and only Eve decides when the relationship should be interrupted.**
