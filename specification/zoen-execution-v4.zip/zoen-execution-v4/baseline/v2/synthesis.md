# Zoen greenfield synthesis — a world that learns

## Decision

Build one living, governed world reached through three products:

1. **Door** proves the person, device, client or workload that is present.
2. **Eve** owns conversation, continuity, attention, channels and Living World presentation.
3. **Ontology** owns released meaning, evidence, identity, interpretations, decisions, actions and their external outcomes. Its native faces are API, CLI, MCP and Studio.

The most important new decision is that **reconciliation and runtime evolution are ordinary product capabilities**, not administrator repair tasks outside the architecture.

A world is not made reliable by deleting disagreement. It becomes reliable by knowing what each source says, which assertions are comparable, how an interpretation was selected, who may rely on it, and what would make that interpretation change.

## Product promise

Understand what is happening. Improve what is known. Watch what matters. Act within a clear mandate. Show the evidence and the outcome.

A grandmother should not configure an ontology before understanding a bill. A confectioner should not reconcile orders by maintaining a miniature data warehouse. An institution should not have to abandon entitlements, point-in-time semantics, change control or auditability to gain the same experience.

The common denominator is not a simplified terminal. It is a consistent way to reason and act on a world; depth is progressively disclosed.

## The irreducible loop

```text
intent / question / new evidence / material change
    ↓ fresh identity + World + purpose + current rights
WorldFrame: released meaning + exact basis + authorized interpretation
    ├─ understand → answer / visual lens / evidence
    ├─ improve   → assertion / resolution / identity decision
    ├─ teach     → DefinitionChange → evaluation → activation
    ├─ watch     → Watch → Notice → Eve attention → delivery observation
    └─ act       → ActionCase → DecisionReceipt → EffectIntent → Settlement
                         ↑                                      ↓
                         └──── bounded Mandate / outcome observation
```

Every path uses the same semantics. An agent is a principal acting under delegation, not a second implementation. A message is input, not a grant. A model output is a proposal, not a fact or a commit.

## Small vocabulary, deep composition

| Concept | What it hides | What it must never hide |
|---|---|---|
| World | Source diversity, topology, projections | Authority and confidentiality boundary |
| Release | Domain definitions and reusable packs | Exact semantics and active version |
| Evidence / Claim | Acquisition, parsing, extraction | Origin, time, uncertainty and competing assertions |
| Interpretation | Normalization, reconciliation and derivation | Selection rule, unresolved rivals and perspective |
| Frame | Query planning across sparse/dense/live planes | Basis, rights, gaps and freshness |
| Action / Case / Receipt | Validation, quorum, retries and effects | Consequences, stale basis, commitment and external outcome |
| Watch / Mandate | Scheduling, ongoing work and notification | Scope, budgets, stop conditions and authority |
| Focus | Continuity across surfaces | Nothing privileged: it is a bookmark, never a key |

These are conceptual contracts, not one service or database per noun. Claims, identity decisions and user resolutions share an evidence-bearing history. Runtime settings and domain definitions share the release/change protocol. A skill is a packaged behavioral definition, not a new kind of authority.

## Three different things people can teach

### Correct an instance

“Esse pagamento foi feito pela conta conjunta.” Admit an attributed assertion or identity resolution with evidence and scope. Recompute affected interpretations. Preserve the prior assertion and downstream history. Do not treat this answer as a universal matching rule.

### Teach a reusable meaning

“Para encomendas, sinal é dinheiro confirmado no banco; promessa de pagamento não conta.” Draft a property-specific rule, show examples and counterexamples, evaluate affected data and open decisions, then activate a new release under current authority. The rule is data interpreted by a stable kernel.

### Add a capability

“Conecte meu sistema de encomendas e acompanhe atrasos.” Instantiate a reviewed connector template, complete OAuth, map fields, inspect proposed identity matches, test incremental synchronization and activate a SourceBinding. If a new adapter requires code, build a signed isolated artifact; never load user code into authority. Installing a skill does not grant its requested powers.

## Reconciliation is a loop, not a winner column

Ingest immutable evidence; normalize explicit units and clocks; map provider records to stable subjects; compare assertions about the same predicate, subject, interval and scope; select a released interpretation or keep the issue unresolved; ask the right authorized person only when clarification earns its cost; record the answer and its limits; recompute dependent knowledge and invalidate stale decisions.

A CRM order, invoice and bank settlement are not three disagreeing values of “revenue.” They may be three different measures. A globally authoritative department can resolve a policy question without becoming authoritative about what a bank actually settled. A copied spreadsheet and its source are not two independent confirmations.

The quality target is not one opaque confidence score. Track coverage, freshness, identity ambiguity, unresolved consequential conflicts, source reliability by field, lineage completeness and decision impact. Every metric has a denominator and a visible scope.

## A trust ladder for every audience

**First minute:** bring one source or one question; obtain one useful provisional answer with explicit gaps. No mandatory full-company setup. A channel subject begins with limited assurance; private history and consequential actions require a verified binding and appropriate step-up.

**First day:** resolve one important ambiguity and configure one useful Watch. Let the person distinguish “this occurrence” from “a rule from now on.” Send a notification only when material change and channel permission both allow it.

**First week:** obtain a narrow mandate for a low-risk action, preserve consent against changing facts, and verify the result. A failed or ambiguous provider attempt is a first-class outcome, not a reassuring sentence.

**As depth grows:** add collaborators, richer domain packs, scenarios, data flows, live observations, application surfaces, programmable analyses and specialized execution. The product model stays stable while operations and policies strengthen.

## The system's three physical planes

**Authority:** PostgreSQL stores identity mappings, claims and decisions that matter operationally, active release references, rights, Cases, Watches, Mandates, receipts and published dataset references. Writes use visible transactions, not a model-generated ORM or SQL surface.

**Evidence and computation:** encrypted raw objects, Parquet/Iceberg datasets, derived indexes, isolated connector and compute runners, and entitled live observations. These components propose or project; they do not silently decide World truth.

**Interaction:** Eve owns accepted inputs, turn state, visible messages, attention and deliveries. Its journal is not the knowledge ledger. It receives freshly authorized Frames rather than retaining broad database access.

The control head changes when configuration, authority epoch or topology changes. Independent data domains advance without taking an exclusive lock on a single global World counter. An exact Frame captures a consistent local cut; a federated Frame records separate component cuts and never invents global simultaneity.

## Runtime variation without runtime lawlessness

The kernel defines the available types, expression operators, validation rules, action protocol, isolation boundaries and cryptographic checks. Packs provide ontology definitions, mapping programs, reconciliation policies, skills, agents, watches, workflows, UI lenses and required capabilities. Bindings instantiate these with local sources, credentials, schedules and policy.

Ordinary data updates do not require release compilation. A user's private layout preference does not trigger a business-data migration. A rule that changes the meaning of an amount does. A change that expands permissions is approved under the old permissions; an emergency deny can take effect immediately, while a new grant cannot.

A change may activate without redeploying the application. It may not retroactively alter a signed receipt, execute unreviewed code in authority, or turn a formerly read-only skill into an autonomous money mover.

## Institutional scope, honest boundaries

The design includes the product contracts for contextual search, ontology and identity workbenches, source inventory and reconciliation, point-in-time analytics, live feeds, operational actions, application building, simulations, agents, domain packs, developer SDKs, institutional cells and federation. Finance has explicit order/fill/correction/settlement semantics, not a generic “trade” tool.

Architecture does not supply proprietary datasets, licensed market access, commercial connectors, network participation, legal compliance or operating trust. Those capabilities remain named execution and commercial gates. We do not claim parity with the reference companies or mathematically perfect knowledge.

## The elegance test

A new audience should usually require a pack, a policy and an experience profile—not a new platform. A new source should usually require a template or isolated adapter and a mapping—not a new domain model. A new explanation should use the same proof dependencies as a decision. A runtime change should use the same governed change path whether authored in chat, Studio, CLI or by an agent.

When a feature requires a second truth store, a second permission model or a second way to commit external effects, challenge the design before implementing it.
