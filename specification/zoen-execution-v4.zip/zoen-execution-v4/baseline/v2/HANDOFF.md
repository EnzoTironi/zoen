# Handoff de implementação

## Mandato

Implementar a arquitetura v2 deste pacote, começando por S0 e progredindo por resultados verificáveis. A ambição é um núcleo comum para pessoa, profissional e empresa, com reconciliação explícita e variação de negócio em runtime. Não construir três produtos desconectados nem um chatbot com permissões genéricas.

## Ordem de leitura

[Resumo do produto](LEIA-ME.pt-BR.md) → [síntese](synthesis.md) → [constituição técnica](technical-blueprint/README.md) → [decisões](technical-blueprint/decision-register.md) → [sequência S0–S11](technical-blueprint/implementation-sequence.md). Consultar o [mapa de sucessão](technical-blueprint/supersession.md) antes de reutilizar uma decisão do ZIP anterior.

## Primeira entrega de código

Criar o workspace e admitir versões exatas com evidência real de compatibilidade. Implementar uma jornada de arquivo: duas fontes autorizadas oferecem valores comparáveis divergentes; o sistema preserva ambas, explica uma interpretação ou a incerteza e aceita uma resposta humana com escopo. Provar isso pelo caminho semântico com PostgreSQL real, roles distintas e falhas de transação. A conversa WhatsApp/Eve entra em S1, sem inventar o estado externo no primeiro marco.

O arquivo SQL e os contratos de exemplo **não são migrações completas**. Elaborar o schema e as invariantes antes de usá-los em aplicação. Não copiar o modelo Python como motor de produção: ele demonstra leis selecionadas de um único domínio sintético, sem banco, provedor ou engine de políticas.

## O que o agente pode alterar

Pode implementar mecanismos por trás dos contratos, melhorar clareza, acrescentar testes e corrigir contradições mediante registro. Mudanças de família tecnológica, autoridade, tempo, formato de release, isolamento, idempotência e publicação precisam de revisão do ADR afetado. Variações de negócio devem ser definitions/packs, não branches por cliente no código.

O agente não pode declarar uma etapa completa porque compilou, trocar uma integração real por um mock e manter a alegação, reabrir ferramentas genéricas, ignorar fontes conflitantes, instalar permissões solicitadas por um artefato como se fossem concedidas ou atribuir sucesso a um timeout.

## Convenção de evidência

Toda entrega informa commit, versões, configurações, fixtures, comandos, resultados, falhas e limites. Classificar evidência como design, referência local, componente real, sandbox, produção admitida ou operação medida. Manter a matriz de capacidades vinculada a evidências específicas. Não editar o histórico para fazer parecer que uma decisão antiga já tinha informações novas.

## Questões externas já identificadas

Confirmar inventário de usuários/dados reais do OS antes de qualquer reset; verificar termos/custos do WhatsApp e provedores; obter acesso/licença de fontes; aprovar escopo clínico/financeiro; provisionar contas/sandboxes e definir responsáveis operacionais. Esses itens não bloqueiam a especificação, mas bloqueiam a ativação das respectivas capacidades.

## Verificação deste pacote

Executar `python tools/verify_package.py`. Ler [escopo de verificação](technical-blueprint/verification/README.md) e [relatório](technical-blueprint/verification/report.json). O ambiente desta sessão não é o runtime Node 24/TypeScript 6 de destino e não executou os serviços externos. O resultado local não deve ser promovido a prova de produção.
