# Change log

## 2.0 — 4 September 2026

Promote source disagreement, scoped human learning and runtime variation from scattered mechanisms into first-class product and execution contracts. Maintain three owners and one semantic operation surface across all audiences.

Continue ADR numbering at 030 with 31 new decisions. Map every original ADR 001–029 and preserve all original Markdown byte-for-byte. Replace the fixed mandatory Eve/Nitro/Workflow runtime with a small owned journal/turn machine, explicitly accepting its proof burden. Replace proprietary dense table manifests with Iceberg v2 and explicit staged publication. Separate control head from data-domain versions and use complete Case dependency guards. Replace the universal single-Fly-machine production constraint with concrete hosted/dedicated/cell profiles. Permit law/property tests alongside real component/failure journeys.

Add runtime change lanes, rights-preserving query planning, hidden-rival perspectives, source/ACL freshness, human error reversal, derivative deletion, external Unknown recovery, bounded Mandates and goal observation. Add executable reference slices, 157 mapped capabilities, 14 canonical journeys, S0–S11 outcomes, eight editable diagram sources and local verification tooling.

No application deployed, no provider account connected, no repository modified and no competitive/production parity claim made.
