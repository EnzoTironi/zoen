# Editable architecture diagrams

Eight Mermaid source diagrams describe ownership, truth/learning, runtime change, external effects, commit domains, dataset publication, cells and the three-audience experience. They contain no hidden implementation or permission shortcuts. Mermaid source is supplied instead of a raster image so an implementation team can update the architecture with the code.

The local verifier checks file integrity and references, **not Mermaid rendering or layout**. Render with a compatible Mermaid client during implementation. Diagram arrows indicate protocol dependencies, not a guarantee of distributed atomicity or synchronous execution.

- [01-system.mmd](01-system.mmd).
- [02-truth-learning.mmd](02-truth-learning.mmd).
- [03-runtime-change.mmd](03-runtime-change.mmd).
- [04-actions.mmd](04-actions.mmd).
- [05-head-and-domains.mmd](05-head-and-domains.mmd).
- [06-data-publication.mmd](06-data-publication.mmd).
- [07-cells.mmd](07-cells.mmd).
- [08-experience.mmd](08-experience.mmd).
