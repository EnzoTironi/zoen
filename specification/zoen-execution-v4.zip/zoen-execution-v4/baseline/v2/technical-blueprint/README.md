# Zoen technical constitution — v2

## Decision

Build a modular TypeScript system with three product owners, a stable semantic kernel, versioned executable definitions, and a physically separated untrusted execution plane. Use PostgreSQL for authority, encrypted object storage for evidence, Parquet with Apache Iceberg for dense datasets, DuckDB for initial bounded analytics, and Restate for external effects only.

Eve owns a PostgreSQL-backed interaction journal and bounded turn state machine. AI SDK is a model adapter, not the authority or durable history. The previous mandatory Eve/Nitro/Workflow package topology is superseded; the product name does not impose a framework. This is a design choice with an explicit implementation burden, not a measured claim that an in-house engine is already safer.

Runtime variation is represented in a released package graph. Users and agents can propose instance corrections, reusable definitions and isolated executable artifacts. All consequential activation uses current authority and effect-aware evaluation. The kernel remains code; business variation becomes governed data and, where necessary, sandboxed code artifacts.

## Non-negotiable invariants

| ID | Invariant |
|---|---|
| I01 | Source evidence, claims, interpretations and conversation are distinct. |
| I02 | A Frame identifies exact meaning, time basis, perspective, gaps and rights. |
| I03 | Identity resolution is reversible and evidence-bound; source keys are not global identity. |
| I04 | No mutation or effect relies on an expired, revoked or silently refreshed authorization. |
| I05 | A semantic commit is atomic in one authority cell and uses a complete dependency check. |
| I06 | Decision, execution attempt and observed external settlement are different states. |
| I07 | Every derived output preserves the restrictions of its supporting inputs unless explicitly declassified. |
| I08 | Runtime changes cannot modify kernel safety laws, self-grant permissions or rewrite historical receipts. |
| I09 | Untrusted connectors, skills, models and apps possess only leased capabilities; never authority credentials. |
| I10 | Attention is earned; a Watch condition and a channel's permission are separate checks. |
| I11 | A World has one fenced authority cell at an epoch; federation preserves independent cuts. |
| I12 | Ingestion, tool execution, jobs and provider delivery tolerate duplicate input without inventing exactly-once external behavior. |
| I13 | Retention, deletion and license expiry apply to raw and derived data, indexes, caches and backups. |
| I14 | Every implementation claim has an evidence gate; benchmark targets are not benchmark results. |

## Fixed choices and activation order

| Concern | Decision | First needed |
|---|---|---|
| Language/runtime | Strict TypeScript; Node 24 LTS; pnpm workspace | S0 |
| Edge | Hono with supported Node adapter; REST/JSON + SSE | S0 |
| Identity | Better Auth behind DoorPort; passkeys/OIDC; step-up | S0 |
| Authority | PostgreSQL 18, explicit SQL through `pg`, RLS defense-in-depth | S0 |
| Interpretation | Deterministic bounded IR, property/scope-specific resolution; models propose | S1 |
| Definitions | Canonical JSON, JSON Schema 2020-12, content-addressed release graph | S2 |
| Policy | Cedar for admission/disclosure; restricted queryable policy profile | S0–S3 |
| Conversation | Zoen-owned Eve journal and bounded turn machine; AI SDK adapters | S0–S1 |
| Jobs/events | Transactional outbox, leased PostgreSQL jobs, per-domain order | S0 |
| Effects | Restate executes ZoenEffect; authoritative state stays PostgreSQL | S4 |
| Connectors | Declarative HTTP/OAuth plans first; signed OCI runners for custom code | S2 / S6 |
| Dense data | Parquet + Iceberg v2, REST catalog, explicit snapshot publication | S7 |
| Catalog | Lakekeeper OSS behind DatasetCatalogPort; isolated catalog PostgreSQL | S7 |
| Analytics | DuckDB Node Neo in bounded worker, not edge event loop | S1 small / S7 dense |
| Retrieval | PostgreSQL FTS + pgvector as rebuildable authorized projections | S5 |
| UI | React, React Aria, React Router, TanStack Query/Table/Virtual | S1 |
| Charts/apps | Declarative ChartDocument/ViewDefinition; ECharts; sandboxed MCP Apps profile | S5 / S8 |
| Channels | WhatsApp via Kapso, web; Telegram and Resend email adapters | S1 / S5 |
| Telemetry | OpenTelemetry; redacted structured logs, traces, SLOs, audit exports | S0 |
| Extensibility | Isolated OCI artifacts under microVM/gVisor-grade profile; no ambient credentials | S6 |
| Enterprise | HA/dedicated cells, SSO/SCIM, residency, federation, fleet policy | S9–S10 |
| Tests | Pure law/property tests + real component tests + fault-injected journeys | S0 |

Node/TypeScript/library exact patch values and binary hashes are admitted into an execution lock manifest at S0. The source ledger distinguishes verified publication from inherited candidate pins. There is no fabricated lockfile or claim that this full stack was installed and integration-tested here.

## Read in order

1. [System shape](reference/system-shape.md).
2. [Ontology and standards](reference/ontology-and-standards.md), [truth and learning](reference/truth-reconciliation-and-learning.md), [identity and time](reference/identity-and-time.md).
3. [Runtime variation](reference/runtime-variation-and-releases.md) and [release compiler](reference/release-engine-and-compiler.md).
4. [Authority and cuts](reference/authority-concurrency-and-cuts.md), [data](reference/data-events-parquet.md), [database access](reference/database-access.md).
5. [Rights](reference/rights-and-access-control.md), [actions](reference/actions-effects-and-settlement.md), [mandates](reference/watches-mandates-and-outcomes.md).
6. [Connectors](reference/connectors-and-ingestion.md), [Eve](reference/release-policy-eve.md), [agents](reference/models-retrieval-and-agents.md), [compute](reference/programmable-compute-and-skills.md).
7. [Interfaces](reference/interfaces-sdk-and-mcp.md), [surfaces](reference/apps-charts-and-surfaces.md), [channels](reference/messaging-channels.md).
8. [Operations](reference/security-and-operations.md), [cells](reference/deployment-cells-and-federation.md), [capacity](reference/capacity-economics-and-slos.md), [testing](reference/testing-and-ci.md).
9. [Decision register](decision-register.md), [execution sequence](implementation-sequence.md), [coverage matrix](capability-matrix.csv), [handoff](../HANDOFF.md).

## Status

Proposed execution baseline, not production certification. The original 001–029 ADRs are archived with explicit succession. New 030+ records contain decisions, consequences, alternatives and proof gates. Product hypotheses, commercial prerequisites and unmeasured capacity are intentionally not presented as solved engineering facts.
