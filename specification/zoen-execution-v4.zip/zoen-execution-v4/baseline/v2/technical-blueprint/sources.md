# Source and verification ledger

**Research date: 4 September 2026.** Primary vendor, standards, law and repository sources were consulted in this session. This is not a mirror of the web and does not guarantee future page content. Stable IDs used in brackets throughout the blueprint resolve here. No PDF was used as a source in the new analysis.

Technical architecture, invariants, targets and tradeoffs are **Zoen design decisions**, not claims that these sources endorse the whole design. Source publication, adapter compatibility, sandbox proof and production operation are different evidence levels. The existing repos were read only; no commit, branch or deployment was made.

## S01 — Palantir Ontology overview

[Palantir Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview/).

Objects, links, actions, functions and operational governance are reference categories; not a claim of Zoen parity.

## S02 — Palantir: how user edits are applied

[Palantir: how user edits are applied](https://palantir.com/docs/foundry/object-edits/how-edits-applied/).

Documented edit conflict strategies. Zoen does not claim competitors have no reconciliation.

## S03 — Palantir Ontology SDK

[Palantir Ontology SDK](https://palantir.com/docs/foundry/ontology-sdk/overview/).

Typed applications over ontology semantics motivate one generated surface.

## S04 — Palantir Workshop

[Palantir Workshop](https://palantir.com/docs/foundry/workshop/overview/).

Operational application-builder reference; design coverage, not implementation evidence.

## S05 — Bloomberg Data License

[Bloomberg Data License](https://professional.bloomberg.com/products/data/data-license/).

Licensed enterprise data categories; commercial access remains separate.

## S06 — Bloomberg fundamentals / point-in-time and real-time feed

[Bloomberg fundamentals / point-in-time and real-time feed](https://professional.bloomberg.com/products/data/enterprise-catalog/cofi/).

Point-in-time fundamentals reference; companion feed page documents real-time product categories.

## S07 — Glean connectors and permissions

[Glean connectors and permissions](https://docs.glean.com/connectors/connectors-power-glean).

Content, identity and permissions across indexed/live/hybrid retrieval; source-specific availability matters.

## S08 — W3C JSON-LD 1.1

[W3C JSON-LD 1.1](https://www.w3.org/TR/json-ld11/).

Interoperable semantic identifiers/export profile, not mandatory operational triple storage.

## S09 — W3C PROV-O

[W3C PROV-O](https://www.w3.org/TR/prov-o/).

Provenance vocabulary for exchange mappings; internal authority adds rights/time contracts.

## S10 — W3C SHACL Recommendation

[W3C SHACL Recommendation](https://www.w3.org/TR/shacl/).

Stable shape-validation interoperability profile; not a general runtime permission engine.

## S11 — PostgreSQL transaction isolation

[PostgreSQL transaction isolation](https://www.postgresql.org/docs/18/transaction-iso.html).

Serializable and repeatable-read behavior informs local transactions; must test actual locking and retries.

## S12 — PostgreSQL row security

[PostgreSQL row security](https://www.postgresql.org/docs/18/ddl-rowsecurity.html).

RLS and privileged-role caveats; application disclosure remains necessary.

## S13 — Cedar documentation

[Cedar documentation](https://docs.cedarpolicy.com/).

Authorization policy evaluator; no documented general SQL compilation is assumed.

## S14 — Apache Iceberg specification

[Apache Iceberg specification](https://iceberg.apache.org/spec/).

Snapshots and metadata format; v2 profile deliberately selected, no cross-system atomicity implied.

## S15 — DuckDB Node Neo

[DuckDB Node Neo](https://duckdb.org/docs/current/clients/node_neo/overview.html).

Official Node API and 1.5.5 observation; Iceberg writes require compatible catalog/extension checks.

## S16 — Lakekeeper concepts

[Lakekeeper concepts](https://docs.lakekeeper.io/docs/0.10.x/concepts/).

REST catalog with PostgreSQL persistence. Do not rely on separately commercialized catalog features.

## S17 — RFC 8785 JSON Canonicalization Scheme

[RFC 8785 JSON Canonicalization Scheme](https://www.rfc-editor.org/info/rfc8785/).

Canonical JSON design profile; decimal values are strings, unsupported numbers are rejected.

## S18 — Restate invocations

[Restate invocations](https://docs.restate.dev/foundations/invocations).

Durable invocation/idempotency mechanisms; external systems and retention still need Zoen evidence contracts.

## S19 — MCP specification 2026-07-28

[MCP specification 2026-07-28](https://modelcontextprotocol.io/specification/2026-07-28).

Latest endpoint resolved to this edition on 4 September 2026; pin protocol negotiation.

## S20 — MCP Apps extension

[MCP Apps extension](https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/2026-01-26/apps.mdx).

Sandboxed app/host interaction profile; support must be negotiated per client.

## S21 — AI SDK documentation

[AI SDK documentation](https://ai-sdk.dev/docs/introduction).

Model/tool transport, structured output and provider adapters; not an authority/durability engine.

## S22 — Node.js previous releases

[Node.js previous releases](https://nodejs.org/en/about/previous-releases).

Node 24 LTS lifecycle reference; exact binary admission remains S0.

## S23 — Hono Node adapter

[Hono Node adapter](https://hono.dev/docs/getting-started/nodejs).

Supported Node integration; verify streaming/body/proxy behavior in components.

## S24 — Better Auth 1.7 / identity plugins

[Better Auth 1.7 / identity plugins](https://better-auth.com/blog/1-7).

Identity features and enterprise plugins; no certification or tested Zoen integration implied.

## S25 — WhatsApp Business Messaging Policy

[WhatsApp Business Messaging Policy](https://business.whatsapp.com/policy/).

Consent, messaging windows/templates and sensitive-information conditions; recheck before launch.

## S26 — WhatsApp Business Solution Terms

[WhatsApp Business Solution Terms](https://www.whatsapp.com/legal/business-solution-terms).

AI-provider restrictions include Brazil/EEA exception in consulted text; not blanket operational approval.

## S27 — Kapso documentation

[Kapso documentation](https://docs.kapso.ai/docs/introduction).

WhatsApp transport adapter candidate; contractual/API behavior must be admitted.

## S28 — Brazil LGPD consolidated law

[Brazil LGPD consolidated law](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/L13709compilado.htm).

Legal primary reference; this design is not a legal opinion or compliance certification.

## S29 — Existing OS repository

[Existing OS repository](https://github.com/EnzoTironi/OS).

Public repository documentation inspected; application was not built, deployed or security-tested.

## S30 — New zoen repository

[New zoen repository](https://github.com/EnzoTironi/zoen).

Public main showed README-level content when consulted; remote can change.

## S31 — Poke documentation

[Poke documentation](https://poke.com/docs).

Conversational assistant and integrations as experience reference; no internal architecture inferred.

## S32 — gVisor security architecture

[gVisor security architecture](https://gvisor.dev/docs/architecture_guide/security/).

Isolation threat model; external network/resource controls and compatibility tests remain necessary.

## S33 — TypeScript registry latest metadata

[TypeScript registry latest metadata](https://registry.npmjs.org/typescript/latest).

Observed latest 7.0.2; inherited 6.0.3 baseline is not falsely labeled latest or independently installed.

## S34 — Supplied zoen-greenfield.zip

[Supplied zoen-greenfield.zip](../baseline/README.md).

Local user-provided architecture, hashed in baseline/input-manifest.json; not public runtime evidence.

## S35 — PostgreSQL supported versions

[PostgreSQL supported versions](https://www.postgresql.org/support/versioning/).

Version lifecycle for the selected PG18 family.

## S36 — AWS RDS PostgreSQL versions

[AWS RDS PostgreSQL versions](https://docs.aws.amazon.com/AmazonRDS/latest/PostgreSQLReleaseNotes/postgresql-versions.html).

PG18 service support reference; exact region/extensions verified at deployment.

## S37 — AWS ECS Fargate

[AWS ECS Fargate](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/AWS_Fargate.html).

Trusted-service task profile; untrusted payloads do not share authority roles or sensitive sidecars.

## S38 — ECharts accessibility

[ECharts accessibility](https://echarts.apache.org/handbook/en/best-practices/aria/).

Accessibility configuration must be enabled and augmented; not automatic complete accessibility.

## Companion primary references

- [Bloomberg real-time data feeds](https://professional.bloomberg.com/products/data/enterprise-catalog/real-time-data-feed/).
- [DuckDB Iceberg write support](https://duckdb.org/docs/current/core_extensions/iceberg/writing.html) and [extension reference](https://duckdb.org/docs/current/core_extensions/iceberg/reference.html).
- [Lakekeeper source](https://github.com/lakekeeper/lakekeeper).
- [Restate service configuration and retention](https://docs.restate.dev/services/configuration).
- [Better Auth SCIM](https://better-auth.com/docs/plugins/scim) and [SSO](https://better-auth.com/docs/plugins/sso).
- [AI SDK 7 migration](https://ai-sdk.dev/docs/migration-guides/migration-guide-7-0), [published ai package](https://www.npmjs.com/package/ai), [published Hono package](https://www.npmjs.com/package/hono).
- [TypeScript 6 release notes](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-6-0.html).
- [gVisor compatibility and resource limitations](https://gvisor.dev/docs/user_guide/compatibility/).
- [RDS PostgreSQL operations](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_PostgreSQL.html).
- [Fly Managed Postgres](https://fly.io/docs/mpg/), reviewed but not selected as the fixed PG18 production profile.
- [OS architecture source](https://raw.githubusercontent.com/EnzoTironi/OS/main/architecture.md).

## Explicit verification gaps

No complete application lockfile, dependency install, AWS provisioning, PostgreSQL transaction experiment, Cedar adapter test, provider credential connection, WhatsApp delivery, Restate failover, Iceberg GC race, native sandbox escape test, licensed financial feed, security audit or legal/commercial approval was performed here. The package's local verification report covers only the listed reference artifacts.

No 92% WhatsApp penetration assumption is used in sizing or product proof. Market reach, willingness to delegate and willingness to pay require separate evidence. The public descriptions of competing products establish inspiration and capability categories, not benchmark parity or an exhaustive competitive audit.
