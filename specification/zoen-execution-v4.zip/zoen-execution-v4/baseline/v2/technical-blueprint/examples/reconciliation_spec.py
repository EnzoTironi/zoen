"""Small deterministic reference model. Not the Zoen runtime or a security boundary.

Callers supply already-authorized claim IDs and source-order/attestation contracts.
This module has no network, database, real credentials, model or provider behavior.
"""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, localcontext
from typing import Iterable, Mapping
import re

DECIMAL = re.compile(r"^-?(0|[1-9][0-9]*)(\.[0-9]+)?$")


def decimal_value(value: str) -> Decimal:
    if not isinstance(value, str) or len(value) > 128 or not DECIMAL.fullmatch(value):
        raise ValueError("A plain finite decimal string is required")
    result = Decimal(value)
    if not result.is_finite():
        raise ValueError("Non-finite values are not admitted")
    return result


def canonical_decimal(value: Decimal) -> str:
    if value == 0:
        return "0"
    out = format(value, "f")
    return out.rstrip("0").rstrip(".") if "." in out else out


@dataclass(frozen=True)
class Claim:
    id: str
    subject: str
    predicate: str
    scope: str
    unit: str
    value: str
    source: str
    family: str
    revision: int
    knowledge: int
    valid_from: date
    valid_until: date | None = None
    retracted_at: int | None = None

    def __post_init__(self) -> None:
        decimal_value(self.value)
        if self.revision < 0 or self.knowledge < 0:
            raise ValueError("Versions must be nonnegative")
        if self.valid_until is not None and self.valid_until <= self.valid_from:
            raise ValueError("Intervals are nonempty and half-open")
        if self.retracted_at is not None and self.retracted_at < self.knowledge:
            raise ValueError("A retraction cannot precede admission")


@dataclass(frozen=True)
class Query:
    subject: str
    predicate: str
    scope: str
    unit: str
    valid_at: date
    cut: int  # one synthetic commit domain only, NOT a production WorldCut
    allowed_claim_ids: frozenset[str]


@dataclass(frozen=True)
class Policy:
    strategy: str
    preferred_source: str | None = None
    quorum: int = 2
    monotonic_sources: frozenset[str] = field(default_factory=frozenset)
    attested_claim_ids: frozenset[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        if self.strategy not in {"manual", "source_of_record", "independent_quorum", "authorized_attestation"}:
            raise ValueError("Unsupported strategy")
        if self.strategy == "source_of_record" and not self.preferred_source:
            raise ValueError("A source-of-record policy requires an explicit source")
        if self.quorum < 2:
            raise ValueError("Independent quorum must be at least two")


@dataclass(frozen=True)
class Interpretation:
    status: str
    value: str | None
    contested: bool
    supporting_ids: tuple[str, ...]
    rival_ids: tuple[str, ...]
    verification: str
    reason: str


def resolve(claims: Iterable[Claim], query: Query, policy: Policy) -> Interpretation:
    """No hidden-source influence: only caller-authorized, comparable claims enter."""
    unique: dict[str, Claim] = {}
    for claim in claims:
        if claim.id not in query.allowed_claim_ids:
            continue
        if claim.id in unique and unique[claim.id] != claim:
            raise ValueError("One immutable claim ID cannot carry two payloads")
        unique[claim.id] = claim
    eligible = [c for c in unique.values() if
        (c.subject, c.predicate, c.scope, c.unit) ==
        (query.subject, query.predicate, query.scope, query.unit)
        and c.knowledge <= query.cut and c.valid_from <= query.valid_at
        and (c.valid_until is None or query.valid_at < c.valid_until)
        and (c.retracted_at is None or query.cut < c.retracted_at)]
    # Latest revision only where the source contract explicitly guarantees ordering.
    latest: dict[str, int] = {}
    for c in eligible:
        if c.source in policy.monotonic_sources:
            latest[c.source] = max(latest.get(c.source, -1), c.revision)
    eligible = [c for c in eligible if c.source not in latest or c.revision == latest[c.source]]
    eligible.sort(key=lambda c: c.id)
    if not eligible:
        return Interpretation("unknown", None, False, (), (), "unverified", "no-authorized-comparable-basis")
    values = {decimal_value(c.value) for c in eligible}
    winners: set[Decimal] = set()
    reason = policy.strategy
    if policy.strategy == "source_of_record":
        preferred = {decimal_value(c.value) for c in eligible if c.source == policy.preferred_source}
        if len(preferred) == 1:
            winners = preferred
    elif policy.strategy == "authorized_attestation":
        attested = {decimal_value(c.value) for c in eligible if c.id in policy.attested_claim_ids}
        if len(attested) == 1:
            winners = attested
    elif policy.strategy == "independent_quorum":
        families: dict[str, set[Decimal]] = defaultdict(set)
        for c in eligible:
            families[c.family].add(decimal_value(c.value))
        votes: dict[Decimal, int] = defaultdict(int)
        for family_values in families.values():
            if len(family_values) == 1:  # self-conflicting family casts no clean vote
                votes[next(iter(family_values))] += 1
        winners = {v for v, count in votes.items() if count >= policy.quorum}
    # Manual policy always requires a governed answer outside this reference model.
    if len(winners) != 1:
        return Interpretation("unresolved", None, len(values) > 1, (), tuple(c.id for c in eligible), "unverified", reason)
    winner = next(iter(winners))
    supports = tuple(c.id for c in eligible if decimal_value(c.value) == winner)
    rivals = tuple(c.id for c in eligible if decimal_value(c.value) != winner)
    return Interpretation("selected", canonical_decimal(winner), bool(rivals), supports, rivals,
                          "attested" if policy.strategy == "authorized_attestation" else "unverified", reason)


class IntentConflict(ValueError):
    pass


class ReferenceLedger:
    """In-memory intent law example. It proves nothing about real concurrency/SQL."""
    def __init__(self) -> None:
        self._items: dict[tuple[str, str, str, str], tuple[str, str]] = {}

    def commit(self, key: tuple[str, str, str, str], intent_digest: str, *, authorized: bool) -> str:
        if not authorized:
            raise PermissionError("Fresh authorization is required even for replay")
        if key in self._items:
            digest, receipt = self._items[key]
            if digest != intent_digest:
                raise IntentConflict("Operation ID reused with a different intent")
            return receipt
        receipt = f"receipt-{len(self._items)+1}"
        self._items[key] = (intent_digest, receipt)
        return receipt


def case_is_stale(expected_head: tuple[str, ...], current_head: tuple[str, ...],
                  expected_fences: Mapping[str, int], current_fences: Mapping[str, int],
                  *, now: int, expires: int) -> bool:
    return (expected_head != current_head or now >= expires or
            any(current_fences.get(k) != v for k, v in expected_fences.items()))


def retry_unknown_effect(*, provider_idempotent: bool, currently_authorized: bool) -> bool:
    """Conservative policy law; real providers additionally require reconciliation."""
    return provider_idempotent and currently_authorized


def reserve(limit: str, reserved: str, requested: str) -> str:
    cap, used, new = map(decimal_value, (limit, reserved, requested))
    # Bound input size and choose enough precision; never depend on ambient context.
    with localcontext() as context:
        context.prec = 2 * max(len(limit), len(reserved), len(requested)) + 8
        total = used + new
        if cap < 0 or used < 0 or new < 0 or total > cap:
            raise ValueError("Invalid or exceeded budget")
        return canonical_decimal(total)
