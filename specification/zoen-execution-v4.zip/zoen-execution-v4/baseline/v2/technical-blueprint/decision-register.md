# Decision register

The following choices are normative for the proposed v2 execution baseline. Detailed consequences and proof gates are in each ADR. Local code examples do not supersede these contracts.

| ID | Decision | Record | Detail |
|---|---|---|---|
| 030 | Three owners and a stable semantic kernel | [ADR](adrs/030-three-owners-stable-kernel.md) | [system-shape](reference/system-shape.md) |
| 031 | Attributed claims and revisable interpretations | [ADR](adrs/031-claims-interpretations-and-correction.md) | [truth-reconciliation-and-learning](reference/truth-reconciliation-and-learning.md) |
| 032 | World-scoped identity with reversible resolution | [ADR](adrs/032-world-scoped-reversible-identity.md) | [identity-and-time](reference/identity-and-time.md) |
| 033 | Four runtime change lanes | [ADR](adrs/033-four-runtime-change-lanes.md) | [runtime-variation-and-releases](reference/runtime-variation-and-releases.md) |
| 034 | Current rights and derived-data restrictions | [ADR](adrs/034-current-rights-derived-lineage.md) | [rights-and-access-control](reference/rights-and-access-control.md) |
| 035 | Control head plus domain-scoped atomic commits | [ADR](adrs/035-control-head-and-domain-commits.md) | [authority-concurrency-and-cuts](reference/authority-concurrency-and-cuts.md) |
| 036 | Committed cuts and complete dependency guards | [ADR](adrs/036-temporal-cuts-and-predicate-guards.md) | [authority-concurrency-and-cuts](reference/authority-concurrency-and-cuts.md) |
| 037 | Source contracts and durable ingestion | [ADR](adrs/037-source-contracts-and-durable-admission.md) | [connectors-and-ingestion](reference/connectors-and-ingestion.md) |
| 038 | Standard semantic and table interchange | [ADR](adrs/038-standard-semantic-and-table-interchange.md) | [ontology-and-standards](reference/ontology-and-standards.md) |
| 039 | Staged datasets and exact authoritative publication | [ADR](adrs/039-staged-dataset-publication.md) | [data-events-parquet](reference/data-events-parquet.md) |
| 040 | Eve-owned journal and bounded turn machine | [ADR](adrs/040-eve-owned-turn-machine.md) | [release-policy-eve](reference/release-policy-eve.md) |
| 041 | Channels transport relationships, not authority | [ADR](adrs/041-channel-contracts-not-authority.md) | [messaging-channels](reference/messaging-channels.md) |
| 042 | One decision protocol and separate external settlement | [ADR](adrs/042-actions-effects-and-settlement.md) | [actions-effects-and-settlement](reference/actions-effects-and-settlement.md) |
| 043 | Compose Watches, Mandates and observable outcomes | [ADR](adrs/043-watches-mandates-and-outcomes.md) | [watches-mandates-and-outcomes](reference/watches-mandates-and-outcomes.md) |
| 044 | Signed isolated executable capabilities | [ADR](adrs/044-isolated-executable-capabilities.md) | [programmable-compute-and-skills](reference/programmable-compute-and-skills.md) |
| 045 | Retrieval projections and models as proposers | [ADR](adrs/045-retrieval-and-models-as-proposers.md) | [models-retrieval-and-agents](reference/models-retrieval-and-agents.md) |
| 046 | One semantic manifest for all interfaces | [ADR](adrs/046-one-surface-manifest.md) | [interfaces-sdk-and-mcp](reference/interfaces-sdk-and-mcp.md) |
| 047 | Declarative surfaces with isolated executable apps | [ADR](adrs/047-declarative-and-isolated-surfaces.md) | [apps-charts-and-surfaces](reference/apps-charts-and-surfaces.md) |
| 048 | Proof, preparation and atomic activation | [ADR](adrs/048-proof-preparation-activation.md) | [release-engine-and-compiler](reference/release-engine-and-compiler.md) |
| 049 | Regional authority cells and explicit federation | [ADR](adrs/049-regional-cells-and-federation.md) | [deployment-cells-and-federation](reference/deployment-cells-and-federation.md) |
| 050 | Retention and deletion across derived state | [ADR](adrs/050-retention-erasure-and-recovery.md) | [lifecycle-privacy-and-retention](reference/lifecycle-privacy-and-retention.md) |
| 051 | Domain packs instead of customer-specific forks | [ADR](adrs/051-domain-packs-not-customer-forks.md) | [domain-packs-and-marketplace](reference/domain-packs-and-marketplace.md) |
| 052 | Explicit authority SQL and rebuildable projections | [ADR](adrs/052-explicit-sql-and-rebuildable-projections.md) | [database-access](reference/database-access.md) |
| 053 | Budgets, observability and measured capacity | [ADR](adrs/053-budgets-observability-and-capacity.md) | [capacity-economics-and-slos](reference/capacity-economics-and-slos.md) |
| 054 | Law tests plus real boundary journeys | [ADR](adrs/054-laws-components-and-real-journeys.md) | [testing-and-ci](reference/testing-and-ci.md) |
| 055 | Concrete stack families with evidence-based pins | [ADR](adrs/055-stack-and-version-admission.md) | [technology-stack](reference/technology-stack.md) |
| 056 | Complete finance lifecycle without invented entitlements | [ADR](adrs/056-finance-lifecycle-and-licenses.md) | [finance-domain](reference/finance-domain.md) |
| 057 | Traceable greenfield design and guarded cutover | [ADR](adrs/057-traceable-greenfield-migration.md) | [migration-and-adoption](reference/migration-and-adoption.md) |
| 058 | Scoped stewardship and proportional governance | [ADR](adrs/058-stewardship-and-change-governance.md) | [runtime-variation-and-releases](reference/runtime-variation-and-releases.md) |
| 059 | Governed data flows, live capture and training artifacts | [ADR](adrs/059-governed-flows-live-and-training.md) | [data-flows-and-live-data](reference/data-flows-and-live-data.md) |
| 060 | Evidence levels and honest product claims | [ADR](adrs/060-design-proof-and-production-claims.md) | [ambition-audit](reference/ambition-audit.md) |

## Chosen, deferred and forbidden

**Chosen now:** product owners, explicit claim/interpretation truth model, four change lanes, typed kernel, current-rights query/commit protocols, PG domain cuts, source and effect leases, isolated artifacts, standard dense snapshots, own Eve turn history, single semantic surface, physical cell fencing, retention and evidence gates.

**Deferred installation, not deferred contracts:** Restate at S4; hybrid projections at S5; arbitrary isolated artifacts at S6; Iceberg/catalog and advanced flows at S7; executable apps at S8; institutional HA/SSO/SCIM at S9; federation/edge at S10; certified institutional financial execution at S11. Earlier slices enforce the core invariants without installing every later service.

**Forbidden:** arbitrary SQL/JS with authority credentials; chat memory as canonical fact; silent conflict overwrite; hidden ACL leakage; agent self-grant; model-only consent; cross-cell ACID fiction; blindly retried unsafe effects; source or catalog latest as a historical proof; in-place release mutation; perpetual retention overriding law; invented provider success, installed versions, benchmarks or competitive parity.

## Decision ownership

Product owns user outcomes and acceptable attention/interaction burden. Kernel owns semantic/authority laws. Data owns source fidelity, mappings, quality and retention. Security owns threat/assurance policy. Operations owns capacity/recovery evidence. Domain stewards own meanings and scoped resolutions. One person may hold several roles in a small team, but the responsibilities and required separation for sensitive approvals remain explicit.
