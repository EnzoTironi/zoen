# Testing, CI and evidence gates

## Decision

Use three complementary layers: fast executable laws, real component tests and end-to-end user journeys with failure injection. The original blanket ban on unit tests is superseded: pure logic benefits from property tests, while a mock of PostgreSQL/provider behavior cannot establish real atomicity or settlement correctness.

## Law suite

Test canonicalization, money/unit normalization, interval intersection, typed resolution, scope comparability, source-family independence, permission monotonicity, lineage propagation, release determinism, dependency invalidation, graph cycle handling and budget conservation. Generated cases include malformed/oversized values and unknown states. Deterministic seeds allow replay; shrinking produces minimal counterexamples. Type-level realm/scope tests reject evaluation IDs in live APIs.

## Real components

Run actual PostgreSQL at the admitted version with distinct roles/RLS, competing SERIALIZABLE transactions, predicate insertion races, membership revocation and head activation locks. Run object-store durability, staged snapshot publication/GC, DuckDB memory limits, actual Cedar policy evaluation, model-provider schema adapters, webhook signature fixtures and sandbox network/resource controls. A fake policy engine or in-memory queue does not satisfy these gates.

Measure transaction retries and confirm `FOR SHARE` blocks head changes while ordinary domain writes can coexist. Include absent-row/aggregate guards: adding a matching invoice after approval must make the Case stale even if the originally read rows did not change.

## Fault-injected journeys

Kill each worker before/after durable admission, model completion, tool dispatch, local commit, effect send, provider response, Settlement commit, outbox ack and release activation. Lose responses without losing the underlying action. Deliver duplicate, reordered and delayed callbacks. Expire source ACLs, revoke users during generation, activate a new rule while a Case is open, restore a backup with an escaped effect, and move a cell with an in-flight request.

At minimum, assert one local semantic result per idempotent intent, no hidden authority bypass, no invented external success, no stale consent reuse and no disclosure after the local revocation boundary. Some providers cannot guarantee one delivery; the expected result may be an explicit Unknown and a reconciliation path, not a falsely perfect assertion.

## EvaluationWorld

Evaluation has independent realm-branded IDs, database roles, source/effect leases, object namespace, channels, outbox and sandbox endpoints. A test email or WhatsApp Notice cannot address a live person. Real production credentials are unavailable. Test captures may replay redacted/authorized evidence under a separate evaluation rights contract; consent and license still apply.

Release evaluation includes semantic diff, backward compatibility, reconciliation fixtures, impact report, rule adversarial cases, runtime budget, rights non-escalation and journey attestations. Missing provider sandbox evidence is recorded as missing; activation rejects capabilities for which it is mandatory.

## CI stages

1. Formatting/lint/type checks, dependency boundaries, unused-code and secret/license checks.
2. Schema and canonical contract compatibility, law/property tests, generated surface parity.
3. Real component suites with pinned dependencies and negative permissions.
4. Canonical journeys + selected fault matrix; expanded chaos/load/security suite before production release.
5. Signed image/SBOM, migration and release preparation rehearsal, restore validation.

A failure is not bypassed with `skip`, blanket warnings or a fake successful receipt. Waivers identify owner, scope, expiry and disabled capability; they cannot waive kernel invariants. External service unavailability can block a production claim without blocking unrelated local law development.

## Evidence classifications

`DesignOnly`, `LocalReferencePassed`, `ComponentPassed`, `SandboxJourneyPassed`, `ProductionAdmitted`, `OperatingMeasured`. Store exact commit, versions, data fixture, hardware, region, time, result and limitations. Never translate a local reference test into `ProductionAdmitted`.

The runnable Python/JSON/TypeScript artifacts in this package are reference slices only. Their actual verification report lists what ran; they do not exercise PostgreSQL, provider accounts, AWS, WhatsApp, Cedar or untrusted runners.
