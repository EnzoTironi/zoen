# Truth, reconciliation and learning

## Decision

Persist immutable evidence and attributed claims. Compute a versioned interpretation under a released policy. Treat human corrections as scoped evidence or decisions, not unconditional truth. Never choose a value merely because it arrived last or because a model sounded certain.

The objective is an increasingly useful and inspectable world, not a falsely complete, permanently perfect database. Some disagreement is irreducible: different people can hold different preferences; forecasts differ; accounts use different consolidation rules; contradictory witnesses may remain unresolved.

## The minimal knowledge model

**EvidenceArtifact:** immutable bytes or a permitted retained excerpt/reference, hash, acquisition provenance, source revision, clocks, rights, retention policy and extraction references. A hash proves byte identity, not factual correctness. Signed provider content authenticates a source, not the truth of every statement.

**Claim:** subject, predicate, typed value, valid interval, scope, source identity, evidence references, asserting principal or extraction run, source revision, knowledge-domain version and lineage. A claim may be an observation, human assertion, estimate, derived assertion or explicit negation. Its origin never disappears during normalization.

**Interpretation:** selected value(s), unresolved state or no-current-evidence result, under a named policy and perspective. It carries supporting/rival/dependent claim references, comparability decisions, quality dimensions, expiry, exact release and dependency set. Selection and verification are separate axes: selected does not imply independently verified or undisputed.

**ResolutionCase:** an ActionCase specialized to ambiguous identity, meaning or claims. It asks an authorized participant to choose a scope-specific interpretation, contribute new evidence, or leave the question unresolved. Its receipt records the decision and the exact question/basis presented.

## Reconciliation pipeline

1. **Admit evidence.** Verify acquisition permission, object integrity, source cursor/revision and rights. Quarantine unsafe or unmappable payloads. Acquisition progress does not mean knowledge admission.
2. **Normalize losslessly.** Preserve original strings and add typed parses with locale, unit, currency, timezone and parser version. “1.234,50” is interpreted only with an explicit locale contract. A failed parse is not zero.
3. **Resolve candidate identity.** Use source-scoped keys and deterministic rules first; probabilistic or model suggestions remain candidate edges. Ambiguous matches do not merge records automatically unless a released low-risk rule explicitly permits that class.
4. **Establish comparability.** Compare only the same semantic predicate, scope, valid interval, unit/basis and entity identity. Invoice amount, received cash and contracted value are not rivals until a definition explicitly makes them comparable.
5. **Group dependence.** Track imports, copies and transformations. A spreadsheet copied from the ERP and an email quoting that sheet are one evidence family, not three independent votes.
6. **Evaluate eligibility.** Check source rights, effective time, schema quality, expiry, release compatibility, identity confidence requirements and any scope-specific authority. Unknown eligibility is not a pass for a consequential fact.
7. **Select or preserve conflict.** Apply the released strategy. Produce selected-with-rivals, plural, unresolved or no-current-evidence. Retain all admissible provenance and the reasons for exclusion.
8. **Propagate.** Record meaningful change, invalidate dependent interpretations and Cases, recompute affected Watches and schedule a clarification only when warranted.

The first implementation is deterministic rules and explicit exceptions. Calibrated entity-linking models, source-reliability models and learned ranking can be added behind the same evidence and evaluation contract; they never silently become the authority policy.

## Supported resolution strategies

`source-of-record-for-field` names the authoritative source, predicate, scope and freshness requirements. `authorized-attestation` accepts a human role for a specified class of facts, with bounded validity. `latest-revision-within-source` orders comparable revisions using the provider's revision contract. `quorum-of-independent-families` requires actual independent provenance groups. `tolerance-agreement` compares values after explicit normalization. `manual-required` blocks consequential selection. `set-valued` retains multiple valid values. `derived` applies a released deterministic computation.

Strategies compose as a bounded decision tree, not a single global source score. Ties remain unresolved unless the domain declares a legitimate tie-break. Last-write-wins is reserved for non-factual preferences and for source revisions whose ordering contract actually supports it.

A factual policy cannot simply say “the owner is always right.” The owner may authoritatively choose an order's promised delivery date; the bank remains the source of evidence about what it settled. An owner assertion that payment occurred can be retained as pending evidence without marking settlement verified.

## Learning from user answers

Before asking, classify the desired intervention:

| Intervention | Example | Stored result |
|---|---|---|
| Instance assertion | “This receipt belongs to order 42.” | Attributed claim with evidence and scope |
| Identity resolution | “These records refer to different customers.” | Versioned mapping/split decision |
| Local selection | “For this estimate, use the signed quote.” | Resolution receipt bound to the current case |
| Reusable rule | “A deposit requires bank confirmation.” | Draft DefinitionChange, evaluation and activation |
| Preference | “Do not notify me before 9.” | Personal interaction setting; not business fact |

Eve must not silently promote an instance answer to a reusable rule. It can propose a rule after repeated observations, show counterexamples and obtain appropriate approval. Learning improves local mappings, clarification selection and configuration; cross-tenant training requires a separate explicit data-use basis, and is off by default.

Every resolution records: actor and assurance; question version; visible Frame; chosen answer; optional new evidence; scope and valid interval; policy; case expiry; operation ID; decision receipt; whether the user opted to propose a rule. “I do not know” and dismissal are not votes for a candidate.

## Ask the right person, not every person

A ClarificationCandidate estimates decision impact, time sensitivity, likely reducibility and interruption/privacy cost. Initial priority is a transparent deterministic rubric, not a fabricated probability of correctness. Questions are deduplicated by subject/predicate/scope/candidate-set version. Evidence changes can invalidate a queued question.

Route by stewardship/mandate, verified competence for that domain and permission to see the evidence. Ask about one meaningful distinction, show what changes with the answer, support undo, and honor quiet hours. Group related issues when this lowers work without hiding independent decisions. The exception inbox exposes unresolved important cases without creating a stream of demands.

## Consistency, invalidation and revisions

An interpretation dependency graph is acyclic per derivation generation. Recursive domain relationships are allowed; recursive computations require a bounded released evaluation scheme and cannot create self-supporting evidence. A derived claim cannot cite its own descendants as independent support.

A correction appends a successor or retraction relation. Reopening history at an old cut yields the then-known interpretation under its release. A present-day user may no longer have the right to see it. A retroactive valid-time correction does not rewrite the historical knowledge cut.

Affected ActionCases become stale when the actual read set, predicate fence, identity mapping, rights, policy, source freshness or relevant live capture changes. A projection that has not caught up returns pending/stale status or computes on demand within budget; it never masquerades as the current interpretation.

## Worked distinction

An order spreadsheet says 80 units and WhatsApp says 100. The intake first determines whether both refer to the same order and revision. If the later message is a signed-off revision by the authorized buyer, the system can select 100 under the order policy while preserving 80 as the old commitment. If the message is only an employee's guess, selection remains unresolved. If 80 refers to delivered units, the values are different predicates and do not conflict.

Payment is separate: a deposit receipt may cover part of an invoice, and “paid” must include amount, currency, account, effective date and settlement evidence. The same method scales from a household bill to enterprise intercompany reconciliation.

## Quality and proof

Measure critical-field coverage, freshness against source SLAs, unresolved consequential conflicts, human minutes spent per resolved issue, identity false-merge rate, correction reversal rate, interpretation stability and proportion of consequential decisions with complete lineage. Report denominators and eligible scopes. Never optimize “few conflicts” by hiding conflicting evidence.

Required journeys: late correction, source outage, duplicate evidence family, wrong locale, disputed authoritative source, revoked steward, split after merge, hidden rival, stale question, wrong human answer, policy rollback, replay under an older release and a high-impact unresolved outcome. Synthetic local fixtures in this package exercise only selected logic; real-source and fault tests remain execution gates.
