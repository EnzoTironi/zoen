# Competitive references and honest ambition

## Decision

Borrow requirements, not a collage of screens or unsupported claims of feature parity. Palantir's operational ontology, Bloomberg's licensed data/analytics/execution ecosystem, Glean's permission-aware connectivity and Poke's conversational accessibility inspire distinct design pressures. Their public documentation is not evidence about private implementations. [S01, S03, S04, S05, S06, S07, S31]

| Reference pressure | Zoen architectural response | Still to earn |
|---|---|---|
| Operational ontology and actions | Released objects/links/interfaces/functions, governed Cases and SurfaceManifest | Domain depth, builder usability, proven deployments. |
| Conflicting source/edit behavior | Explicit claims, scoped resolution, reversible identity and interpretation histories | Correct source integrations, steward trust and correction usefulness. |
| Search across existing systems | Source contracts, ACL mapping, hybrid authorized retrieval and context | Reliable connectors, complete permissions and recall/precision. |
| Data/analysis/monitoring/execution continuity | Frames, live capture, datasets, Watches, scenarios, receipts and Settlement | Licensed feeds, execution certification and operating history. |
| Accessible personal relationship | Eve continuity, progressive setup, quiet attention, WhatsApp and visual deepening | Real user retention, attention quality and affordable cost. |
| Runtime builders and apps | Definition packages, isolated artifacts, generated SDK/MCP and views | Usable authoring, compatibility, publisher ecosystem and support. |

The proposed reconciliation model is a design emphasis, not a claim that Palantir or Glean lack conflict handling. Palantir documents user-edit conflict strategies. The relevant Zoen question is how to expose uncertainty and improve meaning through ordinary user interaction without destroying provenance or granting false authority. [S02]

## What architecture cannot supply

It cannot manufacture Bloomberg's licensed data/network, Palantir's customer integrations/operational track record, Glean's tested connector breadth or Poke's acquired product trust. Rights, partnerships, implementation, support and distribution remain work. All entries in the capability matrix start as `DesignOnly` unless specifically marked as a local reference artifact.
