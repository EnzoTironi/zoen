# Watches, mandates and outcomes

## Decision

Ontology decides whether a change is semantically material. Eve decides whether, when, how and where to interrupt. A bounded Mandate composes Watches and Actions to care for an outcome over time; it is not a new autonomous authority or a general workflow engine hidden in chat.

## Watch contract

A Watch binds subject/object-set, released predicate, interpretation basis, materiality, source freshness, evaluation cadence, temporal window, release compatibility, authorized audience, escalation and stop conditions. “Tell me when this changes” is converted into a visible proposed contract, with a plain-language default and a meaningful example.

Changes include becoming stale or unknown, not only crossing a numeric threshold. A Watch over incomplete data states its coverage. A latest-price Watch cannot pretend to inspect every market tick if its feed is conflated.

## Evaluation

Semantic commit envelopes enqueue affected Watches by dependency. A clock-triggered job handles expiry/cadence; clock sampling is explicit. A run evaluates a fresh authorized basis, compares a compact checkpoint and atomically advances the checkpoint, creates at most one canonical Notice for the transition and writes outbox.

Notice uniqueness is keyed by Watch/version and a semantic transition identity, not a random notification ID. Hysteresis, cooldown and grouping are explicit policy; they cannot suppress a required critical escalation silently. High-rate raw observations are reduced by released detectors before they wake Eve.

## Eve attention

Eve receives an opaque Notice reference. It reopens an authorized view, then applies preferences, urgency, quiet hours, already-delivered context, grouping and channel constraints. Immediately before composing/sending a deferred Notice it reauthorizes again; a stale stored payload is not reused after permission changes.

Record why a Notice was sent, merged, deferred, suppressed, expired or blocked by channel policy. The user can inspect what is being watched, last evaluation basis, stale sources, pending questions and delivery status. Silence is explainable, not absence of accounting.

## Mandate contract

A Mandate contains a named goal/subject, observable outcome definition, success/failure/unknown states, deadline, allowed Action definitions and parameter bounds, current delegation, evidence/freshness requirements, money/resource/token/time budgets, escalation conditions, stop rules and reporting preference.

A mandate such as “acompanhe esta encomenda até a entrega; prepare alternativas e me consulte antes de gastar” combines order/delivery Watches, read-only scenarios and proposal-only actions. It does not grant blanket provider access. A goal with no observable completion basis explicitly remains unverified rather than being marked complete after an agent performs some tasks.

## Lifecycle

`Draft → Active → WaitingEvidence/WaitingDecision/Running → Achieved | Failed | Expired | Stopped`.

`Suspended` covers lost authority, unavailable critical sources, budget exhaustion or an incompatible release. Operational retries cannot move a suspended mandate back to active without fresh eligibility. The mandate history records each policy-bound transition and outcome evidence.

A simple released state-machine interpreter runs jobs triggered by semantic events/timers. PostgreSQL owns state. Restate executes only the resulting external effects. Do not add Temporal, Rivet or a second durable workflow history simply to represent a sequence of existing Watches/Cases. A future runtime adapter must preserve the same canonical state and recovery tests.

## Outcome vs activity

An email sent is activity. A recipient's confirmed acceptance may be evidence toward an outcome. The product distinguishes tasks attempted, actions committed, effects observed and goal progress. Every reported completion cites the declared completion predicate and evidence. A reply saying “thanks” does not imply a supplier accepted a new delivery date unless the domain policy supports that interpretation.

For broad goals, the agent can propose a decomposition, but each sub-mandate inherits stricter or equal scope, budget and deadline. It cannot make the goal more achievable by weakening success conditions without an explicit approved revision.

## Release changes

A Watch checkpoint can migrate only through a declared semantic compatibility transform. A changed metric or resolved identity can require reevaluation from a new basis. Mandates using a changed Action/goal definition pause or require reauthorization according to the activation impact plan. Historical outcome evidence remains tied to its old meaning.

## Proof

Test duplicate semantic events, high-rate noise, source staleness, quiet-hour escalation, notice revocation during delay, budget exhaustion, release changes mid-mandate, unverifiable success, unreachable user, stop after provider dispatch and repeated agent decomposition trying to exceed authority.
