# Security and operations

## Threat model

Treat users, source documents, connector payloads, model outputs, installed artifacts and provider callbacks as potentially hostile. Trusted code can be compromised or wrong. Primary assets are domain authority, source credentials, private evidence, identity/session assertions, release-signing keys, money/action budgets and audit integrity.

| Threat | Boundary and required evidence |
|---|---|
| Prompt injection in retrieved text | Content cannot add tools/grants; exact semantic call validation and adversarial source journeys. |
| Cross-World or hidden-field leak | Current scoped query, RLS, Cedar exact disclosure, perspective handling and output/metadata tests. |
| Agent self-escalation | Current-policy change approval, signer separation, narrowed leases and no arbitrary authority execution. |
| Malicious connector/artifact | Isolated runtime, external egress broker, no metadata/ambient credentials, resource and SSRF tests. |
| Duplicate/forged webhooks | Provider authenticity, stable ingress keys, replay window and durable admission. |
| Stale approval or lost external reply | Dependency/predicate guards, stable effect ID and explicit Unknown reconciliation. |
| Compromised worker/zombie | Narrow role and fenced leases; no authority mutation from progress role. |
| Supply-chain replacement | Signed artifact digest, SBOM, dependency lock, provenance and emergency recall. |
| Operator misuse | Named workload identity, just-in-time support grants, two-person sensitive elevation and immutable access audit. |
| Resource abuse | Per-World quotas, query bounds, recursion/fanout limits, fair queueing, upload limits and billing guards. |

## Cryptographic and network baseline

TLS for external/internal transport; short-lived service identities bind audience and purpose. Store keys in managed KMS/secret vault, never runtime release JSON, chat, logs or model context. Use envelope encryption for evidence; institutional profiles can isolate keys per World/account. Digest integrity does not provide confidentiality. Key rotation updates wrapping metadata while preserving content identity where safe; key loss is a recoverability event, not a content correction.

Webhook ingress validates raw bytes before normalization. Browser endpoints use secure cookies/CSRF protection where appropriate, CSP, explicit CORS and rate limits. OAuth flows bind state/PKCE and validated redirect origins. SSRF controls cover DNS rebinding, redirects, private/link-local/metadata destinations and credential forwarding. Signed URLs have minimal lifetime and still cannot revoke an already downloaded copy.

Isolated apps have a separate origin, strict bridge schema and host-rendered approval surfaces. Rich source HTML and file previews are sanitized or rendered in isolated viewers; attachments are size/MIME/magic checked and scanned/quarantined before evidence admission. OCR is optional extraction with provenance, not automatically trusted text.

## Audit and observability

Semantic receipts are append-only records with actor, purpose, release, basis, intent, effect references and decision outcome. Operations logs are separate, redacted and retention-limited. Do not log hidden model reasoning, credentials, full sensitive prompts or provider payloads by default. Correlation IDs connect ingress, turn, Frame, Case, receipt and effect without requiring plaintext data in traces.

OpenTelemetry instruments queue age, source freshness, ACL freshness, unresolved high-impact conflicts, quality, query budgets, authorization denials, stale Cases, external Unknowns, release preparation backlog and deletion obligations. Dashboards must not become a side-channel to unauthorized data; tenant labels and examples are access-controlled.

## Operational runbooks

**Source or rights outage:** mark basis stale, stop affected consequential actions at contract threshold, preserve visible last-known date, reconcile checkpoints on return. Do not turn missing data into zero.

**Effect ambiguity:** suspend unsafe retries, retain reservation, query provider by stable reference, request authorized human reconciliation when necessary, append Settlement with evidence.

**Wrong rule release:** emergency deny impacted action capability; freeze affected reinterpretation/Notice delivery if necessary; prepare a forward repair; invalidate affected Cases; do not rewrite old receipts.

**Database recovery:** restore to isolated recovery environment; verify domain versions, receipt/outbox linkage, evidence pins and security revision; reconcile escaped provider effects before enabling dispatch. Mark data-loss window honestly. Never replay an entire old outbox blindly after PITR.

**Credential compromise:** revoke source/effect leases, rotate secrets, suppress queued disclosure, find derived outputs and provider calls affected, preserve incident evidence under lawful retention and notify under applicable process.

**Cell partition:** retain a single fenced authority epoch, fail closed promotion, drain source attempts and reconcile before move.

**Model regression:** disable model profile; restore an admitted alternative with permitted data routing; replay redacted evaluation corpus, not production side effects.

## Production admission

Require external security review proportional to risk, backup restoration, incident simulation, provider contract validation, license/residency approval and an accountable on-call owner. Consumer, clinical, payments and enterprise profiles have distinct gates. The design does not confer LGPD compliance, security certification, financial licensing or permission to process sensitive health data. [S28, S32]
