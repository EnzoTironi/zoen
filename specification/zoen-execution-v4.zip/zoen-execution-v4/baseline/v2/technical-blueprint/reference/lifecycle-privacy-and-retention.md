# Lifecycle, privacy, retention and deletion

## Decision

Preserve disagreement without preserving every byte forever. Immutability means historical records are not silently edited while retained; it does not override lawful deletion, license expiry, contractual retention or security response. Brazil's LGPD is a primary legal reference, not a compliance claim for this unimplemented design. Exact controller/processor roles, lawful basis, sensitive-data conditions, notices and obligations require legal review. [S28]

## Data lifecycle contract

Each admitted artifact/claim/dataset carries classification, source rights, lawful purpose, owner/steward, residence, retention class, permitted model/destination profiles, legal-hold state and deletion lineage. The contract attaches before data becomes searchable or available to an agent. Unknown rights mean restricted/quarantined, not public.

Source inventory separates discoverable from authorized and connected data. “All company data” means a governed coverage ambition, not scraping employees' personal accounts, bypassing source permissions or copying prohibited licensed feeds. Coverage denominator may be unknown; report that rather than claiming 100% completeness.

## Correction versus erasure

Ordinary factual correction appends a competing/retracting claim and recomputes interpretations. Erasure is a governed lifecycle operation that removes or cryptographically renders inaccessible the retained content when required. A minimal receipt can persist only to the extent legally permitted and must not preserve the erased personal data through an identifier, hash, excerpt or embedding. A hash may still be identifying in context.

`DeletionCase` records scoped targets, basis, hold conflicts, derivation graph, destinations and evidence of completion. It expands to raw files, claims, interpreted projections, search/embedding indexes, caches, staged generations, dataset snapshots, model/provider stores under contract and export obligations. Inability to delete a third-party copy is reported, not counted as completed.

## Snapshots and backups

Iceberg snapshot expiry and object GC respect active legal-hold, Case/evaluation and retained-history pins. Legal erasure may deliberately break historical content replay; retain a permitted tombstone with reason rather than reconstruct prohibited bytes. Snapshot references do not promise perpetual availability.

Backups have declared retention and isolated restore access. Deletion tombstones/obligations are replayed before restoring user access; expired/revoked rights are not resurrected from old backups. Disaster recovery has a tested post-restore suppression phase. Immutable backups and legal erasure may conflict; choose a documented compliant retention/key policy before production, not a universal “crypto-shredding solves law” assertion.

## Subjects and collaboration

A caregiver invitation is not automatic guardianship or power of attorney. Health/child/sensitive profiles require appropriate authorization and user-facing limits. Employee/source identity may differ from Zoen account identity; access requests must resolve the correct subject without leaking other people's records. Consent for WhatsApp messaging is not consent for unrelated processing or broad organizational data access.

A shared conversation uses an explicit audience/purpose and retention policy. Revocation stops future access; it cannot remove content already seen or saved by participants. Sharing a source into another World requires permitted export and fresh admission, not automatic policy union.

## Completion evidence

Deletion tests seed identifiable data across raw evidence, interpretation, vector projections, staged release generations, caches and restored backups. The test asserts absence from permitted APIs and physical deletion queues according to the declared schedule. A delete flag in one table is not sufficient proof.
