# Governed data flows and live observations

## Decision

Data flows are released definitions with typed inputs, transformations, rights propagation and publication gates. They do not create a second path for truth. Batch, incremental, CDC, streaming and virtual sources share SourceBinding/admission contracts but retain their different consistency and replay semantics.

## Flow grammar

`DataFlowDefinition` declares input bindings/snapshot requirements, DAG nodes, schema versions, transformation implementation (bounded IR or signed isolated artifact), partitioning, event-time/watermark policy, quality checks, output dataset/object mappings, schedule/trigger, budget and owner. Every output records lineage to exact inputs and transformation digest.

Quality gates are `Pass | Warn | Fail | Unknown`. Unknown is never silently treated as pass for required checks. Expectations include uniqueness in scope, referential coverage, reconciliation balances, schema compatibility, freshness, completeness and unit/currency constraints. Failed partitions can be quarantined without presenting a partial dataset as complete; publication identifies omitted partitions and downstream restrictions.

## Incremental and CDC correctness

A provider cursor is bound to its source, schema and lease, not a universal transaction offset. Initial snapshot plus CDC catch-up requires a provider-supported consistent boundary or an explicitly labeled gap risk. Deleted records/tombstones are captured and propagated; absence from one page is not deletion. Cursor reset triggers re-snapshot/reconciliation, not silent skip.

Idempotent admission keys include source binding, external record/event identity and revision when available. Sources without stable IDs require an explicit conservative dedup heuristic with limitations; content hashes alone cannot distinguish two legitimate identical events. Checkpoint advancement follows durable capture/admission semantics and never outruns committed evidence.

## Virtual/federated sources

A virtual query records source version/time, request plan, authorization and completeness. If no reproducible source snapshot exists, the Frame is labeled non-replayable/transient. A consequential Action captures and admits the exact required values and evidence first. A live API response is not magically a durable World fact.

## Live plane

`LiveObservationEnvelope` carries provider/source, subject/field, sequence/event ID when available, event/acquisition time, entitlement, validity, quality and payload reference. The live plane supports conflated latest-value views and explicitly unconflated feeds; consumers choose and see the contract. Sequence gaps, reconnect windows, provider corrections and stale leases are visible.

Raw ticks do not each mutate WorldHead or wake Eve. Released detectors process bounded windows and emit semantic deltas; a Watch evaluates only admitted/material changes. High-throughput replay uses partitioned data and checkpoints, not millions of conversational turns.

`CaptureObservation` verifies rights, source envelope, freshness and admissibility, persists exact evidence, and returns a `CapturedObservationRef` bound to a cut. Only this pinned reference can support a consequential Case. Later quote movement or entitlement change can invalidate the Case. A live chart may continue displaying newer data separately with its live label.

## Publications

Dataset runs stage immutable objects/snapshots; checks and retention pins precede the authoritative publication transaction. Publication can atomically admit a coherent set of snapshot references inside one World. A source publishing in another cell has an independent cut. Compaction preserves logical provenance and required historical snapshots; it cannot rewrite the evidentiary basis of an old retained Frame.

## Compute growth

DuckDB is the initial bounded engine. A distributed engine can implement the same `DatasetQueryPort` once it proves authorization before aggregation, exact snapshot inputs, cancellation, scan budgets, lineage and output checks. GPU/model training outputs are signed model artifacts with evaluation and rights, not new kernel privileges. [S14, S15]
