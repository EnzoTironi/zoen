# Ambition audit

## Result

The design provides explicit extension contracts for the requested consumer/prosumer/institutional experience, source disagreement, runtime variation, analytical depth and accountable agency. This is a structured design review, not a proof that every future domain or workload is already accommodated.

## Hardest remaining risks

**Question burden:** a reconciliation engine can become an endless questionnaire. Pilot with attention budgets, impact prioritization and “unknown” responses; measure user effort and reversal rates.

**Ontology authoring burden:** generic expressiveness can force ordinary users to become database designers. Ship complete domain journeys/packs and progressive suggestions; test installation/correction without semantic vocabulary.

**Authority query complexity:** arbitrary fine-grained policies and large analytics may be expensive. Restricted queryable profiles, exact disclosure and explicit unsupported-plan errors are safer than silent security weakening.

**Turn machine ownership:** removing a mandatory framework removes coupling but creates implementation responsibility for recovery, stream state and provider retries. The real kill/replay suite is a release blocker.

**Dataset publication/retention:** a catalog and PG are not one transaction. Pin-before-publish, orphan handling, snapshot exactness and GC/deletion races need actual component proof before dense production use.

**Institutional scale:** domain counters avoid unnecessary World-wide serialization but hot business aggregates still serialize. Benchmark real workloads; do not hide single-primary constraints under the word “cell.”

**Commercial distribution:** WhatsApp policy/cost, licensed datasets, provider APIs, clinical/financial restrictions and enterprise procurement can invalidate an otherwise sound technical plan. Owners and gates are explicit in the execution sequence.

## Elegance test

A feature should reuse definitions, evidence/claims, interpretation, Frames, Cases/receipts and leased effects. A new subsystem is justified by a distinct consistency or trust boundary, not a fashionable library. Every capability must have a visible user outcome, an owner, a released contract, an execution slice and a failure test. The machine-readable matrix enforces the last four structurally; real user testing must establish the first.

Reject designs that achieve apparent simplicity by confusing assertion with fact, choice with permission, attempt with settlement, source discovery with authorized access or a model's confidence with calibrated truth.
