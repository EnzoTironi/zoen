# Programmable compute, skills and isolated artifacts

## Decision

Keep trusted interpretation small and make extensions powerful outside it. Runtime-installed skills are governed behavioral data. Custom code is a signed executable artifact in an isolated runner. Calling executable bytes “configuration” does not make them safe or non-code.

## SkillDefinition

A skill packages purpose, instructions, domain symbols, input/output schemas, retrieval plan, allowed semantic capabilities, optional bounded workflow, requested permissions, model constraints, evaluations and presentation hints. It can be authored in chat or Studio and versioned through the same DefinitionChange protocol.

Instructions cannot grant rights, turn read tools into write tools or override approvals. Installing a skill records both what it requests and what the installation actually grants. A missing permission produces a clear capability limitation. Skill updates with expanded requests require new approval; an old signature is not continuing consent.

## Artifact envelope

An Executor/Connector/MiniApp artifact declares content digest, source/build provenance, entrypoint, runtime/ABI, dependency lock/SBOM, signature/issuer, requested capabilities, allowed source/destination classes, input/output schemas, resource limits, deterministic/replay profile, evaluation results, retention and revocation identifiers.

A signature proves origin/integrity, not benign behavior. Untrusted artifacts cannot use authority credentials, database sockets, host filesystem mounts, Docker sockets, metadata services or unrestricted network. They see only a bounded input bundle and a capability bridge.

## Execution profiles

**Pure analysis:** read-only immutable inputs, no egress, explicit clock/random seed only when declared, CPU/memory/time/output limits. It returns an AnalysisArtifact with lineage, code/model versions and uncertainty. It cannot publish results as fact or invoke an Action directly.

**Connector:** provider-specific acquisition/effects through approved egress and short credential leases. It returns SourceCapture or provider observations. Ontology validates/adopts them separately.

**Application:** isolated browser origin/iframe with restrictive CSP and host-mediated requests. It receives current authorized views; it never gets raw World tokens or provider secrets.

**Agent:** ModelPort and a narrowed semantic tool set, with a bounded run/mandate. The agent is not an unrestricted shell process.

Initially use isolated OCI execution with a reviewed microVM or gVisor-grade host profile. gVisor is a possible isolation mechanism, not complete network/resource policy [S32]. Enforce outer cgroup/resource limits, explicit network denial and filesystem mounts. Host compatibility, startup overhead and adversarial containment are activation gates. WASI can later serve pure deterministic functions; it is not required to launch.

## Capability and secret brokering

A lease binds artifact digest, invocation, principal, World/realm, operation, resource/account, purpose, egress host/path class, expiry, budget and revocation generation. The broker injects provider credentials at the last authorized boundary where possible; a general script receives opaque handles, not a long-lived token.

Validate DNS resolution, redirects, IP ranges, TLS identity and endpoint ownership. Deny loopback, link-local, metadata and private-network access unless an explicitly isolated enterprise connector profile permits that exact destination. Application-level URL validation alone does not constrain arbitrary socket code; enforce the policy in the runner's network boundary.

Return values and logs are tainted output: schema validation, size limits, secret redaction and evidence attribution apply. A connector may lie about what it observed, so higher-assurance sources need verifiable provider evidence and reconciliation. The artifact cannot sign its own admission receipt.

## Runtime build and installation

A user/agent proposes source or a connector template. Build in a separate builder with pinned dependencies, no production secrets and controlled package access. Produce immutable artifact/SBOM/provenance, scan and evaluate against synthetic and permitted sandbox data, then approve installation/binding under existing policy. Core authority does not restart for each installation.

Repository URLs or package names without a digest are not executable artifact identity. Do not run `npm install` in the authority process. Artifact builders and runners are distinct capabilities: a compiler toolchain has a larger filesystem/network surface than a production invocation.

## Results and publication

An analysis may be nondeterministic; record that and its inputs. Reproducing the exact bytes may be impossible with an external model, but the admitted result and its provenance remain immutable while retained. A deterministic declaration requires a controlled environment and test evidence, not just a seed field.

Publishing output as a DatasetVersion/claim or applying a recommended action uses the normal governance path. A generated mini-app shares the same authorization and action protocol as hand-authored UI. No extension gets a parallel persistent truth store; local app state is presentation or explicitly governed domain state.

## Proof

Malicious package import, SSRF/redirect/DNS rebinding, secret echo, fork bomb, resource exhaustion, cross-tenant file access, output-schema abuse, revoked artifact, replayed lease, no-sandbox provider and changed executable digest all have required denial/recovery tests. Export/replay and operational cost are evaluated before enabling a marketplace installation class.
