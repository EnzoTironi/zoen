# Capacity, economics and proposed SLOs

## Status

Every number below is a **proposed acceptance target or test workload**, not a measured result, service guarantee or current production capability. Recalibrate after S0/S1 measurements and contractual review. Cost is measured per useful outcome, not only per token.

## Initial service objectives

| Operation | Proposed objective | Exclusions / required reporting |
|---|---|---|
| Durable channel ingress | p95 < 500 ms inside Zoen | Provider transit excluded; report verification and durable queue time. |
| Authorized bounded sparse Frame | p95 < 750 ms at admitted workload | No LLM or cold dense scan; log query class and row budget. |
| First useful conversational acknowledgement | p95 < 3 s | Clearly distinguish acknowledgement from final answer. |
| Typical grounded answer | p95 < 15 s | Model/provider delays separate; disclose slower analysis asynchronously only through an installed job/notification feature. |
| Local guarded Action commit | p95 < 750 ms after complete approval | External settlement excluded; serialization retry rate reported. |
| Material Watch evaluation | p95 < 60 s after source admission | Source synchronization delay separately visible. |
| Revocation inside a cell | No new result after completed local revocation check | No guarantee of erasing already delivered copies; source ACL lag separately bounded. |
| Hosted pilot availability | Target 99.5% monthly | Not contractual; dependency budgets and planned maintenance visible. |
| Admitted institutional profile | Target 99.9% monthly, RPO ≤ 5 min, RTO ≤ 60 min | Must pass failover/restore drills and contract review before advertised. |

Avoid a universal SLO across chat, bulk ingestion and institutional market data. Each SourceBinding declares expected freshness, maximum tolerated stale time, checkpoint coverage and provider constraints. A 60-second Watch target is not a market-feed latency guarantee. High-frequency trading is not claimed.

## Workload suite

Benchmark at least three envelopes: 1,000 active personal Worlds with sparse histories; 100 small businesses with concurrent bookings/inventory and file ingestion; one enterprise cell with 1 million subjects, 20 million claims and partitioned bulk datasets. These are synthetic **test definitions**, not supported limits. Include skew: one hot aggregate, large ACL groups, high conflict rates, mass revocation, source outages, million-row correction impacts and long-tail attachments.

Record p50/p95/p99, throughput, queue age, DB CPU/I/O/locks, serialization conflicts, heap/external native memory, object requests, model tokens, egress and per-World fairness. A test must state data distribution, hardware, region, exact versions, policy complexity and cache warmth. A “rows per second” number without these is not an admission decision.

## Budgets

`ResourceBudget` reserves model tokens/currency, CPU seconds, memory, scan bytes, storage, connector calls, messages and external spend separately. Budget values use decimal currency and explicit billing windows. Authority performs consequential spend reservations; inference/tool workers spend narrowly leased sub-budgets and reconcile usage. Child agents share the parent's ceiling rather than multiplying it.

User-facing plans expose understandable limits and behavior on exhaustion: reduce frequency, request approval, defer optional work or stop. Never silently drop a consequential Notice or substitute an unapproved cheaper model that changes data residence. Free/consumer tiers do not justify weaker tenant isolation.

Question prioritization also has an attention budget. Measure unanswered questions, repeated clarification, false alerts, correction reversals and outcomes completed without user rework. An assistant that increases administrative work fails even if its token cost is low.

## Scale triggers

Extract a queue only when PostgreSQL jobs measurably harm authority latency despite indexing, retention, quotas and worker shaping. Add distributed analytics when bounded DuckDB cannot meet an admitted query workload; preserve the same snapshot/disclosure contract. Add specialized search after authorized candidate retrieval proves inadequate. Split cells when workload/residency/fault isolation requires it; do not shard an inseparable transaction by accident.

Capacity admission is a release artifact: workload definition, observed results, headroom, failure behavior, cost and operating owner. Lower confidence produces lower supported limits, not optimistic marketing.
