# Deployment cells, scale and federation

## Decision

The same semantic grammar supports all audiences. Physical tenancy, assurance, operational isolation and topology vary. A World has one writable authority cell at a fenced epoch; an enterprise can contain many Worlds/cells. Do not promise unlimited throughput in one PostgreSQL primary or a global transaction spanning independent organizations.

## Profiles

| Profile | Topology | Admission |
|---|---|---|
| Development | One machine, disposable services and evaluation sinks | Never exposed as production isolation or durability proof. |
| Personal/prosumer hosted | Shared regional cells; logical World isolation, fair-use quotas, encrypted stores | Cross-tenant/rights/restore/load suite; no custom runner shares trusted credentials. |
| Dedicated enterprise | Dedicated authority database/cell and object namespace; SSO/SCIM, private connectors, audit export | Residence, identity lifecycle, failover, incident and cost gates. |
| Regulated/large enterprise | Multiple cells by legal entity, region or domain; private network and dedicated runner pools | Federation contracts, per-region keys, fleet policy, qualified operating team. |
| Self-hosted/edge | Same OCI/contracts on tested equivalent infrastructure | Support matrix, update/rollback, recovery, source leases and disconnected semantics. |

A company is a domain subject; it is not automatically a tenancy boundary. A World is a governed collaboration and policy boundary. A household may share a World; a multinational may deliberately separate payroll, jurisdictions and subsidiaries. A user can have access to multiple Worlds without silently merging their data or policies.

## Directory and routing

A small control-plane directory maps `(worldId, realm)` to cell, epoch and allowed region. It contains no domain evidence or grants. Every signed internal request binds destination, realm, epoch, operation, purpose, principal and deadline. Authority validates its locally installed epoch, not just directory routing. A stale router cannot reopen writes on a retired cell.

Cell-to-cell traffic uses authenticated service identities plus principal-bound grants, never a global superuser token. A control-plane outage may preserve already-routed reads/writes within bounded lease policy; moving authority or issuing new routes fails closed.

## Move protocol

1. Provision destination and install approved runtime/release with equivalent residency/keys.
2. Copy retained authoritative data and evidence references, then replay committed envelopes into a non-authoritative destination generation.
3. Validate counts, hashes, rights, open Cases/Watches, retained snapshot pins and pending effects.
4. Fence source writes and attempts, drain or explicitly transfer pending jobs, record final cut.
5. Advance the authority epoch through a mutually exclusive promotion record; persist rejection of old epochs at both cells before routing new writes.
6. Admit destination, update routing, run reconciliation, keep old source read-only until retention cleanup.

No simultaneous live writers or automatic promotion merely because a health check timed out. Recovery from an uncertain promotion requires the fencing coordinator's durable record; a partition must sacrifice availability rather than create split-brain authority. In-flight provider requests may already have escaped the source: preserve their stable effect IDs and reconcile before any destination retry.

## Federated reads and actions

`FederatedFrame` pins a vector of independent component cuts, release digests, rights and freshness. It labels skew/missing components and never pretends to be a single instantaneous global snapshot. Remote derived values keep source restrictions and licenses. A receiving World may admit a signed export as evidence, not as an unconditional local truth/grant.

Cross-World actions use a coordination Case with independent local approvals/receipts and explicit pending/partial/failed outcomes. Compensation is a new action. Global inventory, money or quotas cannot be treated as atomically reserved unless a single owning World manages that resource. Real-time global optimization may calculate a scenario, but executing it still follows local guarded decisions.

## Offline edge

Offline work uses a distinct child/evaluation-like authority scope with explicit leased rights, expiry, local receipts and reconciliation on reconnect. It does not become a disconnected second writable copy of the same live World. Non-reversible external actions are disabled unless an explicitly partitioned resource/authority contract permits them. Clock uncertainty, lease expiry and stale source state are visible.

## Capacity boundaries

Per-World domain versioning removes one unnecessary global data-head lock, not every bottleneck. Shared business aggregates, serializable conflicts, wide predicates and a single primary still constrain throughput. Separate independent Worlds/cells only when business semantics allow it. A Fortune 500 deployment is admitted by real workload and operating evidence, not by its employee count or by a “multi-tenant” flag.
