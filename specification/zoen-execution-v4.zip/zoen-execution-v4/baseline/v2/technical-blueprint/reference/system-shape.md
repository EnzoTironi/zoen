# System shape

## Decision

Three product owners, three physical planes, one authority protocol. A module boundary is not a service mandate. A process boundary is not a security guarantee. An untrusted runtime never shares the authority process or its credentials.

## Ownership

| Owner | Owns | Does not own |
|---|---|---|
| Door | Account/session/workload identity, assurance, channel-binding proof | Business membership, evidence interpretation, domain authorization |
| Eve | Input admission, interaction journal, turn lifecycle, Focus, wording, attention and delivery | Accepted knowledge, policy, Action commitment or external settlement |
| Ontology | Released meanings, rights, stable subjects, evidence admission, interpretations, Cases, Watches, Mandates, receipts, published datasets | Model-internal reasoning, provider outcomes or conversation replay |
| Connector/compute plane | Acquisition, parsing, isolated computation and provider requests under leases | World head, claims admission, permission grants, canonical decisions |
| Data engine/catalog | Physical files, snapshots, query execution and maintenance | Whether a snapshot is admitted into the World or who may see semantic outputs |

The connector and data rows describe infrastructure owners inside Ontology's execution boundary, not fourth and fifth user-facing products.

## Code and runtime map

```text
channel/web/API/CLI/MCP
          │
       edge + Door ─────────── Ontology application ports
          │                          │
     Eve turn engine             semantic kernel
          │                          │
    authorized tools             authority repository
          │                          │
    model gateway                 PostgreSQL
                                     │
                                  outbox
                     ┌───────────────┼────────────────┐
               knowledge jobs    effect dispatch    notifications
                     │               │                  │
        evidence / dense / index   Restate          Eve attention
                     │               │                  │
            isolated runners   effect connector     channel delivery
```

Ontology application ports are the only callers allowed to form an AuthorityCommit. Parsers cannot write claims directly. The model gateway cannot see a secret merely because a connector requires it. Delivery callbacks create attributed observations and progress, not automatic claims of user consent.

## Initial physical profile

Use one codebase and one signed application image with independently invokable `edge`, `eve-worker`, `authority-worker` and `effect-handler` commands. A development Compose profile may colocate them. A pilot uses managed PostgreSQL and object storage, and may colocate trusted edge/Eve/authority processes only while the documented threat model allows it. This is not hostile-code isolation or high availability.

The first custom executable connector uses a separate runner machine/pool with enforced egress and secret brokering. It is never added as a child process of a trusted pilot container. Enterprise deployment separates Eve, authority, connectors and analytical compute into independently permissioned workloads, with HA and regional controls. The protocol does not change with that topology.

## Kernel composition

The kernel comprises a bounded definition interpreter, scalar/type and expression semantics, identity/claim invariants, dependency construction, policy-bound read and Action planning, and release validation. It has no HTTP client, model SDK, clock access or database connection. Application services provide explicit clock/basis inputs and ports. Physical adapters handle SQL, files, provider APIs and model calls.

Do not create a generic event-sourced application framework. PostgreSQL owns authoritative state plus append-only evidence/decision history and meaningful commit envelopes. Materialized projections are rebuildable. Operational jobs have a deliberately smaller transition protocol than business decisions.

## Port contracts

`DoorPort` proves presence; `PolicyPort` decides admission/disclosure; `AuthorityStore` executes a typed transaction plan; `EvidenceStore` reads immutable admitted references; `DatasetPort` scans explicit published snapshots; `ModelPort` returns untrusted proposals; `ConnectorPort` obtains evidence or attempts effects; `EveStore` persists interaction; `ChannelPort` returns provider delivery observations; `ClockPort` supplies an attributed clock sample. Ports expose domain types, not third-party clients.

Every port specifies deadline, cancellation, idempotency scope, output size, allowed errors, provenance and observability. Cancellation is not rollback of an already committed effect. A cancelled model attempt may incur a bill; it cannot settle a second turn or bypass an Action.

## Failure containment

An LLM outage does not prevent a person from inspecting a Frame or approving a prepared Action through web/API. A dense-engine outage does not invent empty datasets. An evidence-store outage can preserve an existing receipt while reporting evidence temporarily unavailable. A rights-service outage fails closed for reads requiring new proof. An Eve outage preserves accepted input and does not hold an open authority transaction.

A kill switch can stop effect dispatch independently of ingestion. A source can be quarantined independently of the World. A broken pack can suspend affected capabilities without deleting their history. A recovery operator cannot reactivate a revoked grant merely by restoring a database backup.

## Proof

Prove the same released operation and outcome across Eve, REST, CLI and MCP; cross-role SQL denial; source runner inability to reach authority credentials; model output inability to mint a receipt; independent outage behavior; and identical semantics when moving from colocated development to isolated production workloads.
