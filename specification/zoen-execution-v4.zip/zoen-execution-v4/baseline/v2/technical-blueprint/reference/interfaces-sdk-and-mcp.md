# Interfaces, SDK and MCP

## Decision

One SurfaceManifest projects released semantics into native REST, CLI, MCP, TypeScript SDK and UI tools. The projection is not lowest-common-denominator transport: each surface can render differently, while action identity, argument meaning, rights, cut, consequences and result algebra remain identical.

## SurfaceManifest

The manifest contains stable symbol/operation IDs, schemas, version/digest, permitted discovery descriptors, verbs, effect/read classifications, required assurance, compatibility ranges, available views, error contracts, pagination/streaming capabilities and deprecation/removal rules. Discovery itself is filtered by current authority; a hidden type or field is not revealed merely through an SDK/schema endpoint.

Public verbs are domain-native. The internal action planner is generic; the product is not a raw CRUD/SQL/invoke API. Example generated operations can include `household.bill.inspect`, `bakery.order.confirmDeposit`, `clinic.appointment.reschedule` and `enterprise.receivable.resolvePayment`.

## API shape

REST JSON is the initial universal contract, with OpenAPI and JSON Schema artifacts. Commands use an explicit operation ID/idempotency key, expected contract digest, principal/purpose context and relevant Case reference. Mutations never occur through GET. Browsers use authenticated sessions plus CSRF protection; machine clients use audience-bound delegated credentials.

Transport status and domain outcome are separate. A completed HTTP request can return a `Stale` Case or `Unknown` external settlement. Typed domain outcomes include Unauthorized/Unavailable/ContractChanged/BudgetExceeded/Ambiguous/Stale/ValidationFailed/Committed/Pending/Unknown. Error details are redacted by disclosure policy.

Pagination cursors bind query digest, cut, audience/purpose and expiry; they cannot become a way to resume under revoked rights. Large exports are governed jobs with rights, retention and resource controls, not unlimited API pagination loops.

## CLI

CLI discovers the active permitted grammar or uses a pinned contract. JSON goes to stdout, human diagnostics to stderr. `--dry-run` produces a proposal/evaluation only, not a false simulation of provider success. Noninteractive scripts can inspect, propose and submit an already appropriate approval under their own delegation; they cannot impersonate a human by sending an approval string.

Login uses a secure browser/device flow. Do not put passwords, bearer tokens or provider keys in command-line arguments or shell history. CLI process identity is distinct from the user's World membership. An offline cached manifest supports help, not offline authority.

## SDK

The first generated SDK is TypeScript, using stable schema/operation IDs and runtime validation. Typed object sets expose declared operations, not a mutable in-memory ORM whose save bypasses governance. Python and Java clients can be generated from the same semantic/OpenAPI contract when required; they are transport projections, not alternate kernel implementations.

Changing labels does not necessarily break a client. Changing semantics, effects, required fields or approval policy can. Clients send contract digests and receive an explicit compatibility result. Runtime-defined capabilities are immediately discoverable through dynamic clients; static clients need regeneration for new types. Do not promise that a user's installed binary spontaneously acquires new compile-time types.

## MCP

Use the currently adopted stable MCP revision through an adapter and pin it in the execution manifest. The official latest specification resolved to `2026-07-28` during this review [S19]. Support the explicitly tested compatibility set, not “all MCP”. Streamable HTTP is the network profile; a local CLI adapter may expose stdio without creating an unauthenticated network service.

Resources return authorized Frames/evidence views; tools expose domain actions/inspect operations. Server annotations such as readOnlyHint are descriptive only. Inbound client tokens are validated for the Zoen audience; remote server tokens are never blindly passed through. Dynamic remote capability changes trigger schema/effect review. MCP Tasks/long-running extensions are enabled only when their contract is explicitly implemented; regular Case/job handles remain valid fallback.

MCP Apps is an optional UI projection with sandboxed resources/host bridge and text fallback [S20]. A client that lacks Apps support still receives the same domain result. A rendered app cannot bypass the ordinary approval or policy path.

## Streaming and subscriptions

SSE carries visible turn deltas, Notice updates and authorized change subscriptions. Event IDs are scoped to stream/generation and support replay only within retained authorized history. Reconnect reauthorizes; permission loss terminates without leaking hidden tombstones. Backpressure and bounded replay windows produce explicit reset/resnapshot outcomes.

Use WebSocket only for a demonstrated bidirectional low-latency requirement. A live-data feed subscription and a semantic World change subscription are different contracts; do not disguise raw ticks as domain events.

## Proof

Compare semantic digests and outcomes across surfaces for the same input/basis; reject hidden discovery and stale SDKs; revoke pagination/SSE; prove CSRF/audience separation; deny remote token passthrough; and preserve action approval in third-party MCP/App hosts.
