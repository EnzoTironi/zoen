# Release engine and bounded definition compiler

## Decision

Use one compiler for the supported semantic language, not one compiler per surface or audience. Input is canonicalizable JSON validated by JSON Schema 2020-12. Output is an immutable content-addressed graph of typed definitions and compiled plans, plus SurfaceManifest and dependency metadata.

Compilation is not execution of arbitrary user JavaScript. Artifacts requiring arbitrary computation run outside authority and return proposals or read-only results.

## Expression profile

The v1 authority expression language permits literals, typed field/input/reference reads, explicit null handling, bounded conditionals, Boolean logic, comparisons over comparable scalars, decimal arithmetic, explicit unit conversion, local string normalization, bounded list operations and allowlisted pure function calls. Queries permit released object sets with filter/project/join/group/aggregate operators under cardinality and cost limits.

No loops without a static bound, unbounded recursion, dynamic import, eval, SQL string, arbitrary URL, filesystem access, clock sampling, random generation, model call or network operation exists in the authority IR. A supplied clock sample, admitted analysis result or captured observation is an explicit input. Decimal overflow, divide-by-zero, incompatible currency, unknown value and execution limit are typed outcomes, not coercions.

Domain Actions compose typed reads, preconditions, claims/links/resolution changes, reservations, approval requirements and declarative EffectIntent construction. Effect templates bind named provider capabilities and typed arguments. They do not contain free-form HTTP requests executable by authority.

## Compiler phases

1. Parse and reject duplicate keys, non-I-JSON values, excessive depth/size and unknown schema versions.
2. Resolve pinned local pack dependencies and namespaces. Remote references cannot trigger network fetch from the compiler.
3. Assign/validate stable symbol identity. A renamed label is not a new semantic ID; incompatible meaning cannot reuse an ID without a supported migration declaration.
4. Typecheck scalar dimensions, cardinalities, null states, effect types, realms, inputs and outputs.
5. Build the dependency graph and reject unsupported cycles and missing capabilities.
6. Validate resource bounds, source/effect rights constraints and trusted operator ABI compatibility.
7. Classify semantic/security/effect diffs and construct migration/reprojection requirements.
8. Emit typed plans, SurfaceManifest, allowed tool definitions, UI descriptors and evaluation-case dependencies.
9. Canonicalize with an RFC 8785-conformant implementation, hash with SHA-256 and sign release envelopes using an approved signing service/key. Secrets and per-user data never enter a reusable release blob.

Canonical JSON is a deterministic representation, not a confidentiality mechanism. Prevent public digest-based presence checks across tenants; artifact IDs exposed to clients are opaque, and content deduplication stays inside an authorized boundary. The canonicalizer rejects unsupported numeric values and is tested against normative vectors [S17].

## Minimal action semantics

An ActionDefinition must declare its read footprint and write/effect kinds. Its planner resolves exact dependencies and conservative predicate fences at proposal time. It returns a Case with an explanation and consequence digest. At commit, the kernel rechecks the dependency guards and applies a typed transaction plan. The storage adapter may compile a bounded query plan to parameterized SQL, but no user SQL string enters that compiler.

An unsupported domain action is not shoehorned into a generic `invoke`. It either composes existing operators, adds a governed isolated analysis/effect artifact, or requires a reviewed kernel extension. Surface verbs remain domain-specific even though the internal planning protocol is shared.

## Test and proof artifacts

`ReleaseProof` binds candidate digest, kernel image digest, evaluation dataset/cut, exercised journeys, semantic diff, capability/effect policy analysis, resource observations and missing attestations. A JSON schema pass alone is never labeled a ReleaseProof.

`PreparedActivation` binds World, expected head, old/new release, ready-through domain cut, source-watermark compatibility, migration/reprojection receipts and the disposition of open work. The final write fence validates these exact dependencies. A statement such as “tested against current data” without a cut is insufficient.

## Upgrade and bootstrap

The kernel contains a small, image-pinned governance grammar for creating Worlds, proposing/activating releases, granting/revoking membership and admitting signed artifacts. A domain release cannot redefine the root verifier or authorize arbitrary grants. Foundation packs are seeded through this grammar and receive a genesis receipt.

Kernel ABI upgrades follow expand/contract only where supported and tested. No indefinite dual-read/dual-write semantic paths. A generation migration is explicit; if a conversion loses meaning, activation requires governed resolution or remains blocked.

## Proof

Compile identical definitions from chat, Studio and CLI to the same digest; demonstrate alias renames vs semantic changes; reject time/random/network calls and unbounded computation; fail an effect/security escalation; bind proof to the actual image; and invalidate preparation when a relevant domain changes.
