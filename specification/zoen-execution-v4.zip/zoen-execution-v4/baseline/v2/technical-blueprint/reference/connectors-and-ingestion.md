# Connectors and ingestion

## Decision

Sources are configured at runtime through governed bindings. Acquisition is separate from semantic mapping and evidence admission. Support existing provider/data platforms rather than rebuilding every protocol, but normalize their outputs through one SourceCapture contract. Provider schemas never become the canonical business ontology by default.

## Acquisition modes

| Mode | Use | Required caveat |
|---|---|---|
| Upload/forward | Receipts, files, spreadsheets, email attachments | Malware/type/size checks; provenance and source authority may be weak |
| Polling API | Paginated business applications | Cursor, rate limits, source revisions, overlap windows and deletion semantics |
| Webhook | Low-latency application changes | Durable admission before acknowledgement; verify signature and replay identity |
| Database snapshot + CDC | Enterprise relational sources | Consistent snapshot/log handoff, schema evolution, resume and retention checks |
| Stream/feed | Sensors, market data, live operational signals | Sequence, gaps, entitlement, conflation and seal semantics |
| Federated/query-in-place | Sources that cannot be copied | Rights, availability and replay limitations explicit; captured basis required for action |

A source can use more than one mode. Reconciliation across modes uses stable source revision and event identity, not arrival order.

## Definitions and bindings

`ConnectorTemplate` declares supported protocols, auth type, credential scopes, acquisition/effect capabilities, endpoint allowlist, cursor/retry contracts, resource bounds, source ACL behavior and provider-specific reconciliation. It is reviewed and versioned.

`SourceBinding` is a World-local instance with template/artifact digest, account/tenant identity, secret reference, selected collections/fields, cadence, mapping release, ACL policy, coverage target, retention and budget. Secrets are never embedded in the template, release, transcript or SDK. Rotating credentials is an operational binding action, not a schema migration.

`SourceMapping` translates source records to typed claims/dataset columns and candidate identity links, retaining originals, null states, units and revisions. Mapping changes generate a new extraction/mapping version and a reprojection plan; old evidence is not rewritten.

## Runtime onboarding

A user asks for an integration. Eve discovers permitted templates, explains requested access and opens an OAuth/secure credential flow on an authentic domain. The host verifies the returned account and scopes; the agent cannot consent for an unrelated person. A minimal test fetch provides a preview with sensitive-field classification, sampled mapping candidates and coverage limits.

The user/steward confirms identity and semantic mappings as needed. The system establishes an initial snapshot/cursor, tests incremental updates and revocation behavior, then activates the binding under the current policy. Unknown provider behavior is exposed as a blocked feature, not hidden behind “connected”.

Read, write and channel capabilities are separate grants. Connecting a source for reading never authorizes writeback. A connector offering effects must declare provider idempotency and reconciliation semantics before that capability can be activated.

## Durable capture and admission

1. Verify caller/provider signature, allowed source binding, payload bounds and realm.
2. Store encrypted immutable bytes or a permitted retained representation; record checksum and provider event identity.
3. Commit `SourceCapture` plus processing outbox atomically. A webhook acknowledgement is sent only after this durable acceptance; it means accepted, not interpreted.
4. Isolated parser/extractor generates proposed records/claims with lineage, schema and model/parser versions.
5. Validate scope, rights, types, source revision and deduplication. Admit eligible claims or a DatasetVersion through AuthorityCommit; quarantine failed/unknown records with reason and owner.
6. Advance the authoritative source admission watermark only for complete admitted ranges. Acquisition and admission cursors are distinct. A skipped poison record remains visible and cannot be silently treated as complete.

Duplicates use `(binding, providerEventId/revision)` where guaranteed. Hash-only deduplication is not enough for two distinct business events with identical bytes. Overlapping fetch windows are expected. A missing event ID requires a declared compound identity strategy and documented residual ambiguity.

## Schema drift and correction

Detect added/removed fields, type changes, changed enum meaning, new currencies and source reset/rekey. Compatible additive drift can remain captured while unrecognized data is quarantined; semantically incompatible drift pauses affected mappings. The source remains inspectable even when semantic admission is blocked.

Source deletion creates a source-scoped retraction/tombstone only when its contract proves deletion. It does not automatically delete independent claims or legally retained evidence. Late revisions replay against source ordering and valid time. Corrections propagate through the knowledge dependency graph and mark affected Cases stale.

Snapshot+CDC connectors declare the snapshot boundary/log position and the sequence required to avoid gaps. Log-retention loss triggers a visible resnapshot/reconciliation state. Unknown completeness never becomes a complete inventory count.

## Custom code and MCP sources

Declarative HTTP/OpenAPI bindings cover a restricted supported request/response/pagination profile. Unsupported auth, custom parsing, browser automation or proprietary protocols require a signed isolated ConnectorArtifact. Build/evaluate/activate it at runtime without modifying authority code. Browser automation has separate credential, terms, audit and fragility gates; it is not the default route around a missing API.

A remote MCP server is untrusted integration input. Tool descriptions, prompts, read-only hints and server-side updates do not grant authority. Pin the discovered capability/schema manifest; reject unexpected changes until review. Calls use audience-bound authorization and approved destinations; no token passthrough to arbitrary hosts. Effectful or unknown-effect tools require an Action/effect wrapper and provider reconciliation, not direct model execution.

## Coverage and operations

Source inventory reports discovered vs approved vs connected vs captured vs admitted vs current coverage, with denominators when known. “All company data connected” is forbidden when the inventory is incomplete. Track cursor lag, ACL lag, poison records, rate-limit budget, schema drift, lost-event risk and cost per admitted useful change. A failed connector does not erase the World.

Proof requires real account authorization, least privilege, duplicate ingress, interrupted pagination, snapshot/CDC handoff, OAuth revocation, source ACL change, malicious attachment, SSRF, provider schema change and lost acknowledgement around every external effect.
