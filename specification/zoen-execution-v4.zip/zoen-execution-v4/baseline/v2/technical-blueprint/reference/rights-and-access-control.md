# Rights, disclosure and authorization

## Decision

Permission is evaluated at every admission, read, derivation, decision, external use and delivery boundary. Door proves identity; Ontology grants World authority. Source permissions, licenses, purposes and residency limits remain attached to their data. A derived answer cannot launder restricted evidence.

Cedar evaluates horizontal admission and disclosure. It is not the business computation engine, a universal SQL-policy compiler, or a source of identity truth. PostgreSQL RLS provides defense in depth for coarse World/partition isolation. Neither replaces current source entitlement checks where the SourceContract requires them.

## Authority model

A `WorldGrant` binds principal, represented actor, delegation chain, World/realm, purpose, operation/resource scope, assurance, audience, validity interval, security revision, budget constraints and revocation reference. It is short-lived and audience-bound. Focus, a conversation ID, a UI link or the model's remembered role carries no grant.

Authorization is an intersection:

```text
current membership and delegation
∩ active World policy
∩ operation/resource scope and purpose
∩ source ACL/entitlement and license
∩ residency/model/destination restrictions
∩ assurance, validity, budget and emergency denies
```

A union of grants must not widen derived-data rights. Some products require combinations of independent permissions, while others can use one lawful evidence path. The derivation records which actual supporting path was used; it cannot borrow the least restrictive labels from unrelated evidence.

## Rights through lineage

A derived result carries a conjunction of the restrictions on its actual dependencies. Permission to read two values independently is not automatically permission to export their join or use them for model training. Derived-data and redistribution rights are separate capabilities. A data license can prohibit a destination or retention even when a human may view the source.

Aggregation does not automatically anonymize data. Declassification is an explicit released operation with disclosure analysis, permitted scope, evidence, approver and receipt. A group-wide metric can be published to a broader audience only through that approved path. The same rules apply to model prompts, embeddings, caches, charts and error explanations.

## The hidden-rival problem

A global interpretation may depend on evidence a caller cannot see. Three safe outcomes exist:

1. Show a published/declassified result that the caller is explicitly permitted to receive, without exposing forbidden lineage.
2. Compute a **view-local interpretation** using only evidence permitted for this caller and mark its perspective and completeness appropriately.
3. Deny or return a generic insufficient-authorized-basis result.

Never say “another confidential source disagrees” to a caller not permitted to know that source exists. Never present a view-local result as the organization's universal authoritative belief. This is the deliberate resolution of the tension between a shared ontology and different visibility boundaries.

## Query planning and prefiltering

The initial policy profile uses membership, explicit resource scopes, classification labels, source ACL membership, purpose and permitted field sets that can be safely compiled to a coarse authorized candidate relation. Exact Cedar authorization is evaluated on candidates before their values enter ranking, aggregation, model context or rendering.

Arbitrary Cedar policies are not automatically translatable to SQL. A policy outside the supported query profile uses a bounded authorized scan or returns a capability/budget error. Filtering an unauthorized top-k result after similarity ranking is not the claimed security model. Initial vector retrieval uses exact scoring over already authorized bounded candidates or security-homogeneous partitions. Approximate mixed-ACL indexes require a separate leakage/recall assessment and are not assumed non-interfering.

Counts, facets, corpus statistics, snippets, timing, explanations and schema discovery can leak existence. Use authorized counts/statistics, constant public error classes where appropriate, rate limits and compartmented caches. Full timing non-interference is not claimed; residual side channels belong in the threat model.

## Source ACL freshness

Each source declares permission-sync mechanism, watermark, maximum tolerated staleness and whether current read-through proof is required. A connector without adequate ACL fidelity is restricted to a smaller explicitly granted corpus; it cannot claim enterprise-wide inherited permissions.

For sensitive decisions or data, expired ACL evidence blocks disclosure until refreshed. Instantaneous revocation in an external system cannot be guaranteed without synchronous provider support. State the maximum exposure window and test it. Local revocation immediately stops new grants; cached Frames are reauthorized. Previously delivered data cannot be recalled from a user's phone.

## Database and workload separation

Authority, Eve interaction, channel operational state and catalog state use separate database roles; enterprise deployments use separate databases/workloads where required. Runtime roles are not owners, superusers or `BYPASSRLS`. Set request context transaction-locally and clear pooled connections. RLS default-deny plus `FORCE ROW LEVEL SECURITY` is applied to protected authority tables; migration ownership is never granted to runtime.

A same-host compromise can cross weak process boundaries. Environment-variable allowlists reduce accidental access but are not a sandbox. Untrusted runners use enforced machine/container isolation, explicit network controls and a credential broker.

## Delegation and high-assurance decisions

A caregiver, employee or agent receives narrow purpose/resource/time delegation. The delegate cannot delegate more than received. Domain approval is separate from a framework's tool-approval UI. Money movement, identity linking, source access expansion, private export and security changes use explicit assurance requirements and step-up where policy requires it.

Pending Cases retain no authority. Every approver contribution and final commit is rechecked. Multi-party conversation participation is not World membership; group delivery must be safe for every intended recipient or be moved into an authorized private channel.

## Proof

Test hidden rivals, row/field/evidence denial, source ACL lag, model-route restrictions, cross-tenant cache poisoning, query facets, group delivery, current revocation of historical Frames, malformed delegation chains and approval under a proposed self-granting policy. RLS and Cedar are documented mechanisms [S12–S13]; end-to-end policy correctness is an implementation gate.
