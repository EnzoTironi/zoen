# Domain packs, extensions and marketplace

## Decision

A reusable pack is a signed graph of versioned definitions, constraints, source mappings, tools, skills, workflows, views, evaluators and optional isolated artifacts. It requests capabilities; it does not grant itself those capabilities. The kernel is domain-neutral, not meaning-free.

## First packs

**Personal/household:** people and relationships, commitments, documents, accounts, bills, tasks and goals. Provide large-text/voice-friendly prompts, shared-device precautions, caregiver delegation and simple escalation. Do not require users to learn “ontology,” “tenant” or “release.”

**Confectioner/prosumer:** customer/order/recipe/ingredient/batch/stock/capacity/supplier/receivable, unit conversions, lead times, expiry, reservations and estimated vs actual margin. Distinguish recipe forecast from physical inventory; sold vs delivered vs paid are different facts.

**Dental practice:** appointments, service plans, provider availability, billing, inventory and restricted patient records. Clinical data is separately classified and licensed/authorized; clinical judgment is not delegated to a general assistant by installing this pack. A receptionist's operational view does not reveal every clinical note.

**Enterprise:** organization/legal entity/location/person/source/system/master data, project/process/assets/contracts/finance, stewardship, data products, entitlements, policy and supervised actions. Domain teams extend and review packages within bounded namespaces; a global ontology team is not required to author every local label.

## Package identity and dependencies

Use publisher identity, namespace, semantic IDs, package version, content digest and dependency lock graph. Exact dependency digests make an installed release reproducible. Installation composes schemas and checks name/meaning conflicts, constraints, rights requests, artifact provenance, migrations, evaluation corpus and removal effects. The same label with incompatible units is a conflict, not automatic deduplication.

Local overlays reference upstream semantic IDs and declare overrides. Upgrades produce semantic/capability diffs and rebase conflicts; they never overwrite local user knowledge or silently grant new network destinations. Deprecated terms remain addressable for retained history. Removal blocks or migrates dependents and parks affected Watches/Cases explicitly.

## Skills and SDKs

A skill is instructions plus typed input/output and allowed semantic operations, triggers, budget, evaluation and artifact references. It is not a secret prompt with unrestricted tools. A user can configure/install a skill in runtime; a new privileged operation still requires a kernel deployment. Generated SDKs expose the installed SurfaceManifest; adding a definition makes dynamic discovery immediate, while static generated types require regeneration/rebuild of the consuming application.

## Trust and distribution

Publisher signing proves origin/integrity, not correctness. Maintain provenance, vulnerability status, evaluation attestations, permission review and revocation/recall. Default third-party artifacts run in evaluation with sinks and no production secrets. Installation and activation require current World authority. A marketplace rating is not permission to handle health data or execute payments.

A commercial marketplace needs billing/tax/refund contracts, publisher terms, support, entitlement enforcement and incident responsibility. These are tracked prerequisites, not implemented by the pack schema. No shared customer data or training corpus is implied by distributing a definition pack.
