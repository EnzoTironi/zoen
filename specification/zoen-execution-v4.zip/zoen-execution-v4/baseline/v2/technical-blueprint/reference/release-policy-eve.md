# Eve, interaction durability and release policy

## Decision

Eve remains the relationship product. Its execution is a small Zoen-owned, PostgreSQL-backed turn machine with AI SDK behind ModelPort. The npm package named `eve`, Nitro and Workflow Postgres are not mandatory platform dependencies in v2. The archived implementation remains an evaluated alternative, not an active second replay owner.

This removes a coupling between file/build-oriented framework configuration and runtime-defined World capabilities. It also transfers durable-turn engineering responsibility to Zoen. The decision is justified by ownership and adaptability, not by an unperformed reliability benchmark. Reconsider the adapter when an upstream runtime demonstrably reduces total complexity while meeting the same contracts.

## One interaction truth

EveStore owns accepted inputs, settled visible messages, turns, model/tool attempts, Focus, attention decisions and delivery observations. There is exactly one authoritative turn state machine, not a journal beside a framework with its own conflicting resumption history.

A connector's durable channel ingress is an accepted-input record with an outbox into that machine. It does not declare that a turn completed. Ontology owns evidence admission if an attachment or message is used as knowledge. The cross-store handoff is at-least-once and idempotent by stable ingress/evidence IDs, not a distributed transaction.

## Bounded turn protocol

`Accepted → ContextReady → ModelPending → ModelObserved → ToolPending/WaitingDecision → Composing → Settled`.

Turns may also become interrupted, cancelled, failed or superseded. A branch/conversation ordering policy serializes visible turn settlement where needed; independent conversations can progress concurrently. Each transition uses compare-and-swap on turn version, a worker lease and attempt identity. Lease takeover fences old workers from settling the turn.

Persist model intent before making the call. Persist allowed output and tool proposals before acting on them. A crash after a provider response but before persistence may require another model call; the system does not promise exactly-once inference or identical tokens. Only one accepted attempt settles the turn. Every tool still goes through idempotent authorized application ports.

Streaming tokens are provisional until message settlement. On interruption, the client receives an explicit interrupted state and a new settled response/version rather than a fabricated byte-perfect continuation. Draft text cannot claim an effect succeeded before a settlement observation supports it.

## Context compiler

For each attempt, compile context from visible settled interaction, the selected Focus, currently authorized Frames, relevant source/evidence snippets, active skill/agent definitions, requested purpose, pending Cases, attention policy and budgets. Every retrieved item carries provenance and disclosure. Do not concatenate all company data or historical messages into a universal prompt.

Conversation summaries are interaction aids, not accepted facts. Fact-like statements extracted from conversation become proposed claims through Ontology. Old summaries cannot carry expired permissions into a new turn. Changing World or audience requires fresh authorization; moving a personal answer into a company group is a new disclosure event.

Store visible messages, safe tool arguments/results, cited evidence, concise decision summaries and usage metadata. Do not persist or expose private model chain-of-thought. Provider response persistence is allowlisted so hidden reasoning fields, credentials and raw transport headers do not leak into the interaction journal.

## Tools and runtime skills

Build a per-attempt tool set from the current authorized SurfaceManifest and active SkillDefinition. Default reach is none. Known actions are exposed with schema, purpose, consequence classification and explicit approval policy. A skill can narrow behavior; it cannot enlarge the principal's grant or invent an authority tool.

Tools can inspect, search, prepare a DefinitionChange, propose a domain Action or contribute to a Case. A pre-authorized mandate may permit a bounded action to commit through the normal Action protocol, not through a hidden direct database mutation. Artifact execution uses the isolated capability broker.

No shell, filesystem, arbitrary fetch, recursive self-delegation or blanket provider SDK is automatically installed in Eve. Read-only web research can be a separately allowed source capability with citation/provenance and egress rules. It does not become authoritative business evidence merely because it was retrieved.

## Runtime definition changes

A turn pins the released tool/skill definition it started with. Before every tool operation, current authorization and compatibility are checked. If an activation changes the relevant capability, return ContractChanged/Stale and replan visibly. Do not continue a parked turn with new tool semantics under old approval.

Personal tone and layout preferences can apply to the next composition without reinterpreting business facts. Changes to a skill's effect set, model route, data access or autonomous budget require the stronger release path.

## Credentials and topology

Eve has its own limited database credentials and model gateway identity. It has no authority repository, release signing key or provider secret. A typed capability client talks to the authority service with short audience/request/body-bound credentials and principal/purpose evidence. Loopback is transport, not authentication.

Colocated trusted development processes are permitted; production confidentiality boundaries require isolated workloads. A compromised Eve must still face server-side authorization and effect policy. Prompt injection defenses cannot make a compromised host trustworthy, so infrastructure isolation is a separate gate.

## Proof and reopen gate

Kill before/after each state transition and model/tool observation; replay ingress; race two workers; change release during a wait; revoke a World membership; lose stream delivery; duplicate a tool request; restore interaction without effect duplication; and test provider output containing forbidden hidden fields.

A replacement durable runtime must pass these journeys with the same external contract, one replay owner, runtime-defined capabilities, export/retention support and no ambient tools. Compare code/operations burden against the compact turn machine before adopting it. No production conversation ships on the strength of a framework's durability marketing alone.
