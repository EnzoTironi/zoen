# Types and protocol index

## Decision

Realm, World, cut, release, scope, purpose, evidence and authority must be explicit at every boundary. Raw strings crossing an API are validated into opaque/branded IDs; static typing is not a substitute for runtime checks.

| Boundary | Input | Output / ownership |
|---|---|---|
| Door proof | Account/session/device/workload assertion | Presence only; no World grant. |
| OpenWorld | Fresh proof, World, purpose and assurance | Current bounded session/grant, or Denied. |
| Inspect | Released operation, typed query, fresh authority | WorldFrame with exact cut, perspective, evidence and gaps. |
| AdmitSource | Captured source artifact + source contract | Evidence/claims/receipt and semantic delta, or quarantine. |
| Resolve | ResolutionCase and scoped human answer | Attributed claim/identity resolution; no automatic reusable rule. |
| ProposeAction | Released action, typed intent, basis | ActionCase/consequences/guards/expiry. |
| AnswerCase | Case digest, actor proof, answer, operation ID | Progress, Stale, rejection or atomic DecisionReceipt. |
| AttemptEffect | Durable intent and narrowly scoped lease | Attempt evidence; no automatic final settlement. |
| RecordSettlement | Provider evidence and current intent correlation | Explicit observed lifecycle outcome. |
| ProposeDefinitionChange | Released base, semantic patch, scope | Risk-classified draft/diff/evaluation request. |
| ActivateRelease | Proof, prepared generation, current approval | Atomic new head plus activation receipt, or stale preparation. |
| EvaluateWatch | Authorized released condition + committed delta | Checkpoint or Notice; Eve owns delivery choice. |
| OpenFocus | Opaque bookmark + fresh authority | Same retained Frame or explicitly newer/unavailable view. |
| PublishDataset | Verified pinned immutable snapshot references | Authoritative dataset generation/cut, not catalog latest. |

Stable errors include Denied, Stale, Conflict, IncompleteBasis, UnsupportedPlan, PreparationStale, BudgetExceeded, SourceStale, HistoricalContentUnavailable and UnknownExternalOutcome. Error details themselves obey disclosure; hidden resources may require an indistinguishable denial/not-found response.

The [representative TypeScript and JSON contracts](../contracts/README.md) illustrate these shapes. The implementation must elaborate all released variants, schema migrations and compatibility fixtures before treating them as a complete public SDK.
