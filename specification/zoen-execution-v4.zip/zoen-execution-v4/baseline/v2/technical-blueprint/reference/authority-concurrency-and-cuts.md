# Authority, concurrency and cuts

## Decision

Keep one authority cell per World epoch, but do not serialize every data change through one exclusive WorldHead counter. Separate an infrequently changing control head from data-domain versions. Use PostgreSQL transactions for atomic local operations; preserve independent component cuts for federation.

This replaces original ADR 005/006's data-head-wide serialization. It does not introduce cross-cell ACID or a claim that arbitrary workloads scale linearly.

## Head and domains

`WorldHead = {worldId, realm, cellId, epoch, releaseDigest, generationId, securityRevision}`.

A `CommitDomain` is a bounded ordering/invalidation scope inside a World, usually a business aggregate or a released bucket. It is not a tenant or independent permission model. Each domain has a committed monotonically increasing version. Domain partitioning is released metadata; repartitioning requires a prepared generation transition. Reads spanning many domains can use a coarse partition fence instead of millions of subject guards.

An `AuthorityCommit` identifies every touched domain/version and a single commit ID. It includes meaningful state changes, a decision/ingestion receipt, events and outbox rows in one PostgreSQL transaction. Dense raw points do not each require a sparse commit; a dataset snapshot or summarized semantic change can be admitted in one commit.

## Data write protocol

1. Verify current principal, purpose, realm and routed authority epoch. Begin a PostgreSQL SERIALIZABLE transaction.
2. Acquire a shared row lock (`FOR SHARE`, not merely `FOR KEY SHARE`) on WorldHead. Validate expected release, generation, security revision and epoch. Shared locks permit concurrent ordinary data commits but exclude head changes.
3. Acquire domain/fence locks in deterministic order; reject unsatisfied freshness, expected versions and predicate fences. Authorization is checked against current authoritative rows in this transaction; an old bearer/Frame is insufficient.
4. Validate or claim the operation-id record under `(world, principal, semanticOperation, operationId)`. Same intent returns its prior result; a different intent with that key conflicts. A replay is still freshly authorized before disclosing a stored result.
5. Evaluate the bounded plan against the pinned read dependencies. Write state/history, advance affected domain counters, and append the receipt, commit envelope and outbox atomically.
6. Commit; retry serialization/deadlock failures only with bounded attempts and the same intended operation. Do not silently rebase a user-approved Case onto different facts. Return `Stale` when consent's basis changed.

No provider or LLM call runs inside this transaction. Uploaded evidence is durably staged before admission; a failed transaction leaves an orphan for controlled cleanup, not an admitted reference to absent bytes.

## Consistent reads

A local Frame builder opens one PostgreSQL REPEATABLE READ snapshot, reads the head, relevant domain versions, admitted evidence/dataset references and current rights. Sparse data and snapshot references come from the same database snapshot. It then executes bounded reads over those immutable references. The resulting Frame pins head, cut, snapshot IDs, query plan, dependencies, quality/freshness and disclosure basis.

Reauthorize immediately before disclosing a composed result. A revoked grant may suppress a result prepared under an earlier snapshot. This check cannot make knowledge globally instantaneous; it binds the service's response to the latest available local rights state. Source ACL freshness is separately governed.

Large scans do not keep a PostgreSQL transaction open for their full duration: persist the small authorized execution basis, pin immutable inputs, release the transaction, run the scan and reauthorize before output. Mutable sparse inputs required by the scan are exported as a bounded snapshot artifact first, or the query uses an explicitly bounded transaction.

## Read sets and phantoms

A Case must capture more than row versions. “No unpaid invoices exist” depends on the absence of matching rows; “total spend below limit” depends on every qualifying addition/removal. The dependency set includes subject/property versions, source watermarks, identity versions, dataset snapshots, policy/head versions, explicit clock bounds and **predicate fences**.

Initial implementation conservatively invalidates a Case when any relevant commit-domain/partition fence changes. This may produce false staleness but cannot silently omit a newly inserted matching record. Finer predicate invalidation is admitted only after equivalence tests against the conservative fence. An aggregate that ignores an unknown partition is incomplete, not approved.

Approval checks and final commit occur in a fresh serializable transaction using these guards. Multiple approvers sign the same Case digest. Changing price, recipient, underlying facts or action meaning creates a new Case revision and invalidates affected approvals.

## Multi-domain operations

A single local transaction may update several domains in the same World/cell, locking them in sorted order and advancing each version. This supports allocating inventory and recording an order without inconsistent local state. A commit envelope identifies the complete touched-domain set, so consumers can process it atomically where required.

There is no global chronological event sequence for all independent domains. Consumers use commit IDs plus per-domain cursors and dependency barriers. A subscription requiring a coherent multi-domain view obtains a fresh Frame after the complete commit is visible.

## Release and security transitions

Activation takes the exclusive head lock after a proof/preparation step and rechecks the expected head and prepared cut. Ordinary writers cannot cross the transition mid-commit. A prepared generation catches up only from committed envelopes. If catch-up cannot converge, impose a bounded write fence with a visible maintenance state. A directory/head update without data readiness is forbidden.

Membership and delegation updates advance the security revision when they affect access. This intentionally invalidates outstanding grants conservatively. Pure personal presentation settings do not advance World authority. An emergency deny is evaluated at the runtime boundary immediately and is durably recorded; it may stop access before a full semantic release, but it cannot grant new power.

## Progress and recovery

`ProgressCommit` may renew leases, checkpoint pagination, record attempt metadata or move an outbox cursor. Its SQL role cannot write interpreted facts, Cases, grants, head or receipts. Staging a SourceCapture is not SourceAdmission. A restated attempt is not Settlement.

Leases use owner token plus fencing generation; a resumed zombie cannot settle a job after a successor has claimed it. Leases alone do not prevent duplicate provider effects; the effect protocol also requires deterministic intent identity, provider idempotency or reconciliation-before-retry.

## Proof

Run concurrent disjoint-domain writes; conflicting writes; insert-phantom changes while a Case waits; multi-domain deadlock/retry; activation during ingestion; revocation before response; operation-key collision; crash around every atomic boundary; and replica lag. PostgreSQL documentation supports isolation mechanisms [S11]; the full protocol and its scalability remain Zoen's implementation responsibility.
