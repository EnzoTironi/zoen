# Migration and adoption

## Decision

Treat the supplied ZIP as a traceable design baseline and the existing OS repository as a source of reusable code and lessons, not a constraint that predetermines the new kernel. Do not erase or migrate real production data without an inventory and tested plan. The new `zoen` repository is a proposed implementation destination, not a repository modified in this session. [S29, S30, S34]

## Migration tracks

**Design:** original Markdown is preserved under `baseline/`; new ADRs start at 030. The supersession table states retained/revised/replaced decisions. No two competing constitutions are active.

**Code:** inventory licenses, tests, public contracts, provider adapters and UI components. Port only through explicit v2 ports; quarantine old broad tools/DB access. Rust/native libraries can remain isolated adapters where valuable, but Zoen-owned application/runtime remains TypeScript.

**Data:** identify actual records, source permissions, credentials, provider external IDs, outstanding effects, retained receipts and deletion obligations. Export without silently changing meaning. Admit source records as evidence; old derived values retain provenance and confidence limitations. Preserve operation/effect identifiers needed to avoid duplicate real-world actions.

**Users:** progressive reconnect/reconsent and source checks; invitations and memberships recreated only through current authority. Explain changes in how conflicting data is shown. Do not force everyone through an enterprise migration workbench.

## Cutover

Run read-only shadow interpretation against authorized snapshots and compare differences by meaning/scope/time. Classify differences as expected semantic changes, incomplete mapping or defects. Do not shadow-send messages or execute external actions. At cutover, fence old writers/effect dispatch, reconcile outstanding provider operations, capture final cut, activate prepared v2 state and admit a single owner. Rollback is a forward reconciled transition, never enabling both dispatchers.

A deployment with no real users/data can start clean, but that fact must be established by inventory rather than inferred from a sparse public repository. Greenfield design is not permission to destroy existing records.
