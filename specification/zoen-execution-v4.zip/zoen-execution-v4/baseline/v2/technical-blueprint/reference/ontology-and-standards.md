# Ontology and standards

## Decision

Use a small operational metamodel with stable semantic identifiers and a bounded, executable definition language. Adopt interoperable standards at the boundary; do not equate ontology with an RDF database or turn unrestricted reasoning into an authority mechanism.

A WorldRelease is a content-addressed closure of definitions. A PackRelease is a reusable subset with dependencies. A World installation binds pack parameters to local source bindings, policies and presentation profiles. Definitions are data; the compiler/interpreter and their safety rules are code.

## Semantic elements

| Element | Required meaning |
|---|---|
| ObjectType | Stable type identifier, properties, capabilities, constraints and presentation facets |
| Interface | Common properties and verbs implemented by multiple domain types |
| LinkType | Typed endpoints, cardinality, temporal semantics, optional properties, evidence requirements |
| PropertyDefinition | Scalar/value type, unit/currency/calendar, multiplicity, scope, clocks, null semantics and resolution policy |
| MetricDefinition | Population, measure, aggregation, time window, currency/basis and comparability contract |
| SourceContract | Acquisition shape, cursors, identity keys, mapping, rights and coverage expectations |
| ResolutionPolicy | Eligibility, comparability, source/role precedence, conflict handling, expiry and escalation |
| FunctionDefinition | Pure bounded computation over explicit inputs and basis |
| ActionDefinition | Inputs, read dependencies, preconditions, consequences, approval and effect contracts |
| WatchDefinition | Subject query, semantic predicate, materiality, freshness and cooldown |
| MandateDefinition | Goal observation, authorized action set, limits, escalation and terminal states |
| Skill/AgentDefinition | Behavior, context selection, tools, models, limits and evaluation cases |
| ViewDefinition | Authorized object sets, fields, charts, interactions and text fallback |

The element catalog is extensible by composition. Adding a new kernel operator or a new security-sensitive execution primitive requires a code release. Adding a property, mapping or domain action that composes existing primitives does not.

## Identity and typing

Use opaque World-scoped subject IDs. A type assignment is temporal and evidence-bound; entities can implement multiple interfaces. Provider identifiers are scoped aliases, never primary keys for all reality. A business name or email is neither stable identity nor proof of unique identity.

Semantic IDs never change when display labels do. A field renamed from “sales” to “bookings” keeps its ID only when its meaning is unchanged. A new accounting basis, granularity, currency convention or null interpretation is a semantic change, often a new definition ID. A compatibility declaration cannot waive that distinction.

## Ontology packs without a universal mega-schema

The foundation pack defines reusable scalar types, Party, Document, Event, Commitment, Location and temporal/evidence conventions. Domain packs compose interfaces: household obligations, bakery production/orders, clinic administration, enterprise operations and finance. Do not force a patient, supplier, family member and trading counterparty into one unrestricted Customer record.

Cross-pack mappings are explicit, typed and versioned. An imported industry vocabulary can annotate a field without acquiring permission or executable semantics. A company may specialize a pack; the fork has its own identity, dependency constraints and migration policy. “Standard” is not an excuse to erase local meaning.

## Standards mapping

| Standard | Use | Deliberate boundary |
|---|---|---|
| JSON Schema 2020-12 | Shape validation for manifests and operation payloads | Schema validity is not semantic or permission validity |
| JSON-LD 1.1 / RDF identifiers | Import/export of objects, links and vocabulary identifiers | No remote context fetch during authority evaluation; contexts are pinned and locally resolved |
| PROV-O | Exchange of Entity/Activity/Agent provenance | Domain-specific decision and rights semantics remain explicit |
| SHACL | Import/export and validation of an explicitly supported shapes profile | Unsupported constraints are rejected/reported; not silently claimed as supported |
| OpenAPI / JSON Schema | API discovery and generated clients | Provider OpenAPI does not become a World ontology automatically |
| MCP | Tool/resource discovery and client interoperability | Protocol annotations are hints, not authorization |
| Parquet / Iceberg | Dense data and physical snapshots | Dataset publication and data rights stay in Ontology |
| ISO-style currency, date/time and unit identifiers | Declared scalar conventions | Conversion requires an explicit factor, source and effective time |

W3C documents establish JSON-LD, PROV-O and SHACL's scope. The selections and restricted profiles here are Zoen design decisions. See sources S08–S10.

## Missing, negative and contested

No value is not the value zero. Missing from a source result is not deleted unless the source contract guarantees a complete authoritative snapshot for that key space. An unavailable connector is not evidence that an object ceased to exist. Negation uses a declared closed-world scope and completeness proof; otherwise the result is unknown.

A multi-valued property, rival claims and incompatible metric definitions are different things. Multilingual labels do not change semantic identity. Calendar dates, time-zone-specific appointments and UTC instants use different scalar types.

## Generated surfaces

The release compiler emits one SurfaceManifest: authorized discovery hooks, operation input/output schemas, stable IDs, text descriptions, effect classification, required assurance, views and compatibility data. REST, CLI, SDK, MCP and Eve derive from it. A typed SDK is a snapshot of the contract; after incompatible changes it must regenerate or fail with an explicit compatibility error. Runtime data cannot retroactively change a compiled client's static types.

## Proof

Round-trip the supported standards profile; reject an unsupported SHACL constraint and remote JSON-LD context; preserve semantic IDs through label changes; reject implicit money/unit conversions; demonstrate one operation across interfaces; and distinguish absent, false, zero, unavailable and deleted values.
