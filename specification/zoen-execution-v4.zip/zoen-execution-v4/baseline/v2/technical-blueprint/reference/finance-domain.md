# Institutional finance domain horizon

## Decision

Finance supplies a rigor benchmark and a domain pack, not an entitlement to market data or a claim of regulatory approval. Consumer money views and institutional execution reuse the same evidence/decision kernel; their source rights, assurance, domain constraints and operating obligations differ dramatically. Bloomberg's data breadth, point-in-time offerings and real-time feed products establish reference categories, not data bundled with Zoen. [S05, S06]

## Released grammar

| Area | Required semantics |
|---|---|
| Security master | Instrument vs listing vs issuer; identifier namespace, valid dates, source mappings, disputed identities. |
| Market data | Quote/trade/book depth, source/event/acquisition time, currency/unit, adjustments, corrections, gaps, entitlement. |
| Fundamentals/news | As-reported and restated values, point-in-time knowledge, filing/news revisions, licensed content and model-use restrictions. |
| Corporate actions | Announcement, ex/record/pay dates, elections, adjustments, affected positions, cancellations/revisions. |
| Accounts and custody | Legal beneficial owner, broker/custodian/account, available vs settled vs reserved quantities/cash. |
| Orders | Proposal, risk approval, submitted/acknowledged/rejected, working, partially filled, filled, cancelled, expired, unknown. |
| Executions | Venue/broker execution ID, allocations, fees, currency, correction/bust and reconciliation. |
| Settlement | Contractual trade date vs actual settlement, fails/partials, cash/security movement and evidence. |
| Risk/compliance | Limits, exposures, restricted lists, mandate suitability constraints, pre-trade controls and immutable review basis. |
| Analytics | Portfolio/time series/scenarios, benchmark identity, missing coverage, price basis and reproducible calculation inputs. |
| Collaboration | Licensed permitted sharing, supervised conversation, retention/legal hold, counterparty identity and approvals. |

A filled order is not settled custody. Cancelling an order request is not proof the order did not fill. A bank balance is not necessarily spendable cash. An adjusted price series is not interchangeable with a raw historical quote. Represent each explicitly.

## Calculation rules

Use exact decimal quantities and named rounding/valuation policies. Currency conversion pins rate source/time and intermediate precision. Corporate-action adjustments and position reconstruction preserve original evidence and versioned interpretation. Point-in-time backtests do not read later revisions, future identity mappings or unavailable membership/data licenses without labeling look-ahead. Scenarios are read-only until a fresh live Case is proposed.

## Execution admission

Actual orders/payments require legal/commercial authorization, contracted broker/bank/venue connectors, provider idempotency and reconciliation semantics, tested failover, sanctions/risk controls appropriate to the jurisdiction, supervisory approval where required and named operational ownership. This package does not offer individualized financial advice, custody or regulated brokerage services.

Provider certification is separate for each lifecycle and API. S11 proves partial fills, busts, cancellation races, provider timeout with eventual acceptance, expired market-data entitlement, stale quote rejection and double-submission prevention/reconciliation. No generic webhook demonstration establishes full financial execution readiness. Ultra-low-latency/high-frequency trading is outside the current performance claim; adding it requires a dedicated proof and possibly specialized execution infrastructure behind the same governed intent boundary.
