# Technology stack and version admission

## Decision

Select technology families now; admit exact interoperable patches, native binaries and provider API versions before implementation merges at S0. The package is not a fabricated installable lockfile. Publication of a version is weaker evidence than successful composition of the complete stack.

| Layer | Selected family | Reason and limit |
|---|---|---|
| Runtime | Node.js 24 LTS | Shared TypeScript operational model; CPU work goes to workers/processes. |
| Compiler/workspace | TypeScript 6 compatibility baseline, pnpm 11 | Preserve strict ecosystem compatibility first; TS 7 upgrade requires lint/type/tool parity. |
| HTTP | Hono 4 + official Node adapter | Thin edge; explicit body/signature and streaming behavior. |
| Identity | Better Auth 1.x behind DoorPort | Passkeys/OIDC; enterprise SSO/SCIM separately admitted. |
| Authority | PostgreSQL 18, `pg` | Explicit SERIALIZABLE commits and REPEATABLE READ Frames. |
| Policy | Cedar evaluator behind PolicyPort | Bounded policy profile; no invented Cedar-to-SQL general compiler. |
| Definitions | JSON Schema 2020-12 + canonical JSON (RFC 8785 profile) | Typed, content-addressed, inspectable runtime changes. |
| Model transport | Vercel AI SDK 7 + direct provider adapters | Model/tool portability, not durable or authoritative state. |
| Effects | Restate server + TypeScript SDK | Retries/attempt orchestration outside local authority. |
| Jobs | PostgreSQL leases + transactional outbox | One initial operational store, measured queue load before extraction. |
| Evidence | S3-compatible encrypted object store | Integrity digests, retention classes, short-lived authorized reads. |
| Analytics | DuckDB Node Neo (`@duckdb/node-api`) | Bounded isolated analytics; never unbounded scans in the edge loop. |
| Dense tables | Apache Iceberg v2 over Parquet + Lakekeeper OSS REST catalog | Standard metadata/snapshots; explicit authority publication. |
| Retrieval | PostgreSQL FTS + pgvector | Rebuildable authorized projections, not source truth. |
| UI | React + React Aria + React Router + TanStack Query/Table/Virtual | One conversation/inspection context with accessible primitives. |
| Visualization | Apache ECharts 6 | Released ChartDocument; explicitly configure accessibility and text alternatives. |
| Public protocol | REST/OpenAPI, SSE, CLI, generated TS SDK, MCP | One semantic manifest; negotiation and compatibility tests. |
| Protocol edition | MCP 2026-07-28, reviewed MCP Apps extension profile | Edition verified as current on research date, not inferred from training memory. |
| Telemetry | OpenTelemetry + structured redacted logs | Separate operational traces from append-only semantic receipts. |
| Infrastructure | Terraform + AWS regional cells | Hosted production profile below; OCI-based portability is bounded, not free. |
| Isolation | Separate artifact OCI + gVisor/microVM-grade execution | Resource/egress enforcement outside guest; signature alone is insufficient. |

## Research observations versus execution pins

On 4 September 2026, official/public package evidence showed Node 24 as LTS, Hono 4.13.5, AI SDK 7.0.92, DuckDB Node Neo 1.5.5 and TypeScript's latest registry metadata as 7.0.2. These are publication observations, not a tested lock set. Original TypeScript 6.0.3 and pnpm 11 choices are inherited candidate pins; neither is represented here as independently installed and validated. Better Auth 1.7 documentation establishes available SSO/SCIM-related capabilities, not enterprise certification. [S15, S19, S21, S22, S23, S24, S33]

S0 emits `execution-lock.json` containing exact versions and integrity hashes for application packages, Cedar/native adapters, DuckDB/Iceberg extension pair, OCI base, Restate, PostgreSQL extensions, catalog and Terraform providers. It records license review, source, release date, vulnerability scan and passed compatibility suite. Unknown fields remain blockers, not invented values. If TypeScript 6 support is unsuitable, the implementation decision may move to 7 only after the documented parity gate; update the ADR and lock together.

## Primary hosted profile

AWS `sa-east-1` is the default region for a Brazilian hosted cell, subject to contracted data residency and exact service/version availability. Trusted stateless services use ECS/Fargate, private subnets, internal service authentication and least-privilege task roles. PostgreSQL uses RDS PostgreSQL 18, Multi-AZ for the production profile, PITR, private networking and restore drills. Evidence uses S3 with KMS envelope controls, retention classes and access logging. Regional/version/extension support is verified during provisioning; global PostgreSQL 18 support does not prove a particular extension or regional SKU. [S35, S36, S37]

A single-node pilot Restate executor may use an encrypted persistent EC2 volume and explicit non-HA status. Institutional production requires the supported replicated Restate deployment for the admitted version and demonstrated failover; do not put durable state on Fargate's ephemeral filesystem. Catalog state uses its own managed PostgreSQL database. Untrusted custom runners use a dedicated EC2 execution pool with gVisor or microVM isolation, separate network/account controls when required, and no instance metadata or ambient task credentials exposed to payloads. Operational controls, not a Dockerfile alone, establish the boundary. [S18, S32]

Development uses Docker Compose with disposable PostgreSQL, object storage and provider sinks. Legacy Fly deployment is optional for non-production migration experiments, not the fixed v2 target. The hosted profile can be reproduced in dedicated accounts; self-hosting requires a tested equivalent of every storage, identity, isolation, backup and egress contract rather than merely running the image.

## Deliberately not required at launch

No Kubernetes, Kafka, Redis, dedicated graph database, separate vector database, generic workflow framework or distributed query cluster is required for S0–S4. These can implement ports after measured need and equivalent recovery/disclosure proofs. S7 adds Iceberg/catalog for a real dense-data journey, not because an empty personal World requires a lakehouse.
