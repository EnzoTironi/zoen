# Messaging channels and durable delivery

## Decision

WhatsApp is the priority entry, not the place where authority lives. Use Kapso as the initial WhatsApp transport adapter, web as the always-supported rich/secure surface, and Telegram plus Resend email as secondary adapters. Provider contracts remain replaceable; identity, consent, evidence, decisions and continuity do not.

No percentage of Brazilian market penetration is a technical premise. Distribution and channel economics must be measured against the actual target population and contract.

## ChannelBinding

A binding connects a verified provider endpoint to a Door subject and an allowed relationship/conversation scope. Provider message sender identity initially proves only control of that channel endpoint at that time. Linking accounts requires a secure ceremony; group membership, caller-supplied phone numbers or remembered names do not grant World membership.

A shared device, recycled number or group conversation has an explicit disclosure policy. Consequential operations require the declared assurance and a current World grant; a message from a familiar phone is not sufficient authentication for every action.

## Inbound protocol

Verify raw-body signatures/secrets, account binding, replay identity and size. Normalize provider event metadata without losing original IDs. Durably record ChannelIngress and its delivery-to-turn outbox before acknowledging the provider. Retries return accepted status for the same ingress identity without starting duplicate turns.

Attachments go through quarantine/type/size/malware and evidence admission or controlled temporary processing. Eve receives an authorized reference, not a path to write arbitrary bytes in its runtime. Voice transcription is a separate attributed extraction; sensitive media is retained only under an explicit policy.

## Outbound protocol

Eve records a settled message/delivery intent with target audience, content basis, consent/template/window requirements and idempotency identity. Before sending, reauthorize the audience and relevant data, check channel policy and obtain a short provider lease. Record accepted/rejected/unknown observations independently of visible conversation settlement.

A timeout after a send is not delivery failure. Use provider idempotency/status reconciliation when available; otherwise choose an explicit duplicate-risk policy for that message class. Never promise exactly one WhatsApp message when the provider cannot support that guarantee. Financial or critical messages may require operator reconciliation instead of blind retry.

## WhatsApp conditions

The official policy reviewed on 4 September 2026 requires appropriate opt-in and approved templates for business-initiated messages outside the customer-service window; the documented 24-hour window is a channel rule, not a World authorization grant [S25]. Exact template categories, pricing, business verification and regional availability are launch gates, verified against the actual provider account.

The Business Solution Terms reviewed include jurisdiction-specific treatment for AI providers, including Brazil and the EEA [S26]. This is dated contract evidence, not unconditional permission for every assistant use case. Legal/provider review of Zoen's actual account, purpose, geography and feature set is required before enabling production. No unofficial consumer-session scraping or account automation is an alternative route around restrictions.

Sensitive authentication, payment authorization and data connections use secure first-party web flows where required. WhatsApp text describes and links the operation; it does not request passwords, full financial identifiers or secret credentials.

## Channel-native rendering

Flatten structured results into excellent readable text: conclusion, relevant uncertainty, one immediate decision and an authentic deep link when useful. Avoid helpdesk-style menus unless the channel requires them. Never invent a link. Large tables/charts open the same Focus on web rather than being squeezed into unreadable messages.

Locale, timezone, audio/text preference, quiet hours and accessibility are relationship settings. Operational source meaning remains unchanged. Email quoting, Telegram threads and WhatsApp replies are mapped to stable conversation/ingress references without treating quoted instructions as a new approval.

## Consent, cost and recovery

Opt-out stops eligible outbound messaging promptly without deleting lawful business records or revoking unrelated World access. Consent records are channel/audience/purpose-specific. A Watch can remain active while delivery is blocked, and the user can inspect that state through another authorized channel.

Track template rejection, provider throttle, duplicate risk, channel failure, media expiry and cost per useful outcome. Budget exhaustion must not silently discard a critical Notice; it records blocked delivery/escalation. Restore a channel journal with outbound sends disabled until accepted inputs, settled messages and ambiguous deliveries are reconciled.

## Proof

Real two-account ceremonies prove binding, opt-in/out, durable ack, duplicate replay, shared/group disclosure, link continuity, template-window behavior, provider timeout and account revocation. Local forged callbacks or mocked sends do not prove actual provider acceptance or commercial eligibility.


## Voice and attachment accessibility

Audio is source content, not a stronger identity proof. A permitted transcription service produces an attributed extract linked to the original audio when lawful retention permits it; uncertain names, amounts and dates remain uncertain. A voice reply can create a scoped claim but does not silently approve a consequential action. Read back material consequences in an accessible form and use the required secure confirmation/assurance path. Users can correct the transcript without rewriting the source artifact. Model routing, retention and sensitive-data policies apply to speech providers exactly as to text providers.
