# Runtime variation and releases

## Decision

Variation belongs to governed data whenever existing kernel primitives can express it. Custom executable variation belongs to signed isolated artifacts. Safety primitives, privileged interpreters and new trust boundaries remain reviewed application code. “Data, not code” is a separation of responsibilities, not a claim that arbitrary new computation can be safely invented without engineering.

## Three mutation lanes

| Lane | Examples | Authority path | Core redeploy |
|---|---|---|---|
| Instance | Correct a mapping, answer a ResolutionCase, add a source account, change a personal reminder time | Ordinary released Action; affected dependency invalidation | No |
| Definition | Add a type/property, mapping, metric, resolution rule, skill, agent, workflow, view or domain action | DefinitionChange → evaluation → preparation → activation | No, when expressible in existing operators |
| Artifact | Install a connector adapter, custom analysis or executable app | Build/sign → isolated evaluation → installation policy → release binding | No authority redeploy; artifact runner deployment required |
| Kernel | Add an operator, extend privileged action grammar, change crypto or isolation model | Code review, supply-chain build, threat review, full affected test suite | Yes |

A template instantiation may be an ordinary instance Action when it changes only previously validated parameters. Changing acquisition scope, source mapping semantics, egress or requested powers is not merely editing a preference and receives the appropriate change/evaluation tier.

## DefinitionChange contract

A change references expected base release, author/delegation, target symbols, semantic edits, intended scope, reasons, affected capabilities and desired activation window. Edits target stable semantic IDs, not arbitrary JSON pointer mutation of hidden kernel fields. The compiler rejects unknown operators and non-local executable URLs.

The author can be a human in Studio, Eve acting on a request, or a delegated agent. All receive the same diff, validation and evaluation path. There is no privileged “agent mode”. A model-generated policy is untrusted input until validated and approved under the currently active policy.

## Lifecycle

`Draft → Validated → Evaluated → Prepared → Approved → Activated`.

Each stage creates a separate immutable artifact or receipt. A release digest identifies bytes and dependency closure; “active” is a WorldHead reference, never a mutable flag inside those bytes. Failed, rejected, expired and superseded are recorded terminal outcomes for the corresponding proposal/attempt, not mutations of historical content.

Validation checks types, stable IDs, dependency cycles, compatible kernels, bounded resources, rights non-widening defaults, action/effect classification, required migration/reprojection, pack dependency closure, and declared evaluation cases. It rejects unsupported operators instead of treating them as permissive extension points.

Evaluation creates an isolated EvaluationWorld with branded realm references, copied/sanitized or explicitly leased test data, no production credentials, sandboxed destinations and captured channel sinks. A production corpus may be used only under a separately approved evaluation purpose and data boundary. A provider without a sandbox produces a missing proof, not an invented pass.

Preparation compares the live World's current generation/cut against the candidate. It stages derived state, replays committed changes, inventories open Cases, Watches, Mandates, subscriptions and SDK clients, and produces `PreparedActivation`. Activation atomically changes the control head only after readiness and current approval are rechecked.

## Risk-proportional checks

| Class | Required behavior |
|---|---|
| Personal, non-authoritative presentation | Validate locally; ordinary preference update; no world migration |
| Additive schema/view using existing fields and rights | Type/compatibility tests, policy check, automatic release allowed under bounded delegated publishing policy |
| Mapping, identity, reconciliation or metric semantics | Reprojection and representative impact report; steward approval where policy requires |
| Actions/effects/permissions/data export/model routing | Security and consequence diff; appropriate approval, sandbox proof, budget/license checks |
| Destructive schema or large reclassification | Migration plan, retention impact, change window, recovery/compensation plan and operator approval |

“Automatic” means a pre-authorized policy covers this precise class; it does not mean no checks. A user's simple change should not require a global full-corpus replay when affected dependencies are known and bounded. Structural content addressing permits reuse of unaffected proof components, but a changed permission or operator invalidates the relevant proof closure.

## Approval safety

Approve using the old active release and current grants. A proposed rule cannot approve itself, raise its author's budget, appoint a new approver or deactivate audit. Self-authored permission changes require an independent authorized approver when the current policy demands separation of duties. A one-person World can authorize its own domain configuration, but cannot change platform isolation laws or grant access it never possessed.

Current delegation, assurance, resource scope, expiry and budget are rechecked at activation. Waiting for approval does not preserve revoked authority. A changed live head returns `PreparationStale` or requires rebase; it is not silently accepted because the original diff looked similar.

## Open work and compatibility

The activation plan classifies each pending Case: unaffected and still valid, stale requiring re-proposal, or cancelled by policy. A Watch may retain its checkpoint only if semantic compatibility is proved. A Mandate whose action set or goal semantics changes pauses until reauthorized. In-flight provider effects keep their original intent identity and are reconciled under the original attempt contract; they are not replayed with new arguments.

Clients declare the release/contract digest they understand. Additive compatible evolution can continue; incompatible changes return `ContractChanged`, including a permitted regeneration path. Stable IDs preserve rename compatibility, not semantic compatibility. Typed SDK updates are generated packages, not magic runtime edits to compiled programs.

## Rollback and emergency controls

Rollback is a forward, prepared transition to a selected prior definition graph, with current rights and data migration. It does not restore expired credentials or revive deleted personal data. Irreversible external effects require explicit compensation; changing a rule cannot undo a message or a payment.

Emergency capability revocation, source quarantine and effect-dispatch stop are monotone deny controls outside user-configurable permission expansion. Re-enabling them follows normal release/operational approval. Each use is attributed and audited.

## Proof

From WhatsApp, change a bakery deposit rule, inspect the semantic diff on web, evaluate old/new orders, activate without restarting authority, invalidate a pending collection action and generate updated SDK discovery. Then prove malicious code, egress expansion, stale approval, self-grant, revoked author, incompatible client and failed backfill are rejected.
