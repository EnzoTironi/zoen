# Database access and physical model

## Decision

Use explicit parameterized SQL through `pg` for Zoen authority. Keep transaction scope, locks, isolation and authorization visible in code. An ORM's mutable entity graph is not the definition of a World. SQL is an internal implementation detail, never a model-facing tool.

## Logical tables

| Family | Representative records |
|---|---|
| Control | worlds, world_heads, commit_domains, releases, generations, release_activations |
| Access | principals, memberships, delegations, grants/revocations, source_acl_versions, policy_bindings |
| Knowledge | subjects, subject_type_history, identity_assertions, evidence_refs, claims, claim_relations, interpretations, interpretation_dependencies |
| Source/data | source_bindings, captures, acquisition_cursors, admission_watermarks, datasets, dataset_versions, retention_pins |
| Agency | action_cases, case_dependencies, case_contributions, decisions, reservations, effect_intents, effect_attempts, settlements |
| Attention | watches, watch_checkpoints, notices, mandates, mandate_observations |
| Changes | definition_changes, release_proofs, prepared_activations, artifact_installations |
| Reliability | commit_envelopes, outbox, consumer_inbox, leased_jobs, operation_results |

Eve's separate schema/database owns channel_ingress, conversations, turns, model_attempts, visible_messages, attention_decisions and deliveries. The catalog owns its own tables. Foreign-key-style identifiers across stores are resolved through contracts; there is no fictitious transaction spanning their databases.

## Keys and constraints

All authority primary/foreign keys include World/realm scope where relevant. A globally unique UUID alone does not prove tenant separation. Unique constraints enforce source-event identity and idempotent operations. Composite foreign keys prevent linking a Case/evidence/subject from another World.

Authority data references its release/generation and commit-domain version. Values are schema-validated on admission; frequently queried scalar projections have explicit types. JSONB is not an untyped escape hatch. Timestamps use `timestamptz` for instants; local dates/times and decimal values retain explicit types and precision. Empty, null, unknown, redacted and zero do not share one representation.

Claim history is append-only while retained. Supersession/retraction relations and interpretation history are versioned; mutable indexes are derived from that history. A retention/erasure operation may remove lawful content under the separate lifecycle protocol, with audit evidence that does not retain the erased payload.

## Transaction boundaries

The AuthorityStore accepts a typed plan and revalidates expected versions under SERIALIZABLE. Head/domain locking is defined in the concurrency reference. No model, provider, filesystem download or long analytics executes while locks are held. Retry only serialization/deadlock conflicts with the same operation identity and bounded backoff; distinguish stale consent from retryable physical contention.

Read Frames use REPEATABLE READ with explicit projection watermarks. Very large analyses use staged immutable inputs. A read replica can serve only when it has replayed the required cut and current rights state; otherwise route to primary or return unavailable. “Read your writes” is a required cut, not a sleep timer.

## Roles

`authority_runtime` performs permitted DML through the repository and does not own tables. `projection_runtime` writes only derived projections. `progress_runtime` writes operational progress only. `eve_runtime` cannot read authority tables. `catalog_runtime` cannot write World state. `migrator` is short-lived and not available to workloads. Source/effect executors receive no database credentials.

RLS default-deny and tenant checks protect coarse rows. Field/evidence disclosure is applied by the semantic planner. Setting a World context variable is allowed only after authenticated application admission; do not mistake a caller-controlled SQL setting for authorization. Security-definer functions are avoided or tightly allowlisted with a fixed search_path and tests.

## Schema evolution and performance

Kernel SQL migrations are application deployments, separate from runtime WorldRelease changes. Runtime fields use the semantic/value model and staged derived projections; they do not generate uncontrolled per-customer table DDL. Add physical indexes through reviewed deployment/migration when measurement justifies them. Rebuild projections in a staged generation and switch the authoritative generation reference atomically.

Start with indexes on World/domain/version, subject/predicate/valid interval, source key/revision, case status, outbox availability and permission partitions. Partition high-volume append-only history by operationally measured World/time cohorts; do not partition prematurely by every tenant. Monitor bloat, vacuum lag, index selectivity, lock waits, transaction retries, WAL/archive lag and connection saturation.

No arbitrary Redis ban is claimed as a theorem. Redis is not part of this constitution because jobs, idempotency and state already have explicit owners; introducing it requires a successor ADR with a measured need and a non-authoritative contract.

## SQL reference slice

[authority-slice.sql](../contracts/authority-slice.sql) is an illustrative schema for selected identity, evidence, claim, cut and decision relationships. It is not the complete database design, a production-ready migration or a substitute for the above role/RLS protocol. CI must implement and test all constraints before any production admission.

## Proof

Real PostgreSQL tests cover cross-World composite keys, row-policy denial, pooled-context leakage, duplicate operation keys, concurrent insert phantoms, serialization retry, migration/rollback, outbox atomicity, restoration and bounded historical queries. Pure tests cannot prove these database properties.
