# Models, retrieval and agents

## Decision

Models propose and explain; released semantics and current authority decide. Use provider-independent ModelPort adapters via AI SDK. Model identity, capabilities, permitted data classes, geography, retention/training terms, latency/cost budgets and evaluation results are versioned configuration. A “best model” label is not a deployment policy.

## Model profiles

Profiles specify provider/model identifier, endpoint boundary, supported structured output/tool/vision/audio features, context/output budget, safety settings, logging constraints, data-use agreement reference, residency eligibility, pricing version and fallback policy. Secrets live in the broker. Runtime model changes require an evaluation and data-routing diff, not an arbitrary string substitution in a prompt.

A fallback can reduce capability or produce an unavailable answer; it cannot send restricted data to a prohibited provider. Provider timeout, refusal, malformed output and capability mismatch are different observations. Actual usage and uncertain usage after a timeout are recorded without inventing exact cost.

## Extraction and understanding

Use deterministic parsers where practical. Model extraction returns schema-valid proposed fields with original spans, evidence references, uncertainty and model/prompt versions. Schema-valid JSON is not proof of truth. Unsupported values, contradictory spans or missing units remain explicit. Documents and connector content are untrusted data, not instructions to the host.

Use vision/audio only under a source/content policy. Transcription retains source evidence and uncertainty; OCR/vision interpretation never authenticates an invoice or identity by itself. Clinical and financial consequence checks remain outside the model.

## Hybrid retrieval

A released RetrievalPlan can combine authorized object-set filters, structured predicates, lexical search, vectors and graph-linked evidence. Construct the permitted candidate relation before scoring or context selection. Enforce limits on objects, tokens, joins, time and destination. Return exact references, cut, index/model version and coverage.

Indexing is asynchronous and generation-bound. A stale index is visible, and consequential reads cannot silently rely on it as current evidence. Start with PostgreSQL FTS and pgvector; exact authorized scoring is the security baseline for bounded corpora. Specialized search engines or approximate mixed-ACL indexes require measured recall/latency/security gates.

Documents, tables and graph objects are complementary. Retrieval finds evidence; deterministic metric definitions calculate amounts. Asking an LLM to sum a collection of retrieved snippets is not the financial calculation path. Large analytical queries use the governed Dataset/Analysis interfaces.

## Agent definitions

An AgentDefinition names its purpose, allowed skills and semantic tools, retrieval/context plan, model profile, maximum actions/steps/cost/wall time, delegation depth, approval policy, evaluation suite and escalation rules. A HeadlessAgentRun carries a principal/delegation, input Frame, release and budget reservation.

Agent state/checkpoints are operational records. Accepted knowledge enters through claim/interpretation admission; consequences through Actions; external execution through EffectIntents. Agents cannot mutate an ontology directly because they “understand the user's intent”. They propose DefinitionChanges with the same evaluation and activation constraints as people.

Multiple agents can collaborate through explicit tasks/messages with typed outputs and inherited constraints. Do not create a swarm for tasks one bounded run can do. Child agents inherit the intersection of parent scope and their own definition; budgets roll up to the parent. Cross-agent messages are evidence/interaction, not authority grants.

## Evaluation

Evaluate extraction fidelity, identity suggestions, retrieval relevance, grounded answer correctness, citation validity, abstention, tool selection, harmful data disclosure, attack resistance, budget behavior, multilingual quality and end-to-end outcomes. Maintain separate corpora for household, bakery/clinic and enterprise workflows.

Use representative user/steward labeling and holdout cases. Repeated corrections may improve a mapping or ranking model, but global learning is a separate reviewed data-use capability. Confidence values are calibrated only when a documented evaluation supports them; otherwise expose categorical uncertainty and evidence quality.

## Prompt-injection boundary

Untrusted text can ask the agent to ignore instructions, reveal a key, change a policy or send data to a URL. The tool broker, network layer, policy engine and Action protocol must deny that even when the model follows the text. Content delimiters and classifiers help but are not a proof of containment.

An authorized user can request an unsafe or out-of-scope operation; user intent does not override World rights, source licenses, platform policy or delegation. A model refusal is not the only safety boundary. Conversely, a model's approval is never the authority proof.

## Proof

Test malicious source instructions, hidden data in retrieval, schema-valid hallucinations, model fallback with forbidden residency, unsupported live data, speculative financial arithmetic, recursive delegation, interrupted runs, source revocation mid-context and a user correction that would poison a global rule.
