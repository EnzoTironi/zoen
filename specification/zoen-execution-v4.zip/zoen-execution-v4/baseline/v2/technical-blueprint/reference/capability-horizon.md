# Capability horizon

The [machine-readable matrix](../capability-matrix.csv) contains **157 explicit capabilities** mapped to audience, owner, contract, ADR, execution slice and proof journey. It covers the requested product ambition and the major categories from the original horizon. It is a traceability tool, not a claim of exhaustive parity with every vendor feature.

All matrix entries start as `DesignOnly`. Selected reference laws in this ZIP have separate local verification; that does not upgrade the platform capabilities. During execution, attach component/sandbox/production evidence to the exact capability and version rather than editing every row to “done.”

The same domain-neutral kernel serves three audiences through different packs, defaults, assurance, deployment and support. Institutional density is allowed by the contracts; user-facing vocabulary and setup burden must remain appropriate to each audience. New domain needs can expose a missing primitive and require a new reviewed ADR rather than a private bypass.

[Ambition audit](ambition-audit.md) lists the hardest unresolved risks. [Execution sequence](../implementation-sequence.md) gives the order and production gates.
