# Living World, applications and charts

## Decision

Conversation and Living World are two views of the same governed subject. Use declarative views for ordinary experiences and signed isolated applications for advanced interaction. No user-facing graph UI is required to benefit from an ontology.

## Focus

Focus records semantic subject/lens intent, desired temporal basis and opaque Frame/Case/Watch references. It contains no token, delegation or saved privileged evidence selection. Opening Focus through a new channel obtains a fresh grant and either opens the permitted historical Frame or clearly shows a newer basis. A stolen link is a bookmark, not a key.

## Progressive surfaces

Consumers begin with plain-language answers, a few facts and a source/decision link. Professionals deepen into orders, appointments, cash, exceptions and production views. Enterprises add ontology, data-quality, lineage, policy, release and operational workbenches. These are profiles of the same surface model, not separate ungoverned dashboards.

The primary UI stack is React with React Aria accessibility primitives, React Router and TanStack Query/Table/Virtual. Business meaning comes from the release, not duplicated frontend reducers. Client state is presentation state or an explicit server-owned draft; it is never accepted World truth.

## Declarative ViewDefinition

A view binds released object sets, allowed fields, calculations, source/quality indicators, navigation, actions and responsive/text alternatives. It declares limits and accessibility requirements. Editing a local layout is a preference. Changing a shared metric, disclosure, action effect or data source is a governed definition change.

Views use component vocabulary such as object detail, table, timeline, relation explorer, chart, comparison, evidence panel, Case approval and exception queue. Components do not run user JavaScript in the host. Generated labels and explanations are localized without changing semantic IDs.

## ChartDocument

A chart specifies metric definitions, dimensions, units/currency, aggregation, time axis, timezone/calendar, missing-value behavior, basis, downsampling, entitlement and interactions. ECharts is the initial renderer behind ChartRendererPort. The text/table fallback conveys the same meaning. The chart must display whether data is live, delayed, stale, estimated or partially covered.

Do not interpolate missing values without a declared policy. Do not mix prices in different currencies or adjusted/unadjusted history without a visible calculation basis. Zoom/resampling requests produce a new authorized view/cut when needed. Financial candles, depth and order overlays are specialized chart profiles with feed and license gates, not implied by installing a chart library.

## Application artifacts

Advanced mini-apps are signed bundles hosted on separate origins/iframes with CSP, dependency integrity and host-mediated capabilities. They receive only authorized data/operation handles. No raw provider tokens, broad World token, top-navigation privilege, unrestricted network, shared-origin storage or direct SQL is granted.

The host renders the authoritative confirmation outside untrusted app-controlled markup when required. An application can prepare an ActionCase, but cannot spoof the final approval result. Host bridge messages bind invocation, origin, app digest, audience and allowed operations. MCP Apps provides a portable profile where the client supports it; other hosts use the same semantic contract with explicit portability limitations.

## Builders and scenarios

Studio lets users/agents edit a proposed ontology, mapping, rule, skill or view, inspect affected capabilities and evaluate cases. A scenario branch uses a pinned live basis plus hypothetical changes, remains read-only with respect to live authority and labels all outputs hypothetical. Applying a scenario generates fresh live ActionCases with current dependencies and permissions; it is not a merge of hypothetical provider settlements into reality.

Notebooks/analyses share the isolated AnalysisRun protocol. Saved analyses cite snapshot sets, code/artifact versions and interpretation basis. A generated visual is not evidence that a model's analysis was correct.

## Proof

Test chat-to-visual continuity after revocation, narrow mobile and keyboard/screen-reader use, stale/missing chart data, malicious app origins, forged bridge messages, unauthorized export, misleading approval markup and scenario application against changed live facts. Accessibility and consumer comprehension require real user evaluation, not only a component library choice.
