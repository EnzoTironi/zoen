# Actions, effects and settlement

## Decision

Every consequential domain operation is a released Action. Planning produces an ActionCase; authorized decision produces a DecisionReceipt; external execution produces EffectIntents and observed Settlements. An LLM tool result or local transaction cannot claim that a bank, calendar or supplier accepted an operation.

## ActionCase

The Case contains semantic action ID, input schema/version, typed arguments, subject, purpose, consequences, read dependencies and predicate fences, policy/approval requirements, participating principals, assurance, expiry, uncertainty, reversibility/compensation, projected cost, requested effects and a digest of exactly what is being approved.

The client sees a purpose-appropriate explanation, not a raw plan dump. Different authorized approvers may see different evidence, but all approve the same consequence/Case digest. A person who cannot see required decision evidence receives an explicit governance outcome, not a deceptively simplified confirmation.

## Local lifecycle

`Proposed → AwaitingDecision → Ready → Committed` with `Rejected`, `Expired`, `Cancelled`, `Stale` and `Blocked` outcomes.

An input or basis change creates a new Case revision. Approval may be a single person, quorum, role-based rule or bounded pre-authorized mandate. Every contribution and final commit rechecks current authority. Framework tool approval is an interaction aid, not the authoritative decision receipt.

At commit, the serializable transaction verifies dependencies, budgets, reservations and policy; applies local semantic changes; records the decision, deterministic effect intents and outbox. Consequence-sensitive consent is never silently rebased during a retry. A stale Case returns the changed permitted basis and offers a fresh proposal.

## Idempotency

The operation key is scoped to World, principal and semantic operation. Store a canonical intent digest and committed result. Same key/same intent returns the prior result after current disclosure checks. Same key/different intent returns conflict. Retain effect-relevant idempotency evidence for the domain's replay/retention horizon, not merely a transient framework default.

An EffectIntent ID derives from the decision identity and an explicit effect ordinal, with stable provider operation identity. It is unchanged across process restarts or Restate retries. Changing destination or arguments creates a new authorized intent, not a mutated retry.

## Effect dispatch

1. The outbox dispatches an admitted intent to Restate with an idempotency key.
2. The handler obtains a short leased execution permit tied to World epoch, original intent, current emergency denies, destination/account, amount/resource bounds and expiry.
3. Recheck the domain's execution preconditions. An already committed decision is not unlimited authority to execute after revocation or expiry. The ActionDefinition declares whether a post-commit change requires cancellation/escalation; it cannot be silently ignored.
4. Record an attempt under a unique attempt ID and call the provider through an isolated approved connector. No broad provider credentials are passed to the model or general worker.
5. Capture provider evidence and submit a Settlement proposal through Ontology's admission path. PostgreSQL records the observation and resulting domain transition atomically.

Restate journals execution progress; PostgreSQL owns the canonical intent/attempt/settlement meaning. Provider-specific network calls run as protected side-effect steps, and unsafe ambiguous operations are not blindly retried by the generic retry policy. Restate request deduplication does not by itself make an external provider exactly-once [S18].

## Honest outcome algebra

A provider observation is `Accepted`, `Rejected`, `PartiallyApplied` or `Unknown`, plus provider-specific lifecycle data. Delivery accepted by an API is not necessarily delivered/read. A trading order accepted is not filled; a transfer submitted is not settled. A timeout after request transmission is `Unknown` unless independent evidence proves a result.

Unknown outcomes enter reconciliation: query provider idempotency/status/history using the original operation identity, consume signed callbacks, or ask an operator for evidence. With no provider idempotency or reliable reconciliation, automatic retry of a consequential ambiguous operation is disabled. Return the ambiguity honestly and preserve reservations where required.

A late callback can add evidence or correct a prior interpretation. It does not erase the earlier observation. Contradictory callbacks trigger a reconciliation case and source health event. Amounts/recipients cannot change as part of status reconciliation.

## Budgets and reservations

A mandate/action budget is enforced transactionally before commitment. Concurrent actions reserve capacity against the same budget-domain fence; checking a cached “remaining amount” is insufficient. Reservations distinguish local commitment, provider pending, settlement, release and unknown. Unknown financial effects may retain a reservation until an explicit resolution policy permits release.

Time, spend, token, invocation, egress and fanout limits belong to typed policy. Approximate provider cost forecasts are labeled estimates; actual usage is admitted later. An agent cannot split work into many children to evade the parent's budget.

## Compensation and stopping

Cancellation before dispatch can prevent a new external attempt. After dispatch it may be too late. A compensating action—refund, cancellation, replacement or corrective message—is a new governed Action, not deletion of the old receipt. Emergency stop revokes new permits and stops queued work; already escaped requests remain an external-reality uncertainty that must be reconciled.

## Proof

Exercise duplicate approval, changed intent under the same key, budget races, stale recipient, revoked mandate, crash before/after provider request, lost acknowledgement, duplicate callback, partial outcome, late correction, expired provider idempotency window and compensation failure. No successful generic mock response establishes provider settlement behavior.
