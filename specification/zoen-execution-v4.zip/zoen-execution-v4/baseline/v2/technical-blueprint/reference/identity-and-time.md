# Identity and time

## Decision

Identity is an evidence-bearing interpretation. Time is a set of explicit clocks. No matching heuristic may silently collapse people, companies or accounts, and no single timestamp is asked to stand for source event time, acquisition time and system knowledge time.

## Subject model

`SubjectId` is opaque and World-scoped. `SourceRecordRef` includes source binding, namespace, external key and revision. An `IdentityAssertion` maps one record/alias to a subject for a declared valid interval and scope, with a method and supporting evidence. Candidate matches and confirmed mappings use separate states.

Blocking keys and deterministic matches reduce candidate search. Verified source identifiers may be auto-linked under a released rule. Names, phone numbers, embeddings and model scores are candidate evidence. Recycled phone numbers, shared family accounts, subsidiaries with common names and records created by multiple ERPs require explicit counterexamples.

## Merge and split

Merging does not rewrite every historical record ID. It creates a versioned equivalence/membership decision over stable IDs, with surviving public reference behavior and a graph of evidence. Splitting retracts or supersedes the relevant equivalence at a new knowledge cut. Source records remain attributable throughout.

A merge/split creates an impact plan: recompute mapped claims, interpretations, links, rights-sensitive views and identity-dependent queries; mark affected Cases stale; reassess Watches; preserve old receipts; and generate repair proposals for external records if necessary. It does not pretend an earlier external action can be undone by changing identity history.

Identity scopes cannot cross World boundaries by default. Federation exports an explicitly licensed mapping or pseudonymous reference. There is no universal cross-customer identity graph constructed secretly from household and enterprise data.

## Clocks

| Clock/basis | Meaning |
|---|---|
| `validFrom` / `validUntil` | When a proposition applies in the represented world; half-open interval |
| `sourceOccurredAt` | Source-declared event time, with timezone/precision |
| `sourceRevision` | Provider-specific ordering/correction key |
| `acquiredAt` | When the connector obtained the evidence |
| `knowledgeVersion` | Committed domain version at which Zoen admitted or changed knowledge |
| `releaseDigest` | Meaning used to interpret that knowledge |
| `evaluatedAt` | Explicit clock sample used for expiry and freshness evaluation |
| `observedSettlementAt` | When external outcome evidence was observed, distinct from provider settlement time |

A Frame uses a `WorldCut` of committed knowledge-domain versions and explicit snapshot references. This is the authoritative point-in-time reference. SQL timestamps are useful observations; they are not a globally ordered distributed commit clock.

A request like “what did we know yesterday at 10?” resolves to a retained sealed cut with declared wall-clock coverage/precision. The service must return the actual cut and any precision gap. It cannot derive an exact cross-domain knowledge state by naïvely filtering on transaction-start timestamps. Higher precision requires more frequent retained cut seals or source-supplied temporal guarantees, not a misleading timestamp column.

## Historical semantics

`asOfValidTime` and `asKnownAtCut` are independent. A corrected August invoice received in September changes present knowledge of August; an August knowledge cut still shows the earlier understanding. A historical Frame pins the old release and interpretation basis, then applies current disclosure. Historical replay never restores old authorization.

“Current” is an explicit request for a fresh cut, not a property of a cached Frame. A source can be stale even when the World cut is new. A current dataset can still contain old observations. Freshness is measured per source/field and declared in the answer.

## Scalars

Money uses decimal strings with currency and scale conventions; arithmetic uses decimal libraries, never binary floating point. Quantity carries a unit; conversion references a factor and effective basis. Date, local date-time and instant are separate scalar types. Recurring schedules bind an IANA timezone and a declared daylight-saving policy. Source precision—day, second, millisecond—is retained.

Intervals are `[from, until)`; unbounded end is explicit. Unknown start/end is not the same as infinite validity. A temporal overlap is assessed only within comparable scopes. Valid-time changes do not mutate previously admitted evidence.

## Proof

Test recycled identifiers, false merges, legitimate shared accounts, corrected historical values, identical wall-clock timestamps with different commit order, daylight-saving changes, decimal rounding, inconsistent currency conventions, and the inability of a current revocation to reveal a historical Frame.
