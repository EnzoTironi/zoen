# OSS selection and rejected shortcuts

## Selection rule

Choose the smallest maintained component that owns the required mechanism without taking ownership of Zoen's meaning, truth, permission or receipts. An open-source license does not imply that every hosted/commercial feature is included.

| Choice | Selected | Rejected or deferred | Reopen trigger |
|---|---|---|---|
| Authority access | Explicit SQL with `pg` | ORM-generated hidden transactions, generic CRUD write layer | Only a typed read builder that preserves reviewed plans and policies. |
| Ontology | Typed semantic kernel over PG + standard export profiles | Graph DB or RDF triple store as mandatory authority | Measured graph traversal failure with equivalent temporal/rights semantics. |
| Durable conversation | Owned minimal journal/turn machine | Mandatory Eve/Nitro/Workflow coupling | Alternative passes all crash, stream, authority and replay contracts with lower total complexity. |
| Dense metadata | Iceberg v2 and REST catalog | Proprietary manifest DAG as default, “latest table” reads | Catalog compatibility/retention failures require another standard implementation, not silent semantics changes. |
| Catalog | Lakekeeper OSS | Dependence on commercial Cedar authorization in catalog | Need for another REST catalog proven with pin/publication/GC suite. |
| Effects | Restate only | Generic workflow engine owning Decisions/settlements | Unsupported provider lifecycle or operational failure that cannot fit narrow attempt port. |
| Retrieval | FTS + pgvector | Mixed-tenant vector service as policy authority | Authorized retrieval latency/scale justifies external indexes with identical leakage tests. |
| Execution | OCI under strong isolation | In-process plugins, arbitrary model-generated SQL with authority credentials | No relaxation; different sandbox only with equivalent adversarial proof. |
| UI | Declarative surfaces + isolated executable apps | LLM-generated privileged DOM/actions without a manifest | No relaxation; add signed reviewed capabilities. |
| Testing | Laws, components and journeys | Original blanket prohibition of unit tests; mocks as integration proof | Property assertions remain pure; production claims always need real boundaries. |

## License and supply-chain admission

Record SPDX license, transitive notice obligations, commercial limits, maintainer/release status, security advisories and exact artifact digest. Run dependency/secret scanning; require two-person review for privileged adapter updates. A vulnerable package recall can disable its installed capability immediately; existing receipts retain the historical artifact digest. Test backward compatibility of queued jobs and parked Cases before an upgrade.

The chosen families are design inputs, not a statement that their combined license/security posture has passed a production procurement audit. An enterprise edition, support agreement, data license or provider sandbox is a separate deliverable with a named owner. [S16, S18, S24, S32]
