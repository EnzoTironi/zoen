# Repository and modules

## Decision

Use one pnpm workspace and one reviewable application codebase, not one process for every trust class. Product imports have a directed ownership graph. Deployable commands consume the same signed build provenance; untrusted artifacts have a different image, credential boundary and release process.

```text
apps/
  edge/                 # Hono public routes, Door, webhook admission, SSE
  eve-worker/           # fenced conversational turns and delivery arbitration
  authority-worker/     # interpretation, projections, Watches, release preparation
  effect-worker/        # Restate endpoint + narrow EffectBroker client
  web/                  # Eve and Living World / builder workbench
  cli/                  # generated semantic client, never a DB client
packages/
  kernel/               # branded types, canonical values, errors, pure invariants
  door/                 # Better Auth adapter + assertion interface
  ontology/
    definitions/        # grammar, compiler, release proofs and package graph
    identity/           # stable subjects, identity assertions and resolution
    evidence/           # capture, admission, claims and provenance
    interpretation/     # deterministic plans and impact propagation
    authority/          # sessions, guards, Cases, commits and receipts
    attention/          # Watches, Notices and bounded Mandates
    datasets/           # snapshot admission, quality and live capture
    surfaces/           # operation manifests, discovery and generated contracts
  eve/                  # journal, turn machine, Focus, context and delivery
  adapters/
    postgres/           # owner-scoped repositories + authored SQL
    object-store/       # encrypted evidence, retention and pins
    policy-cedar/       # exact authorization + restricted planning profile
    models/             # AI SDK providers and permitted model routing
    channels/           # Kapso, web, Telegram, Resend
    restate/            # external attempt transport, not canonical outcome
    datasets/           # DuckDB, Iceberg REST catalog
  clients/              # typed internal and generated public clients
  telemetry/            # redaction, tracing, operational metrics
  testing/              # deterministic law generators and real journey harness
runners/
  connector/            # separate OCI image, no authority credentials
  analysis/             # Python/SQL/R/custom compute under isolated leases
infra/
  compose/              # reproducible development, not production security
  terraform/aws/        # primary hosted profile and regional cell module
contracts/              # reviewed public schemas and compatibility fixtures
journeys/               # user outcomes, hostile inputs and recovery gates
```

## Import laws

`kernel` imports no owner, adapter or application. Ontology knows ports, not Eve or channel providers. Door does not import domain authority. Eve receives typed semantic capabilities; it cannot import the PostgreSQL adapter, an Ontology repository, compiler internals or storage credentials. The web/CLI/SDK have no privileged database dependency. Adapters implement ports and may not create a second semantic mutation API.

Business packs are release data, not new `packages/customer-X` directories. A genuinely new privileged kernel operation follows a reviewed deployment; arbitrary customer-specific code is never conditionally loaded into authority.

Use dependency-cruiser plus ESLint boundaries as static gates. An implementation may colocate trusted workers in a developer process with explicit interfaces; production Eve communicates through authenticated, request-bound internal semantic endpoints so compromise of the conversation process does not expose authority credentials. One codebase is not proof of isolation.

## Database roles and ownership

Keep `door`, `ontology`, `eve`, `channels`, `jobs` and `audit` explicit schemas/roles on the initial managed PostgreSQL cluster; use separate databases for catalog and externally owned runtime stores when installed. Migration roles own DDL; runtime roles do not. Authority service alone holds authority mutation credentials. Eve holds only its journal role; channel ingress holds only admission/outbox privileges. Analytics gets no authority credential. Cross-schema access is a narrow repository contract, not `SELECT *` over every schema.

Do not use a cross-database transaction to pretend that inbox admission and semantic action are atomic. Stable event IDs, outboxes and idempotent handoff join those owners.

## Build and operational entrypoints

Required scripts: `check`, `test:law`, `test:component`, `test:journey`, `test:chaos`, `migrate:plan`, `migrate:apply`, `release:compile`, `release:evaluate`, `release:prepare`, `release:activate`, `start:edge`, `start:eve`, `start:authority`, `start:effects`. Runtime release commands use the same authenticated domain operations as Studio/CLI, not private admin SQL.

Pin dependencies, Node, compiler, image bases, native extensions, generated schemas and provider API versions in a reviewed lock manifest. Freeze pnpm resolution, restrict lifecycle build scripts, generate an SBOM and provenance, and sign deployable images. No `latest` image tag is a release identity.

## Reuse from OS

Inventory existing code by invariant and tests: authentication adapters, provider wiring, UI components and domain vocabulary are candidates. Do not automatically port the Rust kernel, database schema or old Eve execution topology. Public repository inspection established documented shape, not a tested implementation baseline. Track each reused component's provenance, license and passed journey in the migration ledger. [S29, S30]
