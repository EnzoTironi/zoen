# Data, events, Parquet and Iceberg

## Decision

Use three different physical representations for three different jobs: sparse PostgreSQL authority; immutable evidence objects; dense Parquet tables managed by Apache Iceberg. Search indexes and live overlays are projections/observations, not additional truth stores. Do not create one graph node and event per raw data point.

This supersedes the custom dense manifest DAG as a storage-engine implementation. Zoen still controls which immutable snapshot set is published; it does not reimplement an entire table format. Iceberg and DuckDB provide documented physical mechanisms [S14–S16]; multi-system publication correctness remains Zoen's responsibility.

## Sparse authority

Operational entities, source identity mappings, claim metadata, resolution decisions, interpretations, Cases, rights, Watches, Mandates and receipts live in PostgreSQL. Structured JSONB stores schema-validated values and manifest bodies; typed index columns cover common predicates, validity, World/domain and security partitions. Releases define the logical schema. They do not run arbitrary DDL.

Do not put every raw ERP row, document token or market tick into an EAV table. Preserve bulk rows in datasets and project only released operational subjects/claims needed by actions, explanations and material change. Entity and claim materialization has a declared policy, quota and lineage.

## Raw evidence

Encrypted object storage contains original files/messages/captures when lawful, source manifests and permitted retained extracts. Objects use immutable version IDs/checksums and scoped encryption; an object-store listing is never a semantic source of truth. Admission verifies that the referenced object is durably readable before a PostgreSQL commit refers to it.

Evidence may be reference-only when retention is prohibited. In that case provenance and replay guarantees are explicitly weaker. An operation that requires immutable captured evidence is blocked when the license forbids retaining a sufficient basis.

## Dense snapshots

A `DatasetVersion` includes logical dataset ID, schema/field semantic IDs, Iceberg table UUID, exact immutable metadata location, metadata digest, snapshot ID, partition-spec identity, provenance, input versions, rights, quality result, watermarks and retention pins. Snapshot IDs and versions are represented as strings to avoid JavaScript integer truncation.

Parquet is the data format; Iceberg v2 is the initial interoperable table profile. Unsupported features, row-level delete modes, timestamp semantics and writer versions are explicitly gated. DuckDB Node Neo runs in bounded analytical workers. Lakekeeper OSS provides the REST catalog and uses a separate PostgreSQL database; its infrastructure ACLs do not replace World disclosure policy.

The dense stack first activates when S7 requires it. A personal pilot can deliver useful sparse claims and raw evidence without starting a catalog service. This is activation order, not a promise to handle enterprise datasets with ad hoc JSON files.

## Publish protocol: no imaginary cross-system transaction

1. A data-flow run writes objects and a staged Iceberg snapshot through the catalog, under a unique run/table branch or equivalent isolated namespace.
2. Validate exact schema, metadata digest, completeness, input cuts, source rights and quality. Create and verify physical retention pins for all files/snapshots required by publication.
3. Propose a DatasetVersion. PostgreSQL AuthorityCommit atomically publishes its immutable reference, derived semantic changes and events. No read follows the catalog's mutable “latest” pointer.
4. After commit, finalize maintenance bookkeeping. Failed bookkeeping is retried without changing the published snapshot identity. A failed authority commit leaves a staged orphan for cleanup, not partially published data.

Retention pins must exist before publication. Catalog garbage collection cannot expire a published snapshot or its underlying files while lawful replay still requires it. The GC service checks the authoritative pin registry and storage/catalog references. If a chosen catalog cannot enforce this protocol, the dense profile remains blocked until an adapter is proved.

Several DatasetVersions can be published atomically in one local authority transaction after all are staged. This provides a coherent published snapshot set, not a globally atomic transaction across independent providers or engines. External inputs retain their different observation times.

## Reads and time travel

A WorldFrame pins published snapshot references from one PostgreSQL cut. Dataset readers open the exact metadata/snapshot; they do not resolve a mutable table name and call the result historical. Derived metrics cite the release, input snapshot set, query plan and calculation version. Source event/valid time remains separate from snapshot commit time.

A historical snapshot unavailable because of lawful erasure or license expiry returns `EvidenceUnavailable` with a permitted reason. “Immutable” means no silent rewriting while retained, not eternal retention in violation of privacy or contract.

## Live observations

Live envelopes contain feed identity, instrument/subject alias, provider sequence, event/acquisition clocks, quality, entitlement and staleness. They are a visibly transient overlay on a Frame. Late/out-of-order events follow the feed contract; gaps remain visible. Conflation is explicitly declared and cannot support a use case requiring every event.

A consequential action captures an exact live observation, verifies entitlement and maximum age, admits the capture as evidence and includes it in the Case read dependencies. A browser's last displayed price is not an action basis. Batches of feed observations are sealed into dense snapshots with source sequence coverage and gap metadata.

## Events

Emit semantic consequences such as EvidenceAdmitted, InterpretationChanged, IdentityResolved, ReleaseActivated, CaseCommitted, NoticeCreated and SettlementObserved. An event includes World/realm, commit ID, per-domain versions, release, causation, correlation, source/action reference and disclosure classification.

The outbox is committed with authority state. At-least-once consumers use inbox deduplication and persist their result/cursor atomically. Cursors are per domain/stream, not an invented universal clock. Poison events block or isolate the affected subscription explicitly; skipping one is a governed operational decision.

## Derived indexes

PostgreSQL FTS, pgvector, object-set caches and UI projections carry generation, release and knowledge watermarks. They are replaceable. An answer that requires a fresher basis waits, computes through a bounded direct path or reports staleness. Index rebuilding cannot make a new semantic generation partially authoritative.

## Proof

Test staged-object orphan cleanup, commit failure after a catalog write, metadata mutation/digest mismatch, published-snapshot GC denial, delete-vector compatibility, integer/timezone round trips, partial data-flow failure, hidden lineage, stale index and capture-at-action races. No pilot throughput is extrapolated to a Fortune 500 without the capacity gate.
