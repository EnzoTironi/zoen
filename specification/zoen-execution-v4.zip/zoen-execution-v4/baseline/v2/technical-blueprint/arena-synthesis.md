# Architecture synthesis and alternatives

## Method

This is a single integrated design review, not a claim that independent agents, production experiments or quantitative benchmark judges were run. Alternatives were compared against the user's ambition, original ZIP and primary documentation. No invented weighted score is used.

## Alternatives considered

**Chatbot + connectors + vector search:** fastest superficial demo, but weak native treatment of identity/time/conflicts and consequential actions. Retain retrieval as a projection, not the authority model.

**Generic agent platform as the OS:** rich extensibility, but turns prompts/tools into an implicit schema and makes authority depend on agent execution. Retain agents as leased proposers/executors over released semantic operations.

**Full graph/triple-store foundation:** strong relationship representation and standard exchange, but does not alone solve scoped truth, local transactional effects, policy planning or accessible authoring. Adopt interoperable identifiers/provenance/shapes without mandating graph storage for every workload.

**Enterprise data platform shrunk into WhatsApp:** preserves institutional power but risks requiring integration/modeling work before first value. Adopt progressive packs and partial honest Worlds rather than forcing an enterprise implementation project on a person.

**Original strict monolith with proprietary dense manifests and mandatory conversation framework:** valuable ownership/invariants, but unnecessary coupling in storage interoperability, runtime product identity and scale head contention. Preserve the authority laws; revise physical and framework choices.

## Selected shape

A small governed semantic kernel; released, composable definitions; attributed evidence and interpretations; a relationship layer; and isolated effect/compute adapters. Physical cells scale independently while preserving one authority owner per World epoch. Variation is data when expressible in the existing grammar, sandboxed artifacts when it introduces new computation, and code only when it changes the privileged kernel.

## Why not simply fewer components?

An untrusted connector, model, bank and local authority have different trust/failure semantics. Merging them into one process does not remove those differences; it hides them. Conversely, a different business label is not a reason to create a new service. Boundaries follow ownership and failure, not nouns in a diagram.
