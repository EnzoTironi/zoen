# Implementation sequence — outcome-first execution

## Sequencing rule

Build one whole truthful user outcome at a time. S0–S4 prove the core relationship, reconciliation, runtime learning and accountable agency. S5–S8 expand information depth and extensibility. S9–S11 admit institutional operations, federation and full finance execution. Later installation is not an architectural ceiling.

Core authorization, evidence separation, idempotency and evaluation isolation begin at S0; later slices deepen them. No slice may waive those laws to create a demo. Domain work can proceed in parallel behind disabled capability flags after its dependencies exist, but production activation requires the explicit gates. No calendar estimates or staffing assumptions are invented here.

Every slice produces code, contracts, migrations, operator runbooks, accessible user flow, evidence report and deletion of temporary shortcuts. A service installed without an outcome does not finish a slice.

## S0: One small, truthful outcome

**Depends on:** None.

**User outcome:** Create a private World and inspect two uploaded synthetic/authorized records with an honest conflict through web and CLI.

**Build:** Workspace/locks, Door, head/domains, source staging/admission, claim/interpretation vertical slice, typed semantic API, explicit PG roles, outbox, observability and evaluation realm.

**Proof:** J01; actual transaction/role tests, duplicate admission, scope/time normalization, restore rehearsal and no external dispatch.

**Accountable functions:** Kernel + data + security.

**Delete before exit:** Remove generic CRUD starter paths, broad runtime roles and invented happy-path providers.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S1: A continuous useful relationship

**Depends on:** S0.

**User outcome:** Ask through WhatsApp/web, receive evidence and answer one scoped clarification without losing context.

**Build:** Eve journal/turn state machine, AI SDK adapters, Kapso signed ingress, consent binding, basic accessible Living World, attachment quarantine, identity-resolution Case and user-claim correction.

**Proof:** J01/J02; kill around ingress/model/stream/tool handoff, wrong reply reversal, revoked access and same operation semantic parity.

**Accountable functions:** Experience + kernel + integrations.

**Delete before exit:** Remove alternate replay journals and all default arbitrary shell/file/web tools.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S2: Teach the World in runtime

**Depends on:** S1.

**User outcome:** Configure a source mapping or business rule and activate it without deploying the application.

**Build:** Definition graph/compiler, JSON schemas/IR, risk classes, source HTTP/OAuth plans, semantic diff, EvaluationWorld, prepared activation, domain packs and dynamic discovery.

**Proof:** J02/J04/J05; self-escalation denial, open-Case staleness, current-policy approval, rollback as forward repair and canonical release determinism.

**Accountable functions:** Kernel + data + builder experience.

**Delete before exit:** Remove code branches that specialize the application by customer/profession.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S3: Share safely and earn an interruption

**Depends on:** S2.

**User outcome:** A family/team shares one concern with restricted views and a quiet Watch.

**Build:** Membership/delegation/step-up, source ACL synchronization, hidden-rival perspective rules, Watch/Notice semantics, attention budget, deletion lifecycle and group audience checks.

**Proof:** J03/J07/J12; hidden field/count/identity leaks, revocation while deferred, source ACL expiry and correction impact tests.

**Accountable functions:** Security + experience + data.

**Delete before exit:** Remove notification paths that accept unrestricted payloads or inherit channel presence as permission.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S4: Take one consequential action honestly

**Depends on:** S3.

**User outcome:** Approve a bounded real-world action and see local decision, external result and goal status separately.

**Build:** ActionCase guards, stable receipts/effects, Restate narrow executor, provider idempotency/reconciliation, reservation budgets, bounded Mandate and outcome observation.

**Proof:** J08/J14; provider accepts then loses reply, cancellation race, duplicate callbacks, predicate insertion, budget fanout and crash after commit.

**Accountable functions:** Kernel + integrations + operations.

**Delete before exit:** Remove blind unsafe retries and success flags based only on local task completion.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S5: Search and inspect the same world

**Depends on:** S4.

**User outcome:** Find authorized evidence across connected sources and deepen the conversation into accessible tables/charts.

**Build:** FTS/pgvector authorized projections, constrained query planning, chart/view contracts, richer Focus, Telegram/email adapters, model routing and SDK/MCP conformance.

**Proof:** J09; source ACL before ranking/aggregation, prompt injection, stale projection cut, missing values and cross-channel continuity.

**Accountable functions:** Data + experience + platform.

**Delete before exit:** Remove direct visualization/index queries that bypass the semantic surface.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S6: Install new computation safely

**Depends on:** S5.

**User outcome:** An authorized user/agent proposes a custom connector or skill and activates a reviewed isolated artifact.

**Build:** Signed artifacts, build provenance, runner pool, capability brokers, egress/resource controls, allowed skill manifests, evaluation sinks and recall.

**Proof:** J06; hostile SSRF, metadata access, sandbox resource exhaustion, revoked leases, signature substitution and child-budget tests.

**Accountable functions:** Platform + security + operations.

**Delete before exit:** Remove in-process plugin loaders and ambient source/effect credentials.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S7: Unify dense and live data without losing history

**Depends on:** S6.

**User outcome:** Reconcile ERP/CRM/bank metrics over large immutable datasets and inspect exact historical/live bases.

**Build:** Iceberg/Parquet, Lakekeeper catalog, DuckDB bounded workers, pin-before-publish, lineage/quality gates, CDC/stream DAGs, live gaps/watermarks and capture-before-action.

**Proof:** J04/J10; catalog/PG crash boundary, snapshot GC race, CDC gaps, late corrections, entitlement expiry and workload benchmark report.

**Accountable functions:** Data + kernel + operations.

**Delete before exit:** Remove proprietary latest-manifest shortcuts and raw-tick-to-Eve fanout.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S8: Build governed apps and analytical scenarios

**Depends on:** S7.

**User outcome:** Create a domain app/workflow and a what-if analysis using runtime definitions, then propose a fresh live action.

**Build:** Executable isolated apps, MCP Apps negotiation, runtime Studio, branches/rebase, static SDK generation, notebooks/training/model artifacts, package dependency/upgrade tools.

**Proof:** J05/J09; app-origin bridge, stale SDK contract, isolated scenario effects, package upgrade conflict and rights-preserving analysis output.

**Accountable functions:** Builder platform + security + experience.

**Delete before exit:** Remove analysis notebooks or app components with direct authority write credentials.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S9: Admit an institutional operating profile

**Depends on:** S8.

**User outcome:** An enterprise uses dedicated identity, residency, recovery and audit controls at a demonstrated workload.

**Build:** SSO/SCIM, dedicated AWS cells, RDS HA/restore, admitted Restate HA, key/secret lifecycle, support access, SIEM/audit exports, load/fairness and deletion drills.

**Proof:** J03/J10/J12; real failover, RPO/RTO measurement, deprovisioning, restored deletion suppression, security review and cost/contract evidence.

**Accountable functions:** Operations + security + enterprise data.

**Delete before exit:** Remove claims of enterprise readiness unsupported by measured operating artifacts.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S10: Coordinate independent Worlds and regions

**Depends on:** S9.

**User outcome:** Move a World without split brain and coordinate with another organization under separate authority.

**Build:** Fenced cell directory/epochs, migration protocol, federated Frames, local coordinated Cases, private/edge connectors, offline child scope and fleet policy.

**Proof:** J11; partition/promotion race, stale routing, escaped effect during migration, independent cut skew and offline expiry.

**Accountable functions:** Platform + kernel + operations.

**Delete before exit:** Remove assumptions of global ACID, automatic shared grants or dual live World writers.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## S11: Prove the full finance execution grammar

**Depends on:** S10 plus licenses/provider contracts.

**User outcome:** Trace an authorized instrument/order from evidence through partial fills/corrections to actual settlement.

**Build:** Security master, point-in-time corpora, market depth/gaps/entitlements, corporate actions, risk/limits, OMS/broker/custody connectors, supervised collaboration and provider certification.

**Proof:** J13; partial fill/bust/cancel race, stale quote, entitlement expiry, reconciliation and separately approved legal/commercial operating gate.

**Accountable functions:** Finance domain + integrations + security + operations.

**Delete before exit:** Remove any claim that generic APIs supply licensed data, financial authorization or institutional certification.

**Exit:** reproducible evidence at the required level, current contracts/schemas and all matrix capabilities for this slice classified honestly. Missing external evidence leaves that route disabled rather than represented as success.

## First implementation request

Implement S0 only as one vertical outcome, following the decision register. Produce an exact execution lock after verifying package composition, the reviewed authority schema/migrations, real role/isolation tests, a file-based divergence journey and a local evidence report. Do not install every S7/S9 service or build a generic admin CRUD scaffold first. The reference types/SQL/Python in this package are inputs to refine, not a complete kernel to paste unreviewed.

## Commercial/operational gates outside code

WhatsApp/provider terms and costs; source/market-data licenses and permissible model use; enterprise lawful basis/residency/security contracts; clinical and financial scope review; sandbox/provider accounts; operational on-call ownership; support and publisher marketplace terms. Each gate has an accountable owner before enabling the affected route. Architecture cannot replace it.
