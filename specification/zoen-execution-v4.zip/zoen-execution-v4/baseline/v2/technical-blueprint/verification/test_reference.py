"""Synthetic law tests only; no real DB, ACL engine, channel or provider exercised."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'examples'))
from reconciliation_spec import *
from dataclasses import replace
from itertools import permutations
import unittest

DAY = date(2026, 9, 4)


def c(id='a', value='100.00', source='erp', family='erp', **kw):
    args=dict(id=id,subject='customer:1',predicate='invoice.amount',scope='invoice:123',unit='BRL',
              value=value,source=source,family=family,revision=1,knowledge=1,valid_from=date(2026,9,1))
    args.update(kw)
    return Claim(**args)


def q(*claims, **kw):
    args=dict(subject='customer:1',predicate='invoice.amount',scope='invoice:123',unit='BRL',
              valid_at=DAY,cut=10,allowed_claim_ids=frozenset(x.id for x in claims))
    args.update(kw)
    return Query(**args)

SOR=Policy('source_of_record',preferred_source='erp')


class ReconciliationLaws(unittest.TestCase):
    def test_source_choice_preserves_disagreement(self):
        a,b=c(),c('b','120','sheet','sheet')
        r=resolve([a,b],q(a,b),SOR)
        self.assertEqual((r.status,r.value,r.contested),('selected','100',True))
        self.assertEqual(r.rival_ids,('b',))
        self.assertEqual(r.verification,'unverified')

    def test_different_metrics_are_not_conflicts(self):
        a,b=c(),c('b','120',predicate='cash.received')
        self.assertFalse(resolve([a,b],q(a,b),SOR).contested)

    def test_different_scope_is_not_conflict(self):
        a,b=c(),c('b','120',scope='invoice:456')
        self.assertFalse(resolve([a,b],q(a,b),SOR).contested)

    def test_currency_mismatch_not_compared(self):
        a,b=c(),c('b','20',unit='USD')
        self.assertFalse(resolve([a,b],q(a,b),SOR).contested)

    def test_subject_mismatch_not_compared(self):
        a,b=c(),c('b','120',subject='customer:2')
        self.assertFalse(resolve([a,b],q(a,b),SOR).contested)

    def test_copied_sources_do_not_form_quorum(self):
        a,b=c(),c('b',source='erp-export',family='erp')
        self.assertEqual(resolve([a,b],q(a,b),Policy('independent_quorum')).status,'unresolved')

    def test_independent_quorum_can_select(self):
        a,b=c(),c('b',source='signed-invoice',family='invoice')
        self.assertEqual(resolve([a,b],q(a,b),Policy('independent_quorum')).value,'100')

    def test_conflicting_family_does_not_vote(self):
        a,b,d=c(),c('b','110','erp-copy','erp'),c('d','100','audit','audit')
        self.assertEqual(resolve([a,b,d],q(a,b,d),Policy('independent_quorum')).status,'unresolved')

    def test_two_sufficient_quorums_remain_unresolved(self):
        cs=[c('a',family='1'),c('b',family='2'),c('c','110',family='3'),c('d','110',family='4')]
        self.assertEqual(resolve(cs,q(*cs),Policy('independent_quorum')).status,'unresolved')

    def test_hidden_source_does_not_influence_view(self):
        a,b=c(),c('hidden','999','secret','secret')
        self.assertEqual(resolve([a,b],q(a),SOR),resolve([a],q(a),SOR))

    def test_revision_order_requires_source_contract(self):
        a,b=c(),c('b','120',revision=2)
        self.assertEqual(resolve([a,b],q(a,b),SOR).status,'unresolved')
        p=replace(SOR,monotonic_sources=frozenset({'erp'}))
        self.assertEqual(resolve([a,b],q(a,b),p).value,'120')

    def test_historical_cut_excludes_later_claim(self):
        a,b=c(),c('b','120',revision=2,knowledge=11)
        p=replace(SOR,monotonic_sources=frozenset({'erp'}))
        self.assertEqual(resolve([a,b],q(a,b),p).value,'100')

    def test_retraction_keeps_old_cut_explainable(self):
        a=c(retracted_at=8)
        self.assertEqual(resolve([a],q(a,cut=7),SOR).value,'100')
        self.assertEqual(resolve([a],q(a,cut=8),SOR).status,'unknown')

    def test_wrong_human_answer_is_not_verified_truth(self):
        a=c(source='human',family='human',retracted_at=8)
        p=Policy('authorized_attestation',attested_claim_ids=frozenset({'a'}))
        self.assertEqual(resolve([a],q(a,cut=7),p).verification,'attested')
        self.assertEqual(resolve([a],q(a,cut=8),p).status,'unknown')

    def test_unapproved_attestation_does_not_select(self):
        a=c(source='human',family='human')
        self.assertEqual(resolve([a],q(a),Policy('authorized_attestation')).status,'unresolved')

    def test_half_open_valid_interval(self):
        a=c(valid_until=DAY)
        self.assertEqual(resolve([a],q(a),SOR).status,'unknown')

    def test_unknown_is_not_zero(self):
        r=resolve([],q(),SOR)
        self.assertIsNone(r.value)

    def test_duplicates_do_not_change_resolution(self):
        a=c()
        self.assertEqual(resolve([a,a],q(a),SOR),resolve([a],q(a),SOR))

    def test_immutable_id_payload_conflict_rejected(self):
        a,b=c(),c(value='120')
        with self.assertRaises(ValueError): resolve([a,b],q(a,b),SOR)

    def test_permutation_invariance(self):
        cs=[c(),c('b','120','sheet','sheet'),c('c','100','audit','audit')]
        expected=resolve(cs,q(*cs),SOR)
        for ordered in permutations(cs): self.assertEqual(resolve(ordered,q(*cs),SOR),expected)

    def test_decimal_equivalence(self):
        a,b=c(value='100.0'),c('b','100.00','sheet','sheet')
        self.assertFalse(resolve([a,b],q(a,b),SOR).contested)

    def test_manual_policy_never_silently_accepts(self):
        a=c()
        self.assertEqual(resolve([a],q(a),Policy('manual')).status,'unresolved')

    def test_nonfinite_and_exponent_values_rejected(self):
        for value in ['NaN','Infinity','1e3','01','','9'*129]:
            with self.assertRaises(ValueError): c(value=value)

    def test_invalid_interval_rejected(self):
        with self.assertRaises(ValueError): c(valid_until=date(2026,8,1))


class AuthorityReferenceLaws(unittest.TestCase):
    def test_same_intent_returns_same_receipt(self):
        ledger=ReferenceLedger();key=('world','user','send','op1')
        self.assertEqual(ledger.commit(key,'digest',authorized=True),ledger.commit(key,'digest',authorized=True))

    def test_different_intent_conflicts(self):
        ledger=ReferenceLedger();key=('world','user','send','op1')
        ledger.commit(key,'first',authorized=True)
        with self.assertRaises(IntentConflict):ledger.commit(key,'second',authorized=True)

    def test_replay_requires_fresh_rights(self):
        ledger=ReferenceLedger();key=('world','user','send','op1')
        ledger.commit(key,'first',authorized=True)
        with self.assertRaises(PermissionError):ledger.commit(key,'first',authorized=False)

    def test_operation_scope_is_not_global(self):
        ledger=ReferenceLedger()
        a=ledger.commit(('world1','user','send','op1'),'d',authorized=True)
        b=ledger.commit(('world2','user','send','op1'),'d',authorized=True)
        self.assertNotEqual(a,b)

    def test_predicate_insert_changes_fence(self):
        h=('epoch1','release1','generation1','rights1')
        self.assertTrue(case_is_stale(h,h,{'invoice-partition':5},{'invoice-partition':6},now=1,expires=2))

    def test_expired_and_changed_head_are_stale(self):
        self.assertTrue(case_is_stale(('a',),('b',),{}, {},now=0,expires=2))
        self.assertTrue(case_is_stale(('a',),('a',),{}, {},now=2,expires=2))

    def test_unchanged_complete_guard_is_current(self):
        self.assertFalse(case_is_stale(('a',),('a',),{'p':1},{'p':1,'unrelated':10},now=1,expires=2))

    def test_missing_fence_fails_closed(self):
        self.assertTrue(case_is_stale(('a',),('a',),{'p':1},{},now=1,expires=2))

    def test_unsafe_unknown_effect_is_not_retried(self):
        self.assertFalse(retry_unknown_effect(provider_idempotent=False,currently_authorized=True))
        self.assertFalse(retry_unknown_effect(provider_idempotent=True,currently_authorized=False))
        self.assertTrue(retry_unknown_effect(provider_idempotent=True,currently_authorized=True))

    def test_budget_exact_decimal_and_limit(self):
        self.assertEqual(reserve('0.30','0.10','0.20'),'0.3')
        self.assertEqual(reserve('1'+'0'*60,'9'*60,'1'),'1'+'0'*60)
        with self.assertRaises(ValueError):reserve('10','9','2')
        with self.assertRaises(ValueError):reserve('10','0','-1')

if __name__ == '__main__': unittest.main()
