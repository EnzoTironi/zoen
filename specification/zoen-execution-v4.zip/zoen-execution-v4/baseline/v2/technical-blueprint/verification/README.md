# Verification scope and reproducibility

Run from the extracted package root:

```sh
python tools/verify_package.py
```

Prerequisites: Python 3.10+ and `jsonschema`; a local `tsc` enables the representative TypeScript checks. The script does not access the network, provider accounts or databases. Read [report.json](report.json) for the actual tool versions, counts and test outputs from this session.

## What is checked

Portable active Markdown target links, JSON parsing, four structural JSON schemas and four synthetic examples, five schema rejection fixtures, capability/ADR/slice/journey references, archived original Markdown hashes, representative TypeScript types including realm-separation negative tests, and 34 deterministic Python reference tests. Once generated, the package manifest checks all fixed content hashes. Report and manifest self-hashes are excluded deliberately to avoid a circular checksum.

The Python tests cover selected laws: metric/scope/unit/identity comparability, source-family independence, current-cut eligibility, reversible retraction, scoped attestation, input-order invariance, immutable-ID conflicts, exact decimal budget examples, scoped operation idempotency, fresh authorization for replay, conservative predicate guards and unsafe-Unknown retry refusal. They are **not real transaction concurrency tests**. Caller-supplied authorized claim IDs and attestation/source contracts are synthetic inputs, not an implementation of Cedar or source ACL synchronization.

## What is not checked

The complete application, the proposed production dependency set, SQL execution or database roles, actual provider behavior, deployment, security isolation, restore/failover, catalog/GC publication races, licensed data, legal/commercial permissions and Mermaid rendering. Neither a passing schema nor TypeScript compilation proves authorization, semantic correctness of all domains or institutional scalability.

The local compiler may differ from the selected target compiler. The report states its actual version; this is not evidence that Node 24, TypeScript 6/7, native adapters and the complete production stack were installed together. The supplied SQL is a design slice that still needs complete migrations, grants/policies, histories, Case/approval storage and real transaction tests.

## Evidence interpretation

`LocalReferencePassed` applies only to these files and checks. The 157 capability rows remain `DesignOnly` until implementation supplies their actual evidence gates. Canonical journeys are acceptance specifications, not tests executed in this session. No certification, production readiness or Palantir/Bloomberg parity follows from this report.
