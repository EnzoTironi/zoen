-- REFERENCE SLICE ONLY. Not the complete migrations or permission model.
-- PostgreSQL 18 design input; this file was NOT executed against PostgreSQL here.
BEGIN;
CREATE SCHEMA IF NOT EXISTS zoen_reference;
REVOKE ALL ON SCHEMA zoen_reference FROM PUBLIC;
CREATE TABLE zoen_reference.world_head (
  realm text NOT NULL CHECK (realm IN ('live','evaluation')),
  world_id uuid NOT NULL,
  cell_id text NOT NULL,
  epoch bigint NOT NULL CHECK (epoch > 0),
  release_digest text NOT NULL,
  generation_id uuid NOT NULL,
  security_revision bigint NOT NULL CHECK (security_revision >= 0),
  PRIMARY KEY (realm, world_id)
);
CREATE TABLE zoen_reference.commit_domain (
  realm text NOT NULL, world_id uuid NOT NULL, domain_id text NOT NULL,
  version bigint NOT NULL DEFAULT 0 CHECK (version >= 0),
  PRIMARY KEY (realm, world_id, domain_id),
  FOREIGN KEY (realm, world_id) REFERENCES zoen_reference.world_head(realm,world_id)
);
CREATE TABLE zoen_reference.evidence (
  realm text NOT NULL, world_id uuid NOT NULL, evidence_id uuid NOT NULL,
  source_binding text NOT NULL, source_key text NOT NULL, source_revision text NOT NULL,
  object_key text NOT NULL, content_digest text NOT NULL, rights_ref text NOT NULL,
  acquired_at timestamptz NOT NULL, retention_class text NOT NULL,
  PRIMARY KEY (realm,world_id,evidence_id),
  UNIQUE (realm,world_id,source_binding,source_key,source_revision),
  FOREIGN KEY (realm,world_id) REFERENCES zoen_reference.world_head(realm,world_id)
);
CREATE TABLE zoen_reference.claim (
  realm text NOT NULL, world_id uuid NOT NULL, claim_id uuid NOT NULL,
  subject_id uuid NOT NULL, predicate_id text NOT NULL, scope jsonb NOT NULL,
  value jsonb NOT NULL, source_family text NOT NULL, asserted_by text NOT NULL,
  evidence_id uuid NOT NULL, domain_id text NOT NULL, knowledge_version bigint NOT NULL,
  valid_from timestamptz NOT NULL, valid_until timestamptz,
  PRIMARY KEY (realm,world_id,claim_id),
  CHECK (valid_until IS NULL OR valid_until > valid_from),
  CHECK (jsonb_typeof(scope) = 'object'),
  FOREIGN KEY (realm,world_id,evidence_id) REFERENCES zoen_reference.evidence(realm,world_id,evidence_id),
  FOREIGN KEY (realm,world_id,domain_id) REFERENCES zoen_reference.commit_domain(realm,world_id,domain_id)
);
CREATE INDEX claim_lookup ON zoen_reference.claim(realm,world_id,subject_id,predicate_id,knowledge_version);
CREATE TABLE zoen_reference.decision_receipt (
  realm text NOT NULL, world_id uuid NOT NULL, receipt_id uuid NOT NULL,
  principal_id uuid NOT NULL, operation_name text NOT NULL, operation_id text NOT NULL,
  intent_digest text NOT NULL, case_digest text NOT NULL, commit_id uuid NOT NULL,
  released_operation text NOT NULL, cut jsonb NOT NULL, committed_at timestamptz NOT NULL,
  PRIMARY KEY (realm,world_id,receipt_id),
  UNIQUE (realm,world_id,principal_id,operation_name,operation_id),
  FOREIGN KEY (realm,world_id) REFERENCES zoen_reference.world_head(realm,world_id)
);
CREATE TABLE zoen_reference.effect_intent (
  realm text NOT NULL, world_id uuid NOT NULL, effect_id uuid NOT NULL,
  receipt_id uuid NOT NULL, intent_digest text NOT NULL, provider text NOT NULL,
  provider_operation text NOT NULL, stable_key text NOT NULL, payload_ref text NOT NULL,
  PRIMARY KEY (realm,world_id,effect_id),
  UNIQUE (realm,world_id,provider,stable_key),
  FOREIGN KEY (realm,world_id,receipt_id) REFERENCES zoen_reference.decision_receipt(realm,world_id,receipt_id)
);
CREATE TABLE zoen_reference.outbox (
  realm text NOT NULL, world_id uuid NOT NULL, event_id uuid NOT NULL,
  commit_id uuid NOT NULL, kind text NOT NULL, reference_id uuid NOT NULL,
  created_at timestamptz NOT NULL, lease_owner text, lease_fence bigint NOT NULL DEFAULT 0,
  lease_until timestamptz, delivered_at timestamptz,
  PRIMARY KEY (realm,world_id,event_id),
  FOREIGN KEY (realm,world_id) REFERENCES zoen_reference.world_head(realm,world_id)
);
-- RLS is fail-closed until the real migration defines reviewed per-role policies.
ALTER TABLE zoen_reference.claim ENABLE ROW LEVEL SECURITY;
ALTER TABLE zoen_reference.claim FORCE ROW LEVEL SECURITY;
ALTER TABLE zoen_reference.evidence ENABLE ROW LEVEL SECURITY;
ALTER TABLE zoen_reference.evidence FORCE ROW LEVEL SECURITY;
COMMIT;
-- Actual AuthorityCommit additionally needs current rights, immutable history/retractions,
-- ActionCase/approval tables, receipt append-only roles, expected head/domain/predicate checks,
-- sorted row locks, a transactionally safe dedup reservation and a scoped outbox dispatcher.
-- No API user receives direct access to these tables; schema validity is not permission proof.
