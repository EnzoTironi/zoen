import type { WorldFrame, SemanticClient, Id, Focus } from "./types";
declare const live: WorldFrame<"live">;
declare const evaluation: WorldFrame<"evaluation">;
declare const client: SemanticClient<"live">;
void live;
// @ts-expect-error An evaluation Frame is not a live authority basis.
const wronglyLive: WorldFrame<"live"> = evaluation;
void wronglyLive;
declare const evaluationCase: Id<"Case", "evaluation">;
// @ts-expect-error An evaluation Case cannot be answered by the live client.
client.answer({ caseId: evaluationCase, digest: evaluation.cut.head.release, answer: null, operationId: "op" });
declare const focus: Focus<"live">;
// @ts-expect-error Focus deliberately has no authority token.
const token = focus.token;
void token;
