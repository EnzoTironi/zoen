# Contract reference slices

These are **representative, deliberately incomplete implementation inputs**, not the complete public schema, runtime or production migrations. They make key boundaries concrete and support local consistency checks. Normative behavior is in the ADRs/references.

- [types.ts](types.ts) and [negative type tests](type-tests.ts): realm separation, Frames, claims, Cases, receipts, leases and interfaces.
- [Claim schema](claim.schema.json), [change schema](change.schema.json), [source binding schema](source-binding.schema.json), [mandate schema](mandate.schema.json): structural JSON Schema 2020-12 examples.
- [Authority SQL slice](authority-slice.sql): composite scope keys and durable local records, not a complete authority service.
- [Example index](../examples/index.json): evaluation/synthetic inputs, no real credentials or destinations.
- [Executable reference model](../examples/reconciliation_spec.py) and [tests](../verification/test_reference.py): selected deterministic laws, not real database/provider behavior.

Schemas cannot prove that an approver has current rights, that a host is safe from SSRF, that a referenced credential is valid, that a time interval is ordered, or that an artifact is trustworthy. These are runtime/kernel/adapter checks. A JSON document passing a schema does not authorize itself.

The reference schemas intentionally model a scalar decimal claim; the full kernel must support the released value types, links, structured claims and data projections described in the ontology contract. Reference integers are bounded by small fixtures; production domain versions/snapshot IDs use decimal strings or database bigint with exact serialization. TypeScript types do not establish runtime security. The SQL is not executed by this package's verifier.

The Python model's `retracted_at` field represents derived eligibility metadata at a retained history cut. A production retraction is a separate governed record/edge; this field is not permission to edit an immutable source claim in place. Decimal inputs in the local model are bounded in length and budget arithmetic sets an explicit sufficient precision.
