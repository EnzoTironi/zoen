/** Representative contract slice, NOT the complete implementation or a source of runtime authority. */
declare const brand: unique symbol;
export type Branded<T, Name> = T & { readonly [brand]: Name };
export type Realm = "live" | "evaluation";
export type Id<Kind extends string, R extends Realm> = Branded<string, { readonly kind: Kind; readonly realm: R }>;
export type Digest = Branded<string, "sha256-canonical-content">;
export type Decimal = Branded<string, "validated-decimal">;
export type Instant = Branded<string, "utc-instant">;
export type LocalDate = Branded<string, "calendar-date">;
export type Json = null | boolean | string | number | readonly Json[] | { readonly [key: string]: Json };
export interface WorldRef<R extends Realm> { readonly id: Id<"World", R>; readonly realm: R }
export interface Money { readonly amount: Decimal; readonly currency: string }
export interface Quantity { readonly amount: Decimal; readonly unit: string }
export interface ValidInterval { readonly from: Instant; readonly until: Instant | null }
export interface WorldHead<R extends Realm> {
  readonly world: WorldRef<R>; readonly cell: string; readonly epoch: number;
  readonly release: Digest; readonly generation: string; readonly securityRevision: number;
}
export interface WorldCut<R extends Realm> {
  readonly head: WorldHead<R>;
  readonly domains: Readonly<Record<string, string>>; // bigint decimal strings, not JS unsafe integers
  readonly datasets: readonly DatasetRef<R>[];
}
export interface DatasetRef<R extends Realm> {
  readonly world: WorldRef<R>; readonly tableUuid: string; readonly snapshotId: string;
  readonly metadataDigest: Digest; readonly metadataLocation: string; readonly pinId: string;
}
export interface SourceRecordRef<R extends Realm> {
  readonly world: WorldRef<R>; readonly binding: Id<"SourceBinding", R>;
  readonly namespace: string; readonly externalId: string; readonly revision: string | null;
}
export interface RightsBasis<R extends Realm> {
  readonly world: WorldRef<R>; readonly purpose: string; readonly audience: readonly Id<"Principal", R>[];
  readonly securityRevision: number; readonly sourceAclRefs: readonly string[];
  readonly licenseRefs: readonly string[]; readonly checkedAt: Instant; readonly validUntil: Instant;
}
export interface EvidenceRef<R extends Realm> {
  readonly id: Id<"Evidence", R>; readonly world: WorldRef<R>; readonly digest: Digest;
  readonly source: SourceRecordRef<R>; readonly acquiredAt: Instant; readonly rightsRef: string;
}
export interface Claim<R extends Realm> {
  readonly id: Id<"Claim", R>; readonly world: WorldRef<R>; readonly subject: Id<"Subject", R>;
  readonly predicate: string; readonly scope: Readonly<Record<string,string>>;
  readonly value: Json; readonly unit: string | null; readonly valid: ValidInterval;
  readonly evidence: readonly EvidenceRef<R>[]; readonly sourceFamily: string;
  readonly assertedBy: string; readonly knowledgeDomain: string; readonly knowledgeVersion: string;
  readonly retracts: readonly Id<"Claim", R>[];
}
export type Interpretation<R extends Realm> = {
  readonly world: WorldRef<R>; readonly cut: WorldCut<R>; readonly policyDigest: Digest;
  readonly selected: readonly Id<"Claim", R>[]; readonly rivals: readonly Id<"Claim", R>[];
  readonly status: "unknown" | "unresolved" | "selected" | "set-valued";
  readonly verification: "unverified" | "attested" | "externally-verified";
  readonly contested: boolean; readonly explanationRef: string;
};
export interface DependencyGuard {
  readonly kind: "domain" | "predicate" | "source-watermark" | "identity" | "clock" | "policy";
  readonly key: string; readonly expected: string;
}
export interface WorldFrame<R extends Realm> {
  readonly id: Id<"Frame", R>; readonly world: WorldRef<R>; readonly cut: WorldCut<R>;
  readonly perspective: "world-authorized" | "view-local" | "declassified";
  readonly rights: RightsBasis<R>; readonly payload: Json; readonly evidence: readonly EvidenceRef<R>[];
  readonly gaps: readonly string[]; readonly guards: readonly DependencyGuard[];
}
/** A bookmark only: deliberately contains no bearer token, grant, role or lease. */
export interface Focus<R extends Realm> {
  readonly world: WorldRef<R>; readonly subject: Id<"Subject", R> | null;
  readonly frame: Id<"Frame", R> | null; readonly lens: string; readonly historicalIntent: string | null;
}
export type CaseState = "proposed" | "awaiting-approval" | "approved" | "stale" | "rejected" | "expired" | "committed";
export interface ActionCase<R extends Realm> {
  readonly id: Id<"Case", R>; readonly world: WorldRef<R>; readonly action: string;
  readonly basis: WorldCut<R>; readonly intent: Json; readonly caseDigest: Digest;
  readonly consequencesDigest: Digest; readonly guards: readonly DependencyGuard[];
  readonly state: CaseState; readonly expiresAt: Instant;
}
export interface DecisionReceipt<R extends Realm> {
  readonly id: Id<"Receipt", R>; readonly world: WorldRef<R>; readonly caseId: Id<"Case", R>;
  readonly caseDigest: Digest; readonly commitId: string; readonly actor: Id<"Principal", R>;
  readonly touchedDomains: Readonly<Record<string,string>>; readonly effects: readonly Id<"Effect", R>[];
}
export interface EffectIntent<R extends Realm> {
  readonly id: Id<"Effect", R>; readonly world: WorldRef<R>; readonly receipt: Id<"Receipt", R>;
  readonly provider: string; readonly operation: string; readonly intentDigest: Digest;
  readonly idempotencyKey: string; readonly leaseRef: string; readonly deadline: Instant;
}
export type Settlement<R extends Realm> = {
  readonly effect: Id<"Effect", R>; readonly status: "accepted" | "rejected" | "partial" | "unknown";
  readonly providerState: string | null; readonly observedAt: Instant;
  readonly evidence: readonly EvidenceRef<R>[]; readonly supersedes: string | null;
};
export interface DefinitionChange<R extends Realm> {
  readonly id: Id<"Change", R>; readonly world: WorldRef<R>; readonly baseRelease: Digest;
  readonly candidateRelease: Digest; readonly risk: "presentation" | "meaning" | "rights" | "effects";
  readonly state: "draft" | "validated" | "evaluated" | "prepared" | "approved" | "activated" | "rejected";
  readonly currentPolicyApprovalRef: string | null;
}
export interface CapabilityLease<R extends Realm> {
  readonly id: Id<"Lease", R>; readonly world: WorldRef<R>; readonly principal: Id<"Principal", R>;
  readonly operations: readonly string[]; readonly purpose: string; readonly expiresAt: Instant;
  readonly budgetRef: string; readonly artifactDigest: Digest | null;
}
export interface Mandate<R extends Realm> {
  readonly id: Id<"Mandate", R>; readonly world: WorldRef<R>; readonly goalDefinition: string;
  readonly permittedActions: readonly string[]; readonly watches: readonly Id<"Watch", R>[];
  readonly budgetRef: string; readonly deadline: Instant;
  readonly outcome: "pending" | "achieved" | "failed" | "unknown" | "stopped";
}
export type SemanticError =
  | { readonly code: "Denied"; readonly correlationId: string }
  | { readonly code: "Stale"; readonly newCaseRequired: true }
  | { readonly code: "Conflict"; readonly intentMismatch: true }
  | { readonly code: "IncompleteBasis"; readonly authorizedGaps: readonly string[] }
  | { readonly code: "UnsupportedPlan"; readonly supportedProfile: string }
  | { readonly code: "UnknownExternalOutcome"; readonly effectRef: string };
export interface SemanticClient<R extends Realm> {
  inspect(input: { readonly operation: string; readonly intent: Json; readonly purpose: string }): Promise<WorldFrame<R>>;
  propose(input: { readonly operation: string; readonly intent: Json; readonly basis: WorldCut<R> }): Promise<ActionCase<R>>;
  answer(input: { readonly caseId: Id<"Case", R>; readonly digest: Digest; readonly answer: Json; readonly operationId: string }): Promise<DecisionReceipt<R> | SemanticError>;
}
// The actual runtime validates world/realm/epoch/rights; TypeScript types are not a security boundary.
