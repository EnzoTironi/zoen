# ADR 060: Evidence levels and honest product claims

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

A detailed architecture can sound like a shipped platform even when no application has run.

## Decision

Separate DesignOnly, LocalReferencePassed, ComponentPassed, SandboxJourneyPassed, ProductionAdmitted and OperatingMeasured evidence.

## Alternatives considered

Fake parity claims, invented multi-agent validation and benchmark targets reported as results are forbidden.

## Consequences

Every commercial/performance/security statement needs evidence and owner; ambition remains broad but testable.

## Required proof

The handoff, matrix and verification report never mark a design-only capability as production-ready.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/ambition-audit.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
