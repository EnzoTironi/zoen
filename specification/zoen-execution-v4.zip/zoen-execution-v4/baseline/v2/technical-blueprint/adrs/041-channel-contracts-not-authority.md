# ADR 041: Channels transport relationships, not authority

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

WhatsApp offers a simple entry but its policies and delivery guarantees differ from domain permission.

## Decision

Durable signed ingress, stable dedup, channel-bound consent/window/template rules and fresh disclosure; web handles stronger inspection/confirmation.

## Alternatives considered

Phone possession as universal authority and blind exactly-once delivery claims are unsafe.

## Consequences

Provider policy changes can disable routes; the relationship must survive channel migration.

## Required proof

Duplicate webhook and lost send response remain idempotent/Unknown; prohibited or stale-audience messages are not sent.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/messaging-channels.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
