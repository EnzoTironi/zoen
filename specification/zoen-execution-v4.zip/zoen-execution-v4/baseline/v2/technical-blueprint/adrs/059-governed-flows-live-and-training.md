# ADR 059: Governed data flows, live capture and training artifacts

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Dense streams and learned models require different execution but must preserve source/rights lineage.

## Decision

Released DAGs and quality gates publish exact datasets; live values require capture for action; trained models are evaluated isolated artifacts.

## Alternatives considered

Every tick as chat event and automatic training on customer corrections are rejected.

## Consequences

Distributed/GPU engines need new adapter evidence; unknown quality may block publication.

## Required proof

CDC snapshot gaps, schema drift, failed partitions and forbidden training rights cannot be hidden by a successful job status.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/data-flows-and-live-data.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
