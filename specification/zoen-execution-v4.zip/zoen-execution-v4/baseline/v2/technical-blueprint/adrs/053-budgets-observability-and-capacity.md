# ADR 053: Budgets, observability and measured capacity

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Affordable personal use and institutional reliability cannot be inferred from a diagram.

## Decision

Track source/ACL freshness, Unknown effects, conflict effort, budgets and workload-class SLOs; capacity evidence precedes claims.

## Alternatives considered

Tokens-only cost and unqualified linear-scale promises ignore real bottlenecks.

## Consequences

Targets are provisional; overload behavior may defer optional work or reject unsupported loads.

## Required proof

Hot tenant cannot starve others; scan/agent/message budgets stop deterministically and remain auditable.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/capacity-economics-and-slos.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
