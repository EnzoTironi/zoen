# ADR 057: Traceable greenfield design and guarded cutover

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Existing code/data can be valuable but should not predetermine the new architecture.

## Decision

Archive baseline, map each ADR, inventory actual data/receipts/effects, reuse by invariant, shadow read-only and cut over one writer.

## Alternatives considered

Destructive reset inferred from a sparse repo and dual effect dispatch are forbidden.

## Consequences

Migration cost depends on real data not yet inventoried; architecture artifacts are not a deployed migration.

## Required proof

Outstanding provider operation IDs survive cutover without duplicate execution or lost accountability.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/migration-and-adoption.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
