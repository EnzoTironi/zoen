# ADR 033: Four runtime change lanes

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Users and agents need to alter business behavior without making every change a software deployment.

## Decision

Separate instance Actions, released DefinitionChanges, isolated executable artifacts and privileged kernel deployments. Current authority controls every lane.

## Alternatives considered

Arbitrary in-process scripts collapse safety; treating every edit as a full release creates needless ceremony.

## Consequences

A closed grammar has limits; new computation can use a sandbox, but new privilege cannot be data.

## Required proof

A rule changes in runtime with no app deploy; a proposed rule cannot approve its own permission escalation.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/runtime-variation-and-releases.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
