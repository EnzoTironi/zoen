# ADR 051: Domain packs instead of customer-specific forks

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Three audiences and many industries require variation without three kernels or per-client codebases.

## Decision

Signed versioned packs define domain semantics, skills, views, mappings and optional artifacts with dependencies and local overlays.

## Alternatives considered

A universal flat schema obscures meaning; a fork per profession destroys maintainability.

## Consequences

Authoring and upgrade conflict UX matter; marketplace commercial operations remain separate work.

## Required proof

Pack upgrade cannot overwrite local claims or grant new network/action permissions silently.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/domain-packs-and-marketplace.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
