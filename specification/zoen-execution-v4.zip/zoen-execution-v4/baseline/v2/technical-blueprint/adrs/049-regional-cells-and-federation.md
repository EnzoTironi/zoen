# ADR 049: Regional authority cells and explicit federation

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Consumer economics, institutional residency and scale require different physical deployment.

## Decision

Use one fenced authority cell per World epoch; hosted AWS profile, dedicated cells and independent-cut federation; offline work uses separate leased scope.

## Alternatives considered

One global database forever and active-active writes without conflict semantics are rejected.

## Consequences

Global ACID is not promised; partial cross-World outcomes and cell migration complexity are explicit.

## Required proof

Partitioned move cannot create two writers; destination reconciles escaped effects before dispatch.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/deployment-cells-and-federation.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
