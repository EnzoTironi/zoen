# ADR 045: Retrieval projections and models as proposers

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Text search and generative confidence do not establish factual truth or mutation rights.

## Decision

Use authorized FTS/vector projections, model routing by rights/budget and typed evidence-bound outputs; agents call only released semantic capabilities.

## Alternatives considered

A RAG answer directly updating canonical facts or executing arbitrary tool names is rejected.

## Consequences

Advanced approximate retrieval is admitted only with demonstrated security/quality; model output remains fallible.

## Required proof

Prompt injection cannot add a capability; unauthorized evidence never reaches a model or influences visible counts.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/models-retrieval-and-agents.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
