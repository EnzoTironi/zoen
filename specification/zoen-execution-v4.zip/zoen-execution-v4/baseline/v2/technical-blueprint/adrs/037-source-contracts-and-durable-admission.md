# ADR 037: Source contracts and durable ingestion

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Connecting a system does not mean all its content, permissions or update semantics are known.

## Decision

SourceBinding owns scope, auth lease, schema mapping, ACL/freshness, cursor/dedup and retention contract. Capture precedes authoritative admission.

## Alternatives considered

Connector JSON directly overwriting canonical objects loses provenance and revocation handling.

## Consequences

Providers without snapshots or stable IDs receive honest weaker coverage/replay guarantees.

## Required proof

Crash/replay cannot advance a cursor past durable data; source disappearance does not become zero or deletion.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/connectors-and-ingestion.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
