# ADR 046: One semantic manifest for all interfaces

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Different channel/API implementations can drift into different meanings and approval behavior.

## Decision

Generate REST/OpenAPI, CLI, SDK, MCP and UI operation contracts from one released SurfaceManifest; every call reauthorizes.

## Alternatives considered

Private CRUD/SQL escape hatches create a second authority path.

## Consequences

Static SDKs need regeneration; dynamic discovery handles new definitions but not arbitrary stale binaries.

## Required proof

Same semantic invocation returns matching basis/consequence digests across supported surfaces.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/interfaces-sdk-and-mcp.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
