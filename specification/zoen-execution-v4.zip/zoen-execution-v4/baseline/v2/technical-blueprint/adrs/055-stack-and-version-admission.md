# ADR 055: Concrete stack families with evidence-based pins

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Current package publication is not integrated compatibility; inventing a lockfile would be misleading.

## Decision

Select stack families and hosted profile now; admit exact patches, native hashes, API versions and licenses through S0 execution lock.

## Alternatives considered

Latest-at-runtime updates and unverified copied version pins are forbidden.

## Consequences

Some install decisions remain evidence gates; changing a selected family needs an ADR amendment.

## Required proof

A clean environment reproduces build/type/runtime/adapter tests from the admitted lock and signed image.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/technology-stack.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
