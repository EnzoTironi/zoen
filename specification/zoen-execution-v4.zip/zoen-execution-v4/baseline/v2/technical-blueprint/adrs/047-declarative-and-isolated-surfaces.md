# ADR 047: Declarative surfaces with isolated executable apps

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Chat cannot adequately present dense analysis, but visual deepening must not lose context or rights.

## Decision

Use authority-free Focus, fresh Frames and released views/charts; advanced apps run isolated with narrow host bridge and fallback.

## Alternatives considered

Screens embedding credentials or independent data/permission state fragment the product.

## Consequences

Accessibility, chart meaning and client compatibility need explicit tests, not only a component library.

## Required proof

A stolen Focus grants nothing; chart missing values/time basis and approval consequences remain honest.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/apps-charts-and-surfaces.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
