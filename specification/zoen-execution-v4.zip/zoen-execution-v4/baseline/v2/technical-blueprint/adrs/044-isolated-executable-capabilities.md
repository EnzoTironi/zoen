# ADR 044: Signed isolated executable capabilities

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Runtime variation eventually requires computation beyond the closed semantic grammar.

## Decision

Run signed OCI connector/analysis/app artifacts outside authority with scoped leases, external egress/resource enforcement and evaluation admission.

## Alternatives considered

In-process plugins or arbitrary shell tools with ambient credentials break the authority boundary.

## Consequences

Sandbox operations are a real platform responsibility; signatures do not guarantee benign behavior.

## Required proof

Hostile code cannot reach metadata, database credentials, unauthorized source paths or unlimited child execution.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/programmable-compute-and-skills.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
