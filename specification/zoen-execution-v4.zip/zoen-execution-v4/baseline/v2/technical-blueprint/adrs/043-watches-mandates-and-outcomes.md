# ADR 043: Compose Watches, Mandates and observable outcomes

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Users delegate ongoing concerns, not only isolated tool calls. Attention and autonomy need boundaries.

## Decision

A Mandate composes bounded Watches and Actions with goal observation, deadline, budget, escalation and stop conditions; Eve controls delivery attention.

## Alternatives considered

An unconstrained agent loop has no completion or cost semantics; raw event alerts create noise.

## Consequences

Not every goal is observable; unknown goal status remains explicit.

## Required proof

A child agent cannot multiply budget; completed steps cannot automatically mark an unobserved goal successful.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/watches-mandates-and-outcomes.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
