# Architecture decision records — v2

**Status: proposed execution baseline, 4 September 2026.** The user may adopt this package as the implementation constitution; it does not modify a repository. Original ADRs 001–029 are archived and mapped in [supersession](../supersession.md). New records continue numbering.

- [030 — Three owners and a stable semantic kernel](030-three-owners-stable-kernel.md).
- [031 — Attributed claims and revisable interpretations](031-claims-interpretations-and-correction.md).
- [032 — World-scoped identity with reversible resolution](032-world-scoped-reversible-identity.md).
- [033 — Four runtime change lanes](033-four-runtime-change-lanes.md).
- [034 — Current rights and derived-data restrictions](034-current-rights-derived-lineage.md).
- [035 — Control head plus domain-scoped atomic commits](035-control-head-and-domain-commits.md).
- [036 — Committed cuts and complete dependency guards](036-temporal-cuts-and-predicate-guards.md).
- [037 — Source contracts and durable ingestion](037-source-contracts-and-durable-admission.md).
- [038 — Standard semantic and table interchange](038-standard-semantic-and-table-interchange.md).
- [039 — Staged datasets and exact authoritative publication](039-staged-dataset-publication.md).
- [040 — Eve-owned journal and bounded turn machine](040-eve-owned-turn-machine.md).
- [041 — Channels transport relationships, not authority](041-channel-contracts-not-authority.md).
- [042 — One decision protocol and separate external settlement](042-actions-effects-and-settlement.md).
- [043 — Compose Watches, Mandates and observable outcomes](043-watches-mandates-and-outcomes.md).
- [044 — Signed isolated executable capabilities](044-isolated-executable-capabilities.md).
- [045 — Retrieval projections and models as proposers](045-retrieval-and-models-as-proposers.md).
- [046 — One semantic manifest for all interfaces](046-one-surface-manifest.md).
- [047 — Declarative surfaces with isolated executable apps](047-declarative-and-isolated-surfaces.md).
- [048 — Proof, preparation and atomic activation](048-proof-preparation-activation.md).
- [049 — Regional authority cells and explicit federation](049-regional-cells-and-federation.md).
- [050 — Retention and deletion across derived state](050-retention-erasure-and-recovery.md).
- [051 — Domain packs instead of customer-specific forks](051-domain-packs-not-customer-forks.md).
- [052 — Explicit authority SQL and rebuildable projections](052-explicit-sql-and-rebuildable-projections.md).
- [053 — Budgets, observability and measured capacity](053-budgets-observability-and-capacity.md).
- [054 — Law tests plus real boundary journeys](054-laws-components-and-real-journeys.md).
- [055 — Concrete stack families with evidence-based pins](055-stack-and-version-admission.md).
- [056 — Complete finance lifecycle without invented entitlements](056-finance-lifecycle-and-licenses.md).
- [057 — Traceable greenfield design and guarded cutover](057-traceable-greenfield-migration.md).
- [058 — Scoped stewardship and proportional governance](058-stewardship-and-change-governance.md).
- [059 — Governed data flows, live capture and training artifacts](059-governed-flows-live-and-training.md).
- [060 — Evidence levels and honest product claims](060-design-proof-and-production-claims.md).
