# ADR 038: Standard semantic and table interchange

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Interoperability and dense data should not depend on a proprietary universal graph or manifest format.

## Decision

Use stable semantic IDs and JSON-LD/PROV-O/SHACL profiles for exchange; Iceberg v2/Parquet for dense snapshots, not sparse transactional authority.

## Alternatives considered

Mandating RDF or graph storage for every operation adds machinery; proprietary lake metadata adds integration burden.

## Consequences

Standards profiles require conformance tests and explicit non-equivalent mappings.

## Required proof

Export/import preserves identifiers/provenance; an Iceberg snapshot is read by exact admitted identity.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/ontology-and-standards.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
