# ADR 030: Three owners and a stable semantic kernel

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

The original ownership distinction remains valuable, but a product name must not dictate a framework or topology.

## Decision

Keep Door, Eve and Ontology. A bounded typed kernel interprets released definitions; infrastructure adapters do not own business truth.

## Alternatives considered

A chatbot-centric model hides meaning in prompts; a service per concept fragments atomicity.

## Consequences

The kernel must remain small and explicit; adding a privileged operator requires deployment and review.

## Required proof

Reject imports from Eve into authority repositories and prove the same operation through every surface.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/system-shape.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
