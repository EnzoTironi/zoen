# ADR 058: Scoped stewardship and proportional governance

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Users and agents need authorship, while sensitive rules and rights changes need accountable review.

## Decision

Separate proposer, steward, approver and operator scopes. Resolve factual Cases locally; reuse rules only via explicit risk-classified change with current-policy approval.

## Alternatives considered

One confirmation approving every future use and agents self-signing authority changes are rejected.

## Consequences

Consumers receive simple confirmations; enterprise roles/quorums can be richer using the same protocol.

## Required proof

A local correction does not become a global rule; rejected/unknown answers and approver revocation are preserved.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/runtime-variation-and-releases.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
