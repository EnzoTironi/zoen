# ADR 036: Committed cuts and complete dependency guards

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Wall-clock timestamps and row-only read sets fail under commit races, backdated facts and phantom inserts.

## Decision

Use domain-version WorldCuts, explicit valid/source/acquisition time and predicate/clock/source guards on approved Cases.

## Alternatives considered

Timestamp-only historical replay and silently refreshing an approved Case change its meaning.

## Consequences

Historical date lookup may resolve to a sealed-cut interval; conservative fences can over-invalidate.

## Required proof

An inserted matching invoice makes an approved aggregate Case stale even when old rows are unchanged.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/authority-concurrency-and-cuts.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
