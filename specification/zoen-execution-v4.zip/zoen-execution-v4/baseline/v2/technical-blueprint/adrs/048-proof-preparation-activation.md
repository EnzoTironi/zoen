# ADR 048: Proof, preparation and atomic activation

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Definitions can be correct in isolation yet unsafe against a live World generation.

## Decision

Compile immutable release graph, evaluate isolated realm, prepare/catch up generation, approve under current policy and switch head atomically.

## Alternatives considered

Mutating active releases or partially migrating reads/writes breaks reproducibility.

## Consequences

Busy Worlds may require a bounded write fence; rollback is a new prepared transition.

## Required proof

Concurrent cut change blocks stale preparation; no mixed release/generation becomes active.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/release-engine-and-compiler.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
