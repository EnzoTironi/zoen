# ADR 039: Staged datasets and exact authoritative publication

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

PostgreSQL, object storage and a table catalog cannot be assumed one atomic transaction.

## Decision

Stage immutable snapshots, verify/pin before publication, atomically admit exact references in PG, then reconcile catalog housekeeping.

## Alternatives considered

Reading catalog latest or relying on a fictional distributed commit creates torn history.

## Consequences

Orphans and pin/GC races require explicit operators and real component tests.

## Required proof

Kill between snapshot creation and publication; neither dangling authority nor unprotected published objects may remain.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/data-events-parquet.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
