# ADR 052: Explicit authority SQL and rebuildable projections

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

A semantic kernel still needs concrete physical indexing, constraints and operational roles.

## Decision

Use explicit pg SQL, typed JSONB plus indexed scalar/projection fields, append histories and narrowly owned roles; projections are rebuildable.

## Alternatives considered

ORM-hidden writes and storing every dense record as an EAV fact are rejected.

## Consequences

Schema/index tuning remains workload-dependent; example SQL is not the complete migration suite.

## Required proof

Cross-World references and duplicate operations fail constraints; projection rebuild cannot mutate authority.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/database-access.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
