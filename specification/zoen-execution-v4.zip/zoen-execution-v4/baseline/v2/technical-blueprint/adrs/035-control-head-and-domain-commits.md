# ADR 035: Control head plus domain-scoped atomic commits

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

A World-wide exclusive data-head update unnecessarily serializes unrelated business mutations.

## Decision

Keep an infrequent control head; ordinary serializable commits lock it FOR SHARE and advance relevant domain/fence versions in one transaction.

## Alternatives considered

One global counter bottlenecks; distributed eventual writes break local decision atomicity.

## Consequences

Hot aggregates still serialize; partitioning and multi-domain guards remain explicit.

## Required proof

Parallel independent domains succeed; a release activation cannot cross an in-flight ordinary commit.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/authority-concurrency-and-cuts.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
