# ADR 042: One decision protocol and separate external settlement

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Local approval/commit cannot prove a bank, calendar or broker completed an operation.

## Decision

ActionCase/DecisionReceipt commits locally; EffectIntents and outbox are atomic; Restate attempts narrow effects, PG stores observed Settlement.

## Alternatives considered

Generic retries can duplicate unsafe provider writes; a task completion flag is not reality.

## Consequences

Some unknown effects stop for reconciliation or human review rather than automatic retry.

## Required proof

Provider accepts then times out: report Unknown, reconcile stable ID and never invent success/failure.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/actions-effects-and-settlement.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
