# ADR 031: Attributed claims and revisable interpretations

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Different sources may disagree, and users may also be wrong. A single mutable fact loses accountability.

## Decision

Preserve evidence, attributed claims and versioned interpretations. Resolve only comparable subject/predicate/scope/time/unit values; corrections remain reversible.

## Alternatives considered

Global source ranking, last-write-wins and unconditional human override erase context or invent certainty.

## Consequences

More provenance and explicit uncertainty; question burden must be measured and controlled.

## Required proof

Copied-source majority cannot win; a wrong user correction can be reversed without destroying prior evidence.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/truth-reconciliation-and-learning.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
