# ADR 056: Complete finance lifecycle without invented entitlements

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Institutional rigor requires instrument/time/market/order/fill/settlement distinctions and licensed sources.

## Decision

Define full finance pack lifecycle, source rights, risk controls and connector certification before live execution.

## Alternatives considered

Treating a generic payment tool as an OMS or a quote API as licensed institutional coverage is rejected.

## Consequences

No HFT, financial licensing or Bloomberg data/network parity is claimed by design.

## Required proof

Partial fill, bust, cancel race, stale quote and settlement failure remain distinct and evidence-bound.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/finance-domain.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
