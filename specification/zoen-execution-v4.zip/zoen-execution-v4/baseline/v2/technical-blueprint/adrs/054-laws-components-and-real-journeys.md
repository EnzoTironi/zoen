# ADR 054: Law tests plus real boundary journeys

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Pure invariants benefit from fast tests; mocks cannot prove real transactions, providers or isolation.

## Decision

Use property/law tests, actual components and fault-injected canonical journeys with signed evidence levels.

## Alternatives considered

Blanket no-unit-tests policy and fake integration success are both rejected.

## Consequences

Production proof is slower and needs real accounts/sandboxes; missing evidence disables the relevant capability.

## Required proof

Kill/replay suite and permission negatives pass against admitted dependency versions, not only reference models.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/testing-and-ci.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
