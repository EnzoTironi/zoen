# ADR 040: Eve-owned journal and bounded turn machine

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

The original mandatory Eve/Nitro/Workflow dependency binds product identity to an execution stack.

## Decision

Own one minimal durable journal/state machine in PG; AI SDK adapts models; fenced workers handle retries and provisional streams.

## Alternatives considered

Framework history plus a second replay journal creates competing owners; raw chat in authority mixes responsibilities.

## Consequences

Zoen accepts the engineering burden of crash recovery and acknowledges possible duplicate inference cost.

## Required proof

Kill around model completion/tool dispatch; one settled response, no duplicate semantic effect, explicit stream interruption.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/release-policy-eve.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
