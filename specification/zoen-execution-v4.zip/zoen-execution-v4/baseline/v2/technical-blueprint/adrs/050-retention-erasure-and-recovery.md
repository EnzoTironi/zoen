# ADR 050: Retention and deletion across derived state

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Permanent immutable storage conflicts with lawful deletion, licenses and source rights.

## Decision

Apply lifecycle contracts to raw and derived data, pins, indexes, staged generations and restores; preserve only lawful minimal receipts.

## Alternatives considered

Soft delete in one table or a claim that hashes never identify people is insufficient.

## Consequences

Historical content may become unavailable; backup handling requires a tested policy.

## Required proof

Deleted data and revoked access do not reappear after restoring an older backup.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/lifecycle-privacy-and-retention.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
