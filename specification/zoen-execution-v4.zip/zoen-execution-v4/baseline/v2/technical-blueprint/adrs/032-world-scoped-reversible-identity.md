# ADR 032: World-scoped identity with reversible resolution

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

Provider IDs and natural names do not establish globally identical real entities.

## Decision

Keep source record identities separate from World subjects; temporal evidence-bound merge/split and explicit cross-World links.

## Alternatives considered

Global person/company IDs inferred by an LLM can leak data and conflate entities.

## Consequences

Identity corrections can invalidate many derived results; recomputation and review need budgets.

## Required proof

Two same-name customers remain distinct without evidence; splitting a mistaken merge preserves source history.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/identity-and-time.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
