# ADR 034: Current rights and derived-data restrictions

Status: **Proposed v2 baseline**. Date: **2026-09-04**.

## Context

A source ACL, World role or chat identity alone does not authorize all uses of a value.

## Decision

Intersect current World grants, purpose, source ACL/license, residence, destination and assurance. Propagate restrictions through lineage; exact disclosure before output.

## Alternatives considered

Post-filtering leaked aggregates and policy stored only in a vector index are insufficient.

## Consequences

Some queries are rejected or use slower authorized scans; source ACL synchronization has explicit staleness.

## Required proof

A hidden rival cannot be inferred from counts/explanations; revocation during generation suppresses disclosure.

The corresponding capability remains `DesignOnly` until this gate passes against the admitted implementation. A local reference example is not this production proof.

## Reopen condition

Reopen when real journey, security, compatibility or workload evidence falsifies the selected contract or shows a simpler implementation with equivalent invariants. A new dependency alone is not a reason to weaken the invariant. Record changed behavior, migration, tests and affected consumers before activation.

## Reference

[Detailed contract](../reference/rights-and-access-control.md). [Execution sequence](../implementation-sequence.md). [Source ledger](../sources.md).
