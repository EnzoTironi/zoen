# Grounding and design constraints

## User mandate

Redesign the OS from first principles, informed by Palantir's operational ontology, Bloomberg's data/decision discipline, Glean's connected organizational context, and Poke's familiar conversational experience. Serve consumers and families, individual professionals and small businesses, and medium through Fortune 500 organizations. Treat divergent sources as normal. Improve the world through authorized user answers. Let humans and agents change business variation at runtime, including integrations, skills, applications, and SDK-exposed capabilities.

The public OS repository and supplied design are learning material, not implementation constraints. The public `zoen` repository is a possible destination, not evidence of delivered code. Repository review was limited to public structure/README and architecture documentation; there was no full source audit, build, or production assessment.

## Assumptions adopted rather than deferred to another interview

- WhatsApp is the priority conversational channel; web is the universal rich and secure continuation surface. Telegram and email use the same interaction contract.
- Begin with Brazil/Portuguese, but do not encode language, currency, jurisdiction, or time zone into the kernel.
- Start with adults. Delegated caregiver access is not presumed consent or legal guardianship. Child-specific products require a separate policy and legal review.
- Business/clinical records and money movement are consequential. Clinical decision support and regulated execution are gated domain capabilities, not automatic benefits of a connector.
- “All data” means an inventoried, permissioned, technically reachable corpus with coverage reporting. It does not mean collecting everything indiscriminately, bypassing source rights, or copying data that must remain in place.
- A company can span multiple Worlds when legal, regional, operational or confidentiality boundaries require it. A World is not synonymous with a company, database, or UI workspace.
- The architecture is greenfield, but real user data is never disposable merely because the product is early.

## Retained identity

Door proves presence. Eve owns relationship. Ontology owns governed meaning, knowledge and action. No Redis in the initial design; no mandatory graph database, Kafka cluster, bespoke workflow platform or provider-specific schema as the public model. Restate remains limited to external effect execution. One Zoen-owned TypeScript codebase; externally supplied runtimes stay behind contracts.

## Explicitly reopened inherited choices

The user asked for a better complete architecture, not mechanically preserving implementation choices. Successor ADRs therefore replace the global data-head bottleneck, custom dense-table format, mandatory Eve/Nitro/Workflow runtime, launch ban on all skills/connections, and absolute ban on pure invariant tests. These changes do not remove provenance, permission, durable admission, honest settlement or real-journey production gates.

## Design method

This is a single integrated architectural analysis, not a report from independent agents or a measured performance tournament. Alternatives are compared by semantic integrity, implementation surface, runtime adaptability, operational isolation and falsifiable proof burden. Scores are not invented. Performance and usability targets are proposed acceptance criteria, not benchmarks already achieved.
